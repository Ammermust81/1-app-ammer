/*    */ package crosswordexpress;public class Node {
/*    */   public static final int DIR_ACROSS = 0;
/*    */   public static final int DIR_DOWN = 1;
/*    */   public static final int DIR_BACK = 2;
/*    */   public static final int DIR_UP = 3;
/*    */   int id;
/*    */   int direction;
/*    */   int x;
/*    */   int y;
/*    */   int length;
/*    */   int revert;
/*    */   int failCount;
/*    */   int group;
/*    */   int count;
/*    */   int status;
/*    */   int select;
/*    */   int wordIndex;
/*    */   int first;
/*    */   int last;
/*    */   int start;
/*    */   int source;
/* 22 */   int[] devWord = new int[50]; int kendokuValue; int kendokuOp; int scoreW; int scoreL; int wNum; int iClue; int mode; int startCell; int nlCt; int nlCl; int nlCb; int nlCr; int nlTop; int nlBot; boolean pending; boolean preset; boolean solved; String word; String clue; String template;
/* 23 */   int[] devTemplate = new int[50];
/* 24 */   Point[] cellLoc = new Point[50];
/*    */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */