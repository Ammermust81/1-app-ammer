/*     */ package crosswordexpress;
/*     */ import java.awt.Point;
/*     */ import java.awt.datatransfer.StringSelection;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileWriter;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ 
/*     */ public class NodeList extends JPanel {
/*  20 */   static final int[] CELL_MODE = new int[] { 16, 15, 15, 20, 24, 28, 10, 5, 6, 12, 3, 9, 47, 79, 111, 0 };
/*     */   
/*     */   static final int maxNodes = 800;
/*     */   
/*     */   static final int BLOCK_RIGHT = 1;
/*     */   
/*     */   static final int BLOCK_BOTTOM = 2;
/*     */   
/*     */   static final int BLOCK_LEFT = 4;
/*     */   
/*     */   static final int BLOCK_TOP = 8;
/*     */   
/*     */   static final int HAS_LETTER = 16;
/*     */   
/*     */   static final int MODE_RTOL = 32;
/*     */   
/*     */   static final int MODE_BTOT = 64;
/*     */   
/*  38 */   static Node[] nodeList = new Node[800];
/*  39 */   static Node[] nodeListCopy = new Node[800];
/*     */   
/*     */   static int nodeListLength;
/*     */   
/*     */   static final int ALPHABETIC = 0;
/*     */   
/*     */   static final int STANDARD = 1;
/*     */   static final int GRIDORDER = 2;
/*     */   static final int ALPHASIZE = 3;
/*     */   static final int VSTANDARD = 4;
/*  49 */   static String exportText = "<div>Under normal circumstances, the Print function will provide all of the layout flexibility you will need when printing your puzzles. Inevitably of course special cases will arise where you need to intervene in the printing of either the words or the clues to achieve some special effect. To meet this need, a text export feature offers the following choices:-<br/><br/><ul><li/><b>Export Words.</b> Each line of text has the format <b>1. WORD</b><p/><li/><b>Export Clues.</b> Each line of text has the format <b>1. Clue</b><p/><li/><b>Export Words and Clues.</b> Each line of text has the format <b>1. WORD : Clue</b><p/><li/><b>Export Puzzle Grid.</b> The puzzle grid is exported as a simple square or rectangular array of letters.</ul>In addition, you have the choice of exporting the text to a text file located anywhere on your computer's hard drive, or to the System Clipboard from where you can Paste into any Word Processor or Desk Top Publishing application.</div></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void buildNodeList() {
/*     */     int j;
/*  67 */     for (j = 0; j < Grid.ySz; j++) {
/*  68 */       for (int i = 0; i < Grid.xSz; i++) {
/*  69 */         Grid.vert[i][j] = -1; Grid.horz[i][j] = -1;
/*     */       } 
/*     */     } 
/*  72 */     for (j = 0; j < Grid.ySz; j++) {
/*  73 */       for (int i = 0; i < Grid.xSz; i++) {
/*  74 */         Grid.control[i][j] = 0;
/*  75 */         int sig = cellSignature(i, j);
/*  76 */         if ((sig & 0x10) == 16) {
/*  77 */           if ((sig & 0x5) != 5)
/*  78 */             Grid.control[i][j] = (byte)(Grid.control[i][j] + 1); 
/*  79 */           if ((sig & 0xA) != 10)
/*  80 */             Grid.control[i][j] = (byte)(Grid.control[i][j] + 1); 
/*     */         } 
/*     */       } 
/*     */     }  int item;
/*  84 */     for (item = 0; item < 800; item++)
/*  85 */       nodeList[item] = null;  int id;
/*  86 */     for (item = 0, id = 1, j = 0; j < Grid.ySz; j++) {
/*  87 */       for (int i = 0; i < Grid.xSz; i++) {
/*  88 */         boolean found = false;
/*  89 */         int sig = cellSignature(i, j);
/*  90 */         if ((sig & 0x15) == 20) {
/*  91 */           found = true;
/*  92 */           buildNode(item, id, 0, i, j);
/*  93 */           item++;
/*     */         } 
/*  95 */         if ((sig & 0x1A) == 24) {
/*  96 */           found = true;
/*  97 */           buildNode(item, id, 1, i, j);
/*  98 */           item++;
/*     */         } 
/* 100 */         if (found)
/* 101 */           id++; 
/*     */       } 
/*     */     } 
/* 104 */     Grid.dirCur = Grid.dirNew = (nodeList[0]).direction;
/* 105 */     Grid.xCur = Grid.xNew = (nodeList[0]).x;
/* 106 */     Grid.yCur = Grid.yNew = (nodeList[0]).y;
/* 107 */     Grid.nCur = 0;
/* 108 */     nodeListLength = item;
/*     */   }
/*     */ 
/*     */   
/*     */   static void buildNode(int item, int id, int direction, int x, int y) {
/* 113 */     int newX = x, newY = y, newDir = direction;
/* 114 */     Point[] cellLoc = new Point[50];
/*     */     int count;
/* 116 */     for (count = 1;; count++) {
/* 117 */       Grid.control[newX][newY] = (byte)(Grid.control[newX][newY] - 1);
/* 118 */       cellLoc[count - 1] = new Point();
/* 119 */       (cellLoc[count - 1]).x = newX;
/* 120 */       (cellLoc[count - 1]).y = newY;
/*     */ 
/*     */       
/* 123 */       if (newDir == 0 || newDir == 2) {
/* 124 */         Grid.horz[newX][newY] = item;
/*     */       } else {
/* 126 */         Grid.vert[newX][newY] = item;
/*     */       } 
/* 128 */       int result = stepToNextCell(newX, newY, newDir);
/* 129 */       if ((result & 0x40000) == 262144) {
/* 130 */         if ((result & 0x100000) != 0)
/* 131 */           for (int i = 0, j = count - 1; i < j; i++, j--) {
/* 132 */             Point temp = cellLoc[i];
/* 133 */             cellLoc[i] = cellLoc[j];
/* 134 */             cellLoc[j] = temp;
/*     */           }  
/*     */         break;
/*     */       } 
/* 138 */       if ((result & 0x80000) == 524288)
/* 139 */         System.out.println("Error"); 
/* 140 */       newX = result & 0xFF;
/* 141 */       newY = (result & 0xFF00) / 256;
/* 142 */       newDir = (result & 0x30000) / 65536;
/*     */     } 
/*     */     
/* 145 */     nodeList[item] = new Node();
/* 146 */     (nodeList[item]).direction = direction;
/* 147 */     (nodeList[item]).id = id;
/* 148 */     (nodeList[item]).x = x;
/* 149 */     (nodeList[item]).y = y;
/* 150 */     (nodeList[item]).length = count;
/* 151 */     (nodeList[item]).word = " ";
/* 152 */     (nodeList[item]).clue = " ";
/* 153 */     (nodeList[item]).failCount = 0;
/* 154 */     (nodeList[item]).mode = 0;
/* 155 */     for (count = 0; count < (nodeList[item]).length; count++) {
/* 156 */       (nodeList[item]).cellLoc[count] = new Point();
/* 157 */       (nodeList[item]).cellLoc[count] = cellLoc[count];
/*     */     } 
/* 159 */     buildTemplate(item);
/* 160 */     (nodeList[item]).word = (nodeList[item]).template;
/*     */   }
/*     */   
/*     */   static void buildTemplate(int item) {
/* 164 */     char[] c = new char[50];
/*     */     
/* 166 */     if ((nodeList[item]).mode == 0) {
/* 167 */       for (int i = 0; i < (nodeList[item]).length; i++) {
/* 168 */         char ch = (char)Grid.letter[((nodeList[item]).cellLoc[i]).x][((nodeList[item]).cellLoc[i]).y];
/*     */         
/* 170 */         c[i] = (ch == '\000') ? ' ' : ch;
/*     */       } 
/*     */     } else {
/* 173 */       for (int i = (nodeList[item]).length - 1; i >= 0; i--) {
/* 174 */         char ch = (char)Grid.letter[((nodeList[item]).cellLoc[i]).x][((nodeList[item]).cellLoc[i]).y];
/*     */         
/* 176 */         c[(nodeList[item]).length - 1 - i] = (ch == '\000') ? ' ' : ch;
/*     */       } 
/*     */     } 
/*     */     
/* 180 */     (nodeList[item]).template = new String(c, 0, (nodeList[item]).length);
/*     */   }
/*     */   
/*     */   static void buildDevTemplate(int item) {
/* 184 */     for (int i = 0; i < (nodeList[item]).length; i++) {
/* 185 */       (nodeList[item]).devTemplate[i] = Grid.letter[((nodeList[item]).cellLoc[i]).x][((nodeList[item]).cellLoc[i]).y];
/*     */     }
/*     */   }
/*     */   
/*     */   static int stepToNextCell(int i, int j, int dir) {
/* 190 */     int[][] STEP_CONT = { { 256, 517, 1034, 2063 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 32, 517, 1034, 2063 }, { 256, 32, 1034, 2063 }, { 32, 32, 1034, 2063 }, { 272, 0, 1050, 0 }, { 0, 533, 0, 2079 }, { 533, 0, 0, 1050 }, { 2079, 1050, 0, 0 }, { 0, 0, 533, 272 }, { 0, 272, 2079, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     int[] tx = { 1, 2, 4, 8 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 228 */       int theControl = STEP_CONT[Grid.mode[i][j]][dir];
/*     */ 
/*     */       
/* 231 */       if ((theControl & 0x20) == 32) return 262144;
/*     */       
/* 233 */       int sig = cellSignature(i, j);
/* 234 */       if ((sig & tx[(theControl & 0xC) / 4]) == tx[dir]) {
/*     */         int rev;
/* 236 */         if ((theControl & 0x10) == 16) {
/* 237 */           return 524288;
/*     */         }
/* 239 */         if ((sig & 0x20) == 32 && dir == 0) { rev = 1048576; }
/* 240 */         else if ((sig & 0x40) == 64 && dir == 1) { rev = 1048576; }
/* 241 */         else { rev = 0; }
/* 242 */          return 0x40000 | rev;
/*     */       } 
/*     */ 
/*     */       
/* 246 */       switch (theControl & 0xF00) { case 256:
/* 247 */           i++; break;
/* 248 */         case 512: j++; break;
/* 249 */         case 1024: i--; break;
/* 250 */         case 2048: j--;
/*     */           break; }
/*     */ 
/*     */       
/* 254 */       dir = (theControl & 0xC) / 4;
/*     */     
/*     */     }
/* 257 */     while ((cellSignature(i, j) & 0x10) != 16);
/*     */ 
/*     */ 
/*     */     
/* 261 */     return (dir * 256 + j) * 256 + i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int cellSignature(int x, int y) {
/* 275 */     int signature = CELL_MODE[Grid.mode[x][y]] & 0x10;
/*     */     
/* 277 */     if (x == Grid.xSz - 1 || (CELL_MODE[Grid.mode[x + 1][y]] & 0x1) == 1 || Grid.mode[x][y] == 3 || Grid.mode[x][y] == 5)
/*     */     {
/*     */ 
/*     */       
/* 281 */       signature |= 0x1;
/*     */     }
/* 283 */     if (x < Grid.xSz - 1) {
/* 284 */       signature |= CELL_MODE[Grid.mode[x + 1][y]] & 0x20;
/*     */     }
/* 286 */     if (y == Grid.ySz - 1 || (CELL_MODE[Grid.mode[x][y + 1]] & 0x2) == 2 || Grid.mode[x][y] == 4 || Grid.mode[x][y] == 5)
/*     */     {
/*     */ 
/*     */       
/* 290 */       signature |= 0x2;
/*     */     }
/* 292 */     if (y < Grid.ySz - 1) {
/* 293 */       signature |= CELL_MODE[Grid.mode[x][y + 1]] & 0x40;
/*     */     }
/* 295 */     if (x == 0 || (CELL_MODE[Grid.mode[x - 1][y]] & 0x4) == 4)
/*     */     {
/* 297 */       signature |= 0x4;
/*     */     }
/* 299 */     if (y == 0 || (CELL_MODE[Grid.mode[x][y - 1]] & 0x8) == 8)
/*     */     {
/* 301 */       signature |= 0x8; } 
/* 302 */     return signature;
/*     */   }
/*     */   
/*     */   static void rebuildHorzAndVert() {
/*     */     int i;
/* 307 */     for (i = 0; i < nodeListLength; i++) {
/* 308 */       for (int j = 0; j < (nodeList[i]).length; j++) {
/* 309 */         int x = ((nodeList[i]).cellLoc[j]).x, y = ((nodeList[i]).cellLoc[j]).y;
/* 310 */         Grid.vert[x][y] = -1; Grid.horz[x][y] = -1;
/*     */       } 
/* 312 */     }  for (i = 0; i < nodeListLength; i++) {
/* 313 */       for (int j = 0; j < (nodeList[i]).length; j++) {
/* 314 */         int x = ((nodeList[i]).cellLoc[j]).x, y = ((nodeList[i]).cellLoc[j]).y;
/* 315 */         if (Grid.horz[x][y] == -1) {
/* 316 */           Grid.horz[x][y] = i;
/*     */         } else {
/* 318 */           Grid.vert[x][y] = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   } static String selectOneClue(String clue, int wordDat) {
/* 323 */     int[] loc = new int[257];
/* 324 */     Random r = new Random();
/*     */     
/* 326 */     if (clue.length() == 0)
/* 327 */       return "";  int i, count;
/* 328 */     for (loc[0] = i = 0, count = 0; i < clue.length(); i++) {
/* 329 */       if (clue.charAt(i) == '*')
/* 330 */         loc[++count] = i + 1; 
/* 331 */     }  loc[++count] = i + 1;
/*     */     
/* 333 */     if (Op.getBool(Op.CW.CwIgnoreLockout.ordinal(), Op.cw).booleanValue() || Def.puzzleMode == 6) {
/*     */       
/* 335 */       i = r.nextInt(count);
/*     */     } else {
/* 337 */       i = wordDat % 256;
/* 338 */     }  if (i == 255) i = 0; 
/* 339 */     return new String(clue.substring(loc[i], loc[i + 1] - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void attachClues(String thisDictionary, Boolean themed) {
/* 346 */     Op.msc[Op.MSC.DictionaryName.ordinal()] = thisDictionary;
/* 347 */     for (int source = 4; source >= 0; source--) {
/* 348 */       String theDictionary = (themed.booleanValue() ? Op.cw[CrosswordBuild.dicList[source]] : thisDictionary) + ".dic/xword.dic";
/* 349 */       if (source <= 0 || theDictionary.startsWith("$")) {
/*     */         
/*     */         try {
/*     */           
/* 353 */           DataInputStream dataIn = new DataInputStream(new FileInputStream(theDictionary)); int i;
/* 354 */           for (i = 0; i < 128; i++)
/* 355 */             dataIn.readByte(); 
/* 356 */           while (dataIn.available() > 2) {
/* 357 */             int wordDat = dataIn.readInt();
/* 358 */             String word = dataIn.readUTF();
/* 359 */             String clue = dataIn.readUTF();
/*     */             
/* 361 */             for (i = 0; i < nodeListLength; i++) {
/* 362 */               if (source == (nodeList[i]).source && 
/* 363 */                 word.compareTo((nodeList[i]).word) == 0)
/* 364 */                 (nodeList[i]).clue = selectOneClue(clue, wordDat).trim(); 
/*     */             } 
/*     */           } 
/* 367 */           dataIn.close();
/*     */         }
/* 369 */         catch (IOException exc) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void sortNodeList(int mode) {
/* 376 */     boolean swap = false;
/*     */     
/* 378 */     for (int i = 0; i < nodeListLength - 1; i++) {
/* 379 */       for (int j = i + 1; j < nodeListLength; j++) {
/* 380 */         switch (mode) {
/*     */           case 3:
/* 382 */             swap = ((nodeList[i]).word.length() > (nodeList[j]).word.length() || ((nodeList[i]).word.length() == (nodeList[j]).word.length() && (nodeList[i]).word.compareTo((nodeList[j]).word) > 0));
/*     */             break;
/*     */           case 0:
/* 385 */             swap = ((nodeList[i]).word.compareTo((nodeList[j]).word) > 0);
/*     */             break;
/*     */           case 1:
/* 388 */             swap = ((nodeList[i]).direction > (nodeList[j]).direction || ((nodeList[i]).direction == (nodeList[j]).direction && (nodeList[i]).id > (nodeList[j]).id));
/*     */             break;
/*     */           case 2:
/* 391 */             swap = ((nodeList[i]).id > (nodeList[j]).id || ((nodeList[i]).id == (nodeList[j]).id && (nodeList[i]).direction > (nodeList[j]).direction));
/*     */             break;
/*     */           case 4:
/* 394 */             swap = ((nodeList[i]).x > (nodeList[j]).x || ((nodeList[i]).x == (nodeList[j]).x && (nodeList[i]).y > (nodeList[j]).y));
/*     */             break;
/*     */         } 
/* 397 */         if (swap) {
/* 398 */           Node node = nodeList[i];
/* 399 */           nodeList[i] = nodeList[j];
/* 400 */           nodeList[j] = node;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/* 405 */   static JRadioButton[] jrbExportMode = new JRadioButton[4];
/*     */   static void exportText(JFrame jf, final boolean includeID) {
/* 407 */     final JDialog jdlgExport = new JDialog(jf, "Export as Text", true);
/* 408 */     jdlgExport.setSize(220, 321);
/* 409 */     jdlgExport.setResizable(false);
/* 410 */     jdlgExport.setLayout((LayoutManager)null);
/* 411 */     jdlgExport.setLocation(jf.getX(), jf.getY());
/*     */     
/* 413 */     jdlgExport
/* 414 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 416 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/* 420 */     Methods.closeHelp();
/*     */     
/* 422 */     JPanel jpExportMode = new JPanel();
/* 423 */     jpExportMode.setLayout((LayoutManager)null);
/* 424 */     jpExportMode.setSize(200, 125);
/* 425 */     jpExportMode.setLocation(10, 10);
/* 426 */     jpExportMode.setOpaque(true);
/* 427 */     jpExportMode.setBorder(BorderFactory.createEtchedBorder());
/* 428 */     jdlgExport.add(jpExportMode);
/*     */     
/* 430 */     JLabel jl = new JLabel("Export Mode");
/* 431 */     jl.setForeground(Def.COLOR_LABEL);
/* 432 */     jl.setSize(190, 20);
/* 433 */     jl.setLocation(5, 3);
/* 434 */     jl.setHorizontalAlignment(0);
/* 435 */     jpExportMode.add(jl);
/*     */     
/* 437 */     ButtonGroup bgExportMode = new ButtonGroup();
/* 438 */     jrbExportMode[0] = new JRadioButton();
/* 439 */     jrbExportMode[0].setForeground(Def.COLOR_LABEL);
/* 440 */     jrbExportMode[0].setOpaque(false);
/* 441 */     jrbExportMode[0].setSize(185, 20);
/* 442 */     jrbExportMode[0].setLocation(10, 25);
/* 443 */     jrbExportMode[0].setText("Export Words");
/* 444 */     jpExportMode.add(jrbExportMode[0]);
/* 445 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[0]);
/*     */     
/* 447 */     jrbExportMode[1] = new JRadioButton();
/* 448 */     jrbExportMode[1].setForeground(Def.COLOR_LABEL);
/* 449 */     jrbExportMode[1].setOpaque(false);
/* 450 */     jrbExportMode[1].setSize(185, 20);
/* 451 */     jrbExportMode[1].setLocation(10, 50);
/* 452 */     jrbExportMode[1].setText("Export Clues");
/* 453 */     jpExportMode.add(jrbExportMode[1]);
/* 454 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[1]);
/*     */     
/* 456 */     jrbExportMode[2] = new JRadioButton();
/* 457 */     jrbExportMode[2].setForeground(Def.COLOR_LABEL);
/* 458 */     jrbExportMode[2].setOpaque(false);
/* 459 */     jrbExportMode[2].setSize(185, 20);
/* 460 */     jrbExportMode[2].setLocation(10, 75);
/* 461 */     jrbExportMode[2].setText("Export Words and Clues");
/* 462 */     jpExportMode.add(jrbExportMode[2]);
/* 463 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[2]);
/*     */     
/* 465 */     jrbExportMode[3] = new JRadioButton();
/* 466 */     jrbExportMode[3].setForeground(Def.COLOR_LABEL);
/* 467 */     jrbExportMode[3].setOpaque(false);
/* 468 */     jrbExportMode[3].setSize(185, 20);
/* 469 */     jrbExportMode[3].setLocation(10, 100);
/* 470 */     jrbExportMode[3].setText("Export Puzzle Grid");
/* 471 */     jpExportMode.add(jrbExportMode[3]);
/* 472 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[3]);
/*     */     
/* 474 */     if (Def.puzzleMode == 10)
/* 475 */       jrbExportMode[3].setEnabled(false); 
/* 476 */     jrbExportMode[1].setSelected(true);
/*     */     
/* 478 */     Action doFile = new AbstractAction("Export to File")
/*     */       {
/*     */         public void actionPerformed(ActionEvent e) {
/* 481 */           String path = ""; int mode;
/* 482 */           for (mode = 0; mode <= 3 && 
/* 483 */             !NodeList.jrbExportMode[mode].isSelected(); mode++);
/*     */ 
/*     */           
/* 486 */           JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/");
/* 487 */           chooser.setDialogTitle("Name the Export File");
/* 488 */           chooser.setFileFilter(new FileNameExtensionFilter("Text File", new String[] { "txt" }));
/* 489 */           chooser.setSelectedFile(new File("puzzle.txt"));
/* 490 */           if (chooser.showSaveDialog(jdlgExport) == 0) {
/* 491 */             path = chooser.getSelectedFile().getAbsolutePath();
/*     */           }
/* 493 */           if (path != null) {
/*     */             try {
/* 495 */               FileWriter fw = new FileWriter(path);
/* 496 */               fw.write(NodeList.getExportText(mode, includeID));
/* 497 */               fw.close();
/*     */             }
/* 499 */             catch (IOException ex) {}
/* 500 */             JOptionPane.showMessageDialog(jdlgExport, "The text has been saved in the file\n" + path);
/*     */           } 
/* 502 */           Methods.clickedOK = true;
/* 503 */           jdlgExport.dispose();
/* 504 */           Methods.closeHelp();
/*     */         }
/*     */       };
/* 507 */     JButton jbExportToFile = Methods.newButton("doFile", doFile, 70, 10, 145, 200, 26);
/* 508 */     jdlgExport.add(jbExportToFile);
/*     */     
/* 510 */     Action doClipboard = new AbstractAction("Export to Clipboard") {
/*     */         public void actionPerformed(ActionEvent e) {
/*     */           int mode;
/* 513 */           for (mode = 0; mode <= 3 && 
/* 514 */             !NodeList.jrbExportMode[mode].isSelected(); mode++);
/*     */           
/* 516 */           StringSelection stringSelection = new StringSelection(NodeList.getExportText(mode, includeID));
/* 517 */           Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
/* 518 */           JOptionPane.showMessageDialog(jdlgExport, "The text has been exported to the Clipboard,\n and is now ready for Pasting into other applications.", "Export Completed", 1);
/*     */ 
/*     */ 
/*     */           
/* 522 */           Methods.clickedOK = true;
/* 523 */           jdlgExport.dispose();
/* 524 */           Methods.closeHelp();
/*     */         }
/*     */       };
/* 527 */     JButton jbExportToClipboard = Methods.newButton("doClipboard", doClipboard, 76, 10, 180, 200, 26);
/* 528 */     jdlgExport.add(jbExportToClipboard);
/*     */     
/* 530 */     Action doCancel = new AbstractAction("Cancel") {
/*     */         public void actionPerformed(ActionEvent e) {
/* 532 */           Methods.clickedOK = false;
/* 533 */           jdlgExport.dispose();
/* 534 */           Methods.closeHelp();
/*     */         }
/*     */       };
/* 537 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 215, 200, 26);
/* 538 */     jdlgExport.add(jbCancel);
/*     */     
/* 540 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*     */         public void actionPerformed(ActionEvent e) {
/* 542 */           Methods.cweHelp(null, jdlgExport, "Export as Text", NodeList.exportText);
/*     */         }
/*     */       };
/* 545 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 10, 250, 200, 61);
/* 546 */     jdlgExport.add(jbHelp);
/*     */     
/* 548 */     jdlgExport.getRootPane().setDefaultButton(jbExportToFile);
/* 549 */     Methods.setDialogSize(jdlgExport, 220, 321);
/*     */   }
/*     */ 
/*     */   
/*     */   static String getExportText(int mode, boolean includeID) {
/* 554 */     boolean headingPrinted = false;
/* 555 */     String str = "";
/*     */ 
/*     */     
/* 558 */     if (mode == 3) {
/* 559 */       if (Def.puzzleMode == 220) {
/* 560 */         for (int j = 0; j < Grid.ySz; j++) {
/* 561 */           for (int i = 0; i < Grid.xSz; i++) {
/* 562 */             String devLetter = DevanagariBuild.recoverDevStringFromInt(Grid.letter[i][j]);
/* 563 */             devLetter = devLetter + ((devLetter.length() == 0) ? "██\t" : "\t");
/* 564 */             str = str + devLetter;
/*     */           } 
/* 566 */           str = str + "\n";
/*     */         } 
/*     */       } else {
/*     */         
/* 570 */         for (int j = 0; j < Grid.ySz; j++) {
/* 571 */           for (int i = 0; i < Grid.xSz; i++) {
/* 572 */             char ch = (char)Grid.letter[i][j];
/* 573 */             str = str + ((ch > ' ') ? ch : 32);
/*     */           } 
/* 575 */           str = str + "\n";
/*     */         } 
/*     */       } 
/* 578 */       return str;
/*     */     } 
/*     */     
/* 581 */     if (Def.puzzleMode == 200) {
/* 582 */       for (int i = 0; i < nodeListLength; i++) {
/* 583 */         switch (mode) { case 0:
/* 584 */             str = str + "\n" + (nodeList[i]).word; break;
/* 585 */           case 1: str = str + "\n" + (nodeList[i]).clue; break;
/* 586 */           case 2: str = str + "\n" + (nodeList[i]).word + " : " + (nodeList[i]).clue; break; }
/*     */       
/*     */       } 
/* 589 */       return str;
/*     */     } 
/*     */     
/* 592 */     for (int thisDirection = 0; thisDirection <= 1; thisDirection++) {
/* 593 */       for (int i = 0; i < nodeListLength; i++) {
/* 594 */         if ((nodeList[i]).direction == thisDirection && (nodeList[i]).id > 0) {
/* 595 */           if (!headingPrinted) {
/* 596 */             str = str + ((thisDirection == 0) ? "ACROSS" : "\n\nDOWN");
/* 597 */             headingPrinted = true;
/*     */           } 
/* 599 */           String theID = "\n" + (nodeList[i]).id + ". ";
/* 600 */           switch (mode) { case 0:
/* 601 */               str = str + theID + (nodeList[i]).word; break;
/* 602 */             case 1: str = str + theID + (nodeList[i]).clue; break;
/* 603 */             case 2: str = str + theID + (nodeList[i]).word + " : " + (nodeList[i]).clue; break; }
/*     */         
/*     */         } 
/* 606 */       }  headingPrinted = false;
/*     */     } 
/* 608 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\NodeList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */