/*     */ package crosswordexpress;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ 
/*     */ class Op {
/*   6 */   static Boolean defaultAll = Boolean.valueOf(false);
/*     */   
/*   8 */   static String[] msc = new String[200];
/*     */   
/*  10 */   enum MSC { LastOtherPuzzle, GridW, GridH, PrintW, PrintH,
/*  11 */     LayoutName, DictionaryName, GridName, TemplateName, WordToolsDic,
/*  12 */     Langacross, Langdown, Langwords, Langclues, Langtext,
/*  13 */     spare15, SolutionPuz, ImportAlphabet, ShortestImport, Ppi; }
/*     */ 
/*     */   
/*  16 */   static String[] ac = new String[200];
/*     */   
/*  18 */   enum AC { spare1, spare2, spare3, spare4, spare5,
/*  19 */     spare6, spare7, spare8, spare9, spare10,
/*  20 */     spare11, spare12, spare13, spare14, spare15,
/*  21 */     spare16, spare17, spare18, spare19, spare20,
/*  22 */     spare21, spare22, spare23, spare24, spare25,
/*  23 */     spare26, spare27, spare28, spare29, spare30,
/*  24 */     spare31, spare32, spare33, spare34, spare35,
/*  25 */     spare36, spare37, spare38, spare39, spare40,
/*  26 */     spare41, spare42, spare43, spare44, spare45,
/*  27 */     spare46, spare47, spare48, spare49, spare50,
/*  28 */     spare51, spare52, spare53, spare54, spare55,
/*  29 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/*  31 */     AcW, AcH, AcShort, AcCell, AcFirstLetter,
/*  32 */     AcPattern, AcGrid, AcCode, AcLetter, AcClue,
/*  33 */     AcError, AcCurrent, AcPuz, AcDic, AcParagraph,
/*  34 */     AcWords, AcFont, AcClueFont, AcCodeFont, AcPuzColor,
/*  35 */     AcSolColor; }
/*     */ 
/*     */   
/*  38 */   static String[] ak = new String[200];
/*     */   
/*  40 */   enum AK { spare1, spare2, spare3, spare4, spare5,
/*  41 */     spare6, spare7, spare8, spare9, spare10,
/*  42 */     spare11, spare12, spare13, spare14, spare15,
/*  43 */     spare16, spare17, spare18, spare19, spare20,
/*  44 */     spare21, spare22, spare23, spare24, spare25,
/*  45 */     spare26, spare27, spare28, spare29, spare30,
/*  46 */     spare31, spare32, spare33, spare34, spare35,
/*  47 */     spare36, spare37, spare38, spare39, spare40,
/*  48 */     spare41, spare42, spare43, spare44, spare45,
/*  49 */     spare46, spare47, spare48, spare49, spare50,
/*  50 */     spare51, spare52, spare53, spare54, spare55,
/*  51 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/*  53 */     AkW, AkH, AkDifficulty, AkPattern, AkNumbers,
/*  54 */     AkLit, AkDark, AkNoLamp, AkLamp, AkLines,
/*  55 */     AkError, AkPuz, AkGrid, AkFont, AkPuzColor,
/*  56 */     AkSolColor, AkRule1, AkRule2, AkRule3, AkRule4,
/*  57 */     AkRule5; }
/*     */ 
/*     */   
/*  60 */   static String[] cd = new String[200];
/*     */   
/*  62 */   enum CD { spare1, spare2, spare3, spare4, spare5,
/*  63 */     spare6, spare7, spare8, spare9, spare10,
/*  64 */     spare11, spare12, spare13, spare14, spare15,
/*  65 */     spare16, spare17, spare18, spare19, spare20,
/*  66 */     spare21, spare22, spare23, spare24, spare25,
/*  67 */     spare26, spare27, spare28, spare29, spare30,
/*  68 */     spare31, spare32, spare33, spare34, spare35,
/*  69 */     spare36, spare37, spare38, spare39, spare40,
/*  70 */     spare41, spare42, spare43, spare44, spare45,
/*  71 */     spare46, spare47, spare48, spare49, spare50,
/*  72 */     spare51, spare52, spare53, spare54, spare55,
/*  73 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/*  75 */     CdW, CdH, CdCell, CdGrid, CdPattern,
/*  76 */     CdLetters, CdID, CdFocusWord, CdError, CdUsed,
/*  77 */     CdCodePanel, CdPuz, CdDic, CdPuzzleFont, CdCodeFont,
/*  78 */     CdPuzColor, CdSolColor; }
/*     */ 
/*     */   
/*  81 */   static String[] cw = new String[200];
/*     */   
/*  83 */   enum CW { spare1, spare2, spare3, spare4, spare5,
/*  84 */     spare6, spare7, spare8, spare9, spare10,
/*  85 */     spare11, spare12, spare13, spare14, spare15,
/*  86 */     spare16, spare17, spare18, spare19, spare20,
/*  87 */     spare21, spare22, spare23, spare24, spare25,
/*  88 */     spare26, spare27, spare28, spare29, spare30,
/*  89 */     spare31, spare32, spare33, spare34, spare35,
/*  90 */     spare36, spare37, spare38, spare39, spare40,
/*  91 */     spare41, spare42, spare43, spare44, spare45,
/*  92 */     spare46, spare47, spare48, spare49, spare50,
/*  93 */     spare51, spare52, spare53, spare54, spare55,
/*  94 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/*  96 */     AwStyle, AwDir, AwBold, AwAlign, AwWidth,
/*  97 */     AwClue, AwCell, AwArrow, AwPattern, AwLine,
/*  98 */     AwText, AwOverlap, spare62, spare63, spare64,
/*     */     
/* 100 */     CwPuz, CwGrid, CwDic, CwSiDic1, CwSiDic2,
/* 101 */     CwSiDic3, CwSiDic4, CwW, CwH, CwSolveW,
/* 102 */     CwSolveH, CwPuzC, CwSolC, CwFrenchAcrossId, CwFrenchDownId,
/* 103 */     CwCellC, CwGridC, CwLettersC, CwIDC, CwShadowC,
/* 104 */     CwPatternC, CwErrorC, CwClueC, CwGeminiA, CwGeminiB,
/* 105 */     CwFont, CwIDFont, CwClueFont, CwIgnoreLockout, CwAutoLock,
/* 106 */     Spare, CwSolvePuz, CwSolveDic, CwCrosswordSep, CwReverseArrow,
/* 107 */     CwIdInSol, CwName, CwStreet, CwTown, CwState,
/* 108 */     CwZip, CwCountry, CwEmail, CwSubFont; }
/*     */ 
/*     */   
/* 111 */   static String[] sw = new String[200];
/*     */   
/* 113 */   enum SW { spare1, spare2, spare3, spare4, spare5,
/* 114 */     spare6, spare7, spare8, spare9, spare10,
/* 115 */     spare11, spare12, spare13, spare14, spare15,
/* 116 */     spare16, spare17, spare18, spare19, spare20,
/* 117 */     spare21, spare22, spare23, spare24, spare25,
/* 118 */     spare26, spare27, spare28, spare29, spare30,
/* 119 */     spare31, spare32, spare33, spare34, spare35,
/* 120 */     spare36, spare37, spare38, spare39, spare40,
/* 121 */     spare41, spare42, spare43, spare44, spare45,
/* 122 */     spare46, spare47, spare48, spare49, spare50,
/* 123 */     spare51, spare52, spare53, spare54, spare55,
/* 124 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 126 */     SwPuz, SwDic, SwW, SwH, SwPuzC,
/* 127 */     SwSolC, SwSize, SwCellC, SwGridC, SwLettersC,
/* 128 */     SwIDC, SwFont, SwIDFont, SwClueFont, SwClueC; }
/*     */ 
/*     */   
/* 131 */   static String[] dm = new String[200];
/*     */   
/* 133 */   enum DM { spare1, spare2, spare3, spare4, spare5,
/* 134 */     spare6, spare7, spare8, spare9, spare10,
/* 135 */     spare11, spare12, spare13, spare14, spare15,
/* 136 */     spare16, spare17, spare18, spare19, spare20,
/* 137 */     spare21, spare22, spare23, spare24, spare25,
/* 138 */     spare26, spare27, spare28, spare29, spare30,
/* 139 */     spare31, spare32, spare33, spare34, spare35,
/* 140 */     spare36, spare37, spare38, spare39, spare40,
/* 141 */     spare41, spare42, spare43, spare44, spare45,
/* 142 */     spare46, spare47, spare48, spare49, spare50,
/* 143 */     spare51, spare52, spare53, spare54, spare55,
/* 144 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 146 */     DmW, DmH, DmSize, DmCell, DmSolved,
/* 147 */     DmLine, DmNumber, DmSolvedNumber, DmError, DmPuz,
/* 148 */     DmFont, DmPuzColor, DmSolColor, DmRule1, DmRule2,
/* 149 */     DmRule3, DmRule4, DmRule5; }
/*     */ 
/*     */   
/* 152 */   static String[] db = new String[200];
/*     */   
/* 154 */   enum DB { spare1, spare2, spare3, spare4, spare5,
/* 155 */     spare6, spare7, spare8, spare9, spare10,
/* 156 */     spare11, spare12, spare13, spare14, spare15,
/* 157 */     spare16, spare17, spare18, spare19, spare20,
/* 158 */     spare21, spare22, spare23, spare24, spare25,
/* 159 */     spare26, spare27, spare28, spare29, spare30,
/* 160 */     spare31, spare32, spare33, spare34, spare35,
/* 161 */     spare36, spare37, spare38, spare39, spare40,
/* 162 */     spare41, spare42, spare43, spare44, spare45,
/* 163 */     spare46, spare47, spare48, spare49, spare50,
/* 164 */     spare51, spare52, spare53, spare54, spare55,
/* 165 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 167 */     DbW, DbH, DbCell, DbGrid, DbAnchor,
/* 168 */     DbFocus, DbLetter, DbID, DbClue, DbError,
/* 169 */     DbPuz, DbDic, DbFont, DbIDFont, DbClueFont,
/* 170 */     DbPuzColor, DbSolColor; }
/*     */ 
/*     */   
/* 173 */   static String[] dv = new String[200];
/*     */   
/* 175 */   enum DV { spare1, spare2, spare3, spare4, spare5,
/* 176 */     spare6, spare7, spare8, spare9, spare10,
/* 177 */     spare11, spare12, spare13, spare14, spare15,
/* 178 */     spare16, spare17, spare18, spare19, spare20,
/* 179 */     spare21, spare22, spare23, spare24, spare25,
/* 180 */     spare26, spare27, spare28, spare29, spare30,
/* 181 */     spare31, spare32, spare33, spare34, spare35,
/* 182 */     spare36, spare37, spare38, spare39, spare40,
/* 183 */     spare41, spare42, spare43, spare44, spare45,
/* 184 */     spare46, spare47, spare48, spare49, spare50,
/* 185 */     spare51, spare52, spare53, spare54, spare55,
/* 186 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 188 */     DvPuz, DvTemplate, DvDic, DvW, DvH,
/* 189 */     DvAcross, DvDown, DvGrid, DvCellC, DvPatternC,
/* 190 */     DvGridC, DvFont, DvLettersC, DvPuzC, DvSolC,
/* 191 */     DvIDFont, DvIDC, DvClueFont, DvErrorC, DvClueC; }
/*     */   
/* 193 */   static String[] fl = new String[200];
/*     */   
/* 195 */   enum FL { spare1, spare2, spare3, spare4, spare5,
/* 196 */     spare6, spare7, spare8, spare9, spare10,
/* 197 */     spare11, spare12, spare13, spare14, spare15,
/* 198 */     spare16, spare17, spare18, spare19, spare20,
/* 199 */     spare21, spare22, spare23, spare24, spare25,
/* 200 */     spare26, spare27, spare28, spare29, spare30,
/* 201 */     spare31, spare32, spare33, spare34, spare35,
/* 202 */     spare36, spare37, spare38, spare39, spare40,
/* 203 */     spare41, spare42, spare43, spare44, spare45,
/* 204 */     spare46, spare47, spare48, spare49, spare50,
/* 205 */     spare51, spare52, spare53, spare54, spare55,
/* 206 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 208 */     FlW, FlH, FlCell, FlGrid, FlPattern,
/* 209 */     FlLetters, FlID, FlFocus, FlError, FlPuz,
/* 210 */     FlDic, FlPuzzleFont, FlIDFont, FlPuzColor, FlSolColor; }
/*     */ 
/*     */   
/* 213 */   static String[] fi = new String[200];
/*     */   
/* 215 */   enum FI { spare1, spare2, spare3, spare4, spare5,
/* 216 */     spare6, spare7, spare8, spare9, spare10,
/* 217 */     spare11, spare12, spare13, spare14, spare15,
/* 218 */     spare16, spare17, spare18, spare19, spare20,
/* 219 */     spare21, spare22, spare23, spare24, spare25,
/* 220 */     spare26, spare27, spare28, spare29, spare30,
/* 221 */     spare31, spare32, spare33, spare34, spare35,
/* 222 */     spare36, spare37, spare38, spare39, spare40,
/* 223 */     spare41, spare42, spare43, spare44, spare45,
/* 224 */     spare46, spare47, spare48, spare49, spare50,
/* 225 */     spare51, spare52, spare53, spare54, spare55,
/* 226 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 228 */     FiW, FiH, FiAcross, FiDown, Fi1,
/* 229 */     Fi2, Fi3, Fi4, Fi5, Fi6,
/* 230 */     Fi7, Fi8, FiEmpty, FiNumber, FiLines,
/* 231 */     FiError, FiPuz, FiFont, FiPuzColor, FiSolColor,
/* 232 */     FiRule1, FiRule2, FiRule3, FiRule4, FiRule5; }
/*     */ 
/*     */   
/* 235 */   static String[] ff = new String[200];
/*     */   
/* 237 */   enum FF { spare1, spare2, spare3, spare4, spare5,
/* 238 */     spare6, spare7, spare8, spare9, spare10,
/* 239 */     spare11, spare12, spare13, spare14, spare15,
/* 240 */     spare16, spare17, spare18, spare19, spare20,
/* 241 */     spare21, spare22, spare23, spare24, spare25,
/* 242 */     spare26, spare27, spare28, spare29, spare30,
/* 243 */     spare31, spare32, spare33, spare34, spare35,
/* 244 */     spare36, spare37, spare38, spare39, spare40,
/* 245 */     spare41, spare42, spare43, spare44, spare45,
/* 246 */     spare46, spare47, spare48, spare49, spare50,
/* 247 */     spare51, spare52, spare53, spare54, spare55,
/* 248 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 250 */     FfPuz, FfTemplate, FfDic, FfW, FfH,
/* 251 */     FfAcross, FfDown, FfOptimize, FfEnforceLink; }
/*     */ 
/*     */   
/* 254 */   static String[] fq = new String[200];
/*     */   
/* 256 */   enum FQ { spare1, spare2, spare3, spare4, spare5,
/* 257 */     spare6, spare7, spare8, spare9, spare10,
/* 258 */     spare11, spare12, spare13, spare14, spare15,
/* 259 */     spare16, spare17, spare18, spare19, spare20,
/* 260 */     spare21, spare22, spare23, spare24, spare25,
/* 261 */     spare26, spare27, spare28, spare29, spare30,
/* 262 */     spare31, spare32, spare33, spare34, spare35,
/* 263 */     spare36, spare37, spare38, spare39, spare40,
/* 264 */     spare41, spare42, spare43, spare44, spare45,
/* 265 */     spare46, spare47, spare48, spare49, spare50,
/* 266 */     spare51, spare52, spare53, spare54, spare55,
/* 267 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 269 */     FqBg, FqLetterColor, FqLetterFont, FqPuzColor, FqW,
/* 270 */     FqH, FqPuz, FqBorder, FqSolColor, FqQ,
/* 271 */     FqTitleFont, FqTitleColor; }
/*     */ 
/*     */   
/* 274 */   static String[] fu = new String[200];
/*     */   
/* 276 */   enum FU { spare1, spare2, spare3, spare4, spare5,
/* 277 */     spare6, spare7, spare8, spare9, spare10,
/* 278 */     spare11, spare12, spare13, spare14, spare15,
/* 279 */     spare16, spare17, spare18, spare19, spare20,
/* 280 */     spare21, spare22, spare23, spare24, spare25,
/* 281 */     spare26, spare27, spare28, spare29, spare30,
/* 282 */     spare31, spare32, spare33, spare34, spare35,
/* 283 */     spare36, spare37, spare38, spare39, spare40,
/* 284 */     spare41, spare42, spare43, spare44, spare45,
/* 285 */     spare46, spare47, spare48, spare49, spare50,
/* 286 */     spare51, spare52, spare53, spare54, spare55,
/* 287 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 289 */     FuW, FuH, FuSize, FuHints, FuDifficulty,
/* 290 */     FuBorder, FuBg, FuCell, FuNumbers, FuGuide,
/* 291 */     FuInequality, FuError, FuPuz, FuFont, FuGuideFont,
/* 292 */     FuPuzColor, FuSolColor, FuRule1, FuRule2, FuRule3,
/* 293 */     FuRule4, FuRule5; }
/*     */ 
/*     */   
/* 296 */   static String[] gk = new String[200];
/*     */   
/* 298 */   enum GK { spare1, spare2, spare3, spare4, spare5,
/* 299 */     spare6, spare7, spare8, spare9, spare10,
/* 300 */     spare11, spare12, spare13, spare14, spare15,
/* 301 */     spare16, spare17, spare18, spare19, spare20,
/* 302 */     spare21, spare22, spare23, spare24, spare25,
/* 303 */     spare26, spare27, spare28, spare29, spare30,
/* 304 */     spare31, spare32, spare33, spare34, spare35,
/* 305 */     spare36, spare37, spare38, spare39, spare40,
/* 306 */     spare41, spare42, spare43, spare44, spare45,
/* 307 */     spare46, spare47, spare48, spare49, spare50,
/* 308 */     spare51, spare52, spare53, spare54, spare55,
/* 309 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 311 */     GkW, GkH, GkAcross, GkDown, GkDifficulty,
/* 312 */     GkCell, GkCircle, GkLine, GkNumber, GkDiagonal,
/* 313 */     GkError, GkPuz, GkFont, GkPuzColor, GkSolColor,
/* 314 */     GkRule1, GkRule2, GkRule3, GkRule4, GkRule5; }
/*     */ 
/*     */   
/* 317 */   static String[] kk = new String[200];
/*     */   
/* 319 */   enum KK { spare1, spare2, spare3, spare4, spare5,
/* 320 */     spare6, spare7, spare8, spare9, spare10,
/* 321 */     spare11, spare12, spare13, spare14, spare15,
/* 322 */     spare16, spare17, spare18, spare19, spare20,
/* 323 */     spare21, spare22, spare23, spare24, spare25,
/* 324 */     spare26, spare27, spare28, spare29, spare30,
/* 325 */     spare31, spare32, spare33, spare34, spare35,
/* 326 */     spare36, spare37, spare38, spare39, spare40,
/* 327 */     spare41, spare42, spare43, spare44, spare45,
/* 328 */     spare46, spare47, spare48, spare49, spare50,
/* 329 */     spare51, spare52, spare53, spare54, spare55,
/* 330 */     spare56, spare57, spare58, spare59, KkMode,
/*     */     
/* 332 */     KkW, KkH, KkBg, KkCell, KkClueBg,
/* 333 */     KkNumber, KkClue, KkGuide, KkError, KkPuz,
/* 334 */     KkGrid, KkFont, KkGuideFont, KkClueFont, KkPuzColor,
/* 335 */     KkSolColor, KkRule1, KkRule2, KkRule3, KkRule4,
/* 336 */     KkRule5; }
/*     */ 
/*     */   
/* 339 */   static String[] ke = new String[200];
/*     */   
/* 341 */   enum KE { spare1, spare2, spare3, spare4, spare5,
/* 342 */     spare6, spare7, spare8, spare9, spare10,
/* 343 */     spare11, spare12, spare13, spare14, spare15,
/* 344 */     spare16, spare17, spare18, spare19, spare20,
/* 345 */     spare21, spare22, spare23, spare24, spare25,
/* 346 */     spare26, spare27, spare28, spare29, spare30,
/* 347 */     spare31, spare32, spare33, spare34, spare35,
/* 348 */     spare36, spare37, spare38, spare39, spare40,
/* 349 */     spare41, spare42, spare43, spare44, spare45,
/* 350 */     spare46, spare47, spare48, spare49, spare50,
/* 351 */     spare51, spare52, spare53, spare54, spare55,
/* 352 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 354 */     KeW, KeH, KeSize, KeDifficulty, KeCell,
/* 355 */     KeGrid, KeLine, KeNumber, KeGuide, KeHint,
/* 356 */     KeError, KePuz, KeFont, KeGuideFont, KeHintFont,
/* 357 */     KePuzColor, KeSolColor, KeRule1, KeRule2, KeRule3,
/* 358 */     KeRule4, KeRule5; }
/*     */ 
/*     */   
/* 361 */   static String[] ks = new String[200];
/*     */   
/* 363 */   enum KS { spare1, spare2, spare3, spare4, spare5,
/* 364 */     spare6, spare7, spare8, spare9, spare10,
/* 365 */     spare11, spare12, spare13, spare14, spare15,
/* 366 */     spare16, spare17, spare18, spare19, spare20,
/* 367 */     spare21, spare22, spare23, spare24, spare25,
/* 368 */     spare26, spare27, spare28, spare29, spare30,
/* 369 */     spare31, spare32, spare33, spare34, spare35,
/* 370 */     spare36, spare37, spare38, spare39, spare40,
/* 371 */     spare41, spare42, spare43, spare44, spare45,
/* 372 */     spare46, spare47, spare48, spare49, spare50,
/* 373 */     spare51, spare52, spare53, spare54, spare55,
/* 374 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 376 */     KsW, KsH, KsDifficulty, KsCell, KsGrid,
/* 377 */     KsBox, KsCage, KsNumber, KsGuide, KsHint,
/* 378 */     KsPuzColor, KsError, KsPuz, KsFont, KsGuideFont,
/* 379 */     KsHintFont, KsSolColor, KsGuideBg, KsAssist; }
/*     */ 
/*     */   
/* 382 */   static String[] lw = new String[200];
/*     */   
/* 384 */   enum LW { spare1, spare2, spare3, spare4, spare5,
/* 385 */     spare6, spare7, spare8, spare9, spare10,
/* 386 */     spare11, spare12, spare13, spare14, spare15,
/* 387 */     spare16, spare17, spare18, spare19, spare20,
/* 388 */     spare21, spare22, spare23, spare24, spare25,
/* 389 */     spare26, spare27, spare28, spare29, spare30,
/* 390 */     spare31, spare32, spare33, spare34, spare35,
/* 391 */     spare36, spare37, spare38, spare39, spare40,
/* 392 */     spare41, spare42, spare43, spare44, spare45,
/* 393 */     spare46, spare47, spare48, spare49, spare50,
/* 394 */     spare51, spare52, spare53, spare54, spare55,
/* 395 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 397 */     LwW, LwH, LwRows, LwFirstLen, LwCell,
/* 398 */     LwGrid, LwFocus, LwLetter, LwID, LwClue,
/* 399 */     LwError, LwPuz, LwDic, LwFont, LwIDFont,
/* 400 */     LwClueFont, LwPuzColor, LwSolColor; }
/*     */ 
/*     */   
/* 403 */   static String[] ld = new String[200];
/*     */   
/* 405 */   enum LD { spare1, spare2, spare3, spare4, spare5,
/* 406 */     spare6, spare7, spare8, spare9, spare10,
/* 407 */     spare11, spare12, spare13, spare14, spare15,
/* 408 */     spare16, spare17, spare18, spare19, spare20,
/* 409 */     spare21, spare22, spare23, spare24, spare25,
/* 410 */     spare26, spare27, spare28, spare29, spare30,
/* 411 */     spare31, spare32, spare33, spare34, spare35,
/* 412 */     spare36, spare37, spare38, spare39, spare40,
/* 413 */     spare41, spare42, spare43, spare44, spare45,
/* 414 */     spare46, spare47, spare48, spare49, spare50,
/* 415 */     spare51, spare52, spare53, spare54, spare55,
/* 416 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 418 */     LdW, LdH, LdCell, LdGrid, LdPattern,
/* 419 */     LdLetter, LdError, LdPuz, LdFont, LdPuzColor,
/* 420 */     LdSolColor; }
/*     */ 
/*     */   
/* 423 */   static String[] ma = new String[200];
/*     */   
/* 425 */   enum MA { spare1, spare2, spare3, spare4, spare5,
/* 426 */     spare6, spare7, spare8, spare9, spare10,
/* 427 */     spare11, spare12, spare13, spare14, spare15,
/* 428 */     spare16, spare17, spare18, spare19, spare20,
/* 429 */     spare21, spare22, spare23, spare24, spare25,
/* 430 */     spare26, spare27, spare28, spare29, spare30,
/* 431 */     spare31, spare32, spare33, spare34, spare35,
/* 432 */     spare36, spare37, spare38, spare39, spare40,
/* 433 */     spare41, spare42, spare43, spare44, spare45,
/* 434 */     spare46, spare47, spare48, spare49, spare50,
/* 435 */     spare51, spare52, spare53, spare54, spare55,
/* 436 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 438 */     MaW, MaH, MaAcross, MaDown, Ma1,
/* 439 */     Ma2, Ma3, Ma4, Ma5, Ma6,
/* 440 */     Ma7, Ma8, MaEmpty, MaNumber, MaLines,
/* 441 */     MaError, MaPuz, MaFont, MaPuzColor, MaSolColor,
/* 442 */     MaRule1, MaRule2, MaRule3, MaRule4, MaRule5; }
/*     */ 
/*     */   
/* 445 */   static String[] ms = new String[200];
/*     */   
/* 447 */   enum MS { spare1, spare2, spare3, spare4, spare5,
/* 448 */     spare6, spare7, spare8, spare9, spare10,
/* 449 */     spare11, spare12, spare13, spare14, spare15,
/* 450 */     spare16, spare17, spare18, spare19, spare20,
/* 451 */     spare21, spare22, spare23, spare24, spare25,
/* 452 */     spare26, spare27, spare28, spare29, spare30,
/* 453 */     spare31, spare32, spare33, spare34, spare35,
/* 454 */     spare36, spare37, spare38, spare39, spare40,
/* 455 */     spare41, spare42, spare43, spare44, spare45,
/* 456 */     spare46, spare47, spare48, spare49, spare50,
/* 457 */     spare51, spare52, spare53, spare54, spare55,
/* 458 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 460 */     MsW, MsH, MsAcross, MsDown, MsDiff,
/* 461 */     MsCell, MsClear, MsFlag, MsNumbers, MsLines,
/* 462 */     MsMine, MsError, MsFuse, MsPuz, MsFont,
/* 463 */     MsPuzColor, MsSolColor, MsRule1, MsRule2, MsRule3,
/* 464 */     MsRule4, MsRule5; }
/*     */ 
/*     */   
/* 467 */   static String[] ob = new String[200];
/*     */   
/* 469 */   enum OB { spare1, spare2, spare3, spare4, spare5,
/* 470 */     spare6, spare7, spare8, spare9, spare10,
/* 471 */     spare11, spare12, spare13, spare14, spare15,
/* 472 */     spare16, spare17, spare18, spare19, spare20,
/* 473 */     spare21, spare22, spare23, spare24, spare25,
/* 474 */     spare26, spare27, spare28, spare29, spare30,
/* 475 */     spare31, spare32, spare33, spare34, spare35,
/* 476 */     spare36, spare37, spare38, spare39, spare40,
/* 477 */     spare41, spare42, spare43, spare44, spare45,
/* 478 */     spare46, spare47, spare48, spare49, spare50,
/* 479 */     spare51, spare52, spare53, spare54, spare55,
/* 480 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 482 */     ObW, ObH, ObPuz,
/* 483 */     ObDic, ObGrid, ObT, ObL, ObShort,
/* 484 */     ObLong, ObSolveW, ObSolveH; }
/*     */ 
/*     */   
/* 487 */   static String[] py = new String[200];
/*     */   
/* 489 */   enum PY { spare1, spare2, spare3, spare4, spare5,
/* 490 */     spare6, spare7, spare8, spare9, spare10,
/* 491 */     spare11, spare12, spare13, spare14, spare15,
/* 492 */     spare16, spare17, spare18, spare19, spare20,
/* 493 */     spare21, spare22, spare23, spare24, spare25,
/* 494 */     spare26, spare27, spare28, spare29, spare30,
/* 495 */     spare31, spare32, spare33, spare34, spare35,
/* 496 */     spare36, spare37, spare38, spare39, spare40,
/* 497 */     spare41, spare42, spare43, spare44, spare45,
/* 498 */     spare46, spare47, spare48, spare49, spare50,
/* 499 */     spare51, spare52, spare53, spare54, spare55,
/* 500 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 502 */     PyW, PyH, PyRows, PyFirstLen, PyCell,
/* 503 */     PyGrid, PyPattern, PyLetter, PyID, PyFocus,
/* 504 */     PyClue, PyError, PyPuz, PyDic, PyFont,
/* 505 */     PyIDFont, PyClueFont, PyPuzColor, PySolColor; }
/*     */ 
/*     */   
/* 508 */   static String[] ra = new String[200];
/*     */   
/* 510 */   enum RA { spare1, spare2, spare3, spare4, spare5,
/* 511 */     spare6, spare7, spare8, spare9, spare10,
/* 512 */     spare11, spare12, spare13, spare14, spare15,
/* 513 */     spare16, spare17, spare18, spare19, spare20,
/* 514 */     spare21, spare22, spare23, spare24, spare25,
/* 515 */     spare26, spare27, spare28, spare29, spare30,
/* 516 */     spare31, spare32, spare33, spare34, spare35,
/* 517 */     spare36, spare37, spare38, spare39, spare40,
/* 518 */     spare41, spare42, spare43, spare44, spare45,
/* 519 */     spare46, spare47, spare48, spare49, spare50,
/* 520 */     spare51, spare52, spare53, spare54, spare55,
/* 521 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 523 */     RaW, RaH, RaAcross, RaDown, RaCell,
/* 524 */     RaCircle, RaGrid, RaPath, RaError, RaPuz,
/* 525 */     RaPuzColor, RaSolColor, RaRule1, RaRule2, RaRule3,
/* 526 */     RaRule4, RaRule5; }
/*     */ 
/*     */   
/* 529 */   static String[] sk = new String[200];
/*     */   
/* 531 */   enum SK { spare1, spare2, spare3, spare4, spare5,
/* 532 */     spare6, spare7, spare8, spare9, spare10,
/* 533 */     spare11, spare12, spare13, spare14, spare15,
/* 534 */     spare16, spare17, spare18, spare19, spare20,
/* 535 */     spare21, spare22, spare23, spare24, spare25,
/* 536 */     spare26, spare27, spare28, spare29, spare30,
/* 537 */     spare31, spare32, spare33, spare34, spare35,
/* 538 */     spare36, spare37, spare38, spare39, spare40,
/* 539 */     spare41, spare42, spare43, spare44, spare45,
/* 540 */     spare46, spare47, spare48, spare49, spare50,
/* 541 */     spare51, spare52, spare53, spare54, spare55,
/* 542 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 544 */     SkW, SkH, SkAcross, SkDown, SkCell,
/* 545 */     SkGrid, SkBorder, SkNumber, SkError, SkPuz,
/* 546 */     SkNumberFont, SkPuzColor, SkSolColor, SkRule1, SkRule2,
/* 547 */     SkRule3, SkRule4, SkRule5; }
/*     */ 
/*     */   
/* 550 */   static String[] sx = new String[200];
/*     */   
/* 552 */   enum SX { SxRuleLang, SxRuleLangIndex, SxDateFormat, SxDateFormatIndex, spare5,
/* 553 */     spare6, spare7, spare8, spare9, spare10,
/* 554 */     spare11, spare12, spare13, spare14, spare15,
/* 555 */     spare16, spare17, spare18, spare19, spare20,
/* 556 */     spare21, spare22, spare23, spare24, spare25,
/* 557 */     spare26, spare27, spare28, spare29, spare30,
/* 558 */     spare31, spare32, spare33, spare34, spare35,
/* 559 */     spare36, spare37, spare38, spare39, spare40,
/* 560 */     spare41, spare42, spare43, spare44, spare45,
/* 561 */     spare46, spare47, spare48, spare49, spare50,
/* 562 */     spare51, spare52, spare53, spare54, spare55,
/* 563 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 565 */     SxW, SxH, SxPuzA, SxPuzB, SxPuzC,
/* 566 */     SxPuzD, SxPuzE, SxPuzF, SxPuzColor, SxSolColor,
/* 567 */     VaryDiff, SxInstructions, SxLang1, SxLang2, SxLang3,
/* 568 */     SxLang4, SxLang5, SxLang6, SxLang7, SxLang8,
/* 569 */     SxLang9, SxLang10, SxPuzTitle, SxSolTitle, SxAk,
/* 570 */     SxDm, SxFi, SxFu, SxGk, SxKk,
/* 571 */     SxKe, SxMa, SxMs, SxRa, SxSk,
/* 572 */     SxSl, SxSu, SxTt, SxTe; }
/*     */ 
/*     */   
/* 575 */   static String[] sl = new String[200];
/*     */   
/* 577 */   enum SL { spare1, spare2, spare3, spare4, spare5,
/* 578 */     spare6, spare7, spare8, spare9, spare10,
/* 579 */     spare11, spare12, spare13, spare14, spare15,
/* 580 */     spare16, spare17, spare18, spare19, spare20,
/* 581 */     spare21, spare22, spare23, spare24, spare25,
/* 582 */     spare26, spare27, spare28, spare29, spare30,
/* 583 */     spare31, spare32, spare33, spare34, spare35,
/* 584 */     spare36, spare37, spare38, spare39, spare40,
/* 585 */     spare41, spare42, spare43, spare44, spare45,
/* 586 */     spare46, spare47, spare48, spare49, spare50,
/* 587 */     spare51, spare52, spare53, spare54, spare55,
/* 588 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 590 */     SlW, SlH, SlAcross, SlDown, SlLine,
/* 591 */     SlBg, SlGrid, SlNumber, SlError, SlPuz,
/* 592 */     SlTemplate, SlFont, SlPuzColor, SlSolColor, SlSym,
/* 593 */     SlRule1, SlRule2, SlRule3, SlRule4, SlRule5; }
/*     */ 
/*     */   
/* 596 */   static String[] su = new String[200];
/*     */   
/* 598 */   enum SU { spare1, spare2, spare3, spare4, spare5,
/* 599 */     spare6, spare7, spare8, spare9, spare10,
/* 600 */     spare11, spare12, spare13, spare14, spare15,
/* 601 */     spare16, spare17, spare18, spare19, spare20,
/* 602 */     spare21, spare22, spare23, spare24, spare25,
/* 603 */     spare26, spare27, spare28, spare29, spare30,
/* 604 */     spare31, spare32, spare33, spare34, spare35,
/* 605 */     spare36, spare37, spare38, spare39, spare40,
/* 606 */     spare41, spare42, spare43, spare44, spare45,
/* 607 */     spare46, spare47, spare48, spare49, spare50,
/* 608 */     spare51, spare52, spare53, spare54, spare55,
/* 609 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 611 */     SuW, SuH, SuDifficulty, SuCell, SuHilite,
/* 612 */     SuBorder, SuGrid, SuNumber, SuGuide, SuError,
/* 613 */     SuPuz, SuSet, SuFont, SuGuideFont, SuPuzColor,
/* 614 */     SuSolColor, SuGuideBg, SuRule1, SuRule2, SuRule3,
/* 615 */     SuRule4, SuRule5; }
/*     */ 
/*     */   
/* 618 */   static String[] te = new String[200];
/*     */   
/* 620 */   enum TE { spare1, spare2, spare3, spare4, spare5,
/* 621 */     spare6, spare7, spare8, spare9, spare10,
/* 622 */     spare11, spare12, spare13, spare14, spare15,
/* 623 */     spare16, spare17, spare18, spare19, spare20,
/* 624 */     spare21, spare22, spare23, spare24, spare25,
/* 625 */     spare26, spare27, spare28, spare29, spare30,
/* 626 */     spare31, spare32, spare33, spare34, spare35,
/* 627 */     spare36, spare37, spare38, spare39, spare40,
/* 628 */     spare41, spare42, spare43, spare44, spare45,
/* 629 */     spare46, spare47, spare48, spare49, spare50,
/* 630 */     spare51, spare52, spare53, spare54, spare55,
/* 631 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 633 */     TeW, TeH, TeAcross, TeDown, TeDifficulty,
/* 634 */     TeCell, TeLine, TeTree, TeTrunk, TeTent,
/* 635 */     TeCount, TeError, TePuz, TeCountFont, TePuzColor,
/* 636 */     TeSolColor, TeRule1, TeRule2, TeRule3, TeRule4,
/* 637 */     TeRule5; }
/*     */ 
/*     */   
/* 640 */   static String[] tt = new String[200];
/*     */   
/* 642 */   enum TT { spare1, spare2, spare3, spare4, spare5,
/* 643 */     spare6, spare7, spare8, spare9, spare10,
/* 644 */     spare11, spare12, spare13, spare14, spare15,
/* 645 */     spare16, spare17, spare18, spare19, spare20,
/* 646 */     spare21, spare22, spare23, spare24, spare25,
/* 647 */     spare26, spare27, spare28, spare29, spare30,
/* 648 */     spare31, spare32, spare33, spare34, spare35,
/* 649 */     spare36, spare37, spare38, spare39, spare40,
/* 650 */     spare41, spare42, spare43, spare44, spare45,
/* 651 */     spare46, spare47, spare48, spare49, spare50,
/* 652 */     spare51, spare52, spare53, spare54, spare55,
/* 653 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 655 */     TtW, TtH, TtAcross, TtDown, TtCell,
/* 656 */     TtGrid, TtTile, TtNumbers, TtError, TtPuz,
/* 657 */     TtFont, TtPuzColor, TtSolColor, TtRule1, TtRule2,
/* 658 */     TtRule3, TtRule4, TtRule5; }
/*     */ 
/*     */   
/* 661 */   static String[] ws = new String[200];
/*     */   
/* 663 */   enum WS { spare1, spare2, spare3, spare4, spare5,
/* 664 */     spare6, spare7, spare8, spare9, spare10,
/* 665 */     spare11, spare12, spare13, spare14, spare15,
/* 666 */     spare16, spare17, spare18, spare19, spare20,
/* 667 */     spare21, spare22, spare23, spare24, spare25,
/* 668 */     spare26, spare27, spare28, spare29, spare30,
/* 669 */     spare31, spare32, spare33, spare34, spare35,
/* 670 */     spare36, spare37, spare38, spare39, spare40,
/* 671 */     spare41, spare42, spare43, spare44, spare45,
/* 672 */     spare46, spare47, spare48, spare49, spare50,
/* 673 */     spare51, spare52, spare53, spare54, spare55,
/* 674 */     spare56, spare57, spare58, spare59, spare60,
/*     */     
/* 676 */     WsW, WsH, WsSolveW, WsSolveH, WsAcross,
/* 677 */     WsDown, WsDirMask, WsBackground, WsBorder, WsLoop,
/* 678 */     WsLetter, WsSlvHilite, WsClue, WsMsgHilite, WsPuz,
/* 679 */     WsDic, WsTemplate, WsMessage, WsFont, WsClueFont,
/* 680 */     WsPuzColor, WsSolColor, WsHint, WsMsgBody, WsShort,
/* 681 */     WsLong; }
/*     */ 
/*     */   
/*     */   static void loadAllOptions() {
/* 685 */     loadOptions("miscellaneous.opt", msc, 0);
/* 686 */     loadOptions("crossword.opt", cw, 4);
/* 687 */     loadOptions("devanagari.opt", dv, 220);
/* 688 */     loadOptions("wordsquare.opt", sw, 210);
/* 689 */     loadOptions("acrostic.opt", ac, 10);
/* 690 */     loadOptions("akari.opt", ak, 20);
/* 691 */     loadOptions("codeword.opt", cd, 30);
/* 692 */     loadOptions("domino.opt", dm, 40);
/* 693 */     loadOptions("doublet.opt", db, 50);
/* 694 */     loadOptions("fillin.opt", fl, 60);
/* 695 */     loadOptions("fillomino.opt", fi, 70);
/* 696 */     loadOptions("findaquote.opt", fq, 72);
/* 697 */     loadOptions("freeform.opt", ff, 6);
/* 698 */     loadOptions("futoshiki.opt", fu, 80);
/* 699 */     loadOptions("gokigen.opt", gk, 90);
/* 700 */     loadOptions("kakuro.opt", kk, 100);
/* 701 */     loadOptions("kendoku.opt", ke, 110);
/* 702 */     loadOptions("ksudoku.opt", ks, 112);
/* 703 */     loadOptions("ladderword.opt", lw, 120);
/* 704 */     loadOptions("letterdrop.opt", ld, 130);
/* 705 */     loadOptions("marupeke.opt", ma, 230);
/* 706 */     loadOptions("minesweeper.opt", ms, 132);
/* 707 */     loadOptions("ouroboros.opt", ob, 134);
/* 708 */     loadOptions("pyramidword.opt", py, 140);
/* 709 */     loadOptions("roundabouts.opt", ra, 150);
/* 710 */     loadOptions("sikaku.opt", sk, 160);
/* 711 */     loadOptions("sixpack.opt", sx, 8);
/* 712 */     loadOptions("slitherlink.opt", sl, 170);
/* 713 */     loadOptions("sudoku.opt", su, 180);
/* 714 */     loadOptions("tatami.opt", tt, 182);
/* 715 */     loadOptions("tents.opt", te, 190);
/* 716 */     loadOptions("wordsearch.opt", ws, 200);
/*     */   }
/*     */   
/*     */   static void defaultOptions() {
/* 720 */     defaultAll = Boolean.valueOf(true);
/*     */     
/* 722 */     CrosswordExpress.def(); saveOptions("miscellaneous.opt", msc);
/* 723 */     CrosswordBuild.def(); saveOptions("crossword.opt", cw);
/* 724 */     DevanagariBuild.def(); saveOptions("devanagari.opt", dv);
/* 725 */     WordsquareBuild.def(); saveOptions("wordsquare.opt", sw);
/* 726 */     AcrosticBuild.def(); saveOptions("acrostic.opt", ac);
/* 727 */     AkariBuild.def(); saveOptions("akari.opt", ak);
/* 728 */     CodewordSolve.def(); saveOptions("codeword.opt", cd);
/* 729 */     DominoBuild.def(); saveOptions("domino.opt", dm);
/* 730 */     DoubletBuild.def(); saveOptions("doublet.opt", db);
/* 731 */     FillinSolve.def(); saveOptions("fillin.opt", fl);
/* 732 */     FillominoBuild.def(); saveOptions("fillomino.opt", fi);
/* 733 */     FindAQuote.def(); saveOptions("findaquote.opt", fq);
/* 734 */     FreeformBuild.def(); saveOptions("freeform.opt", ff);
/* 735 */     FutoshikiBuild.def(); saveOptions("futoshiki.opt", fu);
/* 736 */     GokigenBuild.def(); saveOptions("gokigen.opt", gk);
/* 737 */     KakuroBuild.def(); saveOptions("kakuro.opt", kk);
/* 738 */     KendokuBuild.def(); saveOptions("kendoku.opt", ke);
/* 739 */     KsudokuBuild.def(); saveOptions("ksudoku.opt", ks);
/* 740 */     LadderwordBuild.def(); saveOptions("ladderword.opt", lw);
/* 741 */     LetterdropBuild.def(); saveOptions("letterdrop.opt", ld);
/* 742 */     MarupekeBuild.def(); saveOptions("marupeke.opt", ma);
/* 743 */     MinesweeperBuild.def(); saveOptions("minesweeper.opt", ms);
/* 744 */     OuroborosBuild.def(); saveOptions("ouroboros.opt", ob);
/* 745 */     PyramidwordBuild.def(); saveOptions("pyramidword.opt", py);
/* 746 */     RoundaboutsBuild.def(); saveOptions("roundabouts.opt", ra);
/* 747 */     SikakuBuild.def(); saveOptions("sikaku.opt", sk);
/* 748 */     Sixpack.def(); saveOptions("sixpack.opt", sx);
/* 749 */     SlitherlinkBuild.def(); saveOptions("slitherlink.opt", sl);
/* 750 */     SudokuBuild.def(); saveOptions("sudoku.opt", su);
/* 751 */     TatamiBuild.def(); saveOptions("tatami.opt", tt);
/* 752 */     TentsBuild.def(); saveOptions("tents.opt", te);
/* 753 */     WordsearchBuild.def(); saveOptions("wordsearch.opt", ws);
/*     */     
/* 755 */     defaultAll = Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadOptions(String file, String[] opts, int puzMode) {
/* 764 */     File fil = new File("option");
/* 765 */     if (!fil.exists()) {
/* 766 */       fil.mkdir();
/*     */     }
/*     */     try {
/* 769 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("option/" + file));
/* 770 */       for (int i = 0; i < 200; i++) {
/* 771 */         opts[i] = dataIn.readUTF();
/*     */       }
/* 773 */       dataIn.close();
/*     */     }
/* 775 */     catch (IOException exc) {
/*     */       
/* 777 */       for (int i = 0; i < 200; i++)
/* 778 */         opts[i] = ""; 
/*     */     } 
/* 780 */     switch (puzMode) { case 0:
/* 781 */         CrosswordExpress.def(); break;
/* 782 */       case 10: AcrosticBuild.def(); break;
/* 783 */       case 20: AkariBuild.def(); break;
/* 784 */       case 30: CodewordSolve.def(); break;
/* 785 */       case 4: CrosswordBuild.def(); break;
/* 786 */       case 220: DevanagariBuild.def(); break;
/* 787 */       case 210: WordsquareBuild.def(); break;
/* 788 */       case 40: DominoBuild.def(); break;
/* 789 */       case 50: DoubletBuild.def(); break;
/* 790 */       case 72: FindAQuote.def(); break;
/* 791 */       case 60: FillinSolve.def(); break;
/* 792 */       case 70: FillominoBuild.def(); break;
/* 793 */       case 6: FreeformBuild.def(); break;
/* 794 */       case 80: FutoshikiBuild.def(); break;
/* 795 */       case 90: GokigenBuild.def(); break;
/* 796 */       case 100: KakuroBuild.def(); break;
/* 797 */       case 110: KendokuBuild.def(); break;
/* 798 */       case 112: KsudokuBuild.def(); break;
/* 799 */       case 120: LadderwordBuild.def(); break;
/* 800 */       case 130: LetterdropBuild.def(); break;
/* 801 */       case 230: MarupekeBuild.def(); break;
/* 802 */       case 132: MinesweeperBuild.def(); break;
/* 803 */       case 134: OuroborosBuild.def(); break;
/* 804 */       case 140: PyramidwordBuild.def(); break;
/* 805 */       case 150: RoundaboutsBuild.def(); break;
/* 806 */       case 160: SikakuBuild.def(); break;
/* 807 */       case 8: Sixpack.def(); break;
/* 808 */       case 170: SlitherlinkBuild.def(); break;
/* 809 */       case 180: SudokuBuild.def(); break;
/* 810 */       case 182: TatamiBuild.def(); break;
/* 811 */       case 190: TentsBuild.def(); break;
/* 812 */       case 200: WordsearchBuild.def(); break; }
/*     */     
/* 814 */     saveOptions(file, opts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void saveOptions(String file, String[] opts) {
/*     */     try {
/* 822 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("option/" + file));
/* 823 */       for (int i = 0; i < 200; i++)
/* 824 */         dataOut.writeUTF(opts[i]); 
/* 825 */       dataOut.close();
/*     */     }
/* 827 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */   
/*     */   static void updateOption(int opIndex, String opVal, String[] opts) {
/* 832 */     if (defaultAll.booleanValue()) {
/* 833 */       opts[opIndex] = opVal;
/*     */     }
/* 835 */     else if (opts[opIndex].length() == 0) {
/* 836 */       opts[opIndex] = opVal;
/*     */     } 
/*     */   }
/*     */   static void setColorInt(int opIndex, int color, String[] opts) {
/* 840 */     String str = Integer.toHexString(color);
/* 841 */     while (str.length() < 6)
/* 842 */       str = "0" + str; 
/* 843 */     opts[opIndex] = str;
/*     */   }
/*     */   
/*     */   static int getColorInt(int opIndex, String[] opts) {
/* 847 */     return Integer.parseInt(opts[opIndex], 16);
/*     */   }
/*     */   
/*     */   static void setInt(int opIndex, int value, String[] opts) {
/* 851 */     String str = Integer.toString(value);
/* 852 */     opts[opIndex] = str;
/*     */   }
/*     */   
/*     */   static int getInt(int opIndex, String[] opts) {
/* 856 */     return Integer.parseInt(opts[opIndex]);
/*     */   }
/*     */   
/*     */   static void setBool(int opIndex, Boolean bool, String[] opts) {
/* 860 */     opts[opIndex] = bool.booleanValue() ? "true" : "false";
/*     */   }
/*     */   
/*     */   static Boolean getBool(int opIndex, String[] opts) {
/* 864 */     return Boolean.valueOf((opts[opIndex].compareToIgnoreCase("true") == 0));
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Op.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */