/*      */ package crosswordexpress;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ 
/*      */ public class OuroborosBuild extends JPanel {
/*      */   static JFrame jfOuroboros;
/*      */   static JPanel pp;
/*      */   static int panelW;
/*      */   static int panelH;
/*   18 */   static int[] wordCount = new int[50]; static JMenuBar menuBar; JMenu menu; JMenu submenu; JMenuItem menuItem; JMenuItem buildMenuItem;
/*   19 */   static String[][][] dicWord = new String[2][50][];
/*   20 */   static int[][] revLink = new int[50][];
/*   21 */   static boolean[][] busy = new boolean[50][];
/*   22 */   static cellDat[] cellSpec = new cellDat[400];
/*      */   static int numCells;
/*      */   static String seed;
/*   25 */   static String letters = ""; static boolean clickedOK;
/*      */   String grid;
/*      */   static JLabel jl1;
/*      */   static JLabel jl2;
/*      */   Thread thread;
/*   30 */   static int howMany = 1; static int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); static int hmCount;
/*      */   static int abandon;
/*   32 */   String ouroborosHelp = "<div>You may recognise the word OUROBOROS as being the name of the ancient symbol showing a snake swallowing its tail and there is an element of that idea in this puzzle. The template on which the puzzle is built is really just an unbroken loop, and the words are placed into this loop with each word starting in the cell which immediately follows the previous word. However, a loop can be traversed in two directions, and regardless of the direction of traversal, an unbroken series of words will be read out. The words are different for each direction of traversal, but exactly the same letters are used, regardless of the direction. There are many similarities between this and the more familiar example of a palindrome.</div><br/><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Select a Dictionary</span><br/>When loading a new puzzle into the Build screen, you begin by selecting the dictionary which was used to build the OUROBOROS puzzle which you want to load.<p/><li/><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of OUROBOROS puzzles currently available in the selected dictionary.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the folder of the dictionary that was used to construct it. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Title, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Select a Dictionary</span><br/>Use this option to select the dictionary which you want to use to build the new OUROBOROS puzzle. It is recommended that you use the ourobors dictionary which contains only words which are of a form which can fit into an ouroboros puzzle. This dictionary doesn't contain any clues, so you should use the <b>Tasks / Edit clues</b> to add suitable clues and when you are satisfied with the puzzle, use the <b>Tasks / Transfer Puzzle Clues to Dictionary</b> to update the dictionary. This will gradually populate the dictionary with clues which will automatically be included in any future puzzles you construct.<p/><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Select a Template</span><br/>Ouroboros puzzles are built on a predefined template, and you can select the one you want to use with this option. Several suitable templates are provided with the program, or you can build an unlimited number of additional templates using the <b>Grid Maintenance</b> button on the Crossword Express opening screen.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Edit clues</span><br/>This function allows you to quickly review the clues that have been selected for this puzzle. If any of them are not to your liking, or indeed if they are missing altogether, it also provides the option of editing the existing clue, entering a suitable one.<p/><li/><span>Transfer Puzzle Clues to Dictionary</span><br/>If you have used the <b>Edit Clues</b> function to modify existing clues, or to add clues to clueless words, you may wish to save the alterations to the dictionary. This option will find all such changes, and merge them into the dictionary that was used to construct the puzzle.<p/><li/><span>Print Ouroboros</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/></ul><li/><span class='s'>Help Menu</span><ul><li/><span>Ouroboros Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   static String optionsHelp = "<div>Before you give the command to build the <b>Ouroboros</b> puzzle, you can set some options which the program will use during the construction process.<br/><br/></div><ul><li/>Two selection boxes allow you to specify both the <b>Shortest</b> and the <b>Longest</b> word which are permitted to be used in constructing the puzzle.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*  111 */     Op.updateOption(Op.OB.ObW.ordinal(), "600", Op.ob);
/*  112 */     Op.updateOption(Op.OB.ObH.ordinal(), "680", Op.ob);
/*  113 */     Op.updateOption(Op.OB.ObPuz.ordinal(), "2.ouroboros", Op.ob);
/*  114 */     Op.updateOption(Op.OB.ObDic.ordinal(), "ouroboros", Op.ob);
/*  115 */     Op.updateOption(Op.OB.ObGrid.ordinal(), "ouroboros1.template", Op.ob);
/*  116 */     Op.updateOption(Op.OB.ObT.ordinal(), "0", Op.ob);
/*  117 */     Op.updateOption(Op.OB.ObL.ordinal(), "0", Op.ob);
/*  118 */     Op.updateOption(Op.OB.ObShort.ordinal(), "4", Op.ob);
/*  119 */     Op.updateOption(Op.OB.ObLong.ordinal(), "5", Op.ob);
/*  120 */     Op.updateOption(Op.OB.ObSolveW.ordinal(), "800", Op.ob);
/*  121 */     Op.updateOption(Op.OB.ObSolveH.ordinal(), "800", Op.ob);
/*      */   }
/*      */   
/*      */   OuroborosBuild(JFrame jf) {
/*  125 */     Def.puzzleMode = 134;
/*  126 */     Def.building = 0;
/*  127 */     Methods.havePuzzle = false;
/*      */     
/*  129 */     Grid.loadGrid(Op.ob[Op.OB.ObGrid.ordinal()]);
/*  130 */     setPoints();
/*      */     
/*  132 */     jfOuroboros = new JFrame("Build Ouroboros Puzzles");
/*  133 */     if (Op.getInt(Op.OB.ObH.ordinal(), Op.ob) > Methods.scrH - 200) {
/*  134 */       int diff = Op.getInt(Op.OB.ObH.ordinal(), Op.ob) - Op.getInt(Op.OB.ObW.ordinal(), Op.ob);
/*  135 */       Op.setInt(Op.OB.ObH.ordinal(), Methods.scrH - 200, Op.ob);
/*  136 */       Op.setInt(Op.OB.ObW.ordinal(), Methods.scrH - 200 + diff, Op.ob);
/*      */     } 
/*  138 */     jfOuroboros.setSize(Op.getInt(Op.OB.ObW.ordinal(), Op.ob), Op.getInt(Op.OB.ObH.ordinal(), Op.ob));
/*      */     
/*  140 */     int frameX = (jf.getX() + jfOuroboros.getWidth() > Methods.scrW) ? (Methods.scrW - jfOuroboros.getWidth() - 10) : jf.getX();
/*  141 */     jfOuroboros.setLocation(frameX, jf.getY());
/*  142 */     jfOuroboros.setLayout((LayoutManager)null);
/*  143 */     jfOuroboros.setDefaultCloseOperation(0);
/*      */     
/*  145 */     jfOuroboros
/*  146 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  148 */             int oldw = Op.getInt(Op.OB.ObT.ordinal(), Op.ob);
/*  149 */             int oldh = Op.getInt(Op.OB.ObL.ordinal(), Op.ob);
/*  150 */             Methods.frameResize(OuroborosBuild.jfOuroboros, oldw, oldh, 600, 680);
/*  151 */             Op.setInt(Op.OB.ObT.ordinal(), OuroborosBuild.jfOuroboros.getWidth(), Op.ob);
/*  152 */             Op.setInt(Op.OB.ObL.ordinal(), OuroborosBuild.jfOuroboros.getHeight(), Op.ob);
/*  153 */             OuroborosBuild.restoreFrame();
/*      */           }
/*      */           public void componentMoved(ComponentEvent ce) {
/*  156 */             Op.setInt(Op.OB.ObT.ordinal(), OuroborosBuild.jfOuroboros.getY(), Op.ob);
/*  157 */             Op.setInt(Op.OB.ObL.ordinal(), OuroborosBuild.jfOuroboros.getX(), Op.ob);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  162 */     jfOuroboros
/*  163 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  165 */             if (Def.building == 1 || Def.selecting)
/*      */               return; 
/*  167 */             Op.saveOptions("ouroboros.opt", Op.ob);
/*  168 */             CrosswordExpress.transfer(1, OuroborosBuild.jfOuroboros);
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  174 */     Runnable buildThread = () -> {
/*      */         buildOuroboros((howMany > 1));
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           restoreFrame();
/*      */           Methods.interrupted(jfOuroboros);
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()] = Methods.theFileName);
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfOuroboros, Op.ob[Op.OB.ObDic.ordinal()], Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  189 */     jl1 = new JLabel(); jfOuroboros.add(jl1);
/*  190 */     jl2 = new JLabel(); jfOuroboros.add(jl2);
/*      */     
/*  192 */     menuBar = new JMenuBar();
/*  193 */     jfOuroboros.setJMenuBar(menuBar);
/*  194 */     this.menu = new JMenu("File");
/*  195 */     menuBar.add(this.menu);
/*  196 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  197 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  198 */     this.menu.add(this.menuItem);
/*  199 */     this.menuItem
/*  200 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.selectDictionary(jfOuroboros, Op.ob[Op.OB.ObDic.ordinal()], 1);
/*      */           Op.ob[Op.OB.ObDic.ordinal()] = Methods.dictionaryName;
/*      */           loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  209 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  210 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  211 */     this.menu.add(this.menuItem);
/*  212 */     this.menuItem
/*  213 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return;  pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfOuroboros, Op.ob[Op.OB.ObDic.ordinal()] + ".dic", "ouroboros", Op.ob, Op.OB.ObPuz.ordinal(), false);
/*      */         });
/*  219 */     this.menuItem = new JMenuItem("SaveAs");
/*  220 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  221 */     this.menu.add(this.menuItem);
/*  222 */     this.menuItem
/*  223 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.puzzleDescriptionDialog(jfOuroboros, Op.ob[Op.OB.ObPuz.ordinal()].substring(0, Op.ob[Op.OB.ObPuz.ordinal()].indexOf(".ouroboros")), Op.ob[Op.OB.ObDic.ordinal()] + ".dic", ".ouroboros");
/*      */           if (Methods.clickedOK) {
/*      */             saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfOuroboros, Op.ob[Op.OB.ObDic.ordinal()] + ".dic", Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  235 */     this.menuItem = new JMenuItem("Quit Construction", 81);
/*  236 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  237 */     this.menu.add(this.menuItem);
/*  238 */     this.menuItem
/*  239 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("ouroboros.opt", Op.ob);
/*      */           
/*      */           CrosswordExpress.transfer(1, jfOuroboros);
/*      */         });
/*  248 */     this.menu = new JMenu("Build");
/*  249 */     menuBar.add(this.menu);
/*  250 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  251 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  252 */     this.menu.add(this.menuItem);
/*  253 */     this.menuItem
/*  254 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.selectDictionary(jfOuroboros, Op.ob[Op.OB.ObDic.ordinal()], 1);
/*      */           Op.ob[Op.OB.ObDic.ordinal()] = Methods.dictionaryName;
/*      */           loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  263 */     this.menuItem = new JMenuItem("Start a New Puzzle");
/*  264 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  265 */     this.menu.add(this.menuItem);
/*  266 */     this.menuItem
/*  267 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.puzzleDescriptionDialog(jfOuroboros, Op.ob[Op.OB.ObPuz.ordinal()].substring(0, Op.ob[Op.OB.ObPuz.ordinal()].indexOf(".ouroboros")), Op.ob[Op.OB.ObDic.ordinal()] + ".dic", ".ouroboros");
/*      */           if (Methods.clickedOK) {
/*      */             Op.ob[Op.OB.ObPuz.ordinal()] = Methods.theFileName;
/*      */             Methods.havePuzzle = false;
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  279 */     this.menuItem = new JMenuItem("Select a Template");
/*  280 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(71, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  281 */     this.menu.add(this.menuItem);
/*  282 */     this.menuItem
/*  283 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Def.dispNullCells = Boolean.valueOf(true);
/*      */           Def.dispCursor = Boolean.valueOf(false);
/*      */           Def.dispSolArray = Boolean.valueOf(true);
/*      */           Def.puzzleMode = 2;
/*      */           JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/grids");
/*      */           chooser.setFileFilter(new FileNameExtensionFilter("Template", new String[] { "template" }));
/*      */           chooser.setSelectedFile(new File(Op.ob[Op.OB.ObGrid.ordinal()]));
/*      */           chooser.setAccessory(new Preview(chooser));
/*      */           if (chooser.showDialog(jfOuroboros, "Select Template") == 0) {
/*      */             this.grid = chooser.getSelectedFile().getName();
/*      */           }
/*      */           Def.puzzleMode = 134;
/*      */           if (this.grid.length() != 0) {
/*      */             Op.ob[Op.OB.ObGrid.ordinal()] = this.grid;
/*      */             Methods.havePuzzle = false;
/*      */           } 
/*      */           Grid.loadGrid(Op.ob[Op.OB.ObGrid.ordinal()]);
/*      */           Def.dispSolArray = Boolean.valueOf(false);
/*      */           Def.dispCursor = Boolean.valueOf(true);
/*      */           Def.dispNullCells = Boolean.valueOf(false);
/*      */           setPoints();
/*      */           restoreFrame();
/*      */         });
/*  310 */     this.menuItem = new JMenuItem("Build Options");
/*  311 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  312 */     this.menu.add(this.menuItem);
/*  313 */     this.menuItem
/*  314 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           ouroborosOptions();
/*      */           if (Methods.clickedOK && howMany > 1)
/*      */             Op.ob[Op.OB.ObPuz.ordinal()] = "" + startPuz + ".ouroboros"; 
/*      */           restoreFrame();
/*      */         });
/*  322 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  323 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  324 */     this.menu.add(this.buildMenuItem);
/*  325 */     this.buildMenuItem
/*  326 */       .addActionListener(ae -> {
/*      */           if (Op.ob[Op.OB.ObPuz.ordinal()].length() == 0 && howMany == 1) {
/*      */             Methods.noName(jfOuroboros);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  343 */     this.menu = new JMenu("Tasks");
/*  344 */     menuBar.add(this.menu);
/*  345 */     this.menuItem = new JMenuItem("Edit Clues");
/*  346 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  347 */     this.menu.add(this.menuItem);
/*  348 */     this.menuItem
/*  349 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Op.msc[Op.MSC.WordToolsDic.ordinal()] = Op.ob[Op.OB.ObDic.ordinal()];
/*      */           Methods.editClues(jfOuroboros, "Ouroboros");
/*      */           restoreFrame();
/*      */         });
/*  357 */     this.menuItem = new JMenuItem("Transfer Puzzle Clues to Dictionary");
/*  358 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(84, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  359 */     this.menu.add(this.menuItem);
/*  360 */     this.menuItem
/*  361 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (!Methods.havePuzzle) {
/*      */             Methods.noPuzzle(jfOuroboros, "Move Clues");
/*      */             
/*      */             return;
/*      */           } 
/*      */           Methods.moveCluesToDic(Op.ob[Op.OB.ObDic.ordinal()]);
/*      */           JOptionPane.showMessageDialog(jfOuroboros, "<html><center>The clues used in this puzzle<br>have been moved to the <font color=880000>" + Op.ob[Op.OB.ObDic.ordinal()] + "</font> dictionary");
/*      */           restoreFrame();
/*      */         });
/*  375 */     this.menuItem = new JMenuItem("Print Ouroboros");
/*  376 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  377 */     this.menu.add(this.menuItem);
/*  378 */     this.menuItem
/*  379 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Def.puzzleMode = 134;
/*      */           CrosswordExpress.toPrint(jfOuroboros, Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */         });
/*  387 */     this.menuItem = new JMenuItem("Solve Ouroboros");
/*  388 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  389 */     this.menu.add(this.menuItem);
/*  390 */     this.menuItem
/*  391 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(135, jfOuroboros);
/*      */           } else {
/*      */             Methods.noPuzzle(jfOuroboros, "Solve");
/*      */           } 
/*      */         });
/*  402 */     this.menu = new JMenu("Help");
/*  403 */     menuBar.add(this.menu);
/*  404 */     this.menuItem = new JMenuItem("Ouroboros Help");
/*  405 */     this.menu.add(this.menuItem);
/*  406 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  407 */     this.menuItem
/*  408 */       .addActionListener(ae -> Methods.cweHelp(jfOuroboros, null, "Building Ouroboros Puzzles", this.ouroborosHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  413 */     if (loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]))
/*  414 */       Methods.havePuzzle = true; 
/*  415 */     pp = new OuroborosPP(0, 37, jfOuroboros);
/*      */     
/*  417 */     pp
/*  418 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  420 */             if (Def.isMac) {
/*  421 */               OuroborosBuild.jfOuroboros.setResizable((OuroborosBuild.jfOuroboros.getWidth() - e.getX() < 15 && OuroborosBuild.jfOuroboros
/*  422 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  427 */     restoreFrame();
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  431 */     jfOuroboros.setVisible(true);
/*  432 */     Insets insets = jfOuroboros.getInsets();
/*  433 */     panelW = jfOuroboros.getWidth() - insets.left + insets.right;
/*  434 */     panelH = jfOuroboros.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  435 */     pp.setSize(panelW, panelH);
/*  436 */     jfOuroboros.requestFocusInWindow();
/*  437 */     pp.repaint();
/*  438 */     Methods.infoPanel(jl1, jl2, "Build Ouroboros", "Dictionary : " + Op.ob[Op.OB.ObDic.ordinal()] + "  -|-  Puzzle : " + Op.ob[Op.OB.ObPuz
/*  439 */           .ordinal()], jfOuroboros.getWidth());
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  443 */     int i = (width - inset) / Grid.xSz;
/*  444 */     int j = (height - inset) / Grid.ySz;
/*  445 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  446 */     Grid.xOrg = x + 10;
/*  447 */     Grid.yOrg = y + 10;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void ouroborosOptions() {
/*  454 */     final JDialog jdlgOuroboros = new JDialog(jfOuroboros, "Ouroboros Options", true);
/*  455 */     jdlgOuroboros.setSize(260, 140);
/*  456 */     jdlgOuroboros.setResizable(false);
/*  457 */     jdlgOuroboros.setLayout((LayoutManager)null);
/*  458 */     jdlgOuroboros.setLocation(jfOuroboros.getX(), jfOuroboros.getY());
/*      */     
/*  460 */     JLabel jlShort = new JLabel("Shortest word to use:");
/*  461 */     jlShort.setForeground(Def.COLOR_LABEL);
/*  462 */     jlShort.setSize(200, 20);
/*  463 */     jlShort.setLocation(25, 10);
/*  464 */     jlShort.setHorizontalAlignment(2);
/*  465 */     jdlgOuroboros.add(jlShort);
/*      */     
/*  467 */     final JComboBox<Integer> jcbbShort = new JComboBox<>(); int i;
/*  468 */     for (i = 4; i <= 6; i++)
/*  469 */       jcbbShort.addItem(Integer.valueOf(i)); 
/*  470 */     jcbbShort.setSize(60, 23);
/*  471 */     jcbbShort.setLocation(175, 10);
/*  472 */     jcbbShort.setBackground(Def.COLOR_BUTTONBG);
/*  473 */     jcbbShort.setSelectedIndex(Op.getInt(Op.OB.ObShort.ordinal(), Op.ob) - 4);
/*  474 */     jdlgOuroboros.add(jcbbShort);
/*      */     
/*  476 */     JLabel jlLong = new JLabel("Longest word to use:");
/*  477 */     jlLong.setForeground(Def.COLOR_LABEL);
/*  478 */     jlLong.setSize(200, 20);
/*  479 */     jlLong.setLocation(25, 40);
/*  480 */     jlLong.setHorizontalAlignment(2);
/*  481 */     jdlgOuroboros.add(jlLong);
/*      */     
/*  483 */     final JComboBox<Integer> jcbbLong = new JComboBox<>();
/*  484 */     for (i = 5; i <= 12; i++)
/*  485 */       jcbbLong.addItem(Integer.valueOf(i)); 
/*  486 */     jcbbLong.setSize(60, 23);
/*  487 */     jcbbLong.setLocation(175, 40);
/*  488 */     jcbbLong.setBackground(Def.COLOR_BUTTONBG);
/*  489 */     jcbbLong.setSelectedIndex(Op.getInt(Op.OB.ObLong.ordinal(), Op.ob) - 5);
/*  490 */     jdlgOuroboros.add(jcbbLong);
/*      */     
/*  492 */     Action doOK = new AbstractAction("OK")
/*      */       {
/*      */         public void actionPerformed(ActionEvent e)
/*      */         {
/*  496 */           Op.setInt(Op.OB.ObShort.ordinal(), jcbbShort.getSelectedIndex() + 4, Op.ob);
/*  497 */           Op.setInt(Op.OB.ObLong.ordinal(), jcbbLong.getSelectedIndex() + 5, Op.ob);
/*  498 */           Methods.clickedOK = true;
/*  499 */           jdlgOuroboros.dispose();
/*      */         }
/*      */       };
/*  502 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 70, 80, 26);
/*  503 */     jdlgOuroboros.add(jbOK);
/*      */     
/*  505 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  507 */           Methods.clickedOK = false;
/*  508 */           jdlgOuroboros.dispose();
/*      */         }
/*      */       };
/*  511 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 105, 80, 26);
/*  512 */     jdlgOuroboros.add(jbCancel);
/*      */     
/*  514 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  516 */           Methods.cweHelp(null, jdlgOuroboros, "Ouroboros Build Options", OuroborosBuild.optionsHelp);
/*      */         }
/*      */       };
/*  519 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 70, 150, 61);
/*  520 */     jdlgOuroboros.add(jbHelp);
/*      */     
/*  522 */     Methods.setDialogSize(jdlgOuroboros, 260, 140);
/*      */   }
/*      */   
/*      */   static void setPoints() {
/*  526 */     int f = 0, r = 0;
/*  527 */     int top = 1, up = 1, right = 2, bot = 3, down = 3, left = 4;
/*      */     
/*  529 */     int i = 0, j = 0; int dir;
/*  530 */     for (numCells = 0, dir = 2;; numCells++) {
/*  531 */       cellSpec[numCells] = new cellDat();
/*  532 */       (cellSpec[numCells]).x = i; (cellSpec[numCells]).y = j;
/*  533 */       if (numCells > 0) (cellSpec[numCells - 1]).f = f;  (cellSpec[numCells]).r = r;
/*  534 */       switch (dir) {
/*      */         case 1:
/*  536 */           if (j > 0 && Grid.mode[i][j - 1] == 0) { j--; f = 3; r = 1; break; }
/*  537 */            if (i > 0 && Grid.mode[i - 1][j] == 0) { i--; f = 2; r = 4; dir = 4; break; }
/*  538 */            i++; f = 4; r = 2; dir = 2;
/*      */           break;
/*      */         case 2:
/*  541 */           if (i < Grid.xSz - 1 && Grid.mode[i + 1][j] == 0) { i++; f = 4; r = 2; break; }
/*  542 */            if (j > 0 && Grid.mode[i][j - 1] == 0) { j--; f = 3; r = 1; dir = 1; break; }
/*  543 */            j++; f = 1; r = 3; dir = 3;
/*      */           break;
/*      */         case 3:
/*  546 */           if (j < Grid.ySz - 1 && Grid.mode[i][j + 1] == 0) { j++; f = 1; r = 3; break; }
/*  547 */            if (i < Grid.xSz - 1 && Grid.mode[i + 1][j] == 0) { i++; f = 4; r = 2; dir = 2; break; }
/*  548 */            i--; f = 2; r = 4; dir = 4;
/*      */           break;
/*      */         case 4:
/*  551 */           if (i > 0 && Grid.mode[i - 1][j] == 0) { i--; f = 2; r = 4; break; }
/*  552 */            if (j < Grid.ySz - 1 && Grid.mode[i][j + 1] == 0) { j++; f = 1; r = 3; dir = 3; break; }
/*  553 */            j--; f = 3; r = 1; dir = 1;
/*      */           break;
/*      */       } 
/*  556 */       if (i == 0 && j == 0)
/*      */         break; 
/*  558 */     }  (cellSpec[0]).r = 1; (cellSpec[numCells]).f = 3;
/*  559 */     numCells++;
/*      */   }
/*      */   
/*      */   static void drawID(Graphics2D g2, int mode, int node, float adj) {
/*      */     String idString;
/*  564 */     FontMetrics fm = g2.getFontMetrics();
/*  565 */     int id = (NodeList.nodeList[node]).id;
/*  566 */     cellDat cS = cellSpec[(NodeList.nodeList[node]).startCell];
/*      */     
/*  568 */     mode = ((NodeList.nodeList[node]).direction == 1) ? cS.f : cS.r;
/*      */     
/*  570 */     switch (mode) {
/*      */       case 1:
/*  572 */         idString = "" + id + "▼";
/*  573 */         g2.drawString(idString, (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + cS.y * Grid.yCell + fm.getAscent()));
/*      */         break;
/*      */       case 2:
/*  576 */         g2.drawString("" + id, Grid.xOrg + (cS.x + 1) * Grid.xCell - fm.stringWidth("" + id) - 1, Grid.yOrg + cS.y * Grid.yCell + fm.getAscent());
/*  577 */         g2.drawString("◀", Grid.xOrg + (cS.x + 1) * Grid.xCell - fm.stringWidth("◀"), Grid.yOrg + cS.y * Grid.yCell + 2 * fm.getAscent());
/*      */         break;
/*      */       case 3:
/*  580 */         idString = "▲" + id;
/*  581 */         g2.drawString(idString, (Grid.xOrg + cS.x * Grid.xCell + Grid.xCell - fm.stringWidth(idString)) - adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj);
/*      */         break;
/*      */       case 4:
/*  584 */         g2.drawString("" + id, (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj);
/*  585 */         g2.drawString("▶", (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj - fm.getAscent());
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawOuroboros(Graphics2D g2, int cont) {
/*  596 */     float strokeWidth = (Grid.xCell < 25) ? 1.0F : (Grid.xCell / 25.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  602 */     Stroke normalStroke = new BasicStroke(strokeWidth, 2, 0);
/*  603 */     g2.setStroke(normalStroke);
/*  604 */     RenderingHints rh = g2.getRenderingHints();
/*  605 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  606 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  607 */     g2.setRenderingHints(rh);
/*      */ 
/*      */     
/*  610 */     for (int j = 0; j < Grid.ySz; j++) {
/*  611 */       for (int i = 0; i < Grid.xSz; i++) {
/*  612 */         if (Grid.mode[i][j] == 0) {
/*  613 */           g2.setColor(Color.BLACK);
/*  614 */           g2.fillRect(Grid.xOrg + i * Grid.xCell + Grid.xCell / 9, Grid.yOrg + j * Grid.yCell + Grid.yCell / 9, Grid.xCell, Grid.yCell);
/*      */           
/*  616 */           g2.setColor(Color.WHITE);
/*  617 */           g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*  618 */           g2.setColor(Color.BLACK);
/*  619 */           g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */         } 
/*      */       } 
/*  622 */     }  if (Methods.havePuzzle) {
/*      */       
/*  624 */       int fontSize = 7 * Grid.xCell / 25;
/*  625 */       g2.setFont(new Font("SansSerif", 0, fontSize));
/*  626 */       for (int node = 0; node < NodeList.nodeListLength; node++) {
/*  627 */         if ((NodeList.nodeList[node]).id > 0) {
/*  628 */           drawID(g2, 2, node, strokeWidth / 2.0F);
/*      */         }
/*      */       } 
/*      */     } 
/*  632 */     if ((cont & 0x1) == 1) {
/*      */       
/*  634 */       int fontSize = 7 * Grid.yCell / 12;
/*  635 */       g2.setFont(new Font("SansSerif", 0, fontSize));
/*  636 */       FontMetrics fm = g2.getFontMetrics();
/*  637 */       for (int x = 0; x < NodeList.nodeListLength; x++) {
/*  638 */         if ((NodeList.nodeList[x]).direction == 1) {
/*  639 */           for (int i = 0; i < (NodeList.nodeList[x]).word.length(); i++) {
/*  640 */             int pos = i + (NodeList.nodeList[x]).startCell;
/*  641 */             cellDat cS = cellSpec[pos];
/*  642 */             String str = "" + (NodeList.nodeList[x]).word.charAt(i);
/*  643 */             fm.stringWidth(str);
/*  644 */             g2.drawString("" + (NodeList.nodeList[x]).word.charAt(i), (Grid.xOrg + cS.x * Grid.xCell) + (Grid.xCell - fm
/*  645 */                 .stringWidth(str)) / 2.0F, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - (Grid.yCell - fm
/*  646 */                 .getAscent()) / 2.0F - strokeWidth);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  654 */     loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*  655 */     setSizesAndOffsets(left, top, width, height, 0);
/*  656 */     Methods.clearGrid(Grid.sol);
/*      */     
/*  658 */     drawOuroboros(g2, 4);
/*  659 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  663 */     loadOuroboros(solutionPuzzle);
/*  664 */     setSizesAndOffsets(left, top, width, height, 0);
/*  665 */     Def.dispGuideDigits = Boolean.valueOf(false);
/*      */     
/*  667 */     drawOuroboros(g2, 3);
/*      */     
/*  669 */     Def.dispGuideDigits = Boolean.valueOf(true);
/*  670 */     loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  674 */     loadOuroboros(solutionPuzzle);
/*  675 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, "Solution " + Methods.puzzleTitle);
/*  676 */     loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean loadOuroboros(String ouroborosName) {
/*  683 */     Op.ob[Op.OB.ObDic.ordinal()] = Methods.confirmDictionary(Op.ob[Op.OB.ObDic.ordinal()] + ".dic", false);
/*      */     
/*  685 */     File fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName);
/*  686 */     if (!fl.exists()) {
/*  687 */       fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/");
/*  688 */       String[] s = fl.list(); int i;
/*  689 */       for (i = 0; i < s.length && (
/*  690 */         s[i].lastIndexOf(".ouroboros") == -1 || s[i].charAt(0) == '.'); i++);
/*      */       
/*  692 */       ouroborosName = s[i];
/*  693 */       Op.ob[Op.OB.ObPuz.ordinal()] = ouroborosName;
/*      */     } 
/*      */     
/*      */     try {
/*  697 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName));
/*  698 */       NodeList.nodeListLength = dataIn.readInt();
/*  699 */       Grid.xSz = dataIn.readInt();
/*  700 */       Grid.ySz = dataIn.readInt(); int i;
/*  701 */       for (i = 0; i < 52; i++) {
/*  702 */         dataIn.readByte();
/*      */       }
/*  704 */       for (int j = 0; j < Grid.ySz; j++) {
/*  705 */         for (i = 0; i < Grid.ySz; i++) {
/*  706 */           Grid.mode[i][j] = dataIn.readInt();
/*      */         }
/*      */       } 
/*  709 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/*  710 */         NodeList.nodeList[i] = new Node();
/*  711 */         (NodeList.nodeList[i]).word = dataIn.readUTF();
/*  712 */         (NodeList.nodeList[i]).clue = dataIn.readUTF();
/*  713 */         (NodeList.nodeList[i]).length = dataIn.readInt();
/*  714 */         (NodeList.nodeList[i]).direction = dataIn.readInt();
/*  715 */         (NodeList.nodeList[i]).startCell = dataIn.readInt();
/*  716 */         (NodeList.nodeList[i]).id = dataIn.readInt();
/*      */       } 
/*      */ 
/*      */       
/*  720 */       numCells = dataIn.readInt();
/*  721 */       for (i = 0; i < numCells; i++) {
/*  722 */         cellSpec[i] = new cellDat();
/*  723 */         (cellSpec[i]).x = dataIn.readInt();
/*  724 */         (cellSpec[i]).y = dataIn.readInt();
/*  725 */         (cellSpec[i]).f = dataIn.readInt();
/*  726 */         (cellSpec[i]).r = dataIn.readInt();
/*      */       } 
/*      */ 
/*      */       
/*  730 */       Methods.puzzleTitle = dataIn.readUTF();
/*  731 */       Methods.author = dataIn.readUTF();
/*  732 */       Methods.copyright = dataIn.readUTF();
/*  733 */       Methods.puzzleNumber = dataIn.readUTF();
/*  734 */       Methods.puzzleNotes = dataIn.readUTF();
/*  735 */       dataIn.close();
/*  736 */       setPoints();
/*  737 */       Methods.havePuzzle = true;
/*  738 */       return true;
/*      */     } catch (IOException exc) {
/*  740 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkOuroboros(String ouroborosName) {
/*  747 */     Op.ob[Op.OB.ObDic.ordinal()] = Methods.confirmDictionary(Op.ob[Op.OB.ObDic.ordinal()] + ".dic", false);
/*      */     
/*  749 */     File fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName);
/*  750 */     if (!fl.exists()) {
/*  751 */       fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/");
/*  752 */       String[] s = fl.list(); int i;
/*  753 */       for (i = 0; i < s.length && (
/*  754 */         s[i].lastIndexOf(".ouroboros") == -1 || s[i].charAt(0) == '.'); i++);
/*      */       
/*  756 */       ouroborosName = s[i];
/*  757 */       Op.ob[Op.OB.ObPuz.ordinal()] = ouroborosName;
/*      */     } 
/*      */     
/*      */     try {
/*  761 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName));
/*  762 */       NodeList.nodeListLength = dataIn.readInt();
/*  763 */       dataIn.close();
/*      */     }
/*  765 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveOuroboros(String ouroborosName) {
/*      */     try {
/*  773 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName));
/*  774 */       dataOut.writeInt(NodeList.nodeListLength);
/*  775 */       dataOut.writeInt(Grid.xSz);
/*  776 */       dataOut.writeInt(Grid.ySz); int i;
/*  777 */       for (i = 0; i < 52; i++) {
/*  778 */         dataOut.writeByte(0);
/*      */       }
/*      */       
/*  781 */       for (int j = 0; j < Grid.ySz; j++) {
/*  782 */         for (i = 0; i < Grid.ySz; i++) {
/*  783 */           dataOut.writeInt(Grid.mode[i][j]);
/*      */         }
/*      */       } 
/*  786 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/*  787 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/*  788 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/*  789 */         dataOut.writeInt((NodeList.nodeList[i]).length);
/*  790 */         dataOut.writeInt((NodeList.nodeList[i]).direction);
/*  791 */         dataOut.writeInt((NodeList.nodeList[i]).startCell);
/*  792 */         dataOut.writeInt((NodeList.nodeList[i]).id);
/*      */       } 
/*      */ 
/*      */       
/*  796 */       dataOut.writeInt(numCells);
/*  797 */       for (i = 0; i < numCells; i++) {
/*  798 */         dataOut.writeInt((cellSpec[i]).x);
/*  799 */         dataOut.writeInt((cellSpec[i]).y);
/*  800 */         dataOut.writeInt((cellSpec[i]).f);
/*  801 */         dataOut.writeInt((cellSpec[i]).r);
/*      */       } 
/*      */ 
/*      */       
/*  805 */       dataOut.writeUTF(Methods.puzzleTitle);
/*  806 */       dataOut.writeUTF(Methods.author);
/*  807 */       dataOut.writeUTF(Methods.copyright);
/*  808 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  809 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  810 */       dataOut.close();
/*      */     }
/*  812 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean loadDictionary() {
/*      */     int i;
/*  821 */     for (i = 0; i < 50; wordCount[i++] = 0);
/*      */     
/*      */     try {
/*  824 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.dic"));
/*  825 */       for (i = 0; i < 128; i++)
/*  826 */         dataIn.readByte(); 
/*  827 */       while (dataIn.available() > 2) {
/*  828 */         dataIn.readInt();
/*  829 */         String word = dataIn.readUTF();
/*  830 */         if (letters.indexOf(word.charAt(0)) == -1)
/*  831 */           letters += word.charAt(0); 
/*  832 */         if (word.length() > 1)
/*  833 */           wordCount[word.length()] = wordCount[word.length()] + 1; 
/*  834 */         dataIn.readUTF();
/*      */       } 
/*  836 */       dataIn.close();
/*  837 */     } catch (IOException exc) {}
/*      */     
/*      */     int len;
/*  840 */     for (len = 2; len < 50; len++) {
/*  841 */       if (wordCount[len] > 0) {
/*  842 */         dicWord[0][len] = new String[wordCount[len]];
/*  843 */         dicWord[1][len] = new String[wordCount[len]];
/*  844 */         busy[len] = new boolean[wordCount[len]];
/*  845 */         revLink[len] = new int[wordCount[len]];
/*  846 */         for (i = 0; i < wordCount[len]; ) { revLink[len][i] = i; i++; }
/*      */       
/*      */       } 
/*      */     } 
/*  850 */     for (i = 0; i < 50; wordCount[i++] = 0);
/*      */     try {
/*  852 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.dic"));
/*  853 */       for (i = 0; i < 128; i++)
/*  854 */         dataIn.readByte(); 
/*  855 */       while (dataIn.available() > 2) {
/*  856 */         dataIn.readInt();
/*  857 */         String word = dataIn.readUTF();
/*  858 */         len = word.length();
/*  859 */         if (len > 1) {
/*  860 */           wordCount[len] = wordCount[len] + 1; dicWord[0][len][wordCount[len]] = word;
/*  861 */         }  dataIn.readUTF();
/*      */       } 
/*  863 */       dataIn.close();
/*  864 */     } catch (IOException exc) {}
/*      */ 
/*      */     
/*  867 */     for (len = 2; len < 50; len++) {
/*  868 */       for (i = 0; i < wordCount[len]; i++) {
/*  869 */         dicWord[1][len][i] = "";
/*  870 */         for (int j = 0; j < len; j++)
/*  871 */           dicWord[1][len][i] = dicWord[1][len][i] + dicWord[0][len][i].charAt(len - 1 - j); 
/*      */       } 
/*  873 */       if (wordCount[len] > 1) {
/*  874 */         qSort(dicWord[1][len], revLink[len], 0, wordCount[len] - 1);
/*      */       }
/*      */     } 
/*  877 */     return true;
/*      */   }
/*      */   
/*      */   static void qSort(String[] list, int[] link, int low, int high) {
/*  881 */     int top = low, bot = high;
/*  882 */     String pivot = list[low + (high - low) / 2];
/*      */ 
/*      */     
/*  885 */     while (top <= bot) {
/*  886 */       for (; list[top].compareTo(pivot) < 0; top++);
/*  887 */       for (; list[bot].compareTo(pivot) > 0; bot--);
/*      */       
/*  889 */       if (top <= bot) {
/*  890 */         String swp = list[top]; list[top] = list[bot]; list[bot] = swp;
/*  891 */         int iSwp = link[top]; link[top] = link[bot]; link[bot] = iSwp;
/*  892 */         top++;
/*  893 */         bot--;
/*      */       } 
/*      */     } 
/*      */     
/*  897 */     if (low < bot)
/*  898 */       qSort(list, link, low, bot); 
/*  899 */     if (top < high) {
/*  900 */       qSort(list, link, top, high);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean acceptPuzzle(int puzzleNum) {
/*      */     int i;
/*  909 */     for (int n = 0; i > 0; i--, n++) {
/*  910 */       int m = 0;
/*  911 */       int target = 8;
/*  912 */       if (n < 161) target = 7; 
/*  913 */       if (n < 105) target = 6; 
/*  914 */       if (n < 63) target = 5; 
/*  915 */       if (n < 42) target = 4; 
/*  916 */       if (n < 21) target = 3; 
/*  917 */       if (n < 14) target = 2; 
/*  918 */       if (n < 7) target = 1; 
/*  919 */       if (n < 3) target = 0;
/*      */       
/*      */       try {
/*  922 */         DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + i + ".ouroboros"));
/*  923 */         int len = dataIn.readInt();
/*  924 */         int xSz = dataIn.readInt();
/*  925 */         int ySz = dataIn.readInt(); int i1;
/*  926 */         for (i1 = 0; i1 < 52; i1++) {
/*  927 */           dataIn.readByte();
/*      */         }
/*      */         
/*  930 */         for (i1 = 0; i1 < ySz; i1++) {
/*  931 */           for (int i2 = 0; i2 < xSz; i2++)
/*  932 */             dataIn.readInt(); 
/*      */         } 
/*  934 */         for (i1 = 0; i1 < len; i1++) {
/*  935 */           String word = dataIn.readUTF();
/*  936 */           dataIn.readUTF();
/*  937 */           dataIn.readInt();
/*  938 */           dataIn.readInt();
/*  939 */           dataIn.readInt();
/*  940 */           dataIn.readInt();
/*  941 */           for (int i2 = 0; i2 < NodeList.nodeListLength; i2++) {
/*  942 */             if (word.compareTo((NodeList.nodeList[i2]).word) == 0)
/*  943 */               m++; 
/*      */           } 
/*  945 */         }  dataIn.close();
/*      */         
/*  947 */         if (m > target) {
/*  948 */           return false;
/*      */         }
/*  950 */       } catch (IOException exc) {
/*      */         break;
/*      */       } 
/*  953 */     }  attachClues();
/*      */     
/*      */     int j;
/*      */     
/*  957 */     for (j = NodeList.nodeListLength / 2; (NodeList.nodeList[j]).direction != 1; j++);
/*  958 */     int adj = (NodeList.nodeList[j]).startCell;
/*      */     
/*  960 */     for (int k = 0, count = k; k < NodeList.nodeListLength; k++) {
/*  961 */       int m = (j + k) % NodeList.nodeListLength;
/*  962 */       (NodeList.nodeList[m]).startCell -= adj;
/*  963 */       if ((NodeList.nodeList[m]).startCell < 0) (NodeList.nodeList[m]).startCell += numCells; 
/*  964 */       (NodeList.nodeList[m]).id = ++count;
/*      */     } 
/*      */ 
/*      */     
/*  968 */     for (i = 0; i < NodeList.nodeListLength - 1; i++) {
/*  969 */       for (j = i + 1; j < NodeList.nodeListLength; j++) {
/*  970 */         if ((NodeList.nodeList[i]).startCell > (NodeList.nodeList[j]).startCell) {
/*  971 */           Node swp = NodeList.nodeList[i];
/*  972 */           NodeList.nodeList[i] = NodeList.nodeList[j];
/*  973 */           NodeList.nodeList[j] = swp;
/*      */         } 
/*      */       } 
/*      */     } 
/*  977 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/*  978 */       (NodeList.nodeList[i]).id = i + 1;
/*      */     }
/*  980 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int addWordToStrand(String ouroborosStrand, int fe, int re, int index, int reqLen) {
/*  989 */     Random r = new Random();
/*      */     
/*  991 */     if (++abandon > 500000) return 2; 
/*  992 */     if (Def.building == 2) return 0; 
/*  993 */     int mode = (fe > re) ? 1 : 0;
/*  994 */     int gap = (mode == 1) ? (fe - re) : (re - fe);
/*      */     
/*  996 */     int begin = Op.getInt(Op.OB.ObShort.ordinal(), Op.ob), end = Op.getInt(Op.OB.ObLong.ordinal(), Op.ob);
/*  997 */     int wLen = begin + r.nextInt(end - begin);
/*  998 */     for (int x = begin; x < end; x++, wLen++) {
/*  999 */       if (wLen == end) wLen = begin; 
/* 1000 */       if (wLen != gap)
/* 1001 */         if (wLen < gap) {
/* 1002 */           if (mode == 0) {
/* 1003 */             String vWord = ouroborosStrand.substring(fe + 1, fe + 1 + wLen);
/* 1004 */             int first = 0, last = wordCount[wLen] - 1;
/*      */             do {
/* 1006 */               int current = (first + last) / 2;
/* 1007 */               int comp = vWord.compareTo(dicWord[0][wLen][current]);
/* 1008 */               if (comp > 0) { first = current + 1; }
/* 1009 */               else if (comp < 0) { last = current - 1; }
/* 1010 */               else { if (!busy[wLen][current]) {
/* 1011 */                   busy[wLen][current] = true;
/* 1012 */                   (NodeList.nodeList[index]).word = dicWord[0][wLen][current];
/* 1013 */                   (NodeList.nodeList[index]).length = wLen;
/* 1014 */                   (NodeList.nodeList[index]).startCell = fe + 1;
/* 1015 */                   (NodeList.nodeList[index]).id = index + 1;
/* 1016 */                   (NodeList.nodeList[index]).direction = 1;
/* 1017 */                   int res = addWordToStrand(ouroborosStrand, fe + wLen, re, index + 1, reqLen);
/* 1018 */                   busy[wLen][current] = false;
/* 1019 */                   if (res == 1)
/* 1020 */                     break;  return res;
/*      */                 } 
/*      */                 break; }
/*      */             
/* 1024 */             } while (last > first);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1029 */             String vWord = ouroborosStrand.substring(re + 1, re + 1 + wLen);
/* 1030 */             int first = 0, last = wordCount[wLen] - 1;
/*      */             do {
/* 1032 */               int current = (first + last) / 2;
/* 1033 */               int comp = vWord.compareTo(dicWord[1][wLen][current]);
/* 1034 */               if (comp > 0) { first = current + 1; }
/* 1035 */               else if (comp < 0) { last = current - 1; }
/* 1036 */               else { if (!busy[wLen][revLink[wLen][current]]) {
/* 1037 */                   busy[wLen][revLink[wLen][current]] = true;
/* 1038 */                   (NodeList.nodeList[index]).word = dicWord[0][wLen][revLink[wLen][current]];
/* 1039 */                   (NodeList.nodeList[index]).length = wLen;
/* 1040 */                   (NodeList.nodeList[index]).startCell = re + wLen;
/* 1041 */                   (NodeList.nodeList[index]).id = index + 1;
/* 1042 */                   (NodeList.nodeList[index]).direction = 0;
/* 1043 */                   int res = addWordToStrand(ouroborosStrand, fe, re + wLen, index + 1, reqLen);
/* 1044 */                   busy[wLen][revLink[wLen][current]] = false;
/* 1045 */                   if (res == 1)
/* 1046 */                     break;  return res;
/*      */                 } 
/*      */                 break; }
/*      */             
/* 1050 */             } while (last > first);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1056 */           String vWord = (mode == 1) ? ouroborosStrand.substring(re + 1) : ouroborosStrand.substring(fe + 1);
/*      */           
/* 1058 */           int first = 0, last = wordCount[wLen] - 1;
/*      */           do {
/* 1060 */             int current = (first + last) / 2;
/* 1061 */             String sWord = dicWord[mode][wLen][current];
/* 1062 */             int comp = vWord.compareTo(sWord);
/* 1063 */             if (sWord.startsWith(vWord)) { first = current; }
/* 1064 */             else if (comp < 0) { last = current; }
/* 1065 */             else if (comp > 0) { first = current; } 
/* 1066 */           } while (last - first > 1);
/*      */           
/* 1068 */           int finish = last;
/* 1069 */           if (dicWord[mode][wLen][finish].startsWith(vWord)) finish++;
/*      */           
/* 1071 */           first = 0;
/*      */           do {
/* 1073 */             int i = (first + last) / 2;
/* 1074 */             String str = dicWord[mode][wLen][i];
/* 1075 */             int j = vWord.compareTo(str);
/* 1076 */             if (str.startsWith(vWord)) { last = i; }
/* 1077 */             else if (j > 0) { first = i; }
/* 1078 */             else if (j < 0) { last = i; } 
/* 1079 */           } while (last - first > 1);
/*      */           
/* 1081 */           int start = first;
/* 1082 */           if (!dicWord[mode][wLen][start].startsWith(vWord)) start++;
/*      */           
/* 1084 */           if (start < finish)
/*      */           {
/* 1086 */             if (mode == 1) {
/*      */               
/* 1088 */               int v = start + r.nextInt(finish - start);
/* 1089 */               for (int i = start; i < finish; i++, v++) {
/* 1090 */                 if (v == finish) v = start; 
/* 1091 */                 if (!busy[wLen][revLink[wLen][v]]) {
/* 1092 */                   String theStrand = ouroborosStrand + dicWord[1][wLen][v].substring(gap);
/* 1093 */                   (NodeList.nodeList[index]).word = dicWord[0][wLen][revLink[wLen][v]];
/* 1094 */                   (NodeList.nodeList[index]).length = wLen;
/* 1095 */                   (NodeList.nodeList[index]).startCell = re + wLen;
/* 1096 */                   (NodeList.nodeList[index]).id = index + 1;
/* 1097 */                   (NodeList.nodeList[index]).direction = 0;
/* 1098 */                   if (theStrand.length() >= reqLen) {
/* 1099 */                     if (theStrand.length() == reqLen) {
/* 1100 */                       vWord = theStrand.substring(fe + 1) + seed;
/* 1101 */                       first = 0; int lastLen = vWord.length(); last = wordCount[vWord.length()] - 1;
/* 1102 */                       if (last > 0) {
/* 1103 */                         busy[wLen][revLink[wLen][v]] = true;
/* 1104 */                         if (lastLen > 3) {
/*      */                           do {
/* 1106 */                             int j = (first + last) / 2;
/* 1107 */                             int k = vWord.compareTo(dicWord[0][lastLen][j]);
/* 1108 */                             if (k > 0) { first = j + 1; }
/* 1109 */                             else if (k < 0) { last = j - 1; }
/* 1110 */                             else { if (!busy[vWord.length()][j]) {
/* 1111 */                                 (NodeList.nodeList[index + 1]).word = vWord;
/* 1112 */                                 (NodeList.nodeList[index + 1]).length = vWord.length();
/* 1113 */                                 (NodeList.nodeList[index + 1]).startCell = fe + 1;
/* 1114 */                                 (NodeList.nodeList[index + 1]).id = index + 2;
/* 1115 */                                 (NodeList.nodeList[index + 1]).direction = 1;
/* 1116 */                                 NodeList.nodeListLength = index + 2;
/* 1117 */                                 busy[wLen][revLink[wLen][v]] = false;
/*      */                                 
/* 1119 */                                 if (acceptPuzzle(startPuz - 1)) {
/* 1120 */                                   Methods.puzzleTitle = "" + startPuz;
/* 1121 */                                   Op.ob[Op.OB.ObPuz.ordinal()] = "" + startPuz++ + ".ouroboros";
/*      */                                   
/* 1123 */                                   saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/* 1124 */                                   restoreFrame();
/* 1125 */                                   Wait.shortWait(2000);
/*      */                                   
/* 1127 */                                   if (startPuz == hmCount) return 0; 
/*      */                                 } 
/* 1129 */                                 return 2;
/*      */                               }  break; }
/*      */                           
/* 1132 */                           } while (last > first);
/*      */                         }
/* 1134 */                         busy[wLen][revLink[wLen][v]] = false;
/*      */                       } 
/*      */                     } 
/*      */                   } else {
/*      */                     
/* 1139 */                     busy[wLen][revLink[wLen][v]] = true;
/* 1140 */                     (NodeList.nodeList[index]).word = dicWord[0][wLen][revLink[wLen][v]];
/* 1141 */                     (NodeList.nodeList[index]).length = wLen;
/* 1142 */                     (NodeList.nodeList[index]).startCell = re + wLen;
/* 1143 */                     (NodeList.nodeList[index]).id = index + 1;
/* 1144 */                     (NodeList.nodeList[index]).direction = 0;
/* 1145 */                     int res = addWordToStrand(theStrand, fe, re + wLen, index + 1, reqLen);
/* 1146 */                     busy[wLen][revLink[wLen][v]] = false;
/* 1147 */                     if (res == 0) return 0; 
/* 1148 */                     if (res == 2) return res;
/*      */                   
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } else {
/*      */               
/* 1155 */               int v = start + r.nextInt(finish - start);
/* 1156 */               for (int i = start; i < finish; i++, v++) {
/* 1157 */                 if (v == finish) v = start; 
/* 1158 */                 if (!busy[wLen][v]) {
/* 1159 */                   String theStrand = ouroborosStrand + dicWord[0][wLen][v].substring(gap);
/* 1160 */                   if (theStrand.length() < reqLen) {
/* 1161 */                     busy[wLen][v] = true;
/* 1162 */                     (NodeList.nodeList[index]).word = dicWord[0][wLen][v];
/* 1163 */                     (NodeList.nodeList[index]).length = wLen;
/* 1164 */                     (NodeList.nodeList[index]).startCell = fe + 1;
/* 1165 */                     (NodeList.nodeList[index]).id = index + 1;
/* 1166 */                     (NodeList.nodeList[index]).direction = 1;
/* 1167 */                     int res = addWordToStrand(theStrand, fe + wLen, re, index + 1, reqLen);
/* 1168 */                     busy[wLen][v] = false;
/* 1169 */                     if (res == 0) return 0; 
/* 1170 */                     if (res == 2) return res; 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             }  } 
/*      */         }  
/* 1176 */     }  return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean buildOuroboros(boolean multiBuild) {
/* 1182 */     Random r = new Random();
/*      */     
/* 1184 */     loadDictionary(); int k;
/* 1185 */     for (k = 0; k < 200; k++)
/* 1186 */       NodeList.nodeList[k] = new Node(); 
/* 1187 */     hmCount = startPuz + howMany;
/*      */     
/* 1189 */     int begin = Op.getInt(Op.OB.ObShort.ordinal(), Op.ob), end = Op.getInt(Op.OB.ObLong.ordinal(), Op.ob);
/*      */     while (true) {
/* 1191 */       int wLen = begin + r.nextInt(end - begin);
/* 1192 */       for (int x = begin; x < end; x++, wLen++) {
/* 1193 */         if (wLen == end) wLen = begin; 
/* 1194 */         int start = 0, finish = wordCount[wLen];
/* 1195 */         int v = start + r.nextInt(finish - start);
/* 1196 */         for (int i = start; i < finish; i++, v++) {
/* 1197 */           if (v == finish) v = start; 
/* 1198 */           abandon = 0;
/* 1199 */           for (k = 0; k < 3; k++) {
/* 1200 */             int fe = k, re = wLen - 1;
/* 1201 */             String ouroborosStrand = dicWord[1][wLen][v];
/* 1202 */             seed = ouroborosStrand.substring(0, k + 1);
/* 1203 */             (NodeList.nodeList[0]).word = dicWord[0][wLen][revLink[wLen][v]];
/* 1204 */             (NodeList.nodeList[0]).length = wLen;
/* 1205 */             (NodeList.nodeList[0]).startCell = wLen - 1;
/* 1206 */             (NodeList.nodeList[0]).id = 1;
/* 1207 */             (NodeList.nodeList[0]).direction = 0;
/* 1208 */             busy[wLen][revLink[wLen][v]] = true;
/* 1209 */             int res = addWordToStrand(ouroborosStrand, fe, re, 1, numCells);
/* 1210 */             busy[wLen][revLink[wLen][v]] = false;
/*      */             
/* 1212 */             if (res == 0) {
/* 1213 */               loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/* 1214 */               return true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static String selectOneClue(String clue, int wordDat) {
/* 1223 */     int[] loc = new int[257];
/* 1224 */     Random r = new Random();
/*      */     int i, count;
/* 1226 */     for (loc[0] = i = 0, count = 0; i < clue.length(); i++) {
/* 1227 */       if (clue.charAt(i) == '*')
/* 1228 */         loc[++count] = i + 1; 
/* 1229 */     }  loc[++count] = i + 1;
/*      */     
/* 1231 */     i = r.nextInt(count);
/* 1232 */     return new String(clue.substring(loc[i], loc[i + 1] - 1));
/*      */   }
/*      */   
/*      */   static void attachClues() {
/* 1236 */     int[] loc = new int[257];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1243 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.dic"));
/* 1244 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.new")); int i;
/* 1245 */       for (i = 0; i < 128; i++)
/* 1246 */         dataOut.writeByte(dataIn.readByte()); 
/* 1247 */       while (dataIn.available() > 2) {
/* 1248 */         int wordDat = dataIn.readInt();
/* 1249 */         String word = dataIn.readUTF();
/* 1250 */         String clue = dataIn.readUTF();
/* 1251 */         if (clue.length() == 0) clue = "No clue"; 
/* 1252 */         for (i = 0; i < NodeList.nodeListLength; i++) {
/* 1253 */           if (word.compareTo((NodeList.nodeList[i]).word) == 0) {
/* 1254 */             int clueEnd, loCount = wordDat % 256; int j, count;
/* 1255 */             for (count = 1, j = 0; j < clue.length(); j++) {
/* 1256 */               if (clue.charAt(j) == '*')
/* 1257 */                 count++; 
/*      */             }  int k, clueStart;
/* 1259 */             for (clueStart = 0, k = 0;; k++) {
/* 1260 */               for (clueEnd = clueStart; clueEnd < clue.length() && clue.charAt(clueEnd) != '*'; clueEnd++);
/* 1261 */               if (k == loCount)
/*      */                 break; 
/* 1263 */               clueStart = clueEnd + 1;
/*      */             } 
/*      */             
/* 1266 */             (NodeList.nodeList[i]).clue = clue.substring(clueStart, clueEnd);
/* 1267 */             if (++loCount == count)
/* 1268 */               loCount = 0; 
/* 1269 */             wordDat = (wordDat & 0xFFFFFF00) + loCount;
/*      */           } 
/* 1271 */         }  dataOut.writeInt(wordDat);
/* 1272 */         dataOut.writeUTF(word);
/* 1273 */         dataOut.writeUTF(clue);
/*      */       } 
/* 1275 */       dataOut.close();
/* 1276 */       dataIn.close();
/*      */     }
/* 1278 */     catch (IOException exc) {}
/* 1279 */     File fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.dic");
/* 1280 */     fl.delete();
/* 1281 */     fl = new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.new");
/* 1282 */     fl.renameTo(new File(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/xword.dic"));
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\OuroborosBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */