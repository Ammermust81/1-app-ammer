/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class OuroborosSolve extends JPanel {
/*     */   static JFrame jfSolveOuroboros;
/*     */   static JMenuBar menuBar;
/*     */   JMenu menu;
/*     */   JMenu submenu;
/*     */   JMenuItem menuItem;
/*     */   static JPanel pp;
/*  22 */   static int CCPREF = 180; static int puzW; static int puzH; static JLabel jl1; static JLabel jl2; Timer myTimer; static ccSpec[] ccDat; static int memMode; static int width; static int height; static boolean R2LClue;
/*     */   Runnable solveThread;
/*     */   int w;
/*     */   int h;
/*  26 */   int direction = 1;
/*  27 */   static cellDat[] cellSpec = new cellDat[400];
/*     */   
/*     */   static int numCells;
/*     */   
/*  31 */   String ouroborosSolveHelp = "<div><span class='m'>Standard Crossword Solve</span><br/>This function allows you to solve crossword puzzles in the traditional way using clues. The clues are presented to you in much the same way as in a printed puzzle with all of the clues continuously in view. In addition, the clue for the  word you are currently working on is highlighted for your convenience. The puzzle is presented within a resizable window, and you are encouraged to experiment with the size of the window, until you get a clue layout and font size which you find most appealing.<p/>Any character which is typed at the keyboard will be placed into the focus cell, and the focus cell will automatically move forward to the next character of the focus word. The location of the focus cell and its corresponding word may be shifted by pointing and clicking with the mouse, or by means of the cursor control keys. You can also move around the puzzle by pointing with the mouse and clicking any clue of interest. This will also automatically select the word associated with that clue.<p/>Other keys which provide useful functions during the solution process are Space bar, Delete, Backspace and Return.<p/><span class='m'>Crossword Solve in Audience Mode</span><br/>This is similar to the standard Solve function, except that only a single clue is displayed at a time, and the puzzle is displayed in a much larger format. The intention is that the puzzle be displayed using a video projector or big screen digital TV connected by an HDMI cable to the computer running the Crossword Express program. This configuration has been found useful for the entertainment of residents of retirement homes, and teachers find that students enjoy solving puzzles in this way.<p/>A dictionary suitable for the construction of these puzzles can be downloaded to your computer using the <b>Dictionary Maintenance / Tasks / Download Dictionary</b> menu option of Crossword Express. The name of this dictionary is <b>audience</b>. It contains words having 7 or less letters, so if you decide to make use of it you must take this into account when designing the grid that you will use to make your puzzles.</div><p/><span class='m'>Menu Functions</span><br/><ul><li/><span class='s'>File Menu</span><ul><li/><span>Select a Dictionary</span><br/>When loading a new puzzle, you begin by selecting the dictionary which was used to build the CROSSWORD puzzle which you want to solve.<p/><li/><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of CROSSWORD puzzles currently available in the selected dictionary.<p/><li/><span>Quit Solving</span><br/>Returns you to either the CROSSWORD Build screen.<p/></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.<p/></ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal One Letter</span><br/>If you need a little help to get started, this option will place the correct letter into the current focus cell.<p/><li/><span>Reveal One Word</span><br/>If you need more help, this option will fill in the entire current word.<p/><li/><span>Google It</span><br/>This menu option will start your default web browser, and send the current clue to Google as a search string. This generally result in a number of links to reference pages which will provide the answer you seek. A more convenient method of accessing this function is simply to issue a mouse click on the currently highlighted clue.<p/><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.<p/></ul><li/><span class='s'>Help Menu</span><ul><li/><span>Crossword Help</span><br/>Displays the Help screen which you are now reading.<p/></ul></ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int tSz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int pSz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OuroborosSolve(JFrame jf) {
/*  99 */     Def.puzzleMode = 135;
/* 100 */     Def.dispSolArray = Boolean.valueOf(true); Def.dispCursor = Boolean.valueOf(true); Def.dispGuideDigits = Boolean.valueOf(true);
/* 101 */     Grid.clearGrid();
/*     */     
/* 103 */     jfSolveOuroboros = new JFrame("Solve an Ouroboros Puzzle");
/*     */     
/* 105 */     this.w = Op.getInt(Op.OB.ObSolveW.ordinal(), Op.ob);
/* 106 */     this.h = Op.getInt(Op.OB.ObSolveH.ordinal(), Op.ob);
/* 107 */     if (Def.audienceMode) { this.w = 500; this.h = this.w + 150; }
/* 108 */      jfSolveOuroboros.setSize(this.w, this.h);
/* 109 */     int frameX = (jf.getX() + jfSolveOuroboros.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveOuroboros.getWidth() - 10) : jf.getX();
/* 110 */     jfSolveOuroboros.setLocation(frameX, jf.getY());
/* 111 */     jfSolveOuroboros.setLayout((LayoutManager)null);
/* 112 */     jfSolveOuroboros.setDefaultCloseOperation(0);
/* 113 */     jfSolveOuroboros
/* 114 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/* 116 */             OuroborosSolve.this.w = OuroborosSolve.jfSolveOuroboros.getWidth();
/* 117 */             OuroborosSolve.this.h = OuroborosSolve.jfSolveOuroboros.getHeight();
/* 118 */             if (!Def.audienceMode) {
/* 119 */               if (OuroborosSolve.this.w < 30 * Grid.xSz) OuroborosSolve.this.w = 30 * Grid.xSz; 
/* 120 */               if (OuroborosSolve.this.h < 30 * Grid.ySz) OuroborosSolve.this.h = 30 * Grid.ySz; 
/* 121 */               if (OuroborosSolve.this.w < 600 || OuroborosSolve.this.h < 600) {
/* 122 */                 OuroborosSolve.this.w = 600; OuroborosSolve.this.h = 600;
/*     */               } 
/* 124 */             }  OuroborosSolve.jfSolveOuroboros.setSize(OuroborosSolve.this.w, OuroborosSolve.this.h);
/* 125 */             Op.setInt(Op.OB.ObSolveW.ordinal(), OuroborosSolve.this.w, Op.ob);
/* 126 */             Op.setInt(Op.OB.ObSolveH.ordinal(), OuroborosSolve.this.h, Op.ob);
/* 127 */             OuroborosSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/* 131 */     jfSolveOuroboros
/* 132 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 134 */             if (Def.selecting)
/* 135 */               return;  OuroborosSolve.this.restoreIfDone();
/* 136 */             OuroborosSolve.saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/* 137 */             Def.dispWithShadow = Boolean.valueOf(false);
/* 138 */             Def.audienceMode = false;
/* 139 */             CrosswordExpress.transfer(134, OuroborosSolve.jfSolveOuroboros);
/*     */           }
/*     */         });
/*     */     
/* 143 */     Methods.closeHelp();
/*     */     
/* 145 */     jl1 = new JLabel(); jfSolveOuroboros.add(jl1);
/* 146 */     jl2 = new JLabel(); jfSolveOuroboros.add(jl2);
/*     */ 
/*     */     
/* 149 */     menuBar = new JMenuBar();
/* 150 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 151 */     jfSolveOuroboros.setJMenuBar(menuBar);
/* 152 */     this.menu = new JMenu("File");
/* 153 */     menuBar.add(this.menu);
/* 154 */     this.menuItem = new JMenuItem("Select a Dictionary");
/* 155 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 156 */     this.menu.add(this.menuItem);
/* 157 */     this.menuItem
/* 158 */       .addActionListener(ae -> {
/*     */           Methods.selectDictionary(jfSolveOuroboros, Op.ob[Op.OB.ObDic.ordinal()], 3);
/*     */           
/*     */           if (!Methods.fileAvailable(Methods.dictionaryName + ".dic", "ouroboros")) {
/*     */             JOptionPane.showMessageDialog(jfSolveOuroboros, "<html>No Ouroboros puzzles are available in this dictionary.<br>Use the <font color=880000>Build</font> option to create one.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*     */           
/*     */           Op.ob[Op.OB.ObDic.ordinal()] = Methods.dictionaryName;
/*     */           loadSolvePuzzle();
/*     */           restoreFrame();
/*     */         });
/* 175 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 176 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 177 */     this.menu.add(this.menuItem);
/* 178 */     this.menuItem
/* 179 */       .addActionListener(ae -> {
/*     */           restoreIfDone();
/*     */           
/*     */           saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*     */           
/*     */           new Select(jfSolveOuroboros, Op.ob[Op.OB.ObDic.ordinal()] + ".dic", "ouroboros", Op.ob, Op.OB.ObPuz.ordinal(), false);
/*     */         });
/* 186 */     this.menuItem = new JMenuItem("Quit Solving");
/* 187 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 188 */     this.menu.add(this.menuItem);
/* 189 */     this.menuItem
/* 190 */       .addActionListener(ae -> {
/*     */           restoreIfDone();
/*     */           
/*     */           saveOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/*     */           
/*     */           Def.audienceMode = false;
/*     */           
/*     */           CrosswordExpress.transfer(134, jfSolveOuroboros);
/*     */         });
/* 199 */     this.menu = new JMenu("View");
/* 200 */     menuBar.add(this.menu);
/* 201 */     this.menuItem = new JMenuItem("Display Options");
/* 202 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 203 */     this.menu.add(this.menuItem);
/* 204 */     this.menuItem
/* 205 */       .addActionListener(ae -> {
/*     */           FreeformBuild.printOptions(jfSolveOuroboros, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 212 */     this.menu = new JMenu("Tasks");
/* 213 */     menuBar.add(this.menu);
/* 214 */     this.menuItem = new JMenuItem("Reveal One Letter");
/* 215 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 216 */     this.menu.add(this.menuItem);
/* 217 */     this.menuItem
/* 218 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             Grid.sol[Grid.xCur][Grid.yCur] = Grid.letter[Grid.xCur][Grid.yCur];
/*     */           } else {
/*     */             Methods.noReveal(jfSolveOuroboros);
/*     */           } 
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 227 */     this.menuItem = new JMenuItem("Reveal One Word");
/* 228 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(87, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 229 */     this.menu.add(this.menuItem);
/* 230 */     this.menuItem
/* 231 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int y = 0; y < Grid.ySz; y++) {
/*     */               for (int x = 0; x < Grid.xSz; x++) {
/*     */                 if (Grid.horz[x][y] == Grid.nCur || Grid.vert[x][y] == Grid.nCur)
/*     */                   Grid.sol[x][y] = Grid.letter[x][y]; 
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveOuroboros);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 244 */     this.menuItem = new JMenuItem("Google It");
/* 245 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(71, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 246 */     this.menu.add(this.menuItem);
/* 247 */     this.menuItem
/* 248 */       .addActionListener(ae -> {
/*     */           String url = "http://www.google.com/search?q=" + (NodeList.nodeList[Grid.nCur]).clue;
/*     */           
/*     */           url = url.replace(' ', '+');
/*     */           
/*     */           browserLaunch.openURL(jfSolveOuroboros, url);
/*     */           
/*     */           Methods.toFront(paramJFrame);
/*     */         });
/* 257 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         restoreFrame();
/*     */         this.myTimer.stop();
/*     */       };
/* 262 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 264 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 265 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 266 */     this.menu.add(this.menuItem);
/* 267 */     this.menuItem
/* 268 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveOuroboros);
/*     */           } 
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 279 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 280 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 281 */     this.menu.add(this.menuItem);
/* 282 */     this.menuItem
/* 283 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++)
/*     */                 Grid.sol[i][j] = Grid.letter[i][j]; 
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveOuroboros);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 294 */     this.menuItem = new JMenuItem("Begin Again");
/* 295 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 296 */     this.menu.add(this.menuItem);
/* 297 */     this.menuItem
/* 298 */       .addActionListener(ae -> {
/*     */           for (int j = 0; j < Grid.ySz; j++) {
/*     */             for (int i = 0; i < Grid.xSz; i++) {
/*     */               Grid.sol[i][j] = 0;
/*     */             }
/*     */           } 
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 307 */     this.menu = new JMenu("Help");
/* 308 */     menuBar.add(this.menu);
/* 309 */     this.menuItem = new JMenuItem("Ouroboros Help");
/* 310 */     this.menu.add(this.menuItem);
/* 311 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 312 */     this.menuItem
/* 313 */       .addActionListener(ae -> Methods.cweHelp(jfSolveOuroboros, null, "Solving an Ouroboros Puzzle", this.ouroborosSolveHelp));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if (Grid.sol[i][j] != Grid.letter[i][j])
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveOuroboros);
/*     */       });
/* 327 */     pp = new OuroborosSolvePP(0, 0, jfSolveOuroboros);
/*     */     
/* 329 */     pp
/* 330 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mouseReleased(MouseEvent e) {
/* 332 */             OuroborosSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 337 */     pp
/* 338 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 340 */             if (Def.isMac) {
/* 341 */               OuroborosSolve.jfSolveOuroboros.setResizable((OuroborosSolve.jfSolveOuroboros.getWidth() - e.getX() < 15 && OuroborosSolve.jfSolveOuroboros
/* 342 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 347 */     jfSolveOuroboros
/* 348 */       .addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent e) {
/* 350 */             OuroborosSolve.this.handleKeyPressed(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 355 */     ccDat = new ccSpec[50];
/* 356 */     for (int i = 0; i < 50; i++) {
/* 357 */       ccDat[i] = new ccSpec();
/*     */     }
/* 359 */     loadOuroboros(Op.ob[Op.OB.ObPuz.ordinal()]);
/* 360 */     restoreFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void restoreFrame() {
/* 367 */     jfSolveOuroboros.setVisible(true);
/* 368 */     Insets insets = jfSolveOuroboros.getInsets();
/* 369 */     int wDec = insets.left + insets.right;
/* 370 */     int hDec = insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 371 */     width = jfSolveOuroboros.getWidth() - wDec;
/* 372 */     height = jfSolveOuroboros.getHeight() - hDec;
/* 373 */     jfSolveOuroboros.setSize(width + wDec, height + hDec);
/* 374 */     pp.setSize(width, height);
/* 375 */     pp.setLocation(0, 37);
/*     */     
/* 377 */     tSz = width * height;
/* 378 */     pSz = tSz * 4 / 10;
/* 379 */     double theCell = Math.sqrt((pSz / Grid.xSz * Grid.ySz));
/* 380 */     if (theCell * Grid.xSz >= (width * 4 / 5)) {
/* 381 */       theCell = width / Grid.xSz;
/* 382 */     } else if (theCell * Grid.ySz >= (height * 4 / 5)) {
/* 383 */       theCell = height / Grid.ySz;
/* 384 */     }  Grid.xCell = Grid.yCell = (int)Math.round(theCell);
/* 385 */     puzW = Grid.xCell * Grid.xSz;
/* 386 */     puzH = Grid.yCell * Grid.ySz;
/*     */     
/* 388 */     jfSolveOuroboros.requestFocusInWindow();
/* 389 */     pp.repaint();
/* 390 */     Methods.infoPanel(jl1, jl2, "Solve Ouroboros", "Dictionary : " + Op.ob[Op.OB.ObDic.ordinal()] + "  -|-  Puzzle : " + Op.ob[Op.OB.ObPuz
/* 391 */           .ordinal()], jfSolveOuroboros.getWidth());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int w, int h, int inset) {
/* 397 */     int i = (w - inset) / Grid.xSz;
/* 398 */     int j = (h - inset) / Grid.ySz;
/* 399 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 400 */     Grid.xOrg = (w == h) ? (x + (w - Grid.xSz * Grid.xCell) / 2) : 10;
/* 401 */     Grid.yOrg = (w == h) ? (y + (h - Grid.ySz * Grid.yCell) / 2) : 10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveOuroboros(String ouroborosName) {
/*     */     try {
/* 409 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName));
/* 410 */       dataOut.writeInt(NodeList.nodeListLength);
/* 411 */       dataOut.writeInt(Grid.xSz);
/* 412 */       dataOut.writeInt(Grid.ySz); int i;
/* 413 */       for (i = 0; i < 52; i++) {
/* 414 */         dataOut.writeByte(0);
/*     */       }
/*     */       int j;
/* 417 */       for (j = 0; j < Grid.ySz; j++) {
/* 418 */         for (i = 0; i < Grid.ySz; i++) {
/* 419 */           dataOut.writeInt(Grid.mode[i][j]);
/*     */         }
/*     */       } 
/* 422 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 423 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/* 424 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/* 425 */         dataOut.writeInt((NodeList.nodeList[i]).length);
/* 426 */         dataOut.writeInt((NodeList.nodeList[i]).direction);
/* 427 */         dataOut.writeInt((NodeList.nodeList[i]).startCell);
/* 428 */         dataOut.writeInt((NodeList.nodeList[i]).id);
/*     */       } 
/*     */ 
/*     */       
/* 432 */       dataOut.writeInt(numCells);
/* 433 */       for (i = 0; i < numCells; i++) {
/* 434 */         dataOut.writeInt((cellSpec[i]).x);
/* 435 */         dataOut.writeInt((cellSpec[i]).y);
/* 436 */         dataOut.writeInt((cellSpec[i]).f);
/* 437 */         dataOut.writeInt((cellSpec[i]).r);
/*     */       } 
/*     */ 
/*     */       
/* 441 */       dataOut.writeUTF(Methods.puzzleTitle);
/* 442 */       dataOut.writeUTF(Methods.author);
/* 443 */       dataOut.writeUTF(Methods.copyright);
/* 444 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 445 */       dataOut.writeUTF(Methods.puzzleNotes);
/*     */ 
/*     */       
/* 448 */       for (j = 0; j < Grid.ySz; j++) {
/* 449 */         for (i = 0; i < Grid.ySz; i++)
/* 450 */           dataOut.writeInt(Grid.sol[i][j]); 
/* 451 */       }  dataOut.close();
/*     */     }
/* 453 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean loadOuroboros(String ouroborosName) {
/* 460 */     Op.ob[Op.OB.ObDic.ordinal()] = Methods.confirmDictionary(Op.ob[Op.OB.ObDic.ordinal()] + ".dic", false);
/*     */     
/*     */     try {
/* 463 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ob[Op.OB.ObDic.ordinal()] + ".dic/" + ouroborosName));
/* 464 */       NodeList.nodeListLength = dataIn.readInt();
/* 465 */       Grid.xSz = dataIn.readInt();
/* 466 */       Grid.ySz = dataIn.readInt(); int i;
/* 467 */       for (i = 0; i < 52; i++) {
/* 468 */         dataIn.readByte();
/*     */       }
/*     */       int j;
/* 471 */       for (j = 0; j < Grid.ySz; j++) {
/* 472 */         for (i = 0; i < Grid.ySz; i++) {
/* 473 */           Grid.mode[i][j] = dataIn.readInt();
/*     */         }
/*     */       } 
/* 476 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 477 */         NodeList.nodeList[i] = new Node();
/* 478 */         (NodeList.nodeList[i]).word = dataIn.readUTF();
/* 479 */         (NodeList.nodeList[i]).clue = dataIn.readUTF();
/* 480 */         (NodeList.nodeList[i]).length = dataIn.readInt();
/* 481 */         (NodeList.nodeList[i]).direction = dataIn.readInt();
/* 482 */         (NodeList.nodeList[i]).startCell = dataIn.readInt();
/* 483 */         (NodeList.nodeList[i]).id = dataIn.readInt();
/*     */       } 
/*     */ 
/*     */       
/* 487 */       numCells = dataIn.readInt();
/* 488 */       for (i = 0; i < numCells; i++) {
/* 489 */         cellSpec[i] = new cellDat();
/* 490 */         (cellSpec[i]).x = dataIn.readInt();
/* 491 */         (cellSpec[i]).y = dataIn.readInt();
/* 492 */         (cellSpec[i]).f = dataIn.readInt();
/* 493 */         (cellSpec[i]).r = dataIn.readInt();
/* 494 */         Grid.grid[(cellSpec[i]).x][(cellSpec[i]).y] = i;
/*     */       } 
/*     */ 
/*     */       
/* 498 */       for (int x = 0; x < NodeList.nodeListLength; x++) {
/* 499 */         if ((NodeList.nodeList[x]).direction == 1) {
/* 500 */           for (int y = 0; y < (NodeList.nodeList[x]).word.length(); y++) {
/* 501 */             i = (NodeList.nodeList[x]).startCell + y;
/* 502 */             if (i >= numCells) i -= numCells; 
/* 503 */             Grid.letter[(cellSpec[i]).x][(cellSpec[i]).y] = (NodeList.nodeList[x]).word.charAt(y);
/* 504 */             Grid.horz[(cellSpec[i]).x][(cellSpec[i]).y] = x;
/*     */           } 
/*     */         } else {
/* 507 */           for (int y = 0; y < (NodeList.nodeList[x]).word.length(); y++) {
/* 508 */             i = (NodeList.nodeList[x]).startCell - y;
/* 509 */             if (i < 0) i += numCells; 
/* 510 */             Grid.vert[(cellSpec[i]).x][(cellSpec[i]).y] = x;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 516 */       Methods.puzzleTitle = dataIn.readUTF();
/* 517 */       Methods.author = dataIn.readUTF();
/* 518 */       Methods.copyright = dataIn.readUTF();
/* 519 */       Methods.puzzleNumber = dataIn.readUTF();
/* 520 */       Methods.puzzleNotes = dataIn.readUTF();
/*     */ 
/*     */       
/* 523 */       if (dataIn.available() > 0)
/* 524 */         for (j = 0; j < Grid.ySz; j++) {
/* 525 */           for (i = 0; i < Grid.ySz; i++)
/* 526 */             Grid.sol[i][j] = dataIn.readInt(); 
/*     */         }  
/* 528 */       dataIn.close();
/* 529 */       Methods.havePuzzle = true;
/*     */       
/* 531 */       return true;
/*     */     } catch (IOException exc) {
/* 533 */       return false;
/*     */     } 
/*     */   }
/*     */   static String removeStyle(String str) {
/* 537 */     String st = "";
/*     */ 
/*     */     
/* 540 */     boolean copy = true;
/*     */     
/* 542 */     if (!str.contains("<")) return str; 
/* 543 */     for (int i = 0; i < str.length(); i++) {
/* 544 */       char ch = str.charAt(i);
/* 545 */       if (ch == '<') { copy = false; }
/* 546 */       else if (ch == '>') { copy = true; }
/* 547 */       else if (copy) { st = st + ch; }
/*     */     
/* 549 */     }  return st;
/*     */   }
/*     */   
/*     */   static void drawID(Graphics2D g2, int mode, int node, float adj) {
/*     */     String idString;
/* 554 */     FontMetrics fm = g2.getFontMetrics();
/* 555 */     int id = (NodeList.nodeList[node]).id;
/* 556 */     cellDat cS = cellSpec[(NodeList.nodeList[node]).startCell];
/*     */     
/* 558 */     mode = ((NodeList.nodeList[node]).direction == 1) ? cS.f : cS.r;
/*     */     
/* 560 */     switch (mode) {
/*     */       case 1:
/* 562 */         idString = "" + id + "▼";
/* 563 */         g2.drawString(idString, (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + cS.y * Grid.yCell + fm.getAscent()));
/*     */         break;
/*     */       case 2:
/* 566 */         g2.drawString("" + id, Grid.xOrg + (cS.x + 1) * Grid.xCell - fm.stringWidth("" + id) - 1, Grid.yOrg + cS.y * Grid.yCell + fm.getAscent());
/* 567 */         g2.drawString("◀", Grid.xOrg + (cS.x + 1) * Grid.xCell - fm.stringWidth("◀"), Grid.yOrg + cS.y * Grid.yCell + 2 * fm.getAscent());
/*     */         break;
/*     */       case 3:
/* 570 */         idString = "▲" + id;
/* 571 */         g2.drawString(idString, (Grid.xOrg + cS.x * Grid.xCell + Grid.xCell - fm.stringWidth(idString)) - adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj);
/*     */         break;
/*     */       case 4:
/* 574 */         g2.drawString("" + id, (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj);
/* 575 */         g2.drawString("▶", (Grid.xOrg + cS.x * Grid.xCell) + adj, (Grid.yOrg + (cS.y + 1) * Grid.yCell) - 2.0F * adj - fm.getAscent());
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawOuroboros(Graphics2D g2, int cont) {
/* 586 */     float nL = (Grid.xCell < 25) ? 1.0F : (Grid.xCell / 25.0F), wL = (int)Math.ceil((Grid.xCell / 12.0F));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 592 */     int ccMax = 0;
/*     */ 
/*     */     
/* 595 */     Stroke normalStroke = new BasicStroke(nL, 2, 0);
/* 596 */     Stroke wideStroke = new BasicStroke(wL, 0, 0);
/* 597 */     g2.setStroke(normalStroke);
/* 598 */     RenderingHints rh = g2.getRenderingHints();
/* 599 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 600 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 601 */     g2.setRenderingHints(rh);
/*     */     
/* 603 */     g2.setColor(Def.COLOR_WHITE);
/* 604 */     g2.fillRect(0, 0, jfSolveOuroboros.getWidth(), jfSolveOuroboros.getHeight());
/*     */     
/*     */     int j;
/* 607 */     for (j = 0; j < Grid.ySz; j++) {
/* 608 */       for (int i = 0; i < Grid.xSz; i++) {
/* 609 */         if (Grid.mode[i][j] == 0) {
/* 610 */           g2.setColor(Color.BLACK);
/* 611 */           g2.fillRect(Grid.xOrg + i * Grid.xCell + Grid.xCell / 7, Grid.yOrg + j * Grid.yCell + Grid.yCell / 7, Grid.xCell, Grid.yCell);
/* 612 */           g2.setColor((Grid.horz[i][j] == Grid.nCur || Grid.vert[i][j] == Grid.nCur) ? new Color(61132) : Color.WHITE);
/* 613 */           g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/* 614 */           g2.setColor(Color.BLACK);
/* 615 */           g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */         } 
/*     */       } 
/* 618 */     }  if (Methods.havePuzzle) {
/*     */       
/* 620 */       int i = 7 * Grid.xCell / 25;
/* 621 */       g2.setFont(new Font("SansSerif", 0, i));
/* 622 */       for (int node = 0; node < NodeList.nodeListLength; node++) {
/* 623 */         if ((NodeList.nodeList[node]).id > 0) {
/* 624 */           drawID(g2, 2, node, nL / 2.0F);
/*     */         }
/*     */       } 
/*     */     } 
/* 628 */     int fontSize = 7 * Grid.yCell / 12;
/* 629 */     g2.setFont(new Font("SansSerif", 0, fontSize));
/* 630 */     FontMetrics fm = g2.getFontMetrics();
/* 631 */     for (j = 0; j < Grid.ySz; j++) {
/* 632 */       for (int i = 0; i < Grid.xSz; i++) {
/* 633 */         if (Grid.sol[i][j] != 0) {
/* 634 */           String str = "" + (char)Grid.sol[i][j];
/* 635 */           int w = fm.stringWidth(str);
/* 636 */           g2.drawString(str, (Grid.xOrg + i * Grid.xCell) + (Grid.xCell - w) / 2.0F, (Grid.yOrg + j * Grid.yCell) + (Grid.yCell + fm
/* 637 */               .getAscent()) / 2.0F - nL);
/*     */         } 
/*     */       } 
/*     */     } 
/* 641 */     g2.setColor(Def.COLOR_RED);
/* 642 */     g2.setStroke(wideStroke);
/* 643 */     g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */     
/* 645 */     if (!Def.selecting) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 652 */       Color clueC = new Color(0), curClueC = new Color(17476);
/* 653 */       Color clueBgC = new Color(61132), clueOlC = new Color(0);
/*     */       
/*     */       int i;
/*     */       
/* 657 */       for (i = 0; i < 50; i++) {
/* 658 */         (ccDat[i]).w = 0;
/*     */       }
/* 660 */       int ccNum = 0;
/* 661 */       if (height - 10 - Grid.ySz * Grid.yCell > 50) {
/* 662 */         int k = Grid.xSz * Grid.xCell + 10;
/* 663 */         i = ccMax = k / CCPREF;
/* 664 */         int ccw = k / i;
/* 665 */         for (; ccNum < i; ccNum++) {
/* 666 */           (ccDat[ccNum]).x = Grid.xOrg + ccNum * ccw;
/* 667 */           (ccDat[ccNum]).y = Grid.yOrg + Grid.ySz * Grid.yCell + 5;
/* 668 */           (ccDat[ccNum]).w = ccw;
/*     */         } 
/*     */       } 
/*     */       
/* 672 */       int cw = width - Grid.xSz * Grid.xCell - 30;
/* 673 */       if (cw > 50) {
/* 674 */         i = cw / CCPREF;
/* 675 */         if (i > 0) {
/* 676 */           ccMax += i;
/* 677 */           int ccw = cw / i;
/* 678 */           for (j = 0; ccNum < 50; j++) {
/* 679 */             (ccDat[ccNum]).x = Grid.xOrg + Grid.xSz * Grid.xCell + 10 + j * ccw;
/* 680 */             (ccDat[ccNum]).y = 0;
/* 681 */             (ccDat[ccNum++]).w = ccw;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 687 */       int ccMin = (((ccDat[0]).w < (ccDat[49]).w || (ccDat[49]).w == 0) ? (ccDat[0]).w : (ccDat[49]).w) - 1;
/* 688 */       int clueFontSize = 60; int z;
/* 689 */       for (z = 0; z < NodeList.nodeListLength; z++) {
/* 690 */         String idStr = (NodeList.nodeList[z]).id + ". ";
/* 691 */         g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 1, clueFontSize));
/* 692 */         fm = g2.getFontMetrics();
/* 693 */         int inset = fm.stringWidth(idStr);
/* 694 */         String str = (NodeList.nodeList[z]).clue;
/* 695 */         for (i = 0, j = 1; j <= str.length(); j++) {
/* 696 */           if (j == str.length() || str.charAt(j) == ' ') {
/* 697 */             String str2 = str.substring(i, j);
/* 698 */             i = j + 1;
/* 699 */             while (fm.stringWidth(str2) >= ccMin - inset - 10) {
/* 700 */               clueFontSize--;
/* 701 */               g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 0, clueFontSize));
/* 702 */               fm = g2.getFontMetrics();
/* 703 */               inset = fm.stringWidth(idStr);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 720 */       int fontSp = clueFontSize;
/* 721 */       int cluB = height;
/* 722 */       g2.setColor(new Color(Op.CW.AwClue.ordinal()));
/* 723 */       int printSt = 0; while (true) {
/* 724 */         ccNum = 0;
/* 725 */         int colW = (ccDat[ccNum]).w;
/* 726 */         int ccTop = Grid.yOrg + Grid.ySz * Grid.yCell;
/*     */         
/* 728 */         int lY = (ccDat[ccNum]).y;
/* 729 */         if ((ccDat[ccNum]).y < ccTop) lY += ccTop % fontSp; 
/* 730 */         int lX = (ccDat[ccNum]).x;
/* 731 */         lY += fontSp;
/* 732 */         g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 1, clueFontSize));
/* 733 */         fm = g2.getFontMetrics();
/* 734 */         if (printSt == 2) {
/* 735 */           String str = "CLUES";
/* 736 */           int xCoord = lX + 5 + (R2LClue ? (colW - fm.stringWidth(str)) : 0);
/* 737 */           g2.drawString(str, xCoord, lY);
/*     */         } 
/* 739 */         for (z = 0; z < NodeList.nodeListLength; z++) {
/* 740 */           if (z == Grid.nCur && printSt == 2) {
/* 741 */             g2.setStroke(normalStroke);
/* 742 */             int t = (NodeList.nodeList[z]).nlCt;
/* 743 */             int l = (NodeList.nodeList[z]).nlCl;
/* 744 */             int b = (NodeList.nodeList[z]).nlCb;
/* 745 */             int r = (NodeList.nodeList[z]).nlCr;
/* 746 */             int T = (NodeList.nodeList[z]).nlTop;
/* 747 */             int B = (NodeList.nodeList[z]).nlBot;
/* 748 */             int x1 = l, y1 = t, h1 = B - t, w1 = colW;
/* 749 */             int x2 = l + colW, y2 = T + 2, h2 = b - T, w2 = (ccDat[ccNum + 1]).w;
/* 750 */             if (b < t) {
/* 751 */               g2.setColor(clueBgC);
/* 752 */               g2.fillRect(x1, y1, w1, h1);
/* 753 */               g2.fillRect(x2, y2, w2, h2);
/* 754 */               g2.setColor(clueOlC);
/* 755 */               g2.drawRect(x1, y1, w1, h1);
/* 756 */               g2.drawRect(x2, y2, w2, h2);
/*     */             } else {
/*     */               
/* 759 */               h1 = b - t;
/* 760 */               g2.setColor(clueBgC);
/* 761 */               g2.fillRect(x1, y1, w1, h1);
/* 762 */               g2.setColor(clueOlC);
/* 763 */               g2.drawRect(x1, y1, w1, h1);
/*     */             } 
/* 765 */             g2.setColor(curClueC);
/*     */           } 
/* 767 */           g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 1, clueFontSize));
/* 768 */           fm = g2.getFontMetrics();
/* 769 */           String str = R2LClue ? (" ." + (NodeList.nodeList[z]).id) : ((NodeList.nodeList[z]).id + ". ");
/* 770 */           int inset = fm.stringWidth(str);
/* 771 */           int xCoord = R2LClue ? (lX + colW - inset) : (lX + 5);
/* 772 */           if (printSt == 2) g2.drawString(str, xCoord, lY + fontSp); 
/* 773 */           g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 0, clueFontSize));
/* 774 */           fm = g2.getFontMetrics();
/* 775 */           str = (NodeList.nodeList[z]).clue;
/* 776 */           (NodeList.nodeList[z]).nlCt = lY + fontSp - 9 * fm.getAscent() / 10;
/* 777 */           (NodeList.nodeList[z]).nlCl = lX; do {
/*     */             int cut;
/* 779 */             if (fm.stringWidth(str) <= colW - inset - 10) {
/* 780 */               lY += fontSp;
/* 781 */               xCoord = R2LClue ? (lX + colW - inset - fm.stringWidth(str)) : (lX + 5 + inset);
/* 782 */               if (printSt == 2) {
/* 783 */                 g2.drawString(str, xCoord, lY);
/*     */               } else {
/* 785 */                 (NodeList.nodeList[z]).nlCb = lY + 9 * fm.getDescent() / 10;
/* 786 */                 (NodeList.nodeList[z]).nlCr = lX + colW;
/*     */               } 
/* 788 */               if (lY + fontSp > cluB - fm.getAscent()) {
/* 789 */                 lX = (ccDat[++ccNum]).x;
/* 790 */                 lY = (ccDat[ccNum]).y;
/* 791 */                 if ((ccDat[ccNum]).y < ccTop) lY += ccTop % fontSp; 
/* 792 */                 colW = (ccDat[ccNum]).w;
/*     */               } 
/*     */               
/*     */               break;
/*     */             } 
/* 797 */             if (str.charAt(str.length() - 1) == ')' && str.indexOf(' ') != -1 && str.indexOf(' ') != str.lastIndexOf(' '))
/* 798 */             { cut = str.lastIndexOf(' '); }
/* 799 */             else { cut = str.length(); }
/* 800 */              for (; --cut > 0; cut--) {
/* 801 */               if (str.charAt(cut) == ' ') {
/* 802 */                 String str2 = str.substring(0, cut);
/* 803 */                 if (fm.stringWidth(str2) <= colW - inset - 10) {
/* 804 */                   lY += fontSp;
/* 805 */                   xCoord = R2LClue ? (lX + colW - inset - fm.stringWidth(str2)) : (lX + 5 + inset);
/* 806 */                   if (printSt == 2) {
/* 807 */                     g2.drawString(str2, xCoord, lY);
/*     */                   } else {
/* 809 */                     (NodeList.nodeList[z]).nlCb = lY + fm.getDescent();
/* 810 */                     (NodeList.nodeList[z]).nlCr = lX + colW;
/*     */                   } 
/* 812 */                   if (lY + fontSp > cluB - fm.getAscent()) {
/* 813 */                     (NodeList.nodeList[z]).nlBot = lY + fm.getDescent();
/* 814 */                     lX = (ccDat[++ccNum]).x;
/* 815 */                     lY = (ccDat[ccNum]).y;
/* 816 */                     if ((ccDat[ccNum]).y < ccTop) lY += ccTop % fontSp; 
/* 817 */                     colW = (ccDat[ccNum]).w;
/* 818 */                     (NodeList.nodeList[z]).nlTop = lY + fontSp - fm.getAscent();
/*     */                   } 
/* 820 */                   str = str.substring(cut + 1);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 825 */           } while (colW != 0);
/*     */           
/* 827 */           g2.setColor(clueC);
/* 828 */           if (colW == 0)
/*     */             break; 
/* 830 */         }  if (colW == 0 || 
/* 831 */           printSt == 2)
/*     */           break; 
/* 833 */         if (ccMax <= ccNum) {
/* 834 */           if (printSt == 0) { fontSp = --clueFontSize; continue; }
/* 835 */            fontSp--; continue;
/* 836 */         }  if (printSt == 0) { printSt = 1; fontSp += 40; continue; }
/* 837 */          printSt = 2;
/*     */       } 
/*     */     } 
/*     */     
/* 841 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   
/*     */   static void loadSolvePuzzle() {
/* 845 */     Grid.clearGrid();
/* 846 */     loadOuroboros(Op.cw[Op.CW.CwSolvePuz.ordinal()]);
/* 847 */     restoreFrame();
/* 848 */     Def.dispCursor = Boolean.valueOf(true); Def.dispSolArray = Boolean.valueOf(true);
/*     */   }
/*     */   void restoreIfDone() {
/*     */     int j;
/* 852 */     for (j = 0; j < Grid.ySz; j++) {
/* 853 */       for (int i = 0; i < Grid.xSz; i++)
/* 854 */       { if (Character.isLetter(Grid.letter[i][j]) && Grid.sol[i][j] != Grid.letter[i][j])
/*     */           return;  } 
/* 856 */     }  for (j = 0; j < Grid.ySz; j++) {
/* 857 */       for (int i = 0; i < Grid.xSz; i++)
/* 858 */         Grid.sol[i][j] = 0; 
/*     */     } 
/*     */   }
/*     */   void changeToNewNode(int newNode) {
/* 862 */     if (Grid.nCur == newNode) {
/* 863 */       String url = "http://www.google.com/search?q=Dictionary+" + (NodeList.nodeList[newNode]).clue;
/* 864 */       url = url.replace(' ', '+');
/* 865 */       browserLaunch.openURL(jfSolveOuroboros, url);
/*     */     } 
/* 867 */     Grid.nCur = newNode;
/* 868 */     Grid.xCur = (NodeList.nodeList[newNode]).x;
/* 869 */     Grid.yCur = (NodeList.nodeList[newNode]).y;
/*     */   }
/*     */   
/*     */   void updateGrid(MouseEvent e) {
/* 873 */     int x = e.getX(), y = e.getY();
/*     */     
/* 875 */     if (Def.dispErrors.booleanValue()) { Def.dispErrors = Boolean.valueOf(false); return; }
/* 876 */      if (x < Grid.xOrg || y < Grid.yOrg)
/* 877 */       return;  int i = (x - Grid.xOrg) / Grid.xCell;
/* 878 */     int j = (y - Grid.yOrg) / Grid.yCell;
/* 879 */     if (i < Grid.xSz && j < Grid.ySz) {
/* 880 */       if (Grid.mode[i][j] == 0)
/* 881 */         if (Grid.xCur == i && Grid.yCur == j) {
/* 882 */           if (Grid.nCur == Grid.horz[Grid.xCur][Grid.yCur] && Grid.vert[Grid.xCur][Grid.yCur] != -1) { Grid.nCur = Grid.vert[Grid.xCur][Grid.yCur]; }
/* 883 */           else if (Grid.nCur == Grid.vert[Grid.xCur][Grid.yCur] && Grid.horz[Grid.xCur][Grid.yCur] != -1) { Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; }
/*     */         
/*     */         } else {
/* 886 */           Grid.xCur = i; Grid.yCur = j;
/* 887 */           if (Grid.nCur != Grid.horz[Grid.xCur][Grid.yCur] && Grid.nCur != Grid.vert[Grid.xCur][Grid.yCur]) {
/* 888 */             int stCell = (NodeList.nodeList[Grid.horz[Grid.xCur][Grid.yCur]]).length;
/* 889 */             if ((cellSpec[stCell]).x == Grid.xCur && (cellSpec[stCell]).y == Grid.yCur)
/* 890 */             { Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; }
/* 891 */             else { Grid.nCur = Grid.vert[Grid.xCur][Grid.yCur]; }
/*     */           
/*     */           } 
/*     */         }  
/*     */     } else {
/* 896 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 897 */         if ((NodeList.nodeList[i]).nlCb < (NodeList.nodeList[i]).nlCt) {
/* 898 */           this.w = (int)Math.floor((((NodeList.nodeList[i]).nlCr - (NodeList.nodeList[i]).nlCl - 10) / 2));
/* 899 */           if ((x > (NodeList.nodeList[i]).nlCl && x < (NodeList.nodeList[i]).nlCl + this.w && y > (NodeList.nodeList[i]).nlCt && y < (NodeList.nodeList[i]).nlBot) || (x > (NodeList.nodeList[i]).nlCr - this.w && x < (NodeList.nodeList[i]).nlCr && y > (NodeList.nodeList[i]).nlTop && y < (NodeList.nodeList[i]).nlCb)) {
/*     */             
/* 901 */             changeToNewNode(i);
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/* 906 */         } else if (x > (NodeList.nodeList[i]).nlCl && x < (NodeList.nodeList[i]).nlCr && y > (NodeList.nodeList[i]).nlCt && y < (NodeList.nodeList[i]).nlCb) {
/* 907 */           changeToNewNode(i);
/*     */           break;
/*     */         } 
/*     */       } 
/* 911 */       if (i == NodeList.nodeListLength)
/*     */         return; 
/* 913 */     }  pp.repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void nextLocation(int mode) {
/* 920 */     int dir = (NodeList.nodeList[Grid.nCur]).direction;
/* 921 */     int i = Grid.grid[Grid.xCur][Grid.yCur];
/* 922 */     if (dir == mode)
/* 923 */     { if (++i >= numCells) i -= numCells;
/*     */        }
/* 925 */     else if (--i < 0) { i += numCells; }
/* 926 */      int x = (cellSpec[i]).x, y = (cellSpec[i]).y;
/* 927 */     if (Grid.nCur == ((dir == 1) ? Grid.horz[x][y] : Grid.vert[x][y])) {
/* 928 */       Grid.xCur = x;
/* 929 */       Grid.yCur = y;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void handleKeyPressed(KeyEvent e) {
/*     */     int i;
/*     */     char theChar;
/* 937 */     if (Def.dispErrors.booleanValue()) { Def.dispErrors = Boolean.valueOf(false); return; }
/* 938 */      if (e.isAltDown())
/* 939 */       return;  switch ((char)e.getKeyCode()) { case '&':
/* 940 */         for (i = Grid.yCur - 1; i >= 0; ) { if (Grid.mode[Grid.xCur][i] == 0) { Grid.yCur = i; Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; break; }  i--; }  break;
/* 941 */       case '(': for (i = Grid.yCur + 1; i < Grid.ySz; ) { if (Grid.mode[Grid.xCur][i] == 0) { Grid.yCur = i; Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; break; }  i++; }  break;
/* 942 */       case '%': for (i = Grid.xCur - 1; i >= 0; ) { if (Grid.mode[i][Grid.yCur] == 0) { Grid.xCur = i; Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; break; }  i--; }  break;
/* 943 */       case '\'': for (i = Grid.xCur + 1; i < Grid.xSz; ) { if (Grid.mode[i][Grid.yCur] == 0) { Grid.xCur = i; Grid.nCur = Grid.horz[Grid.xCur][Grid.yCur]; break; }  i++; }  break;
/* 944 */       case '$': for (i = 0; i < Grid.xSz; ) { if (Grid.mode[i][Grid.yCur] == 0) { Grid.xCur = i; break; }  i++; }  break;
/* 945 */       case '#': for (i = Grid.xSz - 1; i > 0; ) { if (Grid.mode[i][Grid.yCur] == 0) { Grid.xCur = i; break; }  i--; }  break;
/* 946 */       case '!': for (i = 0; i < Grid.xSz; ) { if (Grid.mode[Grid.xCur][i] == 0) { Grid.yCur = i; break; }  i++; }  break;
/* 947 */       case '"': for (i = Grid.ySz - 1; i < Grid.ySz; ) { if (Grid.mode[Grid.xCur][i] == 0) { Grid.yCur = i; break; }  i--; }  break;
/* 948 */       case '\n': Grid.nCur = (Grid.nCur == Grid.horz[Grid.xCur][Grid.yCur]) ? Grid.vert[Grid.xCur][Grid.yCur] : Grid.horz[Grid.xCur][Grid.yCur]; break;
/* 949 */       case '\b': Grid.sol[Grid.xCur][Grid.yCur] = 0; nextLocation(0); break;
/* 950 */       case '': Grid.sol[Grid.xCur][Grid.yCur] = 0; nextLocation(1); break;
/*     */       default:
/* 952 */         if (!Character.isLetter(e.getKeyChar()) && !Character.isSpaceChar(e.getKeyChar()))
/* 953 */           return;  theChar = Character.toUpperCase(e.getKeyChar());
/* 954 */         Grid.sol[Grid.xCur][Grid.yCur] = theChar;
/* 955 */         nextLocation(1);
/* 956 */         (new Thread(this.solveThread)).start();
/*     */         break; }
/*     */     
/* 959 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\OuroborosSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */