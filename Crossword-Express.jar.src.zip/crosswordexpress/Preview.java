/*    */ package crosswordexpress;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JFileChooser;
/*    */ 
/*    */ class Preview extends JComponent implements PropertyChangeListener {
/*    */   public Preview(JFileChooser fc) {
/* 11 */     this.file = fc.getSelectedFile().getName();
/* 12 */     setPreferredSize(new Dimension(300, 300));
/* 13 */     fc.addPropertyChangeListener("SelectedFileChangedProperty", this);
/*    */   }
/*    */   String file;
/*    */   public void propertyChange(PropertyChangeEvent e) {
/* 17 */     if ("SelectedFileChangedProperty".equals(e.getPropertyName())) {
/* 18 */       Object obj = e.getNewValue();
/* 19 */       if (obj == null)
/* 20 */         return;  this.file = ((File)obj).getName();
/* 21 */       repaint();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void paintComponent(Graphics g) {
/* 26 */     super.paintComponent(g);
/* 27 */     Grid.loadGrid(this.file);
/* 28 */     Grid.setSizesAndOffsets(10, 10, 278, 278);
/* 29 */     Graphics2D g2 = (Graphics2D)g;
/* 30 */     g2.setColor(Def.COLOR_WHITE);
/* 31 */     g2.fillRect(0, 0, 298, 298);
/* 32 */     if (this.file.length() != 0)
/* 33 */       Grid.drawGrid(g2); 
/* 34 */     g2.setColor(Def.COLOR_GRAY);
/* 35 */     g2.setStroke(new BasicStroke(1.0F));
/* 36 */     g2.drawRect(0, 0, 298, 298);
/*    */   }
/*    */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Preview.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */