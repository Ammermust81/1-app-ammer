/*      */ package crosswordexpress;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.File;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.SpinnerNumberModel;
/*      */ 
/*      */ public final class Print extends JPanel {
/*      */   static JFrame jfPrint;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   static JPanel pp;
/*      */   static int frameX;
/*      */   static int frameY;
/*      */   static int printRes;
/*      */   JLabel jlLayoutName;
/*      */   static JSpinner jspinx;
/*      */   static JSpinner jspiny;
/*      */   static JSpinner jspinw;
/*      */   static JSpinner jspinh;
/*      */   static JComboBox<String> jcbbLayoutItem;
/*      */   static JComboBox<String> jcbbLayouts;
/*   37 */   static String[] layoutItemName = new String[] { "Puzzle Name", "Author", "Copyright", "Puzzle Number", "Puzzle Notes", "Puzzle", "Solution Name", "Solution", "Clues 1", "Clues 2", "Clues 3", "Clues 4", "Clues 5", "Clues 6", "Clues 7", "Clues 8", "Clues 9", "Clues 10", "Clues 11", "Clues 12", "Acrostic", "Codeword", "Word Pool" }; static String puzzleFile; static String thePuzzle; final JButton jbSave; final JButton jbSaveAs; final JButton jbDelete; static final int IDLE = 0; static final int MOVE = 1; static final int RESIZE = 2;
/*      */   static final int LIMIT = 500;
/*      */   static final int NUM_ITEMS = 31;
/*      */   static final int L = 0;
/*      */   static final int T = 1;
/*      */   static final int W = 2;
/*      */   static final int H = 3;
/*   44 */   static int thisItem = 5; static int cursorMode = 0;
/*   45 */   static int[][] puzzleItem = new int[31][4]; static boolean previewMode;
/*      */   static boolean memCursor;
/*      */   static Component comp;
/*   48 */   static JRadioButton[] jrbExportMode = new JRadioButton[5];
/*      */   Timer myTimer;
/*   50 */   static int howMany = 1; static int startPuz = 1;
/*      */   static int hmCount;
/*   52 */   String graphicExportOptions = "<div>This function allows you to export a puzzle to the System Clipboard, or to a Graphics file. The layout of the exported puzzle will be the same as depicted in the Print Preview panel. The Options you can change before exporting the puzzle are as follows:-</div><br><ul><li/><span>PNG Export Mode.</span> This is the default Mode when exporting puzzles. It is the preferred export mode as it includes an option to control the Resolution of the exported image. Resolution is commonly expressed as <b>Dots Per Inch (DPI)</b> but the more correct term <b>Pixels Per Inch (PPI)</b> is used here. The Resolution can be adjusted over a wide enough range of values to satisfy all requirements.<p/><li/><span>Multi-Puzzle Control.</span> If you have used the <b>Multi Build</b> option to build an extended series of puzzles, it is likely that you would want to be able to export all of those puzzles in a single operation. Simply type the number of puzzles you would like to export into the <b>How many Puzzles</b> field, and type the number of the first puzzle to be exported into the <b>First Puzzle</b> field. When you click the <b>Export</b> button, you will be given an opportunity to select the location on your hard drive where the puzzles will be saved as a series of <b>PNG</b> files having the resolution you specified in <b>PNG Export Mode.</b><p/><li/><b>HOWEVER:</b> If you used the simplified numbering scheme for your puzzles when you created them, you can enter just the number which you specified as the first number, and Crossword Express will number the puzzles sequentially starting with your number.<p/><li/><span>Other Export Modes.</span> The other Export Modes available are <b>BMP, GIF, JPG</b> and <b>System Clipboard. </b>The only resolution available for these modes is the standard default of 72 PPI.<p/><li/><span>Graphic width:</span> The default Export size is determined by the settings selected for the Layout design, and is reported in the dialog for your information. If the exported graphic image is not precisely the size you would like it to be you can control it by use of the <b>Graphic Width</b> control. When you do, the height of the graphic image will be automatically scaled to maintain the correct aspect ratio.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   String printingHelp = "<span class='m'>Puzzle Layout Functions</span><br/><br/><div>The Crossword Express Print function provides you with a very high degree of printout configurability. The controls in this dialog allow you to specify exactly which components of a puzzle will be printed, and the exact sizes and locations of those components. The following options and controls are available:-</div><ul><li/><span>Select a Puzzle Layout</span><br/>The process of printing a puzzle is controlled by means of a <b>Puzzle Layout</b> specification. A Number of these specifications are provided with the program, and you can select the one which appears to be most suitable for your requirements using the <b>Select a Puzzle Layout</b> drop down list. If none of them are exactly right it is a simple matter for you to create and save as many new ones as you require. Alternatively, you can modify an existing layout and save it under a new name using the <b>Save As</b> button. The steps involved in doing this are described in later sections of this Help topic.<p/><li/><span>Select a Layout Item</span><br/>Each puzzle layout consists of a number of <b>Layout Items</b> each of which can be adjusted in terms of its size and its location within the layout. Before you can adjust a layout item you must select it. If the layout item you wish to adjust is already visible on the screen, you can select it by simply clicking anywhere within its area. If it is not yet included in the layout, you can add it to the layout using the <b>Select a Layout Item</b> combo box.<p/><br>The Layout Item types you can select, and their functions are as follows<ul><li/><b>Puzzle Name:</b> Before you create any type of puzzle, you must use the <b>Start a New Puzzle</b> menu option available from the <b>Construction</b> screen to enter some items of information about the puzzle you are going to build. One of these items is the name of the puzzle, and if the <b>Puzzle Name</b> item is included in the layout, the <b>Print</b> function will include the puzzle name in the location you specify, using the largest font which will allow the name to fit into the space provided.<li/><b>Author:</b> You can include some details about yourself as the author of the puzzle. Those details are also input via the <b>Start a New Puzzle</b> menu option.<li/><b>Copyright:</b> As above, but contains any copyright information you may care to include.<li/><b>Puzzle Number:</b> As above, but provides for a puzzle serial number if required.<li/><b>Puzzle Notes:</b> As above. Any relevant information may be included, and if it extends beyond a single line of text, the program will make the necessary arrangements.<li/><b>Puzzle:</b> This item allocates the space in which the graphic image representing the puzzle will be located.<li/><b>Solution Name:</b> Similar in all respects to <b>Puzzle Name</b> above.<li/><b>Solution:</b> This item allocates the space in which the graphic image representing the solution will be located. Normally this would be the solution to yesterday's puzzle, or last week's puzzle.<li/><b>Clues 1 to 12:</b> A maximum of 12 rectangular spaces may be allocated for the clues. The program uses these spaces in sequence, and will use the largest font which allows the clues to fit neatly into the space provided.<li/><b>Acrostic:</b> This item allocates the space into which the solver will place the answers to the individual clues of the acrostic.<li/><b>Codeword:</b> This item allocates the area which wiil be used to display the additional letter tables associated with <b>Codeword</b> puzzles.<li/><b>Word Pool:</b> If you include this item in the case of a crossword puzzle, the program will fill the entire area of the <b>WordPool</b> with words. These words will include all of the solution words for the puzzle, plus an equal number of words selected at random from the dictionary used to create the puzzle. This would be very useful for bilingual puzzles used for teaching a second language.</ul><li/><span>Adjust the Layout Item</span><br/>After selecting a layout item, that item will be colored blue on the Puzzle Layout. It can be adjusted by either of the following methods:-<ul><li/><b>Drag and Drop: </b>When an item has been selected, it acquires two <b>handles</b> which can be captured by the mouse, and dragged to a new location. The top left handle drags the item to a new location, while the bottom right handle changes the size of the item. This is good for making large and quick adjustments.<p/><li/><b>Spinner control: </b>The control panel contains four spinner controls labeled <b>Left, Top, Width</b> and <b>Height.</b> The Left and Top spinners control the location of the Layout Item, while the Width and Height spinners control its size. This is good for making fine adjustments.</ul><li/><span>Remove the Layout Item</span><br/>If you find that one of your Layout Items is no longer required, it can be removed by first selecting it, and then clicking the <b>Remove the Layout Item</b> button.<p/><li/><span>Move the Layout</span><br/>It will often happen when designing a new <b>Layout</b>, that all of the <b>Items</b> are the correct size, and are correctly located with respect to each other, but the whole layout is not correctly located on the page. This is easily corrected by using the <b>Left, Right, Up</b> and <b>Down</b> buttons.<p/><li/><span>Save the Layout</span><br/>If you have made some minor changes to a <b>Layout</b> design, and you want to keep those changes for future use, then clicking the <b>Save the Layout</b> button will save the layout under its original name.<p/><li/><span>Save Layout As</span><br/>If, on the other hand, you have made some significant changes, it is likely that you will want to save the new layout and still retain the original one. This can be achieved by use of the <b>Save Layout As</b> button.<p/><li/><span>Delete this Layout</span><br/>The layout currently being displayed can be removed from the system by clicking the <b>Delete this Layout</b> button.</ul><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Quit Printing</span><br/>When you have finished all of your printing operations, this option will return you to the screen from which you called the print function.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Print Layout</span><br/>The right hand side of the screen can display either the Print Layout, or a Preview of the puzzle as it will appear when it is printed. This menu option will redisplay the screen to show the Print Layout.<p/><li/><span>Display Print Preview</span><br/>This menu option will redisplay the screen to show a Preview of the Puzzle.<p/><li/><span>Print Options</span><br/> A set of Options is available for each of the puzzle types you can print from the Print screen. In every case, color and font options are available, while a few puzzle types include specialised options which are described in the Help available from the Print Options dialog.<p/><li/><span>Language Elements</span><br/> Many word puzzles include standard words in the printed output. The most obvious example of this would be the ACROSS and DOWN labels associated with the clues of a crossword. If you are not working in the English language you will probably want to change these labels to something appropriate to your own language. This option will allow you to do that.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Select Solution Puzzle</span><br/>If the <b>Layout</b> you have selected includes space for both a <b>Puzzle</b> and a <b>Solution</b>, then normally you would want the solution to apply to a different puzzle (yesterday's or last week's). You can use the <b>Select Solution Puzzle</b> button to nominate the puzzle whose solution will be included in the printout. If you don't select a solution puzzle, the program will print the solution which applies to the current puzzle.<p/><li/><span>Print</span><br/>When you are satisfied with the layout you have chosen, and with the appearance of the preview, clicking this button will begin the process of printing the puzzle. If you are operating the program on a Windows computer, and have installed the <b>Primo PDF</b> program you will have the option of sending output either to the printer or to a PDF file located anywhere on your hard drive.<p/><li/><span>Export</span><br/>Alternatively you can export the output to the System Clipboard or to a graphics file located anywhere on your hard drive by clicking the <b>Export</b> button.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Print Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   String languageElementsHelp = "<div>When you are performing the printing function for some of the word puzzles, the print will normally include one or more language elements (such as ACROSS and DOWN in a crossword) which you may want to change if you are making puzzles in a language other than English. This dialog contains input fields which allow you to change the following English words to the corresponding words for the language of your choice.</div><ul><li/><span>ACROSS</span><br/>The word you enter here will be used when printing the Across clues for Crossword and Ladder-word puzzles.<p/><li/><span>DOWN</span><br/>The word you enter here will be used when printing the Down clues for Crossword and Ladder-word puzzles.<p/><li/><span>WORDS</span><br/>The printed forms of Acrostic solutions and Word-search puzzles include a list of words. The word you enter here willbe used as a label at the head of this list.<p/><li/><span>CLUES</span><br/>Doublet, Pyramid-word and Acrostic puzzles all require a list of clues in the printed output. The word you enter here will be used as a label at the head of this list.<p/><li/><span>TEXT</span><br/>The solution to an Acrostic puzzle includes a block of text, and the label at the beginning of this text will be provided by the word you enter in this field.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Print(JFrame jf, String file) {
/*  210 */     Op.msc[Op.MSC.SolutionPuz.ordinal()] = puzzleFile = file; Op.msc[Op.MSC.SolutionPuz.ordinal()] = puzzleFile = file;
/*  211 */     previewMode = false;
/*  212 */     Def.printing = true;
/*  213 */     Def.dispCursor = Boolean.valueOf(false);
/*      */     
/*  215 */     jfPrint = new JFrame("Print");
/*  216 */     jfPrint.setSize(Op.getInt(Op.MSC.PrintW.ordinal(), Op.msc), Op.getInt(Op.MSC.PrintH.ordinal(), Op.msc));
/*  217 */     int frameX = (jf.getX() + jfPrint.getWidth() > Methods.scrW) ? (Methods.scrW - jfPrint.getWidth() - 10) : jf.getX();
/*  218 */     jfPrint.setLocation(frameX, jf.getY());
/*  219 */     jfPrint.setLayout((LayoutManager)null);
/*  220 */     jfPrint.setDefaultCloseOperation(0);
/*  221 */     jfPrint
/*  222 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  224 */             Print.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  228 */     jfPrint
/*  229 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  231 */             Print.jfPrint.dispose();
/*  232 */             Methods.closeHelp();
/*  233 */             Print.this.disposePrintScreen();
/*      */           }
/*      */         });
/*      */     
/*  237 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  240 */     menuBar = new JMenuBar();
/*  241 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  242 */     jfPrint.setJMenuBar(menuBar);
/*      */     
/*  244 */     this.menu = new JMenu("File");
/*  245 */     menuBar.add(this.menu);
/*  246 */     this.menuItem = new JMenuItem("Quit Printing");
/*  247 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  248 */     this.menu.add(this.menuItem);
/*  249 */     this.menuItem
/*  250 */       .addActionListener(ae -> {
/*      */           jfPrint.dispose();
/*      */           
/*      */           Methods.closeHelp();
/*      */           
/*      */           disposePrintScreen();
/*      */         });
/*      */     
/*  258 */     this.menu = new JMenu("View");
/*  259 */     menuBar.add(this.menu);
/*  260 */     this.menuItem = new JMenuItem("Display Print Layout");
/*  261 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  262 */     this.menu.add(this.menuItem);
/*  263 */     this.menuItem
/*  264 */       .addActionListener(ae -> {
/*      */           previewMode = false;
/*      */           
/*      */           pp.repaint();
/*      */         });
/*      */     
/*  270 */     this.menuItem = new JMenuItem("Display Print Preview");
/*  271 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  272 */     this.menu.add(this.menuItem);
/*  273 */     this.menuItem
/*  274 */       .addActionListener(ae -> {
/*      */           previewMode = true;
/*      */           
/*      */           Def.dispPrinting = Boolean.valueOf(true);
/*      */           
/*      */           Def.dispCursor = Boolean.valueOf(false);
/*      */           pp.repaint();
/*      */           this.myTimer.start();
/*      */         });
/*  283 */     this.menuItem = new JMenuItem("Print Options");
/*  284 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  285 */     this.menu.add(this.menuItem);
/*  286 */     this.menuItem
/*  287 */       .addActionListener(ae -> { Methods.closeHelp(); switch (Def.puzzleMode) { case 10: AcrosticBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 20: AkariBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 7: Arrowword.arrowwordPrintOptions(); pp.repaint(); return;
/*      */             case 30: CodewordSolve.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 4: case 6: case 12: FreeformBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 220: DevanagariBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 210: WordsquareBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 40: DominoBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 50: DoubletBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 60: FillinSolve.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 70: FillominoBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 72: FindAQuote.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 80: FutoshikiBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 90: GokigenBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 100: KakuroBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 110: KendokuBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 112: KsudokuBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 120:
/*      */               LadderwordBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 230:
/*      */               MarupekeBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 132:
/*      */               MinesweeperBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 140:
/*      */               PyramidwordBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 150:
/*      */               RoundaboutsBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 160:
/*      */               SikakuBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 170:
/*      */               SlitherlinkBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 180:
/*      */               SudokuBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 182:
/*      */               TatamiBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 190:
/*      */               TentsBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return;
/*      */             case 200:
/*      */             case 202:
/*  326 */               WordsearchBuild.printOptions(jfPrint, "Print Options"); pp.repaint(); return; }  Methods.pending(jfPrint); }); this.menuItem = new JMenuItem("Language Elements");
/*  327 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(71, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  328 */     this.menu.add(this.menuItem);
/*  329 */     this.menuItem
/*  330 */       .addActionListener(ae -> {
/*      */           Methods.closeHelp();
/*      */ 
/*      */           
/*      */           languageElements();
/*      */         });
/*      */     
/*  337 */     this.menu = new JMenu("Tasks");
/*  338 */     menuBar.add(this.menu);
/*  339 */     this.menuItem = new JMenuItem("Select Solution Puzzle");
/*  340 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  341 */     this.menu.add(this.menuItem);
/*  342 */     this.menuItem
/*  343 */       .addActionListener(ae -> {
/*      */           boolean res = false;
/*      */           Methods.theFileName = "5-May-2009";
/*      */           switch (Def.puzzleMode) {
/*      */             case 10:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ac[Op.AC.AcPuz.ordinal()];
/*      */               new Select(jfPrint, Op.ac[Op.AC.AcDic.ordinal()] + ".dic", "acrostic", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 20:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ak[Op.AK.AkPuz.ordinal()];
/*      */               new Select(jfPrint, "akari", "akari", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 4:
/*      */             case 7:
/*      */             case 12:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.cw[Op.CW.CwPuz.ordinal()];
/*      */               new Select(jfPrint, Op.cw[Op.CW.CwDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 220:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.dv[Op.DV.DvPuz.ordinal()];
/*      */               new Select(jfPrint, Op.dv[Op.DV.DvDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 210:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.sw[Op.SW.SwPuz.ordinal()];
/*      */               new Select(jfPrint, Op.sw[Op.SW.SwDic.ordinal()] + ".dic", "wordsquare", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 30:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.cw[Op.CW.CwPuz.ordinal()];
/*      */               new Select(jfPrint, Op.cw[Op.CW.CwDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 40:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.dm[Op.DM.DmPuz.ordinal()];
/*      */               new Select(jfPrint, "domino", "domino", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 50:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.db[Op.DB.DbPuz.ordinal()];
/*      */               new Select(jfPrint, Op.db[Op.DB.DbDic.ordinal()] + ".dic", "doublet", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 60:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.cw[Op.CW.CwPuz.ordinal()];
/*      */               new Select(jfPrint, Op.cw[Op.CW.CwDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 13:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ff[Op.FF.FfPuz.ordinal()];
/*      */               new Select(jfPrint, Op.ff[Op.FF.FfDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 70:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.fi[Op.FI.FiPuz.ordinal()];
/*      */               new Select(jfPrint, "fillomino", "fillomino", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 6:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ff[Op.FF.FfPuz.ordinal()];
/*      */               new Select(jfPrint, Op.ff[Op.FF.FfDic.ordinal()] + ".dic", "crossword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 80:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.fu[Op.FU.FuPuz.ordinal()];
/*      */               new Select(jfPrint, "futoshiki", "futoshiki", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 90:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.gk[Op.GK.GkPuz.ordinal()];
/*      */               new Select(jfPrint, "gokigen", "gokigen", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 100:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.kk[Op.KK.KkPuz.ordinal()];
/*      */               new Select(jfPrint, "kakuro", "kakuro", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 110:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ke[Op.KE.KePuz.ordinal()];
/*      */               new Select(jfPrint, "kendoku", "kendoku", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 112:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ke[Op.KE.KePuz.ordinal()];
/*      */               new Select(jfPrint, "ksudoku", "ksudoku", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 120:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.lw[Op.LW.LwPuz.ordinal()];
/*      */               new Select(jfPrint, Op.lw[Op.LW.LwDic.ordinal()] + ".dic", "ladderword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 130:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ld[Op.LD.LdPuz.ordinal()];
/*      */               new Select(jfPrint, "letterdrop", "letterdrop", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 230:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ma[Op.MA.MaPuz.ordinal()];
/*      */               new Select(jfPrint, "marupeke", "marupeke", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 132:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ms[Op.MS.MsPuz.ordinal()];
/*      */               new Select(jfPrint, "minesweeper", "minesweeper", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 134:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ob[Op.OB.ObPuz.ordinal()];
/*      */               new Select(jfPrint, Op.ob[Op.OB.ObDic.ordinal()] + ".dic", "ouroboros", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 140:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.py[Op.PY.PyPuz.ordinal()];
/*      */               new Select(jfPrint, Op.py[Op.PY.PyDic.ordinal()] + ".dic", "pyramidword", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 150:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ra[Op.RA.RaPuz.ordinal()];
/*      */               new Select(jfPrint, "roundabouts", "roundabouts", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 160:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.sk[Op.SK.SkPuz.ordinal()];
/*      */               new Select(jfPrint, "sikaku", "sikaku", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 170:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.sl[Op.SL.SlPuz.ordinal()];
/*      */               new Select(jfPrint, "slitherlink", "slitherlink", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 180:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.su[Op.SU.SuPuz.ordinal()];
/*      */               new Select(jfPrint, "sudoku", "sudoku", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 182:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.tt[Op.TT.TtPuz.ordinal()];
/*      */               new Select(jfPrint, "tatami", "tatami", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 190:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.te[Op.TE.TePuz.ordinal()];
/*      */               new Select(jfPrint, "tents", "tents", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */             case 200:
/*      */               Op.msc[Op.MSC.SolutionPuz.ordinal()] = Op.ws[Op.WS.WsPuz.ordinal()];
/*      */               new Select(jfPrint, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", "wordsearch", Op.msc, Op.MSC.SolutionPuz.ordinal(), true);
/*      */               break;
/*      */           } 
/*      */           if (!res) {
/*      */             return;
/*      */           }
/*      */           pp.repaint();
/*      */         });
/*  475 */     this.menuItem = new JMenuItem("Print");
/*  476 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  477 */     this.menu.add(this.menuItem);
/*  478 */     this.menuItem
/*  479 */       .addActionListener(ae -> {
/*      */           Methods.closeHelp();
/*      */           
/*      */           Def.dispPrinting = Boolean.valueOf(true);
/*      */           
/*      */           printProcess();
/*      */           Def.dispPrinting = Boolean.valueOf(false);
/*      */           printResultMessage();
/*      */           pp.repaint();
/*      */         });
/*  489 */     this.menuItem = new JMenuItem("Export");
/*  490 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(88, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  491 */     this.menu.add(this.menuItem);
/*  492 */     this.menuItem
/*  493 */       .addActionListener(ae -> {
/*      */           int maxx = 0; int maxy = 0; int minx = 10000;
/*      */           int miny = 10000;
/*      */           for (int i = 0; i < 31; i++) {
/*      */             if (puzzleItem[i][2] != 0) {
/*      */               if (puzzleItem[i][0] < minx)
/*      */                 minx = puzzleItem[i][0]; 
/*      */               int v = puzzleItem[i][0] + puzzleItem[i][2];
/*      */               if (v > maxx)
/*      */                 maxx = v; 
/*      */               if (puzzleItem[i][1] < miny)
/*      */                 miny = puzzleItem[i][1]; 
/*      */               v = puzzleItem[i][1] + puzzleItem[i][3];
/*      */               if (v > maxy)
/*      */                 maxy = v; 
/*      */             } 
/*      */           } 
/*      */           exportGraphic(maxx + minx, maxy + miny);
/*      */           printResultMessage();
/*      */           pp.repaint();
/*      */         });
/*  514 */     this.menu = new JMenu("Help");
/*  515 */     menuBar.add(this.menu);
/*  516 */     this.menuItem = new JMenuItem("Print Help");
/*  517 */     this.menu.add(this.menuItem);
/*  518 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  519 */     this.menuItem
/*  520 */       .addActionListener(ae -> Methods.cweHelp(jfPrint, null, "Printing a Puzzle", this.printingHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  526 */     JLabel jlSelectLayout = new JLabel("<html><font color=005555>S<u>e</u>lect a Puzzle Layout");
/*  527 */     jlSelectLayout.setSize(210, 16);
/*  528 */     jlSelectLayout.setLocation(15, 10);
/*  529 */     jlSelectLayout.setHorizontalAlignment(2);
/*  530 */     jfPrint.add(jlSelectLayout);
/*      */     
/*  532 */     File fl = new File(System.getProperty("user.dir") + "/layouts/");
/*  533 */     String[] s = fl.list();
/*  534 */     jcbbLayouts = new JComboBox<>();
/*  535 */     jcbbLayouts.setBackground(Def.COLOR_BUTTONBG);
/*  536 */     jcbbLayouts.setSize(210, 26);
/*  537 */     jcbbLayouts.setLocation(15, 28);
/*  538 */     for (int i = 0; i < s.length; i++) {
/*  539 */       if (s[i].endsWith(".layout") && !s[i].startsWith(".")) {
/*  540 */         s[i] = s[i].substring(0, s[i].lastIndexOf('.'));
/*  541 */         jcbbLayouts.addItem("    " + s[i]);
/*      */       } 
/*  543 */     }  jcbbLayouts.setSelectedItem("    " + Op.msc[Op.MSC.LayoutName.ordinal()]);
/*  544 */     jfPrint.add(jcbbLayouts);
/*  545 */     jcbbLayouts
/*  546 */       .addActionListener(ae -> {
/*      */           Op.msc[Op.MSC.LayoutName.ordinal()] = ((String)jcbbLayouts.getSelectedItem()).trim();
/*      */           
/*      */           loadLayout(Op.msc[Op.MSC.LayoutName.ordinal()]);
/*      */           
/*      */           setSpinners();
/*      */           this.jlLayoutName.setText("<html><font color=005500>" + Op.msc[Op.MSC.LayoutName.ordinal()]);
/*      */           comp = jcbbLayouts;
/*      */           pp.repaint();
/*      */         });
/*  556 */     JLabel jlSelectItem = new JLabel("<html><font color=005555>Se<u>l</u>ect a Layout Item");
/*  557 */     jlSelectItem.setSize(210, 16);
/*  558 */     jlSelectItem.setLocation(15, 58);
/*  559 */     jlSelectItem.setHorizontalAlignment(2);
/*  560 */     jfPrint.add(jlSelectItem);
/*      */     
/*  562 */     jcbbLayoutItem = new JComboBox<>();
/*  563 */     jcbbLayoutItem.setBackground(Def.COLOR_BUTTONBG);
/*  564 */     jcbbLayoutItem.setSize(210, 26);
/*  565 */     jcbbLayoutItem.setLocation(15, 78);
/*  566 */     for (String layoutItemName1 : layoutItemName)
/*  567 */       jcbbLayoutItem.addItem("    " + layoutItemName1); 
/*  568 */     jcbbLayoutItem.setSelectedIndex(thisItem);
/*  569 */     jfPrint.add(jcbbLayoutItem);
/*  570 */     jcbbLayoutItem
/*  571 */       .addActionListener(ae -> {
/*      */           if (puzzleItem[thisItem][0] == 2 && puzzleItem[thisItem][1] == 2) {
/*      */             puzzleItem[thisItem][3] = 0; puzzleItem[thisItem][2] = 0;
/*      */             puzzleItem[thisItem][1] = 0;
/*      */             puzzleItem[thisItem][0] = 0;
/*      */             pp.repaint();
/*      */           } 
/*      */           thisItem = jcbbLayoutItem.getSelectedIndex();
/*      */           if (puzzleItem[thisItem][2] == 0) {
/*      */             puzzleItem[thisItem][0] = 2;
/*      */             puzzleItem[thisItem][1] = 2;
/*      */             puzzleItem[thisItem][2] = 50;
/*      */             puzzleItem[thisItem][3] = 6;
/*      */           } 
/*      */           setSpinners();
/*      */           previewMode = false;
/*      */           comp = jcbbLayoutItem;
/*      */           pp.repaint();
/*      */         });
/*  590 */     JLabel jl = new JLabel("<html><font color=005555>Adjust the Layout Item - (mm)");
/*  591 */     jl.setSize(210, 16);
/*  592 */     jl.setLocation(15, 108);
/*  593 */     jl.setHorizontalAlignment(2);
/*  594 */     jfPrint.add(jl);
/*  595 */     loadLayout(Op.msc[Op.MSC.LayoutName.ordinal()]);
/*      */     
/*  597 */     SpinnerNumberModel spm1 = new SpinnerNumberModel(1, 1, 400, 1);
/*  598 */     jspinx = new JSpinner(spm1);
/*  599 */     jspinx.setSize(50, 24);
/*  600 */     jspinx.setLocation(53, 128);
/*  601 */     jfPrint.add(jspinx);
/*  602 */     JLabel jlL = new JLabel("Left");
/*  603 */     jlL.setSize(37, 21);
/*  604 */     jlL.setLocation(10, 128);
/*  605 */     jlL.setHorizontalAlignment(4);
/*  606 */     jfPrint.add(jlL);
/*      */     
/*  608 */     SpinnerNumberModel spm2 = new SpinnerNumberModel(1, 1, 400, 1);
/*  609 */     jspiny = new JSpinner(spm2);
/*  610 */     jspiny.setSize(50, 24);
/*  611 */     jspiny.setLocation(53, 163);
/*  612 */     jfPrint.add(jspiny);
/*  613 */     JLabel jlT = new JLabel("Top");
/*  614 */     jlT.setSize(37, 21);
/*  615 */     jlT.setLocation(10, 163);
/*  616 */     jlT.setHorizontalAlignment(4);
/*  617 */     jfPrint.add(jlT);
/*      */     
/*  619 */     SpinnerNumberModel spm3 = new SpinnerNumberModel(1, 1, 400, 1);
/*  620 */     jspinw = new JSpinner(spm3);
/*  621 */     jspinw.setSize(50, 24);
/*  622 */     jspinw.setLocation(175, 128);
/*  623 */     jfPrint.add(jspinw);
/*  624 */     JLabel jlW = new JLabel("Width");
/*  625 */     jlW.setSize(65, 21);
/*  626 */     jlW.setLocation(104, 128);
/*  627 */     jlW.setHorizontalAlignment(4);
/*  628 */     jfPrint.add(jlW);
/*      */     
/*  630 */     SpinnerNumberModel spm4 = new SpinnerNumberModel(1, 1, 400, 1);
/*  631 */     jspinh = new JSpinner(spm4);
/*  632 */     jspinh.setSize(50, 24);
/*  633 */     jspinh.setLocation(175, 163);
/*  634 */     jfPrint.add(jspinh);
/*  635 */     JLabel jlH = new JLabel("Height");
/*  636 */     jlH.setSize(65, 21);
/*  637 */     jlH.setLocation(104, 163);
/*  638 */     jlH.setHorizontalAlignment(4);
/*  639 */     jfPrint.add(jlH);
/*      */     
/*  641 */     setSpinners();
/*      */     
/*  643 */     jspinx
/*  644 */       .addChangeListener(ce -> {
/*      */           comp = jspinx;
/*      */           
/*      */           int i = ((Integer)jspinx.getValue()).intValue();
/*      */           
/*      */           if (i + puzzleItem[thisItem][2] <= 500) {
/*      */             puzzleItem[thisItem][0] = i;
/*      */             pp.repaint();
/*      */           } else {
/*      */             jspinx.setValue(Integer.valueOf(puzzleItem[thisItem][0]));
/*      */           } 
/*      */         });
/*  656 */     jspiny
/*  657 */       .addChangeListener(ce -> {
/*      */           comp = jspiny;
/*      */           
/*      */           int i = ((Integer)jspiny.getValue()).intValue();
/*      */           if (i + puzzleItem[thisItem][3] <= 500) {
/*      */             puzzleItem[thisItem][1] = i;
/*      */             pp.repaint();
/*      */           } else {
/*      */             jspiny.setValue(Integer.valueOf(puzzleItem[thisItem][1]));
/*      */           } 
/*      */         });
/*  668 */     jspinw
/*  669 */       .addChangeListener(ce -> {
/*      */           comp = jspinw;
/*      */           
/*      */           int i = ((Integer)jspinw.getValue()).intValue();
/*      */           if (i + puzzleItem[thisItem][0] <= 500) {
/*      */             puzzleItem[thisItem][2] = i;
/*      */             pp.repaint();
/*      */           } else {
/*      */             jspinw.setValue(Integer.valueOf(puzzleItem[thisItem][2]));
/*      */           } 
/*      */         });
/*  680 */     jspinh
/*  681 */       .addChangeListener(ce -> {
/*      */           comp = jspinh;
/*      */           
/*      */           int i = ((Integer)jspinh.getValue()).intValue();
/*      */           
/*      */           if (i + puzzleItem[thisItem][1] <= 500) {
/*      */             puzzleItem[thisItem][3] = i;
/*      */             pp.repaint();
/*      */           } else {
/*      */             jspinh.setValue(Integer.valueOf(puzzleItem[thisItem][3]));
/*      */           } 
/*      */         });
/*  693 */     Action doRemove = new AbstractAction("Remove the Layout Item") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  695 */           Print.puzzleItem[Print.thisItem][3] = 0; Print.puzzleItem[Print.thisItem][2] = 0; Print.puzzleItem[Print.thisItem][1] = 0; Print.puzzleItem[Print.thisItem][0] = 0;
/*  696 */           for (Print.thisItem = 0; Print.thisItem < 31 && 
/*  697 */             Print.puzzleItem[Print.thisItem][2] <= 0; Print.thisItem++);
/*      */           
/*  699 */           if (Print.thisItem == 31)
/*  700 */             Print.thisItem = 5; 
/*  701 */           Print.jcbbLayoutItem.setSelectedIndex(Print.thisItem);
/*  702 */           Print.setSpinners();
/*  703 */           Print.pp.repaint();
/*      */         }
/*      */       };
/*  706 */     JButton jbRemove = Methods.newButton("doRemove", doRemove, 82, 15, 198, 210, 26);
/*  707 */     jfPrint.add(jbRemove);
/*      */     
/*  709 */     jl = new JLabel("<html><font color=005555>Move the Layout");
/*  710 */     jl.setSize(210, 16);
/*  711 */     jl.setLocation(15, 228);
/*  712 */     jl.setHorizontalAlignment(2);
/*  713 */     jfPrint.add(jl);
/*      */     
/*  715 */     Action doLeft = new AbstractAction("1: Left") { public void actionPerformed(ActionEvent e) {
/*      */           int i;
/*  717 */           for (i = 0; i < 31; i++) {
/*  718 */             if (Print.puzzleItem[i][0] == 1 && Print.puzzleItem[i][2] > 0)
/*      */               return; 
/*  720 */           }  for (i = 0; i < 31; i++) {
/*  721 */             if (Print.puzzleItem[i][0] > 1)
/*  722 */               Print.puzzleItem[i][0] = Print.puzzleItem[i][0] - 1; 
/*  723 */           }  Print.setSpinners();
/*  724 */           Print.pp.repaint();
/*      */         } }
/*      */       ;
/*  727 */     JButton jbLeft = Methods.newButton("doLeft", doLeft, 49, 15, 248, 90, 26);
/*  728 */     jfPrint.add(jbLeft);
/*      */     
/*  730 */     Action doRight = new AbstractAction("2: Right") { public void actionPerformed(ActionEvent e) {
/*      */           int i;
/*  732 */           for (i = 0; i < 31; i++) {
/*  733 */             if (Print.puzzleItem[i][0] + Print.puzzleItem[i][2] >= 500 && Print.puzzleItem[i][2] > 0)
/*      */               return; 
/*  735 */           }  for (i = 0; i < 31; i++) {
/*  736 */             if (Print.puzzleItem[i][0] + Print.puzzleItem[i][2] < 500)
/*  737 */               Print.puzzleItem[i][0] = Print.puzzleItem[i][0] + 1; 
/*  738 */           }  Print.setSpinners();
/*  739 */           Print.pp.repaint();
/*      */         } }
/*      */       ;
/*  742 */     JButton jbRight = Methods.newButton("doRight", doRight, 50, 125, 248, 100, 26);
/*  743 */     jfPrint.add(jbRight);
/*      */     
/*  745 */     Action doUp = new AbstractAction("3: Up") { public void actionPerformed(ActionEvent e) {
/*      */           int i;
/*  747 */           for (i = 0; i < 31; i++) {
/*  748 */             if (Print.puzzleItem[i][1] == 1 && Print.puzzleItem[i][3] > 0)
/*      */               return; 
/*  750 */           }  for (i = 0; i < 31; i++) {
/*  751 */             if (Print.puzzleItem[i][1] > 1)
/*  752 */               Print.puzzleItem[i][1] = Print.puzzleItem[i][1] - 1; 
/*  753 */           }  Print.setSpinners();
/*  754 */           Print.pp.repaint();
/*      */         } }
/*      */       ;
/*  757 */     JButton jbUp = Methods.newButton("doUp", doUp, 51, 15, 283, 90, 26);
/*  758 */     jfPrint.add(jbUp);
/*      */     
/*  760 */     Action doDown = new AbstractAction("4: Down") { public void actionPerformed(ActionEvent e) {
/*      */           int i;
/*  762 */           for (i = 0; i < 31; i++) {
/*  763 */             if (Print.puzzleItem[i][1] + Print.puzzleItem[i][3] >= 500 && Print.puzzleItem[i][3] > 0)
/*      */               return; 
/*  765 */           }  for (i = 0; i < 31; i++) {
/*  766 */             if (Print.puzzleItem[i][1] + Print.puzzleItem[i][3] < 500)
/*  767 */               Print.puzzleItem[i][1] = Print.puzzleItem[i][1] + 1; 
/*  768 */           }  Print.setSpinners();
/*  769 */           Print.pp.repaint();
/*      */         } }
/*      */       ;
/*  772 */     JButton jbDown = Methods.newButton("doDown", doDown, 52, 125, 283, 100, 26);
/*  773 */     jfPrint.add(jbDown);
/*      */     
/*  775 */     Action doSave = new AbstractAction("Save Layout") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  777 */           Print.this.saveLayout(Op.msc[Op.MSC.LayoutName.ordinal()]);
/*      */         }
/*      */       };
/*  780 */     this.jbSave = Methods.newButton("doSave", doSave, 83, 15, 318, 210, 26);
/*  781 */     jfPrint.add(this.jbSave);
/*      */     
/*  783 */     this.jlLayoutName = new JLabel("<html><font color=005500>" + Op.msc[Op.MSC.LayoutName.ordinal()]);
/*  784 */     this.jlLayoutName.setSize(210, 16);
/*  785 */     this.jlLayoutName.setLocation(15, 348);
/*  786 */     this.jlLayoutName.setHorizontalAlignment(0);
/*  787 */     jfPrint.add(this.jlLayoutName);
/*      */     
/*  789 */     Action doSaveAs = new AbstractAction("Save Layout As") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  791 */           Print.this.saveLayoutAs();
/*      */         }
/*      */       };
/*  794 */     this.jbSaveAs = Methods.newButton("doSaveAs", doSaveAs, 65, 15, 368, 210, 26);
/*  795 */     jfPrint.add(this.jbSaveAs);
/*      */     
/*  797 */     Action doDelete = new AbstractAction("Delete this Layout") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  799 */           int response = JOptionPane.showConfirmDialog(Print.jfPrint, "<html>Delete the Layout <font color=880000 size=4>" + Op.msc[Op.MSC.LayoutName.ordinal()] + "</font>?", "Delete a Layout", 0);
/*  800 */           if (response == 0) {
/*  801 */             File fl1 = new File("layouts/" + Op.msc[Op.MSC.LayoutName.ordinal()] + ".layout");
/*  802 */             fl1.delete();
/*  803 */             Print.jcbbLayouts.removeItemAt(Print.jcbbLayouts.getSelectedIndex());
/*  804 */             Print.jcbbLayouts.validate();
/*      */           } 
/*      */         }
/*      */       };
/*  808 */     this.jbDelete = Methods.newButton("doDelete", doDelete, 68, 15, 403, 210, 26);
/*  809 */     jfPrint.add(this.jbDelete);
/*      */ 
/*      */     
/*  812 */     ActionListener timerAL = ae -> {
/*      */         while (Def.dispPrinting.booleanValue());
/*      */         printResultMessage();
/*      */         this.myTimer.stop();
/*      */       };
/*  817 */     this.myTimer = new Timer(100, timerAL);
/*  818 */     pp = new PreviewPanel(240, 10, jfPrint);
/*  819 */     restoreFrame();
/*      */   }
/*      */   
/*      */   void disposePrintScreen() {
/*  823 */     Def.printing = false;
/*  824 */     Def.dispCursor = Boolean.valueOf(true);
/*  825 */     switch (Def.puzzleMode) { case 13:
/*  826 */         new FreeformBuild(CrosswordExpress.jfCWE); break;
/*      */       case 7:
/*      */       case 12:
/*      */       case 30:
/*      */       case 60:
/*  831 */         Def.puzzleMode = 4;
/*  832 */         Grid.clearGrid();
/*  833 */         new CrosswordBuild(CrosswordExpress.jfCWE);
/*      */         break;
/*      */       case 4:
/*  836 */         new CrosswordBuild(CrosswordExpress.jfCWE); break;
/*  837 */       case 220: new DevanagariBuild(CrosswordExpress.jfCWE); break;
/*  838 */       case 210: new WordsquareBuild(CrosswordExpress.jfCWE); break;
/*  839 */       case 10: new AcrosticBuild(CrosswordExpress.jfCWE); break;
/*  840 */       case 20: new AkariBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  841 */       case 40: new DominoBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  842 */       case 50: new DoubletBuild(CrosswordExpress.jfCWE); break;
/*  843 */       case 61: new FreeformBuild(CrosswordExpress.jfCWE); break;
/*  844 */       case 70: new FillominoBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  845 */       case 72: new FindAQuote(CrosswordExpress.jfCWE); break;
/*  846 */       case 6: new FreeformBuild(CrosswordExpress.jfCWE); break;
/*  847 */       case 80: new FutoshikiBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  848 */       case 90: new GokigenBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  849 */       case 100: new KakuroBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  850 */       case 110: new KendokuBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  851 */       case 112: new KsudokuBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  852 */       case 120: new LadderwordBuild(CrosswordExpress.jfCWE); break;
/*  853 */       case 130: new LetterdropBuild(CrosswordExpress.jfCWE); break;
/*  854 */       case 230: new MarupekeBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  855 */       case 132: new MinesweeperBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  856 */       case 134: new OuroborosBuild(CrosswordExpress.jfCWE); break;
/*  857 */       case 140: new PyramidwordBuild(CrosswordExpress.jfCWE); break;
/*  858 */       case 150: new RoundaboutsBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  859 */       case 160: new SikakuBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  860 */       case 170: new SlitherlinkBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  861 */       case 180: new SudokuBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  862 */       case 190: new TentsBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*  863 */       case 182: new TatamiBuild(CrosswordExpress.jfCWE, false, 1, 1); break;
/*      */       case 200: case 202:
/*  865 */         Def.dispWSloops = Boolean.valueOf(true); new WordsearchBuild(CrosswordExpress.jfCWE);
/*      */         break; }
/*      */   
/*      */   }
/*      */   static void restoreFrame() {
/*  870 */     Dimension dim = jfPrint.getSize();
/*  871 */     Op.setInt(Op.MSC.PrintW.ordinal(), dim.width, Op.msc);
/*  872 */     Op.setInt(Op.MSC.PrintH.ordinal(), dim.height, Op.msc);
/*  873 */     frameX = dim.width; frameY = dim.height;
/*  874 */     jfPrint.setVisible(true);
/*  875 */     pp.setSize(frameX, frameY);
/*  876 */     pp.repaint();
/*      */   }
/*      */   
/*      */   static void printResultMessage() {
/*  880 */     if (printRes > 0) {
/*  881 */       JOptionPane.showMessageDialog(jfPrint, (printRes == 1) ? "A standard arrowword output cannot be created using this puzzle." : "One or more of the clues are too long to be printed in the available space.", "Print Failure", 1);
/*      */ 
/*      */       
/*  884 */       printRes = 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   static void setSpinners() {
/*  889 */     jspinx.setValue(Integer.valueOf(puzzleItem[thisItem][0]));
/*  890 */     jspiny.setValue(Integer.valueOf(puzzleItem[thisItem][1]));
/*  891 */     jspinw.setValue(Integer.valueOf(puzzleItem[thisItem][2]));
/*  892 */     jspinh.setValue(Integer.valueOf(puzzleItem[thisItem][3]));
/*      */   }
/*      */   
/*      */   private void saveLayoutAs() {
/*  896 */     final JDialog jdlgSaveAs = new JDialog(jfPrint, "Save Layout As", true);
/*  897 */     jdlgSaveAs.setSize(235, 100);
/*  898 */     jdlgSaveAs.setResizable(false);
/*  899 */     jdlgSaveAs.setLayout((LayoutManager)null);
/*  900 */     jdlgSaveAs.setLocation(jfPrint.getX(), jfPrint.getY());
/*      */     
/*  902 */     JLabel jl = new JLabel("Layout Name:");
/*  903 */     jl.setForeground(Def.COLOR_LABEL);
/*  904 */     jl.setSize(100, 20);
/*  905 */     jl.setLocation(10, 5);
/*  906 */     jl.setHorizontalAlignment(4);
/*  907 */     jdlgSaveAs.add(jl);
/*      */     
/*  909 */     final JTextField jtfLayoutName = new JTextField("untitled", 15);
/*  910 */     jtfLayoutName.setSize(100, 22);
/*  911 */     jtfLayoutName.setLocation(120, 5);
/*  912 */     jtfLayoutName.selectAll();
/*  913 */     jtfLayoutName.setHorizontalAlignment(2);
/*  914 */     jdlgSaveAs.add(jtfLayoutName);
/*      */     
/*  916 */     jtfLayoutName.setFont(new Font("SansSerif", 1, 13));
/*      */     
/*  918 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  920 */           String s = jtfLayoutName.getText();
/*  921 */           File fl = new File("layouts/" + s + ".layout");
/*  922 */           int response = 0;
/*  923 */           if (fl.exists()) {
/*  924 */             response = JOptionPane.showConfirmDialog(jdlgSaveAs, "<html>The layout <font color=AA0000 size=4>" + s + "</font> already exists.<br>Continue anyway?", "Warning!", 0);
/*      */           }
/*      */           
/*  927 */           if (response == 0) {
/*  928 */             Print.this.saveLayout(s);
/*  929 */             Op.msc[Op.MSC.LayoutName.ordinal()] = s;
/*  930 */             Print.this.jlLayoutName.setText("<html><font color=880000 size=4>" + Op.msc[Op.MSC.LayoutName.ordinal()]);
/*  931 */             Print.jcbbLayouts.addItem("    " + s);
/*  932 */             Print.jcbbLayouts.setSelectedItem("    " + s);
/*      */           } 
/*  934 */           jdlgSaveAs.dispose();
/*      */         }
/*      */       };
/*  937 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 35, 100, 26);
/*  938 */     jdlgSaveAs.add(jbOK);
/*      */     
/*  940 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  942 */           jdlgSaveAs.dispose();
/*      */         }
/*      */       };
/*  945 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 120, 35, 100, 26);
/*  946 */     jdlgSaveAs.add(jbCancel);
/*      */     
/*  948 */     jdlgSaveAs.getRootPane().setDefaultButton(jbOK);
/*  949 */     Methods.setDialogSize(jdlgSaveAs, 230, 71);
/*      */   }
/*      */ 
/*      */   
/*      */   void saveLayout(String s) {
/*      */     try {
/*  955 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("layouts/" + s + ".layout"));
/*  956 */       for (int i = 0; i < 31; i++) {
/*  957 */         for (int j = 0; j < 4; j++)
/*  958 */           dataOut.writeInt(puzzleItem[i][j]); 
/*  959 */       }  dataOut.close();
/*      */     }
/*  961 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */   
/*      */   static void loadLayout(String s) {
/*      */     try {
/*  967 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("layouts/" + s + ".layout"));
/*  968 */       for (int i = 0; i < 31; i++) {
/*  969 */         for (int j = 0; j < 4; j++)
/*  970 */           puzzleItem[i][j] = dataIn.readInt(); 
/*  971 */       }  dataIn.close();
/*      */     }
/*  973 */     catch (IOException exc) {}
/*      */   }
/*      */   static boolean isNumber(String string) {
/*      */     
/*  977 */     try { Long.parseLong(string); }
/*  978 */     catch (Exception e) { return false; }
/*  979 */      return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawPreviewPanel(Graphics2D g2, float scale) {
/*  986 */     RenderingHints rh = g2.getRenderingHints();
/*  987 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  988 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  989 */     g2.setRenderingHints(rh);
/*      */     
/*  991 */     g2.setColor(Def.COLOR_WHITE);
/*  992 */     g2.fillRect(0, 0, frameX, frameY);
/*  993 */     if (!previewMode) {
/*  994 */       g2.setColor(Def.COLOR_LIGHTGRAY);
/*  995 */       g2.drawRect(0, 0, 420, 594);
/*  996 */       g2.drawRect(0, 0, 594, 420);
/*  997 */       g2.drawRect(0, 0, 400, 548);
/*  998 */       g2.setFont(new Font("SansSerif", 0, 12));
/*  999 */       g2.drawString("A4-portrait", 425, 14);
/* 1000 */       g2.drawString("A4-landscape", 599, 14);
/* 1001 */       g2.drawString("PDF", 370, 14);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1008 */     Def.dispCursor = Boolean.valueOf(false);
/* 1009 */     g2.setColor(Def.COLOR_BLACK);
/* 1010 */     g2.setFont(new Font("SansSerif", 0, 10));
/* 1011 */     for (int i = 0; i < 31; i++) {
/* 1012 */       int left = (int)(puzzleItem[i][0] * scale);
/* 1013 */       int top = (int)(puzzleItem[i][1] * scale);
/* 1014 */       int width = (int)(puzzleItem[i][2] * scale);
/* 1015 */       int height = (int)(puzzleItem[i][3] * scale);
/* 1016 */       if (width > 0) {
/* 1017 */         if (previewMode) {
/* 1018 */           String pn; int x; String theFont; int theColor; switch (i) { case 0:
/* 1019 */               if (Methods.puzzleTitle.length() > 0) {
/* 1020 */                 outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle); break;
/*      */               } 
/* 1022 */               pn = Op.ws[Op.WS.WsPuz.ordinal()]; pn = pn.substring(0, pn.indexOf('.'));
/* 1023 */               outputTextItem(g2, left, top, width, height, "SansSerif", 0, "Puzzle : " + pn);
/*      */               break;
/*      */             case 1:
/* 1026 */               outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.author); break;
/* 1027 */             case 2: outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.copyright); break;
/* 1028 */             case 3: outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleNumber); break;
/* 1029 */             case 4: Methods.renderText(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleNotes, 3, 5, true, 0, 0);
/*      */               break;
/*      */             
/*      */             case 5:
/* 1033 */               switch (Def.puzzleMode) {
/*      */                 case 7:
/* 1035 */                   CrosswordBuild.loadCrossword(Op.cw[Op.CW.CwPuz.ordinal()]);
/* 1036 */                   Grid.setSizesAndOffsets(left, top, width, height);
/* 1037 */                   printRes = Arrowword.arrowwordPrint(g2, left, top, width, height); break;
/*      */                 case 30:
/* 1039 */                   CodewordSolve.printPuz(g2, left, top, width, height); break;
/* 1040 */                 case 10: AcrosticBuild.printPuz(g2, left, top, width, height); break;
/* 1041 */                 case 20: AkariBuild.printPuz(g2, left, top, width, height); break;
/*      */                 case 4: case 12:
/* 1043 */                   CrosswordBuild.printPuz(g2, left, top, width, height); break;
/* 1044 */                 case 220: DevanagariBuild.printPuz(g2, left, top, width, height); break;
/* 1045 */                 case 40: DominoBuild.printPuz(g2, left, top, width, height); break;
/* 1046 */                 case 50: DoubletBuild.printPuz(g2, left, top, width, height); break;
/* 1047 */                 case 60: FillinSolve.printPuz(g2, left, top, width, height); break;
/* 1048 */                 case 70: FillominoBuild.printPuz(g2, left, top, width, height); break;
/* 1049 */                 case 72: FindAQuote.printPuz(g2, left, top, width, height); break;
/*      */                 case 6: case 13:
/* 1051 */                   FreeformBuild.printPuz(g2, left, top, width, height, true); break;
/* 1052 */                 case 80: FutoshikiBuild.printPuz(g2, left, top, width, height); break;
/* 1053 */                 case 90: GokigenBuild.printPuz(g2, left, top, width, height); break;
/* 1054 */                 case 100: KakuroBuild.printPuz(g2, left, top, width, height); break;
/* 1055 */                 case 110: KendokuBuild.printPuz(g2, left, top, width, height); break;
/* 1056 */                 case 112: KsudokuBuild.printPuz(g2, left, top, width, height); break;
/* 1057 */                 case 120: LadderwordBuild.printPuz(g2, left, top, width, height); break;
/* 1058 */                 case 130: LetterdropBuild.printPuz(g2, left, top, width, height); break;
/* 1059 */                 case 230: MarupekeBuild.printPuz(g2, left, top, width, height); break;
/* 1060 */                 case 132: MinesweeperBuild.printPuz(g2, left, top, width, height); break;
/* 1061 */                 case 134: OuroborosBuild.printPuz(g2, left, top, width, height); break;
/* 1062 */                 case 140: PyramidwordBuild.printPuz(g2, left, top, width, height); break;
/* 1063 */                 case 150: RoundaboutsBuild.printPuz(g2, left, top, width, height); break;
/* 1064 */                 case 160: SikakuBuild.printPuz(g2, left, top, width, height); break;
/* 1065 */                 case 170: SlitherlinkBuild.printPuz(g2, left, top, width, height); break;
/* 1066 */                 case 180: SudokuBuild.printPuz(g2, left, top, width, height); break;
/* 1067 */                 case 210: WordsquareBuild.printPuz(g2, left, top, width, height); break;
/* 1068 */                 case 182: TatamiBuild.printPuz(g2, left, top, width, height); break;
/* 1069 */                 case 190: TentsBuild.printPuz(g2, left, top, width, height); break;
/* 1070 */                 case 200: WordsearchBuild.printWordSearchPuz(g2, left, top, width, height); break;
/* 1071 */                 case 202: WordsearchBuild.printWordWeavePuz(g2, left, top, width, height); break;
/*      */               } 
/*      */               break;
/*      */             case 6:
/* 1075 */               if (Op.msc[Op.MSC.SolutionPuz.ordinal()].length() == 0)
/* 1076 */                 break;  switch (Def.puzzleMode) { case 10:
/* 1077 */                   AcrosticBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1078 */                 case 20: AkariBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/*      */                 case 4: case 7:
/*      */                 case 12:
/* 1081 */                   CrosswordBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1082 */                 case 40: DominoBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1083 */                 case 50: DoubletBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1084 */                 case 60: FillinSolve.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1085 */                 case 70: FillominoBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1086 */                 case 6: FreeformBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1087 */                 case 80: FutoshikiBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1088 */                 case 90: GokigenBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1089 */                 case 100: KakuroBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1090 */                 case 110: KendokuBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1091 */                 case 112: KsudokuBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1092 */                 case 120: LadderwordBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1093 */                 case 130: LetterdropBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1094 */                 case 230: MarupekeBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1095 */                 case 132: MinesweeperBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1096 */                 case 134: OuroborosBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1097 */                 case 140: PyramidwordBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1098 */                 case 150: RoundaboutsBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1099 */                 case 160: SikakuBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1100 */                 case 170: SlitherlinkBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1101 */                 case 180: SudokuBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1102 */                 case 210: WordsquareBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1103 */                 case 182: TatamiBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1104 */                 case 190: TentsBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/*      */                 case 200: case 202:
/* 1106 */                   WordsearchBuild.printSolTitle(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break; }
/*      */               
/*      */               break;
/*      */             case 7:
/* 1110 */               if (Def.puzzleMode != 8 && 
/* 1111 */                 Op.msc[Op.MSC.SolutionPuz.ordinal()].length() == 0)
/* 1112 */                 break;  switch (Def.puzzleMode) { case 10:
/* 1113 */                   AcrosticBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1114 */                 case 20: AkariBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1115 */                 case 30: CodewordSolve.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/*      */                 case 4: case 7:
/*      */                 case 12:
/* 1118 */                   CrosswordBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1119 */                 case 220: DevanagariBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1120 */                 case 40: DominoBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1121 */                 case 50: DoubletBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1122 */                 case 60: FillinSolve.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1123 */                 case 70: FillominoBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/*      */                 case 6: case 13:
/* 1125 */                   FreeformBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()], true); break;
/* 1126 */                 case 80: FutoshikiBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1127 */                 case 90: GokigenBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1128 */                 case 100: KakuroBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1129 */                 case 110: KendokuBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1130 */                 case 112: KsudokuBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1131 */                 case 120: LadderwordBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1132 */                 case 130: LetterdropBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1133 */                 case 230: MarupekeBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1134 */                 case 132: MinesweeperBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1135 */                 case 134: OuroborosBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1136 */                 case 140: PyramidwordBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1137 */                 case 150: RoundaboutsBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1138 */                 case 160: SikakuBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1139 */                 case 170: SlitherlinkBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1140 */                 case 180: SudokuBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1141 */                 case 210: WordsquareBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1142 */                 case 182: TatamiBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/* 1143 */                 case 190: TentsBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break;
/*      */                 case 200: case 202:
/* 1145 */                   WordsearchBuild.printSol(g2, left, top, width, height, Op.msc[Op.MSC.SolutionPuz.ordinal()]); break; }
/*      */               
/*      */               break;
/*      */             case 20:
/* 1149 */               AcrosticBuild.loadAcrostic(Op.ac[Op.AC.AcPuz.ordinal()]);
/* 1150 */               AcrosticBuild.setSizesAndOffsetsW(left, top, width, height, 0);
/* 1151 */               Def.dispSolArray = Boolean.valueOf(true);
/* 1152 */               Def.dispWithColor = Op.getBool(Op.AC.AcPuzColor.ordinal(), Op.ac);
/* 1153 */               AcrosticBuild.drawAcrosticWords(g2);
/* 1154 */               Def.dispWithColor = Boolean.valueOf(true);
/* 1155 */               Def.dispSolArray = Boolean.valueOf(false);
/*      */               break;
/*      */             case 21:
/* 1158 */               for (x = 0; x < 256; x++)
/* 1159 */                 CodewordSolve.solLetter[x] = Character.MIN_VALUE; 
/* 1160 */               CodewordSolve.allocateCodes();
/* 1161 */               Def.dispWithColor = Op.getBool(Op.CD.CdPuzColor.ordinal(), Op.cd);
/* 1162 */               CodewordSolve.drawCWTables(g2, left, top, width, height, 0);
/* 1163 */               Def.dispWithColor = Boolean.valueOf(true);
/*      */               break;
/*      */             case 8:
/* 1166 */               switch (Def.puzzleMode) {
/*      */ 
/*      */ 
/*      */                 
/*      */                 case 4:
/*      */                 case 6:
/*      */                 case 10:
/*      */                 case 50:
/*      */                 case 120:
/*      */                 case 134:
/*      */                 case 140:
/*      */                 case 210:
/*      */                 case 220:
/* 1179 */                   switch (Def.puzzleMode) {
/*      */                     case 4:
/*      */                     case 6:
/*      */                     case 210:
/* 1183 */                       theFont = Op.cw[Op.CW.CwClueFont.ordinal()];
/* 1184 */                       theColor = Op.getBool(Op.CW.CwPuzC.ordinal(), Op.cw).booleanValue() ? Op.getColorInt(Op.CW.CwClueC.ordinal(), Op.cw) : 0;
/*      */                       break;
/*      */                     case 10:
/* 1187 */                       theFont = Op.ac[Op.AC.AcClueFont.ordinal()];
/* 1188 */                       theColor = Op.getBool(Op.AC.AcPuzColor.ordinal(), Op.ac).booleanValue() ? Op.getColorInt(Op.AC.AcClue.ordinal(), Op.ac) : 0;
/*      */                       break;
/*      */                     case 50:
/* 1191 */                       theFont = Op.db[Op.DB.DbClueFont.ordinal()];
/* 1192 */                       theColor = Op.getBool(Op.DB.DbPuzColor.ordinal(), Op.db).booleanValue() ? Op.getColorInt(Op.DB.DbClue.ordinal(), Op.db) : 0;
/*      */                       break;
/*      */                     case 120:
/* 1195 */                       theFont = Op.lw[Op.LW.LwClueFont.ordinal()];
/* 1196 */                       theColor = Op.getBool(Op.LW.LwPuzColor.ordinal(), Op.lw).booleanValue() ? Op.getColorInt(Op.LW.LwClue.ordinal(), Op.lw) : 0;
/*      */                       break;
/*      */                     case 134:
/* 1199 */                       theFont = Op.py[Op.PY.PyClueFont.ordinal()];
/* 1200 */                       theColor = 0;
/*      */                       break;
/*      */                     case 140:
/* 1203 */                       theFont = Op.py[Op.PY.PyClueFont.ordinal()];
/* 1204 */                       theColor = Op.getBool(Op.PY.PyPuzColor.ordinal(), Op.py).booleanValue() ? Op.getColorInt(Op.PY.PyClue.ordinal(), Op.py) : 0;
/*      */                       break;
/*      */                     default:
/* 1207 */                       theFont = "SansSerif";
/* 1208 */                       theColor = 0;
/*      */                       break;
/*      */                   } 
/*      */                   
/* 1212 */                   if (Def.puzzleMode != 50 && Def.puzzleMode != 134) NodeList.sortNodeList(1); 
/* 1213 */                   Methods.drawTheClues(g2, puzzleItem, scale, theFont, theColor);
/* 1214 */                   if (Def.puzzleMode != 50 && Def.puzzleMode != 134) NodeList.sortNodeList(2); 
/*      */                   break;
/*      */                 case 13:
/*      */                 case 60:
/* 1218 */                   NodeList.sortNodeList(3);
/* 1219 */                   Methods.drawWordsearchClues(g2, puzzleItem, scale, Op.fl[Op.FL.FlPuzzleFont.ordinal()], 
/* 1220 */                       Op.getBool(Op.FL.FlPuzColor.ordinal(), Op.fl).booleanValue() ? Op.getColorInt(Op.FL.FlLetters.ordinal(), Op.fl) : 0);
/* 1221 */                   NodeList.sortNodeList(2);
/*      */                   break;
/*      */                 case 200:
/* 1224 */                   Methods.drawWordsearchClues(g2, puzzleItem, scale, "SansSerif", 0);
/*      */                   break;
/*      */                 case 202:
/* 1227 */                   Methods.drawWordsearchClues(g2, puzzleItem, scale, "SansSerif", 0);
/*      */                   break;
/*      */                 case 12:
/* 1230 */                   drawFrenchClues(left, top, width, height, g2);
/*      */                   break;
/*      */               } 
/*      */               break;
/*      */             case 22:
/* 1235 */               drawWordPool(left, top, width, height, g2);
/*      */               break; }
/*      */ 
/*      */         
/*      */         } else {
/* 1240 */           g2.setColor(Def.COLOR_VERYLIGHTGRAY);
/* 1241 */           g2.fillRect(left, top, width, height);
/* 1242 */           g2.setColor(Def.COLOR_BLACK);
/* 1243 */           g2.drawRect(left, top, width, height);
/* 1244 */           g2.drawString(layoutItemName[i], left + 10, top + 10);
/*      */         } 
/*      */       }
/*      */     } 
/* 1248 */     if (!previewMode) {
/* 1249 */       int left = (int)(puzzleItem[thisItem][0] * scale);
/* 1250 */       int top = (int)(puzzleItem[thisItem][1] * scale);
/* 1251 */       int width = (int)(puzzleItem[thisItem][2] * scale);
/* 1252 */       int height = (int)(puzzleItem[thisItem][3] * scale);
/* 1253 */       if (width > 0) {
/* 1254 */         g2.setColor(Def.COLOR_VERYLIGHTGRAY);
/* 1255 */         g2.fillRect(left, top, width, height);
/* 1256 */         g2.setColor(Def.COLOR_BLUE);
/* 1257 */         g2.drawRect(left, top, width, height);
/* 1258 */         g2.drawString(layoutItemName[thisItem], left + 10, top + 10);
/* 1259 */         g2.fillRect(left, top, 9, 9);
/* 1260 */         g2.fillRect(left + width - 8, top + height - 8, 9, 9);
/*      */       } 
/*      */     } 
/*      */     
/* 1264 */     if (comp != null) {
/* 1265 */       comp.requestFocus();
/*      */     }
/* 1267 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   static void drawWordPool(int left, int top, int width, int height, Graphics2D g2) {
/*      */     int h, colCount;
/*      */     float topMargin, botMargin, sideMargin;
/*      */     FontMetrics fm;
/* 1273 */     Random rand = new Random();
/* 1274 */     String[] wordPool = new String[2 * NodeList.nodeListLength];
/*      */ 
/*      */ 
/*      */     
/* 1278 */     g2.setColor(Def.COLOR_BLACK);
/* 1279 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1280 */     g2.drawRect(left, top, width, height);
/*      */     int i;
/* 1282 */     for (i = 0; i < NodeList.nodeListLength; i++)
/* 1283 */       wordPool[i * 2] = (NodeList.nodeList[i]).word; 
/* 1284 */     CrosswordBuild.loadDictionary();
/* 1285 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/*      */       int j; String str; do {
/* 1287 */         int k = (NodeList.nodeList[i]).length;
/* 1288 */         int r = rand.nextInt(CrosswordBuild.wordCount[0][k] - 1);
/* 1289 */         str = new String(CrosswordBuild.chWord[0][0][k][r]);
/* 1290 */         for (j = 0; j < 2 * NodeList.nodeListLength && 
/* 1291 */           !str.equals(wordPool[j]); j++);
/*      */       }
/* 1293 */       while (j != 2 * NodeList.nodeListLength);
/*      */ 
/*      */       
/* 1296 */       wordPool[i * 2 + 1] = str;
/*      */     } 
/*      */     
/* 1299 */     int len = 2 * NodeList.nodeListLength;
/* 1300 */     for (i = 0; i < len - 1; i++) {
/* 1301 */       for (int j = i + 1; j < len; j++) {
/* 1302 */         if (wordPool[i].length() > wordPool[j].length() || (wordPool[i]
/* 1303 */           .length() == wordPool[j].length() && wordPool[i].compareTo(wordPool[j]) > 0)) {
/* 1304 */           String str = wordPool[i];
/* 1305 */           wordPool[i] = wordPool[j];
/* 1306 */           wordPool[j] = str;
/*      */         } 
/*      */       } 
/* 1309 */     }  for (int fontHeight = 60;; fontHeight--) {
/* 1310 */       g2.setFont(new Font(Op.cw[Op.CW.CwFont.ordinal()], 0, fontHeight));
/* 1311 */       fm = g2.getFontMetrics();
/* 1312 */       h = fm.getHeight();
/* 1313 */       topMargin = (h / 4); botMargin = (h / 2); sideMargin = h; float t;
/* 1314 */       for (f2 = left + sideMargin, t = top + topMargin, f3 = (i = 0); i < len; i++) {
/* 1315 */         t += h;
/* 1316 */         if (t > (top + height) - botMargin) { t = top + topMargin + h; f2 += f3 + 10.0F; f3 = 0.0F; }
/* 1317 */          if (fm.stringWidth(wordPool[i]) > f3) f3 = fm.stringWidth(wordPool[i]); 
/* 1318 */         if (f2 + fm.stringWidth(wordPool[i] + sideMargin) > width)
/*      */           break; 
/* 1320 */       }  if (i == len)
/*      */         break; 
/*      */     }  float xtraLine;
/* 1323 */     for (xtraLine = 40.0F;; xtraLine = (float)(xtraLine - 0.1D)) {
/* 1324 */       float f; for (colCount = 0, f2 = left + sideMargin, f = top + topMargin, f3 = (i = 0); i < len; i++) {
/* 1325 */         f += h + xtraLine;
/* 1326 */         if (f > (top + height) - botMargin) { f = top + topMargin + h + xtraLine; f2 += f3 + 10.0F; f3 = 0.0F; colCount++; }
/* 1327 */          if (fm.stringWidth(wordPool[i]) > f3) f3 = fm.stringWidth(wordPool[i]); 
/* 1328 */         if (f2 + fm.stringWidth(wordPool[i] + sideMargin) > width)
/*      */           break; 
/* 1330 */       }  if (i == len)
/*      */         break; 
/*      */     } 
/* 1333 */     float colGap = (width - f2 + f3 + sideMargin + (colCount * 10)) / colCount;
/* 1334 */     for (float f2 = left + sideMargin, f1 = top + topMargin, f3 = (i = 0); i < len; i++) {
/* 1335 */       f1 += h + xtraLine;
/* 1336 */       if (f1 > (top + height) - botMargin) { f1 = top + topMargin + h + xtraLine; f2 += f3 + colGap; f3 = 0.0F; }
/* 1337 */        if (fm.stringWidth(wordPool[i]) > f3) f3 = fm.stringWidth(wordPool[i]); 
/* 1338 */       g2.drawString(wordPool[i], f2, f1);
/*      */     } 
/*      */   }
/*      */   
/*      */   static void drawFrenchClues(int left, int top, int width, int height, Graphics2D g2) {
/* 1343 */     String sDown = "";
/*      */     
/* 1345 */     float fontSize = 40.0F;
/*      */     
/*      */     String sAcross;
/*      */     
/*      */     int i, iD;
/* 1350 */     for (iD = -1, sAcross = "<b>" + Op.msc[Op.MSC.Langacross.ordinal()] + "</b>", i = 0; i < NodeList.nodeListLength; i++) {
/* 1351 */       if ((NodeList.nodeList[i]).direction != 1) {
/* 1352 */         if ((NodeList.nodeList[i]).y > iD) {
/* 1353 */           iD = (NodeList.nodeList[i]).y;
/* 1354 */           sAcross = sAcross + " <b>" + (Op.getBool(Op.CW.CwFrenchAcrossId.ordinal(), Op.cw).booleanValue() ? ("" + (char)(65 + iD)) : (String)Integer.valueOf(iD + 1)) + ":</b>";
/*      */         } 
/* 1356 */         sAcross = sAcross + " " + (NodeList.nodeList[i]).clue + ":";
/*      */       } 
/*      */     } 
/* 1359 */     NodeList.sortNodeList(4);
/* 1360 */     for (iD = -1; iD < Grid.xSz; iD++) {
/* 1361 */       for (sDown = "<b>" + Op.msc[Op.MSC.Langdown.ordinal()] + "</b>", i = 0; i < NodeList.nodeListLength; i++) {
/* 1362 */         if ((NodeList.nodeList[i]).direction != 0)
/* 1363 */         { if ((NodeList.nodeList[i]).x > iD) {
/* 1364 */             iD = (NodeList.nodeList[i]).x;
/* 1365 */             sDown = sDown + " <b>" + (Op.getBool(Op.CW.CwFrenchDownId.ordinal(), Op.cw).booleanValue() ? ("" + (char)(65 + iD)) : (String)Integer.valueOf(iD + 1)) + ":</b>";
/*      */           } 
/* 1367 */           sDown = sDown + " " + (NodeList.nodeList[i]).clue + ":"; } 
/*      */       } 
/* 1369 */     }  NodeList.sortNodeList(1);
/*      */     
/* 1371 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.CW.CwClueC.ordinal(), Op.cw) : 0));
/* 1372 */     boolean draw = false; while (true) {
/* 1373 */       float y = top + fontSize;
/* 1374 */       FontMetrics fm = g2.getFontMetrics();
/*      */       
/* 1376 */       g2.setFont(new Font(Op.cw[Op.CW.CwClueFont.ordinal()], 0, (int)fontSize));
/* 1377 */       float res = Methods.renderOneString(g2, left, y, width, top + height, fontSize, fm, sAcross, 0, 3, draw);
/* 1378 */       if (res <= 0.0F) {
/* 1379 */         fontSize = (float)(fontSize - 0.1D);
/*      */         continue;
/*      */       } 
/* 1382 */       y = res + fontSize;
/* 1383 */       res = Methods.renderOneString(g2, left, y, width, top + height, fontSize, fm, sDown, 0, 3, draw);
/* 1384 */       if (draw)
/* 1385 */         break;  if (res <= 0.0F) {
/* 1386 */         fontSize = (float)(fontSize - 0.1D); continue;
/*      */       } 
/* 1388 */       draw = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   static void outputTextItem(Graphics2D g2, int left, int top, int width, int height, String face, int style, String text) {
/* 1393 */     if (text.isEmpty())
/* 1394 */       return;  g2.setColor(Def.COLOR_BLACK);
/* 1395 */     for (int fontSize = height;; fontSize--) {
/* 1396 */       g2.setFont(new Font(face, style, fontSize));
/* 1397 */       int w = g2.getFontMetrics().stringWidth(text);
/* 1398 */       if (w < width) {
/* 1399 */         g2.drawString(text, left + (width - w) / 2, top + height);
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void printProcess() {
/* 1406 */     previewMode = true;
/* 1407 */     PrinterJob job = PrinterJob.getPrinterJob();
/* 1408 */     job.setPrintable(new PrintObject());
/* 1409 */     if (job.printDialog()) {
/* 1410 */       try { job.print(); }
/* 1411 */       catch (Exception pe) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void languageElements() {
/* 1418 */     final JDialog jdlgLanguageItems = new JDialog(jfPrint, "Language Items", true);
/* 1419 */     jdlgLanguageItems.setSize(260, 233);
/* 1420 */     jdlgLanguageItems.setResizable(false);
/* 1421 */     jdlgLanguageItems.setLayout((LayoutManager)null);
/* 1422 */     jdlgLanguageItems.setLocation(jfPrint.getX(), jfPrint.getY());
/*      */     
/* 1424 */     jdlgLanguageItems
/* 1425 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/* 1427 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/* 1431 */     Methods.closeHelp();
/*      */     
/* 1433 */     JLabel jl = new JLabel("ENGLISH");
/* 1434 */     jl.setForeground(Def.COLOR_LABEL);
/* 1435 */     jl.setSize(70, 20);
/* 1436 */     jl.setLocation(10, 10);
/* 1437 */     jl.setHorizontalAlignment(2);
/* 1438 */     jdlgLanguageItems.add(jl);
/*      */     
/* 1440 */     jl = new JLabel("Your Language");
/* 1441 */     jl.setForeground(Def.COLOR_LABEL);
/* 1442 */     jl.setSize(170, 20);
/* 1443 */     jl.setLocation(80, 10);
/* 1444 */     jl.setHorizontalAlignment(2);
/* 1445 */     jdlgLanguageItems.add(jl);
/*      */     
/* 1447 */     JLabel jlAcross = new JLabel("ACROSS");
/* 1448 */     jlAcross.setForeground(Def.COLOR_LABEL);
/* 1449 */     jlAcross.setSize(130, 20);
/* 1450 */     jlAcross.setLocation(10, 35);
/* 1451 */     jlAcross.setHorizontalAlignment(2);
/* 1452 */     jdlgLanguageItems.add(jlAcross);
/*      */     
/* 1454 */     final JTextField jtfAcross = new JTextField(Op.msc[Op.MSC.Langacross.ordinal()], 10);
/* 1455 */     jtfAcross.setSize(170, 23);
/* 1456 */     jtfAcross.setLocation(80, 35);
/* 1457 */     jtfAcross.selectAll();
/* 1458 */     jtfAcross.setHorizontalAlignment(2);
/* 1459 */     jdlgLanguageItems.add(jtfAcross);
/* 1460 */     jtfAcross.setFont(new Font("SansSerif", 1, 13));
/*      */     
/* 1462 */     JLabel jlDown = new JLabel("DOWN");
/* 1463 */     jlDown.setForeground(Def.COLOR_LABEL);
/* 1464 */     jlDown.setSize(130, 20);
/* 1465 */     jlDown.setLocation(10, 60);
/* 1466 */     jlDown.setHorizontalAlignment(2);
/* 1467 */     jdlgLanguageItems.add(jlDown);
/*      */     
/* 1469 */     final JTextField jtfDown = new JTextField(Op.msc[Op.MSC.Langdown.ordinal()], 10);
/* 1470 */     jtfDown.setSize(170, 23);
/* 1471 */     jtfDown.setLocation(80, 60);
/* 1472 */     jtfDown.selectAll();
/* 1473 */     jtfDown.setHorizontalAlignment(2);
/* 1474 */     jdlgLanguageItems.add(jtfDown);
/* 1475 */     jtfDown.setFont(new Font("SansSerif", 1, 13));
/*      */     
/* 1477 */     JLabel jlWords = new JLabel("WORDS");
/* 1478 */     jlWords.setForeground(Def.COLOR_LABEL);
/* 1479 */     jlWords.setSize(130, 20);
/* 1480 */     jlWords.setLocation(10, 85);
/* 1481 */     jlWords.setHorizontalAlignment(2);
/* 1482 */     jdlgLanguageItems.add(jlWords);
/*      */     
/* 1484 */     final JTextField jtfWords = new JTextField(Op.msc[Op.MSC.Langwords.ordinal()], 10);
/* 1485 */     jtfWords.setSize(170, 23);
/* 1486 */     jtfWords.setLocation(80, 85);
/* 1487 */     jtfWords.selectAll();
/* 1488 */     jtfWords.setHorizontalAlignment(2);
/* 1489 */     jdlgLanguageItems.add(jtfWords);
/* 1490 */     jtfWords.setFont(new Font("SansSerif", 1, 13));
/*      */     
/* 1492 */     JLabel jlClues = new JLabel("CLUES");
/* 1493 */     jlClues.setForeground(Def.COLOR_LABEL);
/* 1494 */     jlClues.setSize(130, 20);
/* 1495 */     jlClues.setLocation(10, 110);
/* 1496 */     jlClues.setHorizontalAlignment(2);
/* 1497 */     jdlgLanguageItems.add(jlClues);
/*      */     
/* 1499 */     final JTextField jtfClues = new JTextField(Op.msc[Op.MSC.Langclues.ordinal()], 10);
/* 1500 */     jtfClues.setSize(170, 23);
/* 1501 */     jtfClues.setLocation(80, 110);
/* 1502 */     jtfClues.selectAll();
/* 1503 */     jtfClues.setHorizontalAlignment(2);
/* 1504 */     jdlgLanguageItems.add(jtfClues);
/* 1505 */     jtfClues.setFont(new Font("SansSerif", 1, 13));
/*      */     
/* 1507 */     JLabel jlText = new JLabel("TEXT");
/* 1508 */     jlText.setForeground(Def.COLOR_LABEL);
/* 1509 */     jlText.setSize(130, 20);
/* 1510 */     jlText.setLocation(10, 135);
/* 1511 */     jlText.setHorizontalAlignment(2);
/* 1512 */     jdlgLanguageItems.add(jlText);
/*      */     
/* 1514 */     final JTextField jtfText = new JTextField(Op.msc[Op.MSC.Langtext.ordinal()], 10);
/* 1515 */     jtfText.setSize(170, 23);
/* 1516 */     jtfText.setLocation(80, 135);
/* 1517 */     jtfText.selectAll();
/* 1518 */     jtfText.setHorizontalAlignment(2);
/* 1519 */     jdlgLanguageItems.add(jtfText);
/* 1520 */     jtfText.setFont(new Font("SansSerif", 1, 13));
/*      */     
/* 1522 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1524 */           Op.msc[Op.MSC.Langacross.ordinal()] = jtfAcross.getText();
/* 1525 */           Op.msc[Op.MSC.Langdown.ordinal()] = jtfDown.getText();
/* 1526 */           Op.msc[Op.MSC.Langwords.ordinal()] = jtfWords.getText();
/* 1527 */           Op.msc[Op.MSC.Langclues.ordinal()] = jtfClues.getText();
/* 1528 */           Op.msc[Op.MSC.Langtext.ordinal()] = jtfText.getText();
/* 1529 */           Methods.clickedOK = true;
/* 1530 */           jdlgLanguageItems.dispose();
/* 1531 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1534 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 164, 80, 26);
/* 1535 */     jdlgLanguageItems.add(jbOK);
/*      */     
/* 1537 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1539 */           Methods.clickedOK = false;
/* 1540 */           jdlgLanguageItems.dispose();
/* 1541 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1544 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 199, 80, 26);
/* 1545 */     jdlgLanguageItems.add(jbCancel);
/*      */     
/* 1547 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1549 */           Methods.cweHelp(null, jdlgLanguageItems, "Language Elements", Print.this.languageElementsHelp);
/*      */         }
/*      */       };
/* 1552 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 164, 150, 61);
/* 1553 */     jdlgLanguageItems.add(jbHelp);
/*      */     
/* 1555 */     jdlgLanguageItems.getRootPane().setDefaultButton(jbOK);
/* 1556 */     Methods.setDialogSize(jdlgLanguageItems, 260, 233);
/*      */   }
/*      */   
/*      */   public void exportGraphic(final int x, final int y) {
/* 1560 */     final JDialog jdlgExport = new JDialog(jfPrint, "Export Puzzle to a Graphics File", true);
/* 1561 */     jdlgExport.setSize(312, 325);
/* 1562 */     jdlgExport.setResizable(false);
/* 1563 */     jdlgExport.setLayout((LayoutManager)null);
/* 1564 */     jdlgExport.setLocation(jfPrint.getX(), jfPrint.getY());
/* 1565 */     final String[] ext = { "bmp", "gif", "jpg", "png" };
/*      */     
/* 1567 */     jdlgExport
/* 1568 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/* 1570 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/* 1574 */     Methods.closeHelp();
/*      */     
/* 1576 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgExport, 10, 71, howMany, startPuz, true);
/* 1577 */     hmp.jcbVaryDiff.setEnabled(false);
/*      */     
/* 1579 */     JPanel jpPNGExportMode = new JPanel();
/* 1580 */     jpPNGExportMode.setLayout((LayoutManager)null);
/* 1581 */     jpPNGExportMode.setSize(290, 54);
/* 1582 */     jpPNGExportMode.setLocation(10, 10);
/* 1583 */     jpPNGExportMode.setOpaque(true);
/* 1584 */     jpPNGExportMode.setBorder(BorderFactory.createEtchedBorder());
/* 1585 */     jdlgExport.add(jpPNGExportMode);
/*      */     
/* 1587 */     ButtonGroup bgExportMode = new ButtonGroup();
/* 1588 */     jrbExportMode[3] = new JRadioButton();
/* 1589 */     jrbExportMode[3].setForeground(Def.COLOR_LABEL);
/* 1590 */     jrbExportMode[3].setOpaque(false);
/* 1591 */     jrbExportMode[3].setSize(180, 20);
/* 1592 */     jrbExportMode[3].setLocation(75, 3);
/* 1593 */     jrbExportMode[3].setText("PNG Export Mode");
/* 1594 */     jpPNGExportMode.add(jrbExportMode[3]);
/* 1595 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[3]);
/*      */     
/* 1597 */     JLabel jlRes = new JLabel("Resolution in Pixels per Inch:");
/* 1598 */     jlRes.setForeground(Def.COLOR_LABEL);
/* 1599 */     jlRes.setSize(180, 20);
/* 1600 */     jlRes.setLocation(10, 25);
/* 1601 */     jlRes.setHorizontalAlignment(4);
/* 1602 */     jpPNGExportMode.add(jlRes);
/*      */     
/* 1604 */     final JTextField jtfRes = new JTextField("" + Op.getInt(Op.MSC.Ppi.ordinal(), Op.msc));
/* 1605 */     jtfRes.setSize(55, 20);
/* 1606 */     jtfRes.setLocation(200, 25);
/* 1607 */     jtfRes.selectAll();
/* 1608 */     jtfRes.setHorizontalAlignment(2);
/* 1609 */     jpPNGExportMode.add(jtfRes);
/*      */     
/* 1611 */     JPanel jpExportMode = new JPanel();
/* 1612 */     jpExportMode.setLayout((LayoutManager)null);
/* 1613 */     jpExportMode.setSize(290, 80);
/* 1614 */     jpExportMode.setLocation(10, 181);
/* 1615 */     jpExportMode.setOpaque(true);
/* 1616 */     jpExportMode.setBorder(BorderFactory.createEtchedBorder());
/* 1617 */     jdlgExport.add(jpExportMode);
/*      */     
/* 1619 */     JLabel jl = new JLabel("Other Export Modes");
/* 1620 */     jl.setForeground(Def.COLOR_LABEL);
/* 1621 */     jl.setSize(270, 20);
/* 1622 */     jl.setLocation(5, 3);
/* 1623 */     jl.setHorizontalAlignment(0);
/* 1624 */     jpExportMode.add(jl);
/*      */     
/* 1626 */     jrbExportMode[0] = new JRadioButton();
/* 1627 */     jrbExportMode[0].setForeground(Def.COLOR_LABEL);
/* 1628 */     jrbExportMode[0].setOpaque(false);
/* 1629 */     jrbExportMode[0].setSize(65, 20);
/* 1630 */     jrbExportMode[0].setLocation(10, 25);
/* 1631 */     jrbExportMode[0].setText("BMP");
/* 1632 */     jpExportMode.add(jrbExportMode[0]);
/* 1633 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[0]);
/*      */     
/* 1635 */     jrbExportMode[1] = new JRadioButton();
/* 1636 */     jrbExportMode[1].setForeground(Def.COLOR_LABEL);
/* 1637 */     jrbExportMode[1].setOpaque(false);
/* 1638 */     jrbExportMode[1].setSize(65, 20);
/* 1639 */     jrbExportMode[1].setLocation(110, 25);
/* 1640 */     jrbExportMode[1].setText("GIF");
/* 1641 */     jpExportMode.add(jrbExportMode[1]);
/* 1642 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[1]);
/*      */     
/* 1644 */     jrbExportMode[2] = new JRadioButton();
/* 1645 */     jrbExportMode[2].setForeground(Def.COLOR_LABEL);
/* 1646 */     jrbExportMode[2].setOpaque(false);
/* 1647 */     jrbExportMode[2].setSize(65, 20);
/* 1648 */     jrbExportMode[2].setLocation(210, 25);
/* 1649 */     jrbExportMode[2].setText("JPG");
/* 1650 */     jpExportMode.add(jrbExportMode[2]);
/* 1651 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[2]);
/*      */     
/* 1653 */     jrbExportMode[4] = new JRadioButton();
/* 1654 */     jrbExportMode[4].setForeground(Def.COLOR_LABEL);
/* 1655 */     jrbExportMode[4].setOpaque(false);
/* 1656 */     jrbExportMode[4].setSize(250, 20);
/* 1657 */     jrbExportMode[4].setLocation(10, 50);
/* 1658 */     jrbExportMode[4].setText("Export to System Clipboard");
/* 1659 */     jpExportMode.add(jrbExportMode[4]);
/* 1660 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[4]);
/*      */     
/* 1662 */     jrbExportMode[3].setSelected(true);
/*      */     
/* 1664 */     jl = new JLabel("Default graphic size is : " + x + "x" + y + " (mm)");
/* 1665 */     jl.setForeground(Def.COLOR_LABEL);
/* 1666 */     jl.setSize(300, 16);
/* 1667 */     jl.setLocation(10, 264);
/* 1668 */     jl.setHorizontalAlignment(0);
/* 1669 */     jdlgExport.add(jl);
/*      */     
/* 1671 */     JLabel jlWidth = new JLabel("Graphic width:");
/* 1672 */     jlWidth.setForeground(Def.COLOR_LABEL);
/* 1673 */     jlWidth.setSize(160, 20);
/* 1674 */     jlWidth.setLocation(10, 284);
/* 1675 */     jlWidth.setHorizontalAlignment(4);
/* 1676 */     jdlgExport.add(jlWidth);
/*      */     
/* 1678 */     JLabel jlUnits = new JLabel("mm");
/* 1679 */     jlUnits.setForeground(Def.COLOR_LABEL);
/* 1680 */     jlUnits.setSize(50, 20);
/* 1681 */     jlUnits.setLocation(240, 284);
/* 1682 */     jlUnits.setHorizontalAlignment(2);
/* 1683 */     jdlgExport.add(jlUnits);
/*      */     
/* 1685 */     final JTextField jtfWidth = new JTextField("" + x, 15);
/* 1686 */     jtfWidth.setSize(55, 20);
/* 1687 */     jtfWidth.setLocation(180, 286);
/* 1688 */     jtfWidth.selectAll();
/* 1689 */     jtfWidth.setHorizontalAlignment(2);
/* 1690 */     jdlgExport.add(jtfWidth);
/*      */     
/* 1692 */     Action doExport = new AbstractAction("Export") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1694 */           String path = "";
/*      */           int mode;
/* 1696 */           for (mode = 0; mode < 5 && 
/* 1697 */             !Print.jrbExportMode[mode].isSelected(); mode++);
/*      */           
/* 1699 */           String fName = new String(Print.puzzleFile.substring(0, Print.puzzleFile.indexOf('.') + 1));
/* 1700 */           Print.previewMode = true;
/*      */           
/* 1702 */           int w = Integer.parseInt(jtfWidth.getText());
/* 1703 */           Op.setInt(Op.MSC.Ppi.ordinal(), Integer.parseInt(jtfRes.getText()), Op.msc);
/* 1704 */           if (mode == 3)
/* 1705 */             w = w * Op.getInt(Op.MSC.Ppi.ordinal(), Op.msc) / 72; 
/* 1706 */           float sz = (float)(2.88D * w / x);
/* 1707 */           BufferedImage puzzleImage = new BufferedImage((int)(sz * x), (int)(sz * y), 5);
/*      */           
/* 1709 */           Graphics2D g = puzzleImage.createGraphics();
/* 1710 */           g.setColor(Def.COLOR_WHITE); g.fillRect(0, 0, (int)(sz * x), (int)(sz * y));
/* 1711 */           Print.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/* 1712 */           Print.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*      */           
/* 1714 */           if (Print.howMany > 1) {
/* 1715 */             JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/");
/* 1716 */             chooser.setDialogTitle("Export Puzzles to Graphic File");
/* 1717 */             chooser.setFileFilter(new FileNameExtensionFilter("BMP GIF JPG PNG", new String[] { this.val$ext[mode] }));
/* 1718 */             chooser.setSelectedFile(new File("" + Print.startPuz + "." + ext[mode]));
/* 1719 */             if (chooser.showSaveDialog(jdlgExport) == 0)
/* 1720 */               path = chooser.getSelectedFile().getAbsolutePath(); 
/* 1721 */             if (path.length() == 0)
/*      */               return; 
/* 1723 */             SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1724 */             Calendar c = Calendar.getInstance();
/*      */             
/* 1726 */             for (Print.hmCount = 1; Print.hmCount <= Print.howMany; Print.hmCount++, Print.startPuz++) {
/* 1727 */               if (Print.startPuz > 10000000) { try {
/* 1728 */                   c.setTime(sdf.parse("" + Print.startPuz));
/* 1729 */                 } catch (ParseException ex) {}
/* 1730 */                 Print.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */               
/* 1732 */               path = path.substring(0, path.lastIndexOf('/') + 1) + "" + Print.startPuz + ".png";
/* 1733 */               switch (Def.puzzleMode) { case 7:
/* 1734 */                   Print.thePuzzle = "Arrow-word : " + Print.startPuz;
/* 1735 */                 case 4: Print.thePuzzle = "Crossword : " + Print.startPuz;
/* 1736 */                 case 60: Print.thePuzzle = "Fillin : " + Print.startPuz;
/* 1737 */                 case 30: Print.thePuzzle = "Codeword : " + Print.startPuz;
/* 1738 */                   CrosswordBuild.loadCrossword(Op.cw[Op.CW.CwPuz.ordinal()] = Print.startPuz + ".crossword");
/* 1739 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".crossword";
/*      */                   break;
/*      */                 case 20:
/* 1742 */                   Print.thePuzzle = "Akari : " + Print.startPuz;
/* 1743 */                   AkariBuild.loadAkari(Op.ak[Op.AK.AkPuz.ordinal()] = Print.startPuz + ".akari");
/* 1744 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".akari";
/*      */                   break;
/*      */                 case 40:
/* 1747 */                   Print.thePuzzle = "Domino : " + Print.startPuz;
/* 1748 */                   DominoBuild.loadDomino(Op.dm[Op.DM.DmPuz.ordinal()] = Print.startPuz + ".domino");
/* 1749 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".domino";
/*      */                   break;
/*      */                 case 70:
/* 1752 */                   Print.thePuzzle = "Fillomino : " + Print.startPuz;
/* 1753 */                   FillominoBuild.loadFillomino(Op.fi[Op.FI.FiPuz.ordinal()] = Print.startPuz + ".fillomino");
/* 1754 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".fillomino";
/*      */                   break;
/*      */                 case 6:
/* 1757 */                   Print.thePuzzle = "Freeform : " + Print.startPuz;
/* 1758 */                   FreeformBuild.loadCrossword(Op.ff[Op.FF.FfPuz.ordinal()] = Print.startPuz + ".crossword");
/* 1759 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".crossword";
/*      */                   break;
/*      */                 case 80:
/* 1762 */                   Print.thePuzzle = "Futoshiki : " + Print.startPuz;
/* 1763 */                   FutoshikiBuild.loadFutoshiki(Op.fu[Op.FU.FuPuz.ordinal()] = Print.startPuz + ".futoshiki");
/* 1764 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".futoshiki";
/*      */                   break;
/*      */                 case 90:
/* 1767 */                   Print.thePuzzle = "Gokigen : " + Print.startPuz;
/* 1768 */                   GokigenBuild.loadGokigen(Op.gk[Op.GK.GkPuz.ordinal()] = Print.startPuz + ".gokigen");
/* 1769 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".gokigen";
/*      */                   break;
/*      */                 case 100:
/* 1772 */                   Print.thePuzzle = "Kakuro : " + Print.startPuz;
/* 1773 */                   KakuroBuild.loadKakuro(Op.kk[Op.KK.KkPuz.ordinal()] = Print.startPuz + ".kakuro");
/* 1774 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".kakuro";
/*      */                   break;
/*      */                 case 110:
/* 1777 */                   Print.thePuzzle = "Kendoku : " + Print.startPuz;
/* 1778 */                   KendokuBuild.loadKendoku(Op.ke[Op.KE.KePuz.ordinal()] = Print.startPuz + ".kendoku");
/* 1779 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".kendoku";
/*      */                   break;
/*      */                 case 230:
/* 1782 */                   Print.thePuzzle = "Marupeke : " + Print.startPuz;
/* 1783 */                   MarupekeBuild.loadMarupeke(Op.ma[Op.MA.MaPuz.ordinal()] = Print.startPuz + ".marupeke");
/* 1784 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".marupeke";
/*      */                   break;
/*      */                 case 132:
/* 1787 */                   Print.thePuzzle = "Minesweeper : " + Print.startPuz;
/* 1788 */                   MinesweeperBuild.loadMinesweeper(Op.ms[Op.MS.MsPuz.ordinal()] = Print.startPuz + ".minesweeper");
/* 1789 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".minesweeper";
/*      */                   break;
/*      */                 case 150:
/* 1792 */                   Print.thePuzzle = "Roundabouts : " + Print.startPuz;
/* 1793 */                   RoundaboutsBuild.loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()] = Print.startPuz + ".roundabouts");
/* 1794 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".roundabouts";
/*      */                   break;
/*      */                 case 160:
/* 1797 */                   Print.thePuzzle = "Sikaku : " + Print.startPuz;
/* 1798 */                   SikakuBuild.loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()] = Print.startPuz + ".sikaku");
/* 1799 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".sikaku";
/*      */                   break;
/*      */                 case 170:
/* 1802 */                   Print.thePuzzle = "Slitherlink : " + Print.startPuz;
/* 1803 */                   SlitherlinkBuild.loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()] = Print.startPuz + ".slitherlink");
/* 1804 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".slitherlink";
/*      */                   break;
/*      */                 case 180:
/* 1807 */                   Print.thePuzzle = "Sudoku : " + Print.startPuz;
/* 1808 */                   SudokuBuild.loadSudoku(Op.su[Op.SU.SuPuz.ordinal()] = Print.startPuz + ".sudoku");
/* 1809 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".sudoku";
/*      */                   break;
/*      */                 case 182:
/* 1812 */                   Print.thePuzzle = "Tatami : " + Print.startPuz;
/* 1813 */                   TatamiBuild.loadTatami(Op.tt[Op.TT.TtPuz.ordinal()] = Print.startPuz + ".tatami");
/* 1814 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".tatami";
/*      */                   break;
/*      */                 case 190:
/* 1817 */                   Print.thePuzzle = "Tents : " + Print.startPuz;
/* 1818 */                   TentsBuild.loadTents(Op.te[Op.TE.TePuz.ordinal()] = Print.startPuz + ".tents");
/* 1819 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".tents";
/*      */                   break;
/*      */                 case 200:
/* 1822 */                   Print.thePuzzle = "Word-Search : " + Print.startPuz;
/* 1823 */                   WordsearchBuild.loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()] = Print.startPuz + ".wordsearch");
/* 1824 */                   Op.msc[Op.MSC.SolutionPuz.ordinal()] = Print.startPuz + ".wordsearch";
/*      */                   break; }
/*      */ 
/*      */               
/* 1828 */               g.setColor(Def.COLOR_WHITE); g.fillRect(0, 0, (int)(sz * x), (int)(sz * y));
/* 1829 */               Print.drawPreviewPanel(g, sz); try {
/* 1830 */                 Print.saveGridImage(path, ext[mode], puzzleImage);
/* 1831 */               } catch (IOException iox) {}
/*      */             } 
/* 1833 */             Methods.puzzleSaved(jdlgExport, path.substring(0, path.lastIndexOf('/')), path.substring(path.lastIndexOf('/') + 1));
/*      */           } else {
/*      */             
/* 1836 */             Print.drawPreviewPanel(g, sz);
/*      */             
/* 1838 */             if (mode == 4) {
/* 1839 */               Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 1840 */               clipboard.setContents(new ImageTransferable(puzzleImage), null);
/* 1841 */               JOptionPane.showMessageDialog(Print.jfPrint, "<html>The puzzle has been exported to the Clipboard.<br>It is now ready for Pasting into other applications.", "Export Completed", 1);
/*      */             
/*      */             }
/*      */             else {
/*      */               
/* 1846 */               JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/");
/* 1847 */               chooser.setDialogTitle("Export Puzzle to Graphic File");
/* 1848 */               chooser.setFileFilter(new FileNameExtensionFilter("BMP GIF JPG PNG", new String[] { this.val$ext[mode] }));
/* 1849 */               chooser.setSelectedFile(new File(fName + ext[mode]));
/* 1850 */               if (chooser.showSaveDialog(jdlgExport) == 0) {
/* 1851 */                 path = chooser.getSelectedFile().getAbsolutePath();
/*      */               }
/* 1853 */               if (path.length() > 0) {
/* 1854 */                 if (mode == 3) { try {
/* 1855 */                     Print.saveGridImage(path, ext[mode], puzzleImage);
/* 1856 */                   } catch (IOException iox) {} }
/*      */                 else
/*      */                 
/*      */                 { try {
/* 1860 */                     File file = new File(path);
/* 1861 */                     ImageIO.write(puzzleImage, ext[mode], file);
/*      */                   }
/* 1863 */                   catch (IOException iox) {} }
/*      */                 
/* 1865 */                 Methods.puzzleSaved(jdlgExport, path.substring(0, path.lastIndexOf('/')), path.substring(path.lastIndexOf('/') + 1));
/*      */               } 
/*      */             } 
/*      */           } 
/* 1869 */           Methods.clickedOK = true;
/* 1870 */           jdlgExport.dispose();
/* 1871 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1874 */     JButton jbExport = Methods.newButton("doExport", doExport, 69, 13, 323, 100, 26);
/* 1875 */     jdlgExport.add(jbExport);
/*      */     
/* 1877 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1879 */           Methods.clickedOK = false;
/* 1880 */           jdlgExport.dispose();
/* 1881 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1884 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 13, 357, 100, 26);
/* 1885 */     jdlgExport.add(jbCancel);
/*      */     
/* 1887 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1889 */           Methods.cweHelp(null, jdlgExport, "Graphic Export Options", Print.this.graphicExportOptions);
/*      */         }
/*      */       };
/* 1892 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 140, 323, 160, 61);
/* 1893 */     jdlgExport.add(jbHelp);
/*      */     
/* 1895 */     Methods.setDialogSize(jdlgExport, 310, 393);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void saveGridImage(String outFile, String formatName, BufferedImage puzzleImage) throws IOException {
/* 1900 */     File f = new File(outFile);
/*      */     
/* 1902 */     ImageIO.write(puzzleImage, formatName, f);
/*      */     
/* 1904 */     Def.dispPrinting = Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void mouseMoved(int x, int y) {
/*      */     int newCursorMode;
/* 1946 */     x /= 2; y /= 2;
/* 1947 */     if (x > puzzleItem[thisItem][0] + puzzleItem[thisItem][2] - 4 && x <= puzzleItem[thisItem][0] + puzzleItem[thisItem][2] && y > puzzleItem[thisItem][1] + puzzleItem[thisItem][3] - 4 && y <= puzzleItem[thisItem][1] + puzzleItem[thisItem][3]) {
/*      */ 
/*      */ 
/*      */       
/* 1951 */       newCursorMode = 6;
/*      */     }
/* 1953 */     else if (x > puzzleItem[thisItem][0] && x < puzzleItem[thisItem][0] + 5 && y > puzzleItem[thisItem][1] && y < puzzleItem[thisItem][1] + 5) {
/*      */ 
/*      */ 
/*      */       
/* 1957 */       newCursorMode = 13;
/*      */     } else {
/* 1959 */       newCursorMode = 0;
/*      */     } 
/* 1961 */     if (newCursorMode != cursorMode) {
/* 1962 */       cursorMode = newCursorMode;
/* 1963 */       jfPrint.setCursor(Cursor.getPredefinedCursor((cursorMode == 13 && 
/* 1964 */             System.getProperty("os.name").startsWith("Mac OS X")) ? 12 : cursorMode));
/* 1965 */       pp.repaint();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void mouseReleased(int x, int y) {
/* 1970 */     jfPrint.setCursor(Cursor.getPredefinedCursor(cursorMode = 0));
/*      */   }
/*      */   
/*      */   static void mouseDragged(int x, int y) {
/* 1974 */     x /= 2; y /= 2;
/* 1975 */     if (cursorMode == 13) {
/* 1976 */       if (x < 3 || y < 3 || x + puzzleItem[thisItem][2] > 502 || y + puzzleItem[thisItem][3] > 502)
/* 1977 */         return;  puzzleItem[thisItem][0] = x - 2;
/* 1978 */       puzzleItem[thisItem][1] = y - 2;
/*      */     }
/* 1980 */     else if (cursorMode == 6) {
/* 1981 */       if (x > 498 || y > 498)
/* 1982 */         return;  int i = x + 2 - puzzleItem[thisItem][0];
/* 1983 */       int j = y + 2 - puzzleItem[thisItem][1];
/* 1984 */       if (i > 3 && j > 3) {
/* 1985 */         puzzleItem[thisItem][2] = i;
/* 1986 */         puzzleItem[thisItem][3] = j;
/*      */       } 
/*      */     } 
/* 1989 */     setSpinners();
/*      */   }
/*      */   
/*      */   static void mouseClicked(int x, int y) {
/* 1993 */     x /= 2; y /= 2;
/* 1994 */     for (int i = 0; i < 31; i++) {
/* 1995 */       if (x > puzzleItem[i][0] && x < puzzleItem[i][0] + puzzleItem[i][2] && y > puzzleItem[i][1] && y < puzzleItem[i][1] + puzzleItem[i][3]) {
/* 1996 */         jcbbLayoutItem.setSelectedIndex(thisItem = i);
/* 1997 */         pp.repaint();
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Print.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */