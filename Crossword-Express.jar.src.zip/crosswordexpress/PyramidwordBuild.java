/*      */ package crosswordexpress;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.util.ArrayList;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ 
/*      */ public class PyramidwordBuild extends JPanel {
/*      */   static JFrame jfPyramidword;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   18 */   static String anchor1 = ""; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Thread thread; static String anchor2 = "";
/*   19 */   List<String> anagrams = new ArrayList<>();
/*      */   
/*      */   static void def() {
/*   22 */     Op.updateOption(Op.PY.PyW.ordinal(), "600", Op.py);
/*   23 */     Op.updateOption(Op.PY.PyH.ordinal(), "400", Op.py);
/*   24 */     Op.updateOption(Op.PY.PyRows.ordinal(), "6", Op.py);
/*   25 */     Op.updateOption(Op.PY.PyFirstLen.ordinal(), "5", Op.py);
/*   26 */     Op.updateOption(Op.PY.PyCell.ordinal(), "FFFFEE", Op.py);
/*   27 */     Op.updateOption(Op.PY.PyGrid.ordinal(), "000000", Op.py);
/*   28 */     Op.updateOption(Op.PY.PyPattern.ordinal(), "000000", Op.py);
/*   29 */     Op.updateOption(Op.PY.PyLetter.ordinal(), "006666", Op.py);
/*   30 */     Op.updateOption(Op.PY.PyID.ordinal(), "006633", Op.py);
/*   31 */     Op.updateOption(Op.PY.PyFocus.ordinal(), "33FFCC", Op.py);
/*   32 */     Op.updateOption(Op.PY.PyClue.ordinal(), "666666", Op.py);
/*   33 */     Op.updateOption(Op.PY.PyError.ordinal(), "FF0000", Op.py);
/*   34 */     Op.updateOption(Op.PY.PyPuz.ordinal(), "sample.pyramidword", Op.py);
/*   35 */     Op.updateOption(Op.PY.PyDic.ordinal(), "english", Op.py);
/*   36 */     Op.updateOption(Op.PY.PyFont.ordinal(), "SansSerif", Op.py);
/*   37 */     Op.updateOption(Op.PY.PyIDFont.ordinal(), "SansSerif", Op.py);
/*   38 */     Op.updateOption(Op.PY.PyClueFont.ordinal(), "SansSerif", Op.py);
/*   39 */     Op.updateOption(Op.PY.PyPuzColor.ordinal(), "true", Op.py);
/*   40 */     Op.updateOption(Op.PY.PySolColor.ordinal(), "true", Op.py);
/*      */   }
/*      */   
/*   43 */   String pyramidwordHelp = "<span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Select a Dictionary</span><br/>When loading a new puzzle into the Build screen, you begin by selecting the dictionary which was used to build the PYRAMID-WORD puzzle which you want to load.<p/><li/><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of PYRAMID-WORD puzzles currently available in the selected dictionary.<p/><li/><span>Save</span><br/>If you have done some manual editing of the puzzle, this option will save those changes under the existing file name.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the folder of the dictionary that was used to construct it. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Select a Dictionary</span><br/>Use this option to select the dictionary which you want to use to build the new PYRAMID-WORD puzzle.<p/><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option.If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b><p/><li/><span>Suggest Anagrams</span><br/>If you don't like any of the words which have been inserted into the puzzle you have an option of changing them. Mouse click into the word you don't like, and then select this option. You will be presented with a selection box containing all of the possibilities. Select the one you want and click <b>OK</b>. Your selection will be placed automatically into the correct location in the puzzle, and any subsequent words affected by the change will also be replaced.<p/><li/><span>Edit a Clue</span><br/>Mouse clicking into any word in the puzzle, and then selecting this option will give you an opportunity to edit the existing clue if there is one, or to enter a new clue if there isn't. If you click <b>OK</b> in the Edit Clue dialog, the puzzle will be saved automatically with the edited clue in place. If you decide not to save your editing, simply click <b>Cancel</b>.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Export Puzzle as Text</span><br/>Under normal circumstances, the Print function will provide all of the layout flexibility you will need when printing your puzzles. Inevitably of course special cases will arise where you need to intervene in the printing of either the words or the clues to achieve some special effect. To meet this need, a text export feature offers the following choices:-<ul><li/><b>Export Words.</b> Each line of text has the format <b>1. WORD</b><li/><b>Export Clues.</b> Each line of text has the format <b>1. Clue</b><li/><b>Export Words and Clues.</b> Each line of text has the format <b>1. WORD : Clue</b><li/><b>Export Puzzle Grid.</b> The puzzle grid is exported as a simple square or rectangular array of letters.</ul>In addition, you have the choice of exporting the text to a text file located anywhere on your computer's hard drive, or to the System Clipboard from where you can Paste into any Word Processor or Desk Top Publishing application.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted PYRAMID-WORD puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Pyramid-word Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   String pyramidwordOptions = "<div>Before you give the command to build a <b>Pyramid-word</b> puzzle, you will need to set some options which the program will use during the construction process.</div><ul><li/><b>Number of Rows: </b>Use this combo-box to select the number of rows of words to appear in your puzzle. Numbers in the range 3 to 10 can be selected.<p/><li/><b>Length of First Word: </b>Use this combo-box to select the length of the first (shortest) word in each half of the puzzle. Lengths in the range 2 to 10 can be selected.<p/><li/><b>Enter 2 Anchor Words: </b>These MUST be entered before a puzzle can be built. In addition, they must be equal in length, and equal to the <b>Length of First Word</b> which you entered previously. If you don't meet this requirement, you will receive an appropriate message when you click the <b>OK</b> button.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PyramidwordBuild(JFrame jf) {
/*  135 */     Def.puzzleMode = 140;
/*  136 */     Def.building = 0;
/*  137 */     Def.dispSolArray = Boolean.valueOf(false); Def.dispCursor = Boolean.valueOf(true); Def.dispGuideDigits = Boolean.valueOf(false);
/*      */ 
/*      */     
/*  140 */     makeGrid();
/*      */     
/*  142 */     jfPyramidword = new JFrame("Pyramidword Construction");
/*  143 */     jfPyramidword.setSize(Op.getInt(Op.PY.PyW.ordinal(), Op.py), Op.getInt(Op.PY.PyH.ordinal(), Op.py));
/*  144 */     int frameX = (jf.getX() + jfPyramidword.getWidth() > Methods.scrW) ? (Methods.scrW - jfPyramidword.getWidth() - 10) : jf.getX();
/*  145 */     jfPyramidword.setLocation(frameX, jf.getY());
/*  146 */     jfPyramidword.setLayout((LayoutManager)null);
/*  147 */     jfPyramidword.setDefaultCloseOperation(0);
/*  148 */     jfPyramidword
/*  149 */       .addComponentListener(new ComponentAdapter()
/*      */         {
/*      */           public void componentResized(ComponentEvent ce) {
/*  152 */             int w = (PyramidwordBuild.jfPyramidword.getWidth() < 600) ? 600 : PyramidwordBuild.jfPyramidword.getWidth();
/*  153 */             int h = (PyramidwordBuild.jfPyramidword.getHeight() < 400) ? 400 : PyramidwordBuild.jfPyramidword.getHeight();
/*  154 */             PyramidwordBuild.jfPyramidword.setSize(w, h);
/*  155 */             Op.setInt(Op.PY.PyW.ordinal(), w, Op.py);
/*  156 */             Op.setInt(Op.PY.PyH.ordinal(), h, Op.py);
/*  157 */             PyramidwordBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  161 */     jfPyramidword
/*  162 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  164 */             if (Def.building == 1 || Def.selecting)
/*  165 */               return;  Op.saveOptions("pyramidword.opt", Op.py);
/*  166 */             CrosswordExpress.transfer(1, PyramidwordBuild.jfPyramidword);
/*      */           }
/*      */         });
/*      */     
/*  170 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  173 */     Runnable buildThread = () -> {
/*      */         boolean res;
/*      */         if (res = buildPyramidword()) {
/*      */           savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */         }
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfPyramidword);
/*      */           makeGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         if (res) {
/*      */           restoreFrame();
/*      */           Methods.puzzleSaved(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()] + ".dic", Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           Methods.havePuzzle = true;
/*      */         } else {
/*      */           JOptionPane.showMessageDialog(jfPyramidword, "<html>It is not possible to build this puzzle.<br><center>Please read the Help.");
/*      */         } 
/*      */         Def.building = 0;
/*      */       };
/*  195 */     jl1 = new JLabel(); jfPyramidword.add(jl1);
/*  196 */     jl2 = new JLabel(); jfPyramidword.add(jl2);
/*      */ 
/*      */     
/*  199 */     menuBar = new JMenuBar();
/*  200 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  201 */     jfPyramidword.setJMenuBar(menuBar);
/*      */     
/*  203 */     this.menu = new JMenu("File");
/*  204 */     menuBar.add(this.menu);
/*  205 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  206 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  207 */     this.menu.add(this.menuItem);
/*  208 */     this.menuItem
/*  209 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.selectDictionary(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()], 1);
/*      */           Op.py[Op.PY.PyDic.ordinal()] = Methods.dictionaryName;
/*      */           loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  218 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  219 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  220 */     this.menu.add(this.menuItem);
/*  221 */     this.menuItem
/*  222 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()] + ".dic/", "pyramidword", Op.py, Op.PY.PyPuz.ordinal(), false);
/*      */         });
/*  229 */     this.menuItem = new JMenuItem("Save");
/*  230 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  231 */     this.menu.add(this.menuItem);
/*  232 */     this.menuItem
/*  233 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           Methods.puzzleSaved(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()] + ".dic", Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  241 */     this.menuItem = new JMenuItem("SaveAs");
/*  242 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  243 */     this.menu.add(this.menuItem);
/*  244 */     this.menuItem
/*  245 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfPyramidword, Op.py[Op.PY.PyPuz.ordinal()].substring(0, Op.py[Op.PY.PyPuz.ordinal()].indexOf(".pyramidword")), Op.py[Op.PY.PyDic.ordinal()] + ".dic", ".pyramidword");
/*      */           if (Methods.clickedOK) {
/*      */             savePyramidword(Op.py[Op.PY.PyPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()] + ".dic", Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  256 */     this.menuItem = new JMenuItem("Quit Construction");
/*  257 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  258 */     this.menu.add(this.menuItem);
/*  259 */     this.menuItem
/*  260 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("pyramidword.opt", Op.py);
/*      */           CrosswordExpress.transfer(1, jfPyramidword);
/*      */         });
/*  268 */     this.menu = new JMenu("Build");
/*  269 */     menuBar.add(this.menu);
/*  270 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  271 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  272 */     this.menu.add(this.menuItem);
/*  273 */     this.menuItem
/*  274 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.selectDictionary(jfPyramidword, Op.py[Op.PY.PyDic.ordinal()], 1);
/*      */           Op.py[Op.PY.PyDic.ordinal()] = Methods.dictionaryName;
/*      */           loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  283 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  284 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  285 */     this.menu.add(this.menuItem);
/*  286 */     this.menuItem
/*  287 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfPyramidword, Op.py[Op.PY.PyPuz.ordinal()].substring(0, Op.py[Op.PY.PyPuz.ordinal()].indexOf(".pyramidword")), Op.py[Op.PY.PyDic.ordinal()] + ".dic", ".pyramidword");
/*      */           if (Methods.clickedOK) {
/*      */             Op.py[Op.PY.PyPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  298 */     this.menuItem = new JMenuItem("Build Options");
/*  299 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  300 */     this.menu.add(this.menuItem);
/*  301 */     this.menuItem
/*  302 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           pyramidwordOptions();
/*      */           if (Methods.clickedOK)
/*      */             makeGrid(); 
/*      */           restoreFrame();
/*      */         });
/*  311 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  312 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  313 */     this.menu.add(this.buildMenuItem);
/*  314 */     this.buildMenuItem
/*  315 */       .addActionListener(ae -> {
/*      */           if (Op.py[Op.PY.PyPuz.ordinal()].length() == 0) {
/*      */             Methods.noName(jfPyramidword);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  331 */     this.menuItem = new JMenuItem("Suggest Anagrams");
/*  332 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(71, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  333 */     this.menu.add(this.menuItem);
/*  334 */     this.menuItem
/*  335 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           int subjectNode = Grid.nCur + ((Grid.nCur % 2 == 1) ? 2 : -2);
/*      */           if (subjectNode < 0 || subjectNode > 2 * Op.getInt(Op.PY.PyRows.ordinal(), Op.py)) {
/*      */             JOptionPane.showMessageDialog(jfPyramidword, "<html>Can't make a suggestion to replace an <html><font color=006644 size=3>Anchor</font> word!");
/*      */           } else {
/*      */             suggestAnagrams(subjectNode);
/*      */             if (Methods.clickedOK) {
/*      */               savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */             }
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  350 */     this.menuItem = new JMenuItem("Edit a Clue");
/*  351 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(67, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  352 */     this.menu.add(this.menuItem);
/*  353 */     this.menuItem
/*  354 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           CrosswordBuild.addAClue(jfPyramidword);
/*      */           if (Methods.clickedOK) {
/*      */             savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */           }
/*      */           restoreFrame();
/*      */         });
/*  365 */     this.menu = new JMenu("View");
/*  366 */     menuBar.add(this.menu);
/*  367 */     this.menuItem = new JMenuItem("Display Options");
/*  368 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  369 */     this.menu.add(this.menuItem);
/*  370 */     this.menuItem
/*  371 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfPyramidword, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  379 */     this.menu = new JMenu("Tasks");
/*  380 */     menuBar.add(this.menu);
/*  381 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  382 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  383 */     this.menu.add(this.menuItem);
/*  384 */     this.menuItem
/*  385 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfPyramidword, Op.py[Op.PY.PyPuz.ordinal()]);
/*      */         });
/*  391 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  392 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  393 */     this.menu.add(this.menuItem);
/*  394 */     this.menuItem
/*  395 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(141, jfPyramidword);
/*      */           } else {
/*      */             Methods.noPuzzle(jfPyramidword, "Solve");
/*      */           } 
/*      */         });
/*  404 */     this.menuItem = new JMenuItem("Export as Text");
/*  405 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(84, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  406 */     this.menu.add(this.menuItem);
/*  407 */     this.menuItem
/*  408 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             NodeList.exportText(jfPyramidword, true);
/*      */           } else {
/*      */             Methods.noPuzzle(jfPyramidword, "Export");
/*      */           } 
/*      */         });
/*  417 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  418 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  419 */     this.menu.add(this.menuItem);
/*  420 */     this.menuItem
/*  421 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfPyramidword, Op.py[Op.PY.PyPuz.ordinal()], Op.py[Op.PY.PyDic.ordinal()] + ".dic", pp)) {
/*      */             loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  431 */     this.menu = new JMenu("Help");
/*  432 */     menuBar.add(this.menu);
/*  433 */     this.menuItem = new JMenuItem("Pyramidword Help");
/*  434 */     this.menu.add(this.menuItem);
/*  435 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  436 */     this.menuItem
/*  437 */       .addActionListener(ae -> Methods.cweHelp(jfPyramidword, null, "Building Pyramidword Puzzles", this.pyramidwordHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  442 */     pp = new PyramidwordPP(0, 37);
/*  443 */     jfPyramidword.add(pp);
/*      */     
/*  445 */     pp
/*  446 */       .addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent e) {
/*  448 */             PyramidwordBuild.this.updateGrid(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  453 */     pp
/*  454 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  456 */             if (Def.isMac) {
/*  457 */               PyramidwordBuild.jfPyramidword.setResizable((PyramidwordBuild.jfPyramidword.getWidth() - e.getX() < 15 && PyramidwordBuild.jfPyramidword
/*  458 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  463 */     jfPyramidword
/*  464 */       .addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent e) {
/*  466 */             PyramidwordBuild.this.handleKeyPressed(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  471 */     loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*  472 */     restoreFrame();
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  476 */     jfPyramidword.setVisible(true);
/*  477 */     Insets insets = jfPyramidword.getInsets();
/*  478 */     panelW = jfPyramidword.getWidth() - insets.left + insets.right;
/*  479 */     panelH = jfPyramidword.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  480 */     pp.setSize(panelW, panelH);
/*  481 */     jfPyramidword.requestFocusInWindow();
/*  482 */     pp.repaint();
/*  483 */     Methods.infoPanel(jl1, jl2, "Build Pyramidword", "Dictionary : " + Op.py[Op.PY.PyDic.ordinal()] + "  -|-  Puzzle : " + Op.py[Op.PY.PyPuz
/*  484 */           .ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  488 */     int i = (width - inset) / Grid.xSz;
/*  489 */     int j = (height - inset) / Grid.ySz;
/*  490 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  491 */     Grid.xOrg = x + (width - Grid.xCell * Grid.xSz) / 2;
/*  492 */     Grid.yOrg = y + (height - Grid.yCell * Grid.ySz) / 2;
/*      */   }
/*      */   
/*      */   private void pyramidwordOptions() {
/*  496 */     final JTextField[] jtfAnchor = new JTextField[2];
/*      */     
/*  498 */     final JDialog jdlgPyramidword = new JDialog(jfPyramidword, "Pyramidword Options", true);
/*  499 */     jdlgPyramidword.setSize(280, 250);
/*  500 */     jdlgPyramidword.setResizable(false);
/*  501 */     jdlgPyramidword.setLayout((LayoutManager)null);
/*  502 */     jdlgPyramidword.setLocation(jfPyramidword.getX(), jfPyramidword.getY());
/*      */     
/*  504 */     jdlgPyramidword
/*  505 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  507 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  511 */     Methods.closeHelp();
/*      */     
/*  513 */     JLabel jlLines = new JLabel("Number of Rows:");
/*  514 */     jlLines.setForeground(Def.COLOR_LABEL);
/*  515 */     jlLines.setSize(170, 20);
/*  516 */     jlLines.setLocation(10, 10);
/*  517 */     jlLines.setHorizontalAlignment(4);
/*  518 */     jdlgPyramidword.add(jlLines);
/*      */     
/*  520 */     final JComboBox<Integer> jcbbLines = new JComboBox<>();
/*  521 */     for (int i = 3; i <= 10; i++)
/*  522 */       jcbbLines.addItem(Integer.valueOf(i)); 
/*  523 */     jcbbLines.setSize(80, 23);
/*  524 */     jcbbLines.setLocation(190, 10);
/*  525 */     jdlgPyramidword.add(jcbbLines);
/*  526 */     jcbbLines.setBackground(Def.COLOR_BUTTONBG);
/*  527 */     jcbbLines.setSelectedIndex(Op.getInt(Op.PY.PyRows.ordinal(), Op.py) - 3);
/*      */     
/*  529 */     JLabel jlFirstLen = new JLabel("Length of First Word:");
/*  530 */     jlFirstLen.setForeground(Def.COLOR_LABEL);
/*  531 */     jlFirstLen.setSize(170, 20);
/*  532 */     jlFirstLen.setLocation(10, 40);
/*  533 */     jlFirstLen.setHorizontalAlignment(4);
/*  534 */     jdlgPyramidword.add(jlFirstLen);
/*  535 */     final JComboBox<Integer> jcbbFirstLen = new JComboBox<>();
/*  536 */     for (int j = 2; j <= 10; j++)
/*  537 */       jcbbFirstLen.addItem(Integer.valueOf(j)); 
/*  538 */     jcbbFirstLen.setSize(80, 23);
/*  539 */     jcbbFirstLen.setLocation(190, 40);
/*  540 */     jdlgPyramidword.add(jcbbFirstLen);
/*  541 */     jcbbFirstLen.setBackground(Def.COLOR_BUTTONBG);
/*  542 */     jcbbFirstLen.setSelectedIndex(Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) - 2);
/*      */     
/*  544 */     JLabel jlAnchor = new JLabel("Enter 2 Anchor Words:");
/*  545 */     jlAnchor.setForeground(Def.COLOR_LABEL);
/*  546 */     jlAnchor.setSize(260, 20);
/*  547 */     jlAnchor.setLocation(10, 70);
/*  548 */     jlAnchor.setHorizontalAlignment(2);
/*  549 */     jdlgPyramidword.add(jlAnchor);
/*  550 */     for (int k = 0; k < 2; k++) {
/*  551 */       jtfAnchor[k] = new JTextField((k == 0) ? anchor1 : anchor2, 15);
/*  552 */       jtfAnchor[k].setSize(260, 23);
/*  553 */       jtfAnchor[k].setLocation(10, 90 + k * 28);
/*  554 */       jtfAnchor[k].selectAll();
/*  555 */       jtfAnchor[k].setHorizontalAlignment(2);
/*  556 */       jdlgPyramidword.add(jtfAnchor[k]);
/*  557 */       jtfAnchor[k].setFont(new Font("SansSerif", 1, 13));
/*      */     } 
/*      */     
/*  560 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  562 */           Op.setInt(Op.PY.PyRows.ordinal(), jcbbLines.getSelectedIndex() + 3, Op.py);
/*  563 */           Op.setInt(Op.PY.PyFirstLen.ordinal(), jcbbFirstLen.getSelectedIndex() + 2, Op.py);
/*  564 */           PyramidwordBuild.anchor1 = jtfAnchor[0].getText().toUpperCase();
/*  565 */           PyramidwordBuild.anchor2 = jtfAnchor[1].getText().toUpperCase();
/*  566 */           if (PyramidwordBuild.anchor1.length() != Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) || PyramidwordBuild.anchor2.length() != Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py)) {
/*  567 */             JOptionPane.showMessageDialog(jdlgPyramidword, "Both Anchor Words must have a length equal to the Length of First Word.");
/*      */             return;
/*      */           } 
/*  570 */           Methods.clickedOK = true;
/*  571 */           jdlgPyramidword.dispose();
/*  572 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  575 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 152, 90, 26);
/*  576 */     jdlgPyramidword.add(jbOK);
/*      */     
/*  578 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  580 */           Methods.clickedOK = false;
/*  581 */           jdlgPyramidword.dispose();
/*  582 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  585 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 187, 90, 26);
/*  586 */     jdlgPyramidword.add(jbCancel);
/*      */     
/*  588 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  590 */           Methods.cweHelp(null, jdlgPyramidword, "Pyramidword Options", PyramidwordBuild.this.pyramidwordOptions);
/*      */         }
/*      */       };
/*  593 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 110, 152, 160, 61);
/*  594 */     jdlgPyramidword.add(jbHelp);
/*      */     
/*  596 */     jdlgPyramidword.getRootPane().setDefaultButton(jbOK);
/*  597 */     Methods.setDialogSize(jdlgPyramidword, 280, 223);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  601 */     String[] colorLabel = { "Cell Color", "Grid Color", "Pattern Color", "Letter Color", "ID Digit Color", "Focus Color", "Clue Color", "Error Color" };
/*  602 */     int[] colorInt = { Op.PY.PyCell.ordinal(), Op.PY.PyGrid.ordinal(), Op.PY.PyPattern.ordinal(), Op.PY.PyLetter.ordinal(), Op.PY.PyID.ordinal(), Op.PY.PyFocus.ordinal(), Op.PY.PyClue.ordinal(), Op.PY.PyError.ordinal() };
/*  603 */     String[] fontLabel = { "Select Puzzle Font", "Select ID Digit Font", "Select Clue Font" };
/*  604 */     int[] fontInt = { Op.PY.PyFont.ordinal(), Op.PY.PyIDFont.ordinal(), Op.PY.PyClueFont.ordinal() };
/*  605 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  606 */     int[] checkInt = { Op.PY.PyPuzColor.ordinal(), Op.PY.PySolColor.ordinal() };
/*  607 */     Methods.stdPrintOptions(jf, "Pyramidword " + type, Op.py, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void savePyramidword(String pyramidwordName) {
/*      */     try {
/*  616 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName));
/*  617 */       dataOut.writeInt(Grid.xSz);
/*  618 */       dataOut.writeInt(Grid.ySz);
/*  619 */       dataOut.writeByte(Methods.noReveal);
/*  620 */       dataOut.writeByte(Methods.noErrors);
/*  621 */       for (int k = 0; k < 54; k++)
/*  622 */         dataOut.writeByte(0); 
/*  623 */       for (int j = 0; j < Grid.ySz; j++) {
/*  624 */         for (int m = 0; m < Grid.xSz; m++) {
/*  625 */           dataOut.writeInt(Grid.mode[m][j]);
/*  626 */           dataOut.writeInt(Grid.letter[m][j]);
/*  627 */           dataOut.writeInt(Grid.sol[m][j]);
/*  628 */           dataOut.writeInt(Grid.color[m][j]);
/*      */         } 
/*      */       } 
/*  631 */       dataOut.writeUTF(Methods.puzzleTitle);
/*  632 */       dataOut.writeUTF(Methods.author);
/*  633 */       dataOut.writeUTF(Methods.copyright);
/*  634 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  635 */       dataOut.writeUTF(Methods.puzzleNotes);
/*      */       
/*  637 */       for (int i = 0; i < NodeList.nodeListLength; i++) {
/*  638 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/*  639 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/*      */       } 
/*  641 */       dataOut.close();
/*      */     }
/*  643 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadPyramidword(String pyramidwordName) {
/*  650 */     Op.py[Op.PY.PyDic.ordinal()] = Methods.confirmDictionary(Op.py[Op.PY.PyDic.ordinal()] + ".dic", false);
/*      */ 
/*      */     
/*  653 */     try { File fl = new File(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName);
/*  654 */       if (!fl.exists()) {
/*  655 */         fl = new File(Op.py[Op.PY.PyDic.ordinal()] + ".dic/");
/*  656 */         String[] s = fl.list(); int k;
/*  657 */         for (k = 0; k < s.length && (
/*  658 */           s[k].lastIndexOf(".pyramidword") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  660 */         if (k == s.length) { makeGrid(); return; }
/*  661 */          pyramidwordName = s[k];
/*  662 */         Op.py[Op.PY.PyPuz.ordinal()] = pyramidwordName;
/*      */       } 
/*      */ 
/*      */       
/*  666 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName));
/*  667 */       Grid.xSz = dataIn.readInt();
/*  668 */       Grid.ySz = dataIn.readInt();
/*      */       
/*  670 */       Methods.noReveal = dataIn.readByte();
/*  671 */       Methods.noErrors = dataIn.readByte(); int i;
/*  672 */       for (i = 0; i < 54; i++)
/*  673 */         dataIn.readByte(); 
/*  674 */       for (int j = 0; j < Grid.ySz; j++) {
/*  675 */         for (i = 0; i < Grid.xSz; i++) {
/*  676 */           Grid.mode[i][j] = dataIn.readInt();
/*  677 */           Grid.letter[i][j] = dataIn.readInt();
/*  678 */           Grid.sol[i][j] = dataIn.readInt();
/*  679 */           Grid.color[i][j] = dataIn.readInt();
/*      */         } 
/*  681 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  682 */       Methods.author = dataIn.readUTF();
/*  683 */       Methods.copyright = dataIn.readUTF();
/*  684 */       Methods.puzzleNumber = dataIn.readUTF();
/*  685 */       Methods.puzzleNotes = dataIn.readUTF();
/*  686 */       NodeList.buildNodeList();
/*  687 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/*  688 */         (NodeList.nodeList[i]).word = dataIn.readUTF();
/*  689 */         (NodeList.nodeList[i]).clue = dataIn.readUTF();
/*      */       } 
/*  691 */       dataIn.close(); }
/*      */     
/*  693 */     catch (IOException exc) { return; }
/*  694 */      Methods.havePuzzle = true;
/*  695 */     Op.setInt(Op.PY.PyRows.ordinal(), Grid.ySz, Op.py);
/*  696 */     Op.setInt(Op.PY.PyFirstLen.ordinal(), (Grid.xSz - Grid.ySz) / 2, Op.py);
/*  697 */     anchor1 = (NodeList.nodeList[0]).word;
/*  698 */     anchor2 = (NodeList.nodeList[Grid.ySz * 2 - 1]).word;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawPyramidword(Graphics2D g2) {
/*  705 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 20.0F, 2, 0);
/*  706 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 12.0F, 2, 0);
/*  707 */     RenderingHints rh = g2.getRenderingHints();
/*  708 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  709 */     g2.setRenderingHints(rh);
/*  710 */     g2.setStroke(normalStroke);
/*      */     
/*      */     int j;
/*  713 */     for (j = 0; j < Grid.ySz; j++) {
/*  714 */       for (int k = 0; k < Grid.xSz; k++) {
/*  715 */         int theColor; if (Grid.mode[k][j] == 1) {
/*  716 */           theColor = Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyPattern.ordinal(), Op.py) : 0;
/*      */         } else {
/*  718 */           theColor = (Grid.curColor[k][j] != 16777215) ? Grid.curColor[k][j] : (Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyCell.ordinal(), Op.py) : 16777215);
/*  719 */         }  g2.setColor(new Color(theColor));
/*  720 */         g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       } 
/*      */     } 
/*      */     
/*  724 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyGrid.ordinal(), Op.py) : 0));
/*  725 */     for (j = 0; j < Grid.ySz; j++) {
/*  726 */       for (int k = 0; k < Grid.xSz; k++) {
/*  727 */         if (Grid.mode[k][j] != 2)
/*  728 */           g2.drawRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */       } 
/*      */     } 
/*  731 */     g2.setFont(new Font(Op.py[Op.PY.PyFont.ordinal()], 0, 8 * Grid.yCell / 10));
/*  732 */     FontMetrics fm = g2.getFontMetrics();
/*  733 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyLetter.ordinal(), Op.py) : 0));
/*  734 */     for (j = 0; j < Grid.ySz; j++) {
/*  735 */       for (int k = 0; k < Grid.xSz; k++) {
/*  736 */         char ch = (char)(Def.dispSolArray.booleanValue() ? Grid.sol[k][j] : Grid.letter[k][j]);
/*  737 */         if (ch != '\000') {
/*  738 */           int w = fm.stringWidth("" + ch);
/*  739 */           g2.drawString("" + ch, Grid.xOrg + k * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + 9 * Grid.yCell / 10);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  744 */     if (Def.dispCursor.booleanValue()) {
/*  745 */       g2.setColor(Def.COLOR_RED);
/*  746 */       g2.setStroke(wideStroke);
/*  747 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */     } 
/*      */ 
/*      */     
/*  751 */     g2.setFont(new Font(Op.py[Op.PY.PyIDFont.ordinal()], 0, Grid.yCell / 3));
/*  752 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyID.ordinal(), Op.py) : 0));
/*  753 */     fm = g2.getFontMetrics();
/*  754 */     for (int i = 0; NodeList.nodeList[i] != null; i++) {
/*  755 */       g2.drawString("" + (NodeList.nodeList[i]).id, Grid.xOrg + (NodeList.nodeList[i]).x * Grid.xCell + Grid.xCell / 10, Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell + fm
/*  756 */           .getAscent());
/*      */     }
/*  758 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  762 */     loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*  763 */     setSizesAndOffsets(left, top, width, height, 0);
/*  764 */     Methods.clearGrid(Grid.sol);
/*  765 */     Def.dispWithColor = Op.getBool(Op.PY.PyPuzColor.ordinal(), Op.py);
/*  766 */     PyramidwordSolve.drawPyramidword(g2);
/*  767 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  771 */     loadPyramidword(solutionPuzzle);
/*  772 */     setSizesAndOffsets(left, top, width, height, 0);
/*  773 */     Def.dispWithColor = Op.getBool(Op.PY.PySolColor.ordinal(), Op.py);
/*  774 */     drawPyramidword(g2);
/*  775 */     Def.dispWithColor = Boolean.valueOf(true);
/*  776 */     loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  780 */     loadPyramidword(solutionPuzzle);
/*  781 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  782 */     loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void makeGrid() {
/*  788 */     Methods.havePuzzle = false;
/*  789 */     Grid.xSz = 2 * Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) + Op.getInt(Op.PY.PyRows.ordinal(), Op.py);
/*  790 */     Grid.ySz = Op.getInt(Op.PY.PyRows.ordinal(), Op.py);
/*  791 */     Grid.clearGrid();
/*  792 */     for (int y = 0; y < Grid.ySz; y++) {
/*  793 */       for (int x = 0; x < Grid.xSz; x++)
/*  794 */         Grid.mode[x][y] = 4; 
/*  795 */       Grid.mode[Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) + y][y] = 1;
/*      */     } 
/*      */     
/*  798 */     Grid.xCur = Grid.yCur = 0;
/*  799 */     NodeList.buildNodeList();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList<String> findAnagrams(String seed) {
/*  805 */     ArrayList<String> containerWords = new ArrayList<>();
/*  806 */     ArrayList<String> suggestions = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  811 */     WordTools.findContainerWords(containerWords, seed, false); int cont;
/*  812 */     for (cont = 0; cont < containerWords.size(); cont++) {
/*  813 */       if (((String)containerWords.get(cont)).length() > Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) + Op.getInt(Op.PY.PyRows.ordinal(), Op.py) - 1) {
/*  814 */         containerWords.remove(cont);
/*  815 */         cont--;
/*      */       } 
/*      */     } 
/*      */     
/*  819 */     suggestions.add(seed); int sug;
/*  820 */     for (sug = 0; sug < suggestions.size(); sug++) {
/*  821 */       String word = suggestions.get(sug);
/*  822 */       int len = word.length();
/*  823 */       for (cont = 0; cont < containerWords.size(); cont++) {
/*  824 */         String tword = containerWords.get(cont);
/*  825 */         char[] thisWord = tword.toCharArray();
/*  826 */         if (tword.length() < len + 1) {
/*  827 */           containerWords.remove(cont);
/*  828 */           cont--;
/*      */         
/*      */         }
/*  831 */         else if (tword.length() == len + 1) {
/*  832 */           int i; int j; for (i = 0; i < len && (
/*  833 */             j = (new String(thisWord)).indexOf(word.charAt(i))) != -1; i++) {
/*  834 */             thisWord[j] = '\001';
/*      */           }
/*  836 */           if (i == len) {
/*  837 */             suggestions.add(tword);
/*  838 */             containerWords.remove(cont);
/*  839 */             cont--;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  845 */     for (int k = 0; k < Op.getInt(Op.PY.PyRows.ordinal(), Op.py); k++) {
/*  846 */       for (sug = 0; sug < suggestions.size(); sug++) {
/*  847 */         String word = suggestions.get(sug);
/*  848 */         int len = word.length(); boolean tested, found;
/*  849 */         for (tested = found = false, cont = sug + 1; cont < suggestions.size(); cont++) {
/*  850 */           String tword = suggestions.get(cont);
/*  851 */           char[] thisWord = tword.toCharArray();
/*  852 */           if (tword.length() >= len + 1) {
/*  853 */             if (tword.length() > len + 1)
/*  854 */               break;  int i; int j; for (tested = true, i = 0; i < len && (
/*  855 */               j = (new String(thisWord)).indexOf(word.charAt(i))) != -1; i++) {
/*  856 */               thisWord[j] = '\001';
/*      */             }
/*  858 */             if (i == len) {
/*  859 */               found = true; break;
/*      */             } 
/*      */           } 
/*      */         } 
/*  863 */         if (tested && !found) {
/*  864 */           suggestions.remove(sug);
/*  865 */           sug--;
/*      */         } 
/*      */       } 
/*      */     } 
/*  869 */     return suggestions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void suggestAnagrams(final int nodeNum) {
/*  879 */     final JDialog jdlgAnagrams = new JDialog(jfPyramidword, "Suggested Anagrams", true);
/*  880 */     jdlgAnagrams.setSize(310, 510);
/*  881 */     jdlgAnagrams.setResizable(false);
/*  882 */     jdlgAnagrams.setLayout((LayoutManager)null);
/*  883 */     jdlgAnagrams.setLocation(jfPyramidword.getX(), jfPyramidword.getY());
/*      */     
/*  885 */     JLabel jl1 = new JLabel("The Anagrams are:");
/*  886 */     jl1.setForeground(Def.COLOR_LABEL);
/*  887 */     jl1.setSize(200, 20);
/*  888 */     jl1.setLocation(10, 10);
/*  889 */     jl1.setHorizontalAlignment(2);
/*  890 */     jdlgAnagrams.add(jl1);
/*      */     
/*  892 */     DefaultListModel<String> lmMatch = new DefaultListModel<>();
/*  893 */     final JList<String> jl = new JList<>(lmMatch);
/*  894 */     JScrollPane jsp = new JScrollPane(jl);
/*  895 */     jsp.setSize(285, 385);
/*  896 */     jsp.setLocation(10, 31);
/*  897 */     jdlgAnagrams.add(jsp);
/*      */     
/*  899 */     ArrayList<String> candidate = findAnagrams((NodeList.nodeList[nodeNum]).word);
/*  900 */     int len = (NodeList.nodeList[nodeNum]).length + 1;
/*  901 */     for (int i = 1; i < candidate.size(); i++) {
/*  902 */       if (((String)candidate.get(i)).length() == len)
/*  903 */         lmMatch.addElement(candidate.get(i)); 
/*      */     } 
/*  905 */     jl1 = new JLabel(lmMatch.size() + " Item(s) in list.");
/*  906 */     jl1.setForeground(Def.COLOR_LABEL);
/*  907 */     jl1.setSize(200, 20);
/*  908 */     jl1.setLocation(10, 417);
/*  909 */     jl1.setHorizontalAlignment(2);
/*  910 */     jdlgAnagrams.add(jl1);
/*      */     
/*  912 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  914 */           if (jl.getSelectedIndex() != -1) {
/*  915 */             String s = ((String)jl.getSelectedValue()).trim();
/*  916 */             PyramidwordBuild.this.insertWords(PyramidwordBuild.this.findAnagrams(s), (nodeNum % 2 == 0));
/*  917 */             NodeList.attachClues(Op.py[Op.PY.PyDic.ordinal()], Boolean.valueOf(false));
/*  918 */             NodeList.sortNodeList(2);
/*  919 */             NodeList.rebuildHorzAndVert();
/*      */             
/*  921 */             Methods.clickedOK = true;
/*  922 */             jdlgAnagrams.dispose();
/*      */           } 
/*      */         }
/*      */       };
/*  926 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 40, 442, 100, 26);
/*  927 */     jdlgAnagrams.add(jbOK);
/*      */     
/*  929 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  931 */           Methods.clickedOK = false;
/*  932 */           jdlgAnagrams.dispose();
/*      */         }
/*      */       };
/*  935 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 160, 442, 100, 26);
/*  936 */     jdlgAnagrams.add(jbCancel);
/*      */     
/*  938 */     jdlgAnagrams.getRootPane().setDefaultButton(jbOK);
/*  939 */     Methods.setDialogSize(jdlgAnagrams, 305, 478);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean insertWords(ArrayList<String> suggestions, boolean left) {
/*  944 */     ArrayList<String> candidate = new ArrayList<>();
/*      */ 
/*      */     
/*  947 */     Random r = new Random();
/*      */ 
/*      */ 
/*      */     
/*  951 */     String word = suggestions.get(0);
/*  952 */     int len = word.length();
/*  953 */     int startLine = len - Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py);
/*  954 */     int nodeNum = left ? (2 * startLine) : (2 * (Op.getInt(Op.PY.PyRows.ordinal(), Op.py) - startLine) - 1);
/*  955 */     for (int line = startLine; line < Op.getInt(Op.PY.PyRows.ordinal(), Op.py); line++, nodeNum += left ? 2 : -2) {
/*      */       
/*  957 */       if (line > startLine) {
/*  958 */         len = word.length();
/*  959 */         candidate.clear();
/*  960 */         for (int sug = 1; sug < suggestions.size(); sug++) {
/*  961 */           String tword = suggestions.get(sug);
/*  962 */           char[] thisWord = tword.toCharArray();
/*  963 */           if (tword.length() >= len + 1) {
/*  964 */             if (tword.length() > len + 1)
/*  965 */               break;  int m; int j; for (m = 0; m < len && (
/*  966 */               j = (new String(thisWord)).indexOf(word.charAt(m))) != -1; m++) {
/*  967 */               thisWord[j] = '\001';
/*      */             }
/*  969 */             if (m == len) candidate.add(tword); 
/*      */           } 
/*  971 */         }  int k; if ((k = candidate.size()) == 0) return false; 
/*  972 */         word = candidate.get(r.nextInt(k));
/*      */       } 
/*      */       
/*  975 */       for (int i = 0; i < Op.getInt(Op.PY.PyFirstLen.ordinal(), Op.py) + line; i++) {
/*  976 */         Point cellLocation = (NodeList.nodeList[nodeNum]).cellLoc[i];
/*  977 */         Grid.letter[cellLocation.x][cellLocation.y] = word.charAt(i);
/*      */       } 
/*  979 */       (NodeList.nodeList[nodeNum]).word = word;
/*      */     } 
/*  981 */     return true;
/*      */   }
/*      */   
/*      */   private boolean buildPyramidword() {
/*  985 */     if (insertWords(findAnagrams(anchor1), true) && 
/*  986 */       insertWords(findAnagrams(anchor2), false)) {
/*  987 */       NodeList.attachClues(Op.py[Op.PY.PyDic.ordinal()], Boolean.valueOf(false));
/*  988 */       NodeList.sortNodeList(2);
/*  989 */       NodeList.rebuildHorzAndVert();
/*  990 */       return true;
/*      */     } 
/*  992 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void findCurrentNode() {
/*  998 */     for (Grid.nCur = 0; Grid.nCur < NodeList.nodeListLength; Grid.nCur++) {
/*  999 */       for (int i = 0; i < (NodeList.nodeList[Grid.nCur]).length; i++) {
/* 1000 */         if (((NodeList.nodeList[Grid.nCur]).cellLoc[i]).x == Grid.xCur && ((NodeList.nodeList[Grid.nCur]).cellLoc[i]).y == Grid.yCur)
/*      */           return; 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   void updateGrid(MouseEvent e) {
/* 1006 */     int x = e.getX(), y = e.getY();
/*      */     
/* 1008 */     if (Def.building == 1)
/* 1009 */       return;  if (x < Grid.xOrg || y < Grid.yOrg)
/* 1010 */       return;  x = (x - Grid.xOrg) / Grid.xCell;
/* 1011 */     y = (y - Grid.yOrg) / Grid.yCell;
/* 1012 */     if (x >= Grid.xSz || y >= Grid.ySz)
/* 1013 */       return;  if (Grid.mode[x][y] != 1) {
/* 1014 */       Grid.yCur = y;
/* 1015 */       Grid.xCur = x;
/* 1016 */       findCurrentNode();
/*      */     } 
/* 1018 */     restoreFrame();
/*      */   }
/*      */   
/*      */   void handleKeyPressed(KeyEvent e) {
/*      */     int i;
/* 1023 */     if (Def.building == 1)
/* 1024 */       return;  if (e.isAltDown())
/* 1025 */       return;  switch (e.getKeyCode()) { case 38:
/* 1026 */         for (i = Grid.yCur - 1; i >= 0 && Grid.mode[Grid.xCur][i] == 1; i--); if (i >= 0) Grid.yCur = i;  break;
/* 1027 */       case 40: for (i = Grid.yCur + 1; i < Grid.ySz && Grid.mode[Grid.xCur][i] == 1; i++); if (i < Grid.ySz) Grid.yCur = i;  break;
/* 1028 */       case 37: for (i = Grid.xCur - 1; i >= 0 && Grid.mode[i][Grid.yCur] == 1; i--); if (i >= 0) Grid.xCur = i;  break;
/* 1029 */       case 39: for (i = Grid.xCur + 1; i < Grid.xSz && Grid.mode[i][Grid.yCur] == 1; i++); if (i < Grid.xSz) Grid.xCur = i;  break;
/* 1030 */       case 36: Grid.xCur = 0; break;
/* 1031 */       case 35: Grid.xCur = Grid.xSz - 1; break;
/* 1032 */       case 33: for (i = 0; Grid.mode[Grid.xCur][i] == 1; i++); Grid.yCur = i; break;
/* 1033 */       case 34: for (i = Grid.ySz - 1; Grid.mode[Grid.xCur][i] == 1; i--); Grid.yCur = i; break; }
/*      */     
/* 1035 */     findCurrentNode();
/* 1036 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\PyramidwordBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */