/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class PyramidwordSolve extends JPanel {
/*  26 */   String pyramidwordSolve = "<div>The process of solving a PYRAMID-WORD Puzzle has much in common with solving Crossword Puzzles. The clue which is presented to you at any given time is the one for the word in which the red focus cell is currently located. Any character which is typed at the keyboard will be placed into the focus cell, and the focus cell will automatically move forward to the next character of the focus word. The location of the focus cell and its corresponding word may be shifted by pointing and clicking with the mouse, or by means of the cursor control keys. Other keys which provide useful functions during the solution process are Space bar and Delete.<br/><br/></div><span class='parhead'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Select a Dictionary</span><br/>When loading a new puzzle, you begin by selecting the dictionary which was used to build the PYRAMID-WORD puzzle which you want to solve.<p/><li/><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of PYRAMID-WORD puzzles currently available in the selected dictionary.<p/><li/><span>Quit Solving</span><br/>Returns you to the PYRAMID-WORD Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal One Letter</span><br/>If you need a little help to get started, this option will place the correct letter into the current focus cell.<p/><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Pyramid-word Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */   
/*     */   static JFrame jfSolvePyramidword;
/*     */ 
/*     */   
/*     */   static JMenuBar menuBar;
/*     */ 
/*     */   
/*     */   JMenu menu;
/*     */ 
/*     */   
/*     */   JMenu submenu;
/*     */ 
/*     */   
/*     */   JMenuItem menuItem;
/*     */ 
/*     */   
/*     */   static JPanel pp;
/*     */ 
/*     */   
/*     */   static JPanel jpClue;
/*     */ 
/*     */   
/*     */   static int panelW;
/*     */   
/*     */   static int panelH;
/*     */   
/*     */   static JLabel jl1;
/*     */   
/*     */   static JLabel jl2;
/*     */   
/*     */   Timer myTimer;
/*     */   
/*     */   Runnable solveThread;
/*     */   
/*     */   static int memMode;
/*     */   
/*     */   static JLabel jlAcross;
/*     */ 
/*     */   
/*     */   PyramidwordSolve(JFrame jf) {
/*  68 */     memMode = Def.puzzleMode;
/*  69 */     Def.puzzleMode = 141;
/*  70 */     Def.dispSolArray = Boolean.valueOf(true); Def.dispCursor = Boolean.valueOf(true);
/*  71 */     Grid.clearGrid();
/*     */     
/*  73 */     jfSolvePyramidword = new JFrame("Solve a Pyramidword Puzzle");
/*  74 */     jfSolvePyramidword.setSize(Op.getInt(Op.PY.PyW.ordinal(), Op.py), Op.getInt(Op.PY.PyH.ordinal(), Op.py));
/*  75 */     jfSolvePyramidword.getContentPane().setBackground(Def.COLOR_FRAMEBG);
/*  76 */     int frameX = (jf.getX() + jfSolvePyramidword.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolvePyramidword.getWidth() - 10) : jf.getX();
/*  77 */     jfSolvePyramidword.setLocation(frameX, jf.getY());
/*  78 */     jfSolvePyramidword.setLayout((LayoutManager)null);
/*  79 */     jfSolvePyramidword.setDefaultCloseOperation(0);
/*  80 */     jfSolvePyramidword
/*  81 */       .addComponentListener(new ComponentAdapter()
/*     */         {
/*     */           public void componentResized(ComponentEvent ce) {
/*  84 */             int w = (PyramidwordSolve.jfSolvePyramidword.getWidth() < 600) ? 600 : PyramidwordSolve.jfSolvePyramidword.getWidth();
/*  85 */             int h = (PyramidwordSolve.jfSolvePyramidword.getHeight() < 400) ? 400 : PyramidwordSolve.jfSolvePyramidword.getHeight();
/*  86 */             PyramidwordSolve.jfSolvePyramidword.setSize(w, h);
/*  87 */             Op.setInt(Op.PY.PyW.ordinal(), w, Op.py);
/*  88 */             Op.setInt(Op.PY.PyH.ordinal(), h, Op.py);
/*  89 */             PyramidwordSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  93 */     jfSolvePyramidword
/*  94 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  96 */             if (Def.selecting)
/*  97 */               return;  Op.saveOptions("pyramidword.opt", Op.py);
/*  98 */             PyramidwordSolve.this.restoreIfDone();
/*  99 */             PyramidwordSolve.savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/* 100 */             CrosswordExpress.transfer(140, PyramidwordSolve.jfSolvePyramidword);
/*     */           }
/*     */         });
/*     */     
/* 104 */     Methods.closeHelp();
/*     */     
/* 106 */     jl1 = new JLabel(); jfSolvePyramidword.add(jl1);
/* 107 */     jl2 = new JLabel(); jfSolvePyramidword.add(jl2);
/*     */ 
/*     */     
/* 110 */     menuBar = new JMenuBar();
/* 111 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 112 */     jfSolvePyramidword.setJMenuBar(menuBar);
/*     */     
/* 114 */     this.menu = new JMenu("File");
/* 115 */     menuBar.add(this.menu);
/* 116 */     this.menuItem = new JMenuItem("Select a Dictionary");
/* 117 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 118 */     this.menu.add(this.menuItem);
/* 119 */     this.menuItem
/* 120 */       .addActionListener(ae -> {
/*     */           Methods.selectDictionary(jfSolvePyramidword, Op.py[Op.PY.PyDic.ordinal()], 1);
/*     */           
/*     */           if (!Methods.fileAvailable(Methods.dictionaryName + ".dic", "pyramidword")) {
/*     */             JOptionPane.showMessageDialog(jfSolvePyramidword, "<html>No Pyramidword puzzles are available in this dictionary.<br>Use the <font color=880000>Build</font> option to create one.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*     */           
/*     */           Op.py[Op.PY.PyDic.ordinal()] = Methods.dictionaryName;
/*     */           loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*     */           restoreFrame();
/*     */         });
/* 137 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 138 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 139 */     this.menu.add(this.menuItem);
/* 140 */     this.menuItem
/* 141 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*     */           new Select(jfSolvePyramidword, Op.py[Op.PY.PyDic.ordinal()] + ".dic", "pyramidword", Op.py, Op.PY.PyPuz.ordinal(), false);
/*     */         });
/* 149 */     this.menuItem = new JMenuItem("Quit Solving");
/* 150 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 151 */     this.menu.add(this.menuItem);
/* 152 */     this.menuItem
/* 153 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("pyramidword.opt", Op.py);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           savePyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/*     */           
/*     */           PyramidwordBuild.restoreFrame();
/*     */           CrosswordExpress.transfer(140, jfSolvePyramidword);
/*     */         });
/* 163 */     this.menu = new JMenu("View");
/* 164 */     menuBar.add(this.menu);
/* 165 */     this.menuItem = new JMenuItem("Display Options");
/* 166 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 167 */     this.menu.add(this.menuItem);
/* 168 */     this.menuItem
/* 169 */       .addActionListener(ae -> {
/*     */           PyramidwordBuild.printOptions(jfSolvePyramidword, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 176 */     this.menu = new JMenu("Tasks");
/* 177 */     menuBar.add(this.menu);
/* 178 */     this.menuItem = new JMenuItem("Reveal One Letter");
/* 179 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 180 */     this.menu.add(this.menuItem);
/* 181 */     this.menuItem
/* 182 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             reveal();
/*     */           } else {
/*     */             Methods.noReveal(jfSolvePyramidword);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/*     */     
/* 192 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 197 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 199 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 200 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 201 */     this.menu.add(this.menuItem);
/* 202 */     this.menuItem
/* 203 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolvePyramidword);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 214 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 215 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 216 */     this.menu.add(this.menuItem);
/* 217 */     this.menuItem
/* 218 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             revealAll();
/*     */           } else {
/*     */             Methods.noReveal(jfSolvePyramidword);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 227 */     this.menuItem = new JMenuItem("Begin again");
/* 228 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 229 */     this.menu.add(this.menuItem);
/* 230 */     this.menuItem
/* 231 */       .addActionListener(ae -> {
/*     */           restart();
/*     */ 
/*     */           
/*     */           pp.repaint();
/*     */         });
/*     */     
/* 238 */     this.menu = new JMenu("Help");
/* 239 */     menuBar.add(this.menu);
/* 240 */     this.menuItem = new JMenuItem("Pyramidword Help");
/* 241 */     this.menu.add(this.menuItem);
/* 242 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 243 */     this.menuItem
/* 244 */       .addActionListener(ae -> Methods.cweHelp(jfSolvePyramidword, null, "Solving Pyramidword Puzzles", this.pyramidwordSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     jlAcross = new JLabel("Clue");
/* 250 */     jlAcross.setSize(50, 16);
/* 251 */     jlAcross.setLocation(10, 55);
/* 252 */     jlAcross.setHorizontalAlignment(2);
/* 253 */     jfSolvePyramidword.add(jlAcross);
/*     */     
/* 255 */     jlAcross.setFont(new Font(null, 1, 18));
/* 256 */     jpClue = new TheCluePanel(180, 35, 300, 45);
/* 257 */     jfSolvePyramidword.add(jpClue);
/*     */ 
/*     */     
/* 260 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if (Grid.sol[i][j] != Grid.letter[i][j])
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolvePyramidword);
/*     */       });
/* 268 */     loadPyramidword(Op.py[Op.PY.PyPuz.ordinal()]);
/* 269 */     pp = new PyramidwordSolvePP(0, 90);
/* 270 */     jfSolvePyramidword.add(pp);
/*     */     
/* 272 */     pp
/* 273 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 275 */             PyramidwordSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 280 */     pp
/* 281 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 283 */             if (Def.isMac) {
/* 284 */               PyramidwordSolve.jfSolvePyramidword.setResizable((PyramidwordSolve.jfSolvePyramidword.getWidth() - e.getX() < 15 && PyramidwordSolve.jfSolvePyramidword
/* 285 */                   .getHeight() - e.getY() < 150));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 290 */     jfSolvePyramidword
/* 291 */       .addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent e) {
/* 293 */             PyramidwordSolve.this.handleKeyPressed(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 298 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 302 */     jfSolvePyramidword.setVisible(true);
/* 303 */     Insets insets = jfSolvePyramidword.getInsets();
/* 304 */     panelW = jfSolvePyramidword.getWidth() - insets.left + insets.right;
/* 305 */     panelH = jfSolvePyramidword.getHeight() - insets.top + insets.bottom + 97 + menuBar.getHeight();
/* 306 */     pp.setSize(panelW, panelH);
/* 307 */     focusColor(true);
/* 308 */     setSizesAndOffsets(0, 0, panelW, panelH, 20);
/* 309 */     jfSolvePyramidword.requestFocusInWindow();
/* 310 */     jlAcross.setLocation(Grid.xOrg, 55);
/* 311 */     jpClue.setSize(panelW - 2 * Grid.xOrg - 60, 45);
/* 312 */     jpClue.setLocation(Grid.xOrg + 60, 45);
/* 313 */     jpClue.repaint();
/* 314 */     pp.repaint();
/* 315 */     Methods.infoPanel(jl1, jl2, "Solve Pyramidword", "Dictionary : " + Op.py[Op.PY.PyDic.ordinal()] + "  -|-  Puzzle : " + Op.py[Op.PY.PyPuz
/* 316 */           .ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 320 */     int i = (width - inset) / Grid.xSz;
/* 321 */     int j = (height - inset) / Grid.ySz;
/* 322 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 323 */     Grid.xOrg = x + (width - Grid.xCell * Grid.xSz) / 2;
/* 324 */     Grid.yOrg = y + (height - Grid.yCell * Grid.ySz) / 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void savePyramidword(String pyramidwordName) {
/*     */     try {
/* 330 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName));
/* 331 */       dataOut.writeInt(Grid.xSz);
/* 332 */       dataOut.writeInt(Grid.ySz);
/* 333 */       dataOut.writeByte(Methods.noReveal);
/* 334 */       dataOut.writeByte(Methods.noErrors);
/* 335 */       for (int k = 0; k < 54; k++)
/* 336 */         dataOut.writeByte(0); 
/* 337 */       for (int j = 0; j < Grid.ySz; j++) {
/* 338 */         for (int m = 0; m < Grid.xSz; m++) {
/* 339 */           dataOut.writeInt(Grid.mode[m][j]);
/* 340 */           dataOut.writeInt(Grid.letter[m][j]);
/* 341 */           dataOut.writeInt(Grid.sol[m][j]);
/* 342 */           dataOut.writeInt(Grid.color[m][j]);
/*     */         } 
/*     */       } 
/* 345 */       dataOut.writeUTF(Methods.puzzleTitle);
/* 346 */       dataOut.writeUTF(Methods.author);
/* 347 */       dataOut.writeUTF(Methods.copyright);
/* 348 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 349 */       dataOut.writeUTF(Methods.puzzleNotes);
/*     */       
/* 351 */       for (int i = 0; i < NodeList.nodeListLength; i++) {
/* 352 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/* 353 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/*     */       } 
/* 355 */       dataOut.close();
/*     */     }
/* 357 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadPyramidword(String pyramidwordName) {
/*     */     try {
/* 365 */       File fl = new File(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName);
/* 366 */       if (!fl.exists()) {
/* 367 */         fl = new File(Op.py[Op.PY.PyDic.ordinal()] + ".dic/");
/* 368 */         String[] s = fl.list(); int k;
/* 369 */         for (k = 0; k < s.length && (
/* 370 */           s[k].lastIndexOf(".pyramidword") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 372 */         pyramidwordName = s[k];
/* 373 */         Op.py[Op.PY.PyPuz.ordinal()] = pyramidwordName;
/*     */       } 
/*     */ 
/*     */       
/* 377 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.py[Op.PY.PyDic.ordinal()] + ".dic/" + pyramidwordName));
/* 378 */       Grid.xSz = dataIn.readInt();
/* 379 */       Grid.ySz = dataIn.readInt();
/* 380 */       Methods.noReveal = dataIn.readByte();
/* 381 */       Methods.noErrors = dataIn.readByte(); int i;
/* 382 */       for (i = 0; i < 54; i++)
/* 383 */         dataIn.readByte(); 
/* 384 */       for (int j = 0; j < Grid.ySz; j++) {
/* 385 */         for (i = 0; i < Grid.xSz; i++) {
/* 386 */           Grid.mode[i][j] = dataIn.readInt();
/* 387 */           Grid.letter[i][j] = dataIn.readInt();
/* 388 */           Grid.sol[i][j] = dataIn.readInt();
/* 389 */           Grid.color[i][j] = dataIn.readInt();
/*     */         } 
/* 391 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 392 */       Methods.author = dataIn.readUTF();
/* 393 */       Methods.copyright = dataIn.readUTF();
/* 394 */       Methods.puzzleNumber = dataIn.readUTF();
/* 395 */       Methods.puzzleNotes = dataIn.readUTF();
/* 396 */       NodeList.buildNodeList();
/* 397 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 398 */         (NodeList.nodeList[i]).word = dataIn.readUTF();
/* 399 */         (NodeList.nodeList[i]).clue = dataIn.readUTF();
/*     */       } 
/* 401 */       dataIn.close();
/*     */     }
/* 403 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawPyramidword(Graphics2D g2) {
/* 410 */     boolean isError = false;
/*     */     
/* 412 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 20.0F, 2, 0);
/* 413 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 12.0F, 2, 0);
/* 414 */     RenderingHints rh = g2.getRenderingHints();
/* 415 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 416 */     g2.setRenderingHints(rh);
/* 417 */     g2.setStroke(normalStroke);
/*     */     
/*     */     int j;
/* 420 */     for (j = 0; j < Grid.ySz; j++) {
/* 421 */       for (int k = 0; k < Grid.xSz; k++) {
/* 422 */         int theColor; if (Grid.mode[k][j] == 1) {
/* 423 */           theColor = Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyPattern.ordinal(), Op.py) : 0;
/*     */         }
/* 425 */         else if (Def.dispErrors.booleanValue() && Grid.sol[k][j] != 0 && Grid.sol[k][j] != Grid.letter[k][j]) {
/* 426 */           theColor = Op.getColorInt(Op.PY.PyError.ordinal(), Op.py);
/* 427 */           isError = true;
/*     */         } else {
/*     */           
/* 430 */           theColor = (Grid.curColor[k][j] != 16777215) ? Grid.curColor[k][j] : (Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyCell.ordinal(), Op.py) : 16777215);
/* 431 */         }  g2.setColor(new Color(theColor));
/* 432 */         g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */       } 
/* 434 */     }  if (!isError) Def.dispErrors = Boolean.valueOf(false);
/*     */ 
/*     */     
/* 437 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyGrid.ordinal(), Op.py) : 0));
/* 438 */     for (j = 0; j < Grid.ySz; j++) {
/* 439 */       for (int k = 0; k < Grid.xSz; k++) {
/* 440 */         if (Grid.mode[k][j] != 2)
/* 441 */           g2.drawRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*     */       } 
/*     */     } 
/* 444 */     g2.setFont(new Font(Op.py[Op.PY.PyFont.ordinal()], 0, 8 * Grid.yCell / 10));
/* 445 */     FontMetrics fm = g2.getFontMetrics();
/* 446 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyLetter.ordinal(), Op.py) : 0));
/* 447 */     for (j = 0; j < Grid.ySz; j++) {
/* 448 */       for (int k = 0; k < Grid.xSz; k++) {
/* 449 */         char ch = (char)Grid.sol[k][j];
/* 450 */         if (ch != '\000') {
/* 451 */           int w = fm.stringWidth("" + ch);
/* 452 */           g2.drawString("" + ch, Grid.xOrg + k * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + 9 * Grid.yCell / 10);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 457 */     if (Def.dispCursor.booleanValue()) {
/* 458 */       g2.setColor(Def.COLOR_RED);
/* 459 */       g2.setStroke(wideStroke);
/* 460 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */     } 
/*     */ 
/*     */     
/* 464 */     g2.setFont(new Font(Op.py[Op.PY.PyIDFont.ordinal()], 0, Grid.yCell / 3));
/* 465 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.PY.PyID.ordinal(), Op.py) : 0));
/* 466 */     fm = g2.getFontMetrics();
/* 467 */     for (int i = 0; NodeList.nodeList[i] != null; i++) {
/* 468 */       g2.drawString("" + (NodeList.nodeList[i]).id, Grid.xOrg + (NodeList.nodeList[i]).x * Grid.xCell + Grid.xCell / 10, Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell + fm
/* 469 */           .getAscent());
/*     */     }
/* 471 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   void restoreIfDone() {
/*     */     int j;
/* 475 */     for (j = 0; j < Grid.ySz; j++) {
/* 476 */       for (int i = 0; i < Grid.xSz; i++)
/* 477 */       { if (Character.isLetter(Grid.letter[i][j]) && Grid.sol[i][j] != Grid.letter[i][j])
/*     */           return;  } 
/* 479 */     }  for (j = 0; j < Grid.ySz; j++) {
/* 480 */       for (int i = 0; i < Grid.xSz; i++)
/* 481 */         Grid.sol[i][j] = 0; 
/*     */     } 
/*     */   }
/*     */   void checkForCompletion() {
/* 485 */     (new Thread(this.solveThread)).start();
/*     */   }
/*     */   
/*     */   public void reveal() {
/* 489 */     Grid.sol[Grid.xCur][Grid.yCur] = Grid.letter[Grid.xCur][Grid.yCur];
/*     */   }
/*     */   
/*     */   public void restart() {
/* 493 */     for (int j = 0; j < Grid.ySz; j++) {
/* 494 */       for (int i = 0; i < Grid.xSz; i++)
/* 495 */         Grid.sol[i][j] = 0; 
/*     */     } 
/*     */   }
/*     */   public void revealAll() {
/* 499 */     for (int j = 0; j < Grid.ySz; j++) {
/* 500 */       for (int i = 0; i < Grid.xSz; i++)
/* 501 */         Grid.sol[i][j] = Grid.letter[i][j]; 
/*     */     } 
/*     */   }
/*     */   static void focusColor(boolean set) {
/* 505 */     for (int i = 0; i < (NodeList.nodeList[Grid.nCur]).length; i++) {
/* 506 */       Grid.curColor[((NodeList.nodeList[Grid.nCur]).cellLoc[i]).x][((NodeList.nodeList[Grid.nCur]).cellLoc[i]).y] = set ? 61132 : 16777215;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void changeCursor() {
/* 512 */     if (Grid.nCur != -1) focusColor(false);
/*     */     
/* 514 */     int targetNodeA = Grid.horz[Grid.xNew][Grid.yNew];
/* 515 */     int targetNodeD = Grid.vert[Grid.xNew][Grid.yNew];
/* 516 */     if (Grid.xCur == Grid.xNew && Grid.yCur == Grid.yNew) {
/* 517 */       if (targetNodeA != -1 && targetNodeD != -1) {
/* 518 */         Grid.nCur = (Grid.nCur == targetNodeA) ? targetNodeD : targetNodeA;
/*     */       }
/*     */     } else {
/* 521 */       if ((targetNodeA != Grid.nCur && targetNodeD != Grid.nCur) || Grid.nCur == -1)
/*     */       {
/*     */ 
/*     */         
/* 525 */         if (Grid.xCur == Grid.xNew) {
/* 526 */           Grid.nCur = (targetNodeD != -1) ? targetNodeD : targetNodeA;
/*     */         } else {
/* 528 */           Grid.nCur = (targetNodeA != -1) ? targetNodeA : targetNodeD;
/*     */         }  } 
/* 530 */       Grid.xCur = Grid.xNew;
/* 531 */       Grid.yCur = Grid.yNew;
/*     */     } 
/*     */     
/* 534 */     if (Grid.nCur != -1) focusColor(true); 
/*     */   }
/*     */   
/*     */   void updateGrid(MouseEvent e) {
/* 538 */     int x = e.getX(), y = e.getY();
/*     */     
/* 540 */     if (Def.dispErrors.booleanValue()) { Def.dispErrors = Boolean.valueOf(false); return; }
/* 541 */      if (x < Grid.xOrg || y < Grid.yOrg)
/* 542 */       return;  int i = (x - Grid.xOrg) / Grid.xCell;
/* 543 */     int j = (y - Grid.yOrg) / Grid.yCell;
/* 544 */     if (i >= Grid.xSz || j >= Grid.ySz)
/* 545 */       return;  if (Grid.letter[i][j] == 0)
/*     */       return; 
/* 547 */     Grid.xNew = i; Grid.yNew = j;
/* 548 */     Def.dispCursor = Boolean.valueOf(true);
/* 549 */     changeCursor();
/* 550 */     restoreFrame();
/*     */   }
/*     */ 
/*     */   
/*     */   void handleKeyPressed(KeyEvent e) {
/*     */     Point[] cellLoc;
/*     */     int i;
/* 557 */     if (Def.dispErrors.booleanValue()) { Def.dispErrors = Boolean.valueOf(false); return; }
/* 558 */      if (e.isAltDown())
/* 559 */       return;  switch (e.getKeyCode()) { case 38:
/* 560 */         for (i = Grid.yCur - 1; i >= 0 && Grid.mode[Grid.xCur][i] == 1; i--); if (i >= 0) Grid.yNew = i;  break;
/* 561 */       case 40: for (i = Grid.yCur + 1; i < Grid.ySz && Grid.mode[Grid.xCur][i] == 1; i++); if (i < Grid.ySz) Grid.yNew = i;  break;
/* 562 */       case 37: for (i = Grid.xCur - 1; i >= 0 && Grid.mode[i][Grid.yCur] == 1; i--); if (i >= 0) Grid.xNew = i;  break;
/* 563 */       case 39: for (i = Grid.xCur + 1; i < Grid.xSz && Grid.mode[i][Grid.yCur] == 1; i++); if (i < Grid.xSz) Grid.xNew = i;  break;
/* 564 */       case 36: Grid.xNew = 0; break;
/* 565 */       case 35: Grid.xNew = Grid.xSz - 1; break;
/* 566 */       case 33: for (i = 0; Grid.mode[Grid.xCur][i] == 1; i++); Grid.yNew = i; break;
/* 567 */       case 34: for (i = Grid.ySz - 1; Grid.mode[Grid.xCur][i] == 1; i--); Grid.yNew = i; break;
/*     */       case 32: case 127:
/* 569 */         Grid.sol[Grid.xCur][Grid.yCur] = 0; break;
/*     */       case 10: break;
/*     */       default:
/* 572 */         if (!Character.isLetter(e.getKeyChar()))
/* 573 */           return;  if (Grid.sol[Grid.xCur][Grid.yCur] != Character.toUpperCase(e.getKeyChar())) {
/* 574 */           Grid.sol[Grid.xCur][Grid.yCur] = Character.toUpperCase(e.getKeyChar());
/* 575 */           checkForCompletion();
/*     */         } 
/* 577 */         cellLoc = (NodeList.nodeList[Grid.nCur]).cellLoc;
/* 578 */         for (i = 0; i < (NodeList.nodeList[Grid.nCur]).length; i++) {
/* 579 */           if ((cellLoc[i]).x == Grid.xCur && (cellLoc[i]).y == Grid.yCur && 
/* 580 */             i < (NodeList.nodeList[Grid.nCur]).length - 1) {
/* 581 */             Grid.xNew = (cellLoc[i + 1]).x;
/* 582 */             Grid.yNew = (cellLoc[i + 1]).y;
/*     */           } 
/*     */         }  break; }
/*     */     
/* 586 */     changeCursor();
/* 587 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\PyramidwordSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */