/*      */ package crosswordexpress;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.util.Random;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class RoundaboutsBuild extends JPanel {
/*      */   static JFrame jfRoundabouts;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   23 */   int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); int hmCount; int segmentCount; int chainNum;
/*      */   boolean sixpack;
/*   25 */   static String rules = "Draw a path which passes through the center of every square without crossing over itself until it returns to the square in which it started. The path must change direction at every roundabout, and it must also change direction exactly once in the intervening squares between roundabouts.";
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*   30 */     Op.updateOption(Op.RA.RaW.ordinal(), "500", Op.ra);
/*   31 */     Op.updateOption(Op.RA.RaH.ordinal(), "580", Op.ra);
/*   32 */     Op.updateOption(Op.RA.RaAcross.ordinal(), "10", Op.ra);
/*   33 */     Op.updateOption(Op.RA.RaDown.ordinal(), "10", Op.ra);
/*   34 */     Op.updateOption(Op.RA.RaCell.ordinal(), "FFFFEE", Op.ra);
/*   35 */     Op.updateOption(Op.RA.RaCircle.ordinal(), "009933", Op.ra);
/*   36 */     Op.updateOption(Op.RA.RaGrid.ordinal(), "000099", Op.ra);
/*   37 */     Op.updateOption(Op.RA.RaPath.ordinal(), "DD0000", Op.ra);
/*   38 */     Op.updateOption(Op.RA.RaError.ordinal(), "3333FF", Op.ra);
/*   39 */     Op.updateOption(Op.RA.RaPuz.ordinal(), "sample.roundabouts", Op.ra);
/*   40 */     Op.updateOption(Op.RA.RaPuzColor.ordinal(), "false", Op.ra);
/*   41 */     Op.updateOption(Op.RA.RaSolColor.ordinal(), "false", Op.ra);
/*      */   }
/*      */   
/*   44 */   String roundaboutsHelp = "<div>A Crossword Express <b>ROUNDABOUTS</b> puzzle consists of a square or rectangular array of squares in which some of the squares contain a circular roundabout. The puzzle is solved by drawing a path which passes through the center of every square without crossing over itself until it returns to the square in which it started. The path must change direction at every roundabout, and it must also change direction exactly once in the intervening squares between ROUNDABOUTS. There is a single unique solution which can be found without recourse to guessing.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of ROUNDABOUTS puzzles currently available on your computer.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>Roundabouts</b> folder along with all of the Roundabouts puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Print a Roundabouts KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted ROUNDABOUTS puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Roundabouts Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  109 */   String roundaboutsOptions = "<div>Before you give the command to build the <b>Roundabouts</b> puzzle, you can set some options which the program will use during the construction process.</div><br/><ul><li/>Roundabouts puzzles can be made in sizes ranging from 6x6 up to 14x14. This can be controlled using the <b>Cells Across</b> and <b>Cells Down</b> combo-boxes.<p/><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> check box will disable it.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RoundaboutsBuild(JFrame jf, boolean auto, int hm, int start) {
/*  132 */     Def.puzzleMode = 150;
/*  133 */     Def.dispCursor = Boolean.valueOf(false);
/*  134 */     Def.building = 0;
/*  135 */     makeGrid();
/*      */     
/*  137 */     jfRoundabouts = new JFrame("Roundabouts");
/*  138 */     if (Op.getInt(Op.RA.RaH.ordinal(), Op.ra) > Methods.scrH - 200) {
/*  139 */       int diff = Op.getInt(Op.RA.RaH.ordinal(), Op.ra) - Op.getInt(Op.RA.RaW.ordinal(), Op.ra);
/*  140 */       Op.setInt(Op.RA.RaH.ordinal(), Methods.scrH - 200, Op.ra);
/*  141 */       Op.setInt(Op.RA.RaW.ordinal(), Methods.scrH - 200 + diff, Op.ra);
/*  142 */     }  jfRoundabouts.setSize(Op.getInt(Op.RA.RaW.ordinal(), Op.ra), Op.getInt(Op.RA.RaH.ordinal(), Op.ra));
/*  143 */     int frameX = (jf.getX() + jfRoundabouts.getWidth() > Methods.scrW) ? (Methods.scrW - jfRoundabouts.getWidth() - 10) : jf.getX();
/*  144 */     jfRoundabouts.setLocation(frameX, jf.getY());
/*  145 */     jfRoundabouts.setLayout((LayoutManager)null);
/*  146 */     jfRoundabouts.setDefaultCloseOperation(0);
/*  147 */     jfRoundabouts
/*  148 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  150 */             int oldw = Op.getInt(Op.RA.RaW.ordinal(), Op.ra);
/*  151 */             int oldh = Op.getInt(Op.RA.RaH.ordinal(), Op.ra);
/*  152 */             Methods.frameResize(RoundaboutsBuild.jfRoundabouts, oldw, oldh, 500, 580);
/*  153 */             Op.setInt(Op.RA.RaW.ordinal(), RoundaboutsBuild.jfRoundabouts.getWidth(), Op.ra);
/*  154 */             Op.setInt(Op.RA.RaH.ordinal(), RoundaboutsBuild.jfRoundabouts.getHeight(), Op.ra);
/*  155 */             RoundaboutsBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  159 */     jfRoundabouts
/*  160 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  162 */             if (Def.building == 1 || Def.selecting)
/*  163 */               return;  Op.saveOptions("roundabouts.opt", Op.ra);
/*  164 */             CrosswordExpress.transfer(1, RoundaboutsBuild.jfRoundabouts);
/*      */           }
/*      */         });
/*      */     
/*  168 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  171 */     Runnable buildThread = () -> {
/*      */         if (this.howMany == 1) {
/*      */           buildRoundabouts();
/*      */         } else {
/*      */           multiBuild();
/*      */           
/*      */           if (this.sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfRoundabouts.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfRoundabouts);
/*      */           Grid.clearGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfRoundabouts, "roundabouts", Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  197 */     jl1 = new JLabel(); jfRoundabouts.add(jl1);
/*  198 */     jl2 = new JLabel(); jfRoundabouts.add(jl2);
/*      */ 
/*      */     
/*  201 */     menuBar = new JMenuBar();
/*  202 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  203 */     jfRoundabouts.setJMenuBar(menuBar);
/*      */     
/*  205 */     this.menu = new JMenu("File");
/*  206 */     menuBar.add(this.menu);
/*  207 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  208 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  209 */     this.menu.add(this.menuItem);
/*  210 */     this.menuItem
/*  211 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfRoundabouts, "roundabouts", "roundabouts", Op.ra, Op.RA.RaPuz.ordinal(), false);
/*      */         });
/*  218 */     this.menuItem = new JMenuItem("SaveAs");
/*  219 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  220 */     this.menu.add(this.menuItem);
/*  221 */     this.menuItem
/*  222 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfRoundabouts, Op.ra[Op.RA.RaPuz.ordinal()].substring(0, Op.ra[Op.RA.RaPuz.ordinal()].indexOf(".roundabouts")), "roundabouts", ".roundabouts");
/*      */           if (Methods.clickedOK) {
/*      */             saveRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfRoundabouts, "roundabouts", Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  233 */     this.menuItem = new JMenuItem("Quit Construction");
/*  234 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  235 */     this.menu.add(this.menuItem);
/*  236 */     this.menuItem
/*  237 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("roundabouts.opt", Op.ra);
/*      */           CrosswordExpress.transfer(1, jfRoundabouts);
/*      */         });
/*  245 */     this.menu = new JMenu("Build");
/*  246 */     menuBar.add(this.menu);
/*  247 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  248 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  249 */     this.menu.add(this.menuItem);
/*  250 */     this.menuItem
/*  251 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfRoundabouts, Op.ra[Op.RA.RaPuz.ordinal()].substring(0, Op.ra[Op.RA.RaPuz.ordinal()].indexOf(".roundabouts")), "roundabouts", ".roundabouts");
/*      */           if (Methods.clickedOK) {
/*      */             Op.ra[Op.RA.RaPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  262 */     this.menuItem = new JMenuItem("Build Options");
/*  263 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  264 */     this.menu.add(this.menuItem);
/*  265 */     this.menuItem
/*  266 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           roundaboutsOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (this.howMany > 1)
/*      */               Op.ra[Op.RA.RaPuz.ordinal()] = "" + this.startPuz + ".roundabouts"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  277 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  278 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  279 */     this.menu.add(this.buildMenuItem);
/*  280 */     this.buildMenuItem
/*  281 */       .addActionListener(ae -> {
/*      */           if (Op.ra[Op.RA.RaPuz.ordinal()].length() == 0 && this.howMany == 1) {
/*      */             Methods.noName(jfRoundabouts);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  298 */     this.menu = new JMenu("View");
/*  299 */     menuBar.add(this.menu);
/*  300 */     this.menuItem = new JMenuItem("Display Options");
/*  301 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  302 */     this.menu.add(this.menuItem);
/*  303 */     this.menuItem
/*  304 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfRoundabouts, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  312 */     this.menu = new JMenu("Export");
/*  313 */     menuBar.add(this.menu);
/*  314 */     this.menuItem = new JMenuItem("Print a Roundabouts KDP puzzle book.");
/*  315 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  316 */     this.menu.add(this.menuItem);
/*  317 */     this.menuItem
/*  318 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfRoundabouts, 150, 6);
/*      */         });
/*  325 */     this.menu = new JMenu("Tasks");
/*  326 */     menuBar.add(this.menu);
/*  327 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  328 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  329 */     this.menu.add(this.menuItem);
/*  330 */     this.menuItem
/*  331 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfRoundabouts, Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */         });
/*  337 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  338 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  339 */     this.menu.add(this.menuItem);
/*  340 */     this.menuItem
/*  341 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(151, jfRoundabouts);
/*      */           } else {
/*      */             Methods.noPuzzle(jfRoundabouts, "Solve");
/*      */           } 
/*      */         });
/*  350 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  351 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  352 */     this.menu.add(this.menuItem);
/*  353 */     this.menuItem
/*  354 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfRoundabouts, Op.ra[Op.RA.RaPuz.ordinal()], "roundabouts", pp)) {
/*      */             makeGrid();
/*      */             loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  365 */     this.menu = new JMenu("Help");
/*  366 */     menuBar.add(this.menu);
/*      */     
/*  368 */     this.menuItem = new JMenuItem("Roundabouts Help", 72);
/*  369 */     this.menu.add(this.menuItem);
/*  370 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  371 */     this.menuItem
/*  372 */       .addActionListener(ae -> Methods.cweHelp(jfRoundabouts, null, "Building Roundabouts Puzzles", this.roundaboutsHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  377 */     pp = new RoundaboutsPP(0, 37);
/*  378 */     jfRoundabouts.add(pp);
/*      */     
/*  380 */     if (Def.isMac) {
/*  381 */       pp
/*  382 */         .addMouseMotionListener(new MouseAdapter() {
/*      */             public void mouseMoved(MouseEvent e) {
/*  384 */               if (Def.isMac) {
/*  385 */                 RoundaboutsBuild.jfRoundabouts.setResizable((RoundaboutsBuild.jfRoundabouts.getWidth() - e.getX() < Def.insets.right + 15 && RoundaboutsBuild.jfRoundabouts
/*  386 */                     .getHeight() - e.getY() < Def.insets.top + RoundaboutsBuild.menuBar.getHeight() + 52));
/*      */               }
/*      */             }
/*      */           });
/*      */     }
/*  391 */     loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*  392 */     restoreFrame();
/*      */ 
/*      */     
/*  395 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  401 */     this.myTimer = new Timer(1000, timerAL);
/*      */     
/*  403 */     if (auto) {
/*  404 */       this.sixpack = true;
/*  405 */       this.howMany = hm; this.startPuz = start;
/*  406 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  411 */     jfRoundabouts.setVisible(true);
/*  412 */     panelW = jfRoundabouts.getWidth() - Def.extraW;
/*  413 */     panelH = jfRoundabouts.getHeight() - Def.extraH + menuBar.getHeight();
/*  414 */     pp.setSize(panelW, panelH);
/*  415 */     jfRoundabouts.requestFocusInWindow();
/*  416 */     pp.repaint();
/*  417 */     Methods.infoPanel(jl1, jl2, "Build Roundabouts", "Puzzle : " + Op.ra[Op.RA.RaPuz.ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  421 */     int i = (width - inset) / Grid.xSz;
/*  422 */     int j = (height - inset) / Grid.ySz;
/*  423 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  424 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/*  425 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*      */   }
/*      */ 
/*      */   
/*      */   private void roundaboutsOptions() {
/*  430 */     String[] size = { "6", "8", "10", "12", "14" };
/*      */     
/*  432 */     final JDialog jdlgRoundabouts = new JDialog(jfRoundabouts, "Roundabouts Options", true);
/*  433 */     jdlgRoundabouts.setSize(270, 282);
/*  434 */     jdlgRoundabouts.setResizable(false);
/*  435 */     jdlgRoundabouts.setLayout((LayoutManager)null);
/*  436 */     jdlgRoundabouts.setLocation(jfRoundabouts.getX(), jfRoundabouts.getY());
/*      */     
/*  438 */     jdlgRoundabouts
/*  439 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  441 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  445 */     Methods.closeHelp();
/*      */     
/*  447 */     JLabel jlAcross = new JLabel("Cells Across:");
/*  448 */     jlAcross.setForeground(Def.COLOR_LABEL);
/*  449 */     jlAcross.setSize(100, 20);
/*  450 */     jlAcross.setLocation(20, 8);
/*  451 */     jlAcross.setHorizontalAlignment(4);
/*  452 */     jdlgRoundabouts.add(jlAcross);
/*      */     
/*  454 */     final JComboBox<String> jcbbAcross = new JComboBox<>(size);
/*  455 */     jcbbAcross.setSize(60, 20);
/*  456 */     jcbbAcross.setLocation(150, 8);
/*  457 */     jdlgRoundabouts.add(jcbbAcross);
/*  458 */     jcbbAcross.setBackground(Def.COLOR_BUTTONBG);
/*  459 */     jcbbAcross.setSelectedIndex((Op.getInt(Op.RA.RaAcross.ordinal(), Op.ra) - 6) / 2);
/*      */     
/*  461 */     JLabel jlDown = new JLabel("Cells Down:");
/*  462 */     jlDown.setForeground(Def.COLOR_LABEL);
/*  463 */     jlDown.setSize(100, 20);
/*  464 */     jlDown.setLocation(20, 30);
/*  465 */     jlDown.setHorizontalAlignment(4);
/*  466 */     jdlgRoundabouts.add(jlDown);
/*      */     
/*  468 */     final JComboBox<String> jcbbDown = new JComboBox<>(size);
/*  469 */     jcbbDown.setSize(60, 20);
/*  470 */     jcbbDown.setLocation(150, 30);
/*  471 */     jdlgRoundabouts.add(jcbbDown);
/*  472 */     jcbbDown.setBackground(Def.COLOR_BUTTONBG);
/*  473 */     jcbbDown.setSelectedIndex((Op.getInt(Op.RA.RaDown.ordinal(), Op.ra) - 6) / 2);
/*      */     
/*  475 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgRoundabouts, 10, 60, this.howMany, this.startPuz, true);
/*      */     
/*  477 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  479 */           Grid.xSz = jcbbAcross.getSelectedIndex() * 2 + 6;
/*  480 */           Op.setInt(Op.RA.RaAcross.ordinal(), Grid.xSz, Op.ra);
/*  481 */           Grid.ySz = jcbbDown.getSelectedIndex() * 2 + 6;
/*  482 */           Op.setInt(Op.RA.RaDown.ordinal(), Grid.ySz, Op.ra);
/*  483 */           RoundaboutsBuild.this.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  484 */           RoundaboutsBuild.this.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  485 */           Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(hmp.jcbVaryDiff.isSelected()), Op.sx);
/*  486 */           Methods.clickedOK = true;
/*  487 */           jdlgRoundabouts.dispose();
/*  488 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  491 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 178, 80, 26);
/*  492 */     jdlgRoundabouts.add(jbOK);
/*      */     
/*  494 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  496 */           Methods.clickedOK = false;
/*  497 */           jdlgRoundabouts.dispose();
/*  498 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  501 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 213, 80, 26);
/*  502 */     jdlgRoundabouts.add(jbCancel);
/*      */     
/*  504 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  506 */           Methods.cweHelp(null, jdlgRoundabouts, "Roundabouts Options", RoundaboutsBuild.this.roundaboutsOptions);
/*      */         }
/*      */       };
/*  509 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 178, 150, 61);
/*  510 */     jdlgRoundabouts.add(jbHelp);
/*      */     
/*  512 */     jdlgRoundabouts.getRootPane().setDefaultButton(jbOK);
/*  513 */     Methods.setDialogSize(jdlgRoundabouts, 260, 249);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  517 */     String[] colorLabel = { "Cell Color", "Roundabout Color", "Grid Color", "Path Color", "Error Color" };
/*  518 */     int[] colorInt = { Op.RA.RaCell.ordinal(), Op.RA.RaCircle.ordinal(), Op.RA.RaGrid.ordinal(), Op.RA.RaPath.ordinal(), Op.RA.RaError.ordinal() };
/*  519 */     String[] fontLabel = { "" };
/*  520 */     int[] fontInt = { 0 };
/*  521 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  522 */     int[] checkInt = { Op.RA.RaPuzColor.ordinal(), Op.RA.RaSolColor.ordinal() };
/*  523 */     Methods.stdPrintOptions(jf, "Roundabouts " + type, Op.ra, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveRoundabouts(String roundaboutsName) {
/*      */     try {
/*  532 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("roundabouts/" + roundaboutsName));
/*  533 */       dataOut.writeInt(Grid.xSz);
/*  534 */       dataOut.writeInt(Grid.ySz);
/*  535 */       dataOut.writeByte(Methods.noReveal);
/*  536 */       dataOut.writeByte(Methods.noErrors);
/*  537 */       for (int i = 0; i < 54; i++)
/*  538 */         dataOut.writeByte(0); 
/*  539 */       for (int j = 0; j < Grid.ySz; j++) {
/*  540 */         for (int k = 0; k < Grid.xSz; k++) {
/*  541 */           dataOut.writeInt(Grid.copy[k][j]);
/*  542 */           dataOut.writeInt(Grid.sol[k][j]);
/*      */         } 
/*  544 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  545 */       dataOut.writeUTF(Methods.author);
/*  546 */       dataOut.writeUTF(Methods.copyright);
/*  547 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  548 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  549 */       dataOut.close();
/*      */     }
/*  551 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadRoundabouts(String roundaboutsName) {
/*      */     
/*  560 */     try { File fl = new File("roundabouts/" + roundaboutsName);
/*  561 */       if (!fl.exists()) {
/*      */         
/*  563 */         fl = new File("roundabouts/");
/*  564 */         String[] s = fl.list(); int k;
/*  565 */         for (k = 0; k < s.length && (
/*  566 */           s[k].lastIndexOf(".roundabouts") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  568 */         if (k == s.length) { makeGrid(); return; }
/*  569 */          roundaboutsName = s[k];
/*  570 */         Op.ra[Op.RA.RaPuz.ordinal()] = roundaboutsName;
/*      */       } 
/*      */ 
/*      */       
/*  574 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("roundabouts/" + roundaboutsName));
/*  575 */       Grid.xSz = dataIn.readInt();
/*  576 */       Grid.ySz = dataIn.readInt();
/*  577 */       Methods.noReveal = dataIn.readByte();
/*  578 */       Methods.noErrors = dataIn.readByte(); int i;
/*  579 */       for (i = 0; i < 54; i++)
/*  580 */         dataIn.readByte(); 
/*  581 */       for (int j = 0; j < Grid.ySz; j++) {
/*  582 */         for (i = 0; i < Grid.xSz; i++) {
/*  583 */           Grid.copy[i][j] = dataIn.readInt();
/*  584 */           Grid.sol[i][j] = dataIn.readInt();
/*      */         } 
/*  586 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  587 */       Methods.author = dataIn.readUTF();
/*  588 */       Methods.copyright = dataIn.readUTF();
/*  589 */       Methods.puzzleNumber = dataIn.readUTF();
/*  590 */       Methods.puzzleNotes = dataIn.readUTF();
/*  591 */       dataIn.close(); }
/*      */     
/*  593 */     catch (IOException exc) { return; }
/*  594 */      Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawRoundabouts(Graphics2D g2, int[][] puzzleArray) {
/*  600 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  601 */     g2.setStroke(normalStroke);
/*      */     
/*  603 */     RenderingHints rh = g2.getRenderingHints();
/*  604 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  605 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  606 */     g2.setRenderingHints(rh);
/*      */     
/*      */     int j;
/*  609 */     for (j = 0; j < Grid.ySz; j++) {
/*  610 */       for (int i = 0; i < Grid.xSz; i++) {
/*  611 */         g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaCell.ordinal(), Op.ra) : 16777215));
/*  612 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*  613 */         g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaGrid.ordinal(), Op.ra) : 0));
/*      */       } 
/*      */     } 
/*      */     
/*  617 */     for (j = 0; j < Grid.ySz + 1; j++)
/*  618 */       g2.drawLine(Grid.xOrg, Grid.yOrg + j * Grid.yCell, Grid.xOrg + Grid.xSz * Grid.xCell, Grid.yOrg + j * Grid.yCell); 
/*  619 */     for (j = 0; j < Grid.xSz + 1; j++) {
/*  620 */       g2.drawLine(Grid.xOrg + j * Grid.xCell, Grid.yOrg, Grid.xOrg + j * Grid.xCell, Grid.yOrg + Grid.xSz * Grid.yCell);
/*      */     }
/*      */     
/*  623 */     for (j = 0; j < Grid.ySz; j++) {
/*  624 */       for (int i = 0; i < Grid.xSz; i++) {
/*  625 */         if ((Grid.copy[i][j] & 0x10) > 0) {
/*  626 */           g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaCircle.ordinal(), Op.ra) : 16777215));
/*  627 */           g2.fillArc(Grid.xOrg + i * Grid.xCell + Grid.xCell / 4, Grid.yOrg + j * Grid.yCell + Grid.xCell / 4, Grid.xCell / 2, Grid.xCell / 2, 0, 360);
/*  628 */           g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaGrid.ordinal(), Op.ra) : 0));
/*  629 */           g2.drawArc(Grid.xOrg + i * Grid.xCell + Grid.xCell / 4, Grid.yOrg + j * Grid.yCell + Grid.xCell / 4, Grid.xCell / 2, Grid.xCell / 2, 0, 360);
/*      */         } 
/*      */       } 
/*      */     } 
/*  633 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaPath.ordinal(), Op.ra) : 0));
/*  634 */     for (j = 0; j < Grid.ySz; j++) {
/*  635 */       for (int i = 0; i < Grid.xSz; i++) {
/*  636 */         int xc = Grid.xOrg + i * Grid.xCell + Grid.xCell / 2;
/*  637 */         int yc = Grid.yOrg + j * Grid.yCell + Grid.yCell / 2;
/*  638 */         if ((Grid.copy[i][j] & 0x1) > 0) g2.drawLine(xc, yc, xc + Grid.xCell, yc); 
/*  639 */         if ((Grid.copy[i][j] & 0x2) > 0) g2.drawLine(xc, yc, xc, yc + Grid.yCell); 
/*  640 */         if ((Grid.copy[i][j] & 0x4) > 0) g2.drawLine(xc, yc, xc - Grid.xCell, yc); 
/*  641 */         if ((Grid.copy[i][j] & 0x8) > 0) g2.drawLine(xc, yc, xc, yc - Grid.yCell); 
/*      */       } 
/*      */     } 
/*  644 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  648 */     loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*  649 */     setSizesAndOffsets(left, top, width, height, 0);
/*  650 */     Methods.clearGrid(Grid.sol);
/*  651 */     Def.dispWithColor = Op.getBool(Op.RA.RaPuzColor.ordinal(), Op.ra);
/*  652 */     RoundaboutsSolve.drawRoundabouts(g2, Grid.sol);
/*  653 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  657 */     loadRoundabouts(solutionPuzzle);
/*  658 */     setSizesAndOffsets(left, top, width, height, 0);
/*  659 */     Def.dispWithColor = Op.getBool(Op.RA.RaSolColor.ordinal(), Op.ra);
/*  660 */     drawRoundabouts(g2, Grid.sol);
/*  661 */     Def.dispWithColor = Boolean.valueOf(true);
/*  662 */     loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  666 */     loadRoundabouts(solutionPuzzle);
/*  667 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  668 */     loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  674 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  676 */     String st = Op.sx[Op.SX.SxRa.ordinal()];
/*  677 */     if (st.length() < 3) st = "ROUNDABOUTS"; 
/*  678 */     int w = fm.stringWidth(st);
/*  679 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  680 */     RoundaboutsSolve.loadRoundabouts(puzName + ".roundabouts");
/*  681 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  682 */     Methods.clearGrid(Grid.sol);
/*  683 */     RoundaboutsSolve.drawRoundabouts(g2, Grid.sol);
/*  684 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/*  685 */       st = rules;
/*      */     } else {
/*  687 */       st = Op.ra[Op.RA.RaRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/*  688 */     }  if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/*  689 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  695 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  697 */     String st = Op.sx[Op.SX.SxRa.ordinal()];
/*  698 */     if (st.length() < 3) st = "ROUNDABOUTS"; 
/*  699 */     int w = fm.stringWidth(st);
/*  700 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  701 */     loadRoundabouts(solName + ".roundabouts");
/*  702 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  703 */     drawRoundabouts(g2, Grid.sol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  709 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  711 */     String st = puzName;
/*  712 */     int w = fm.stringWidth(st);
/*  713 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  714 */     RoundaboutsSolve.loadRoundabouts(puzName + ".roundabouts");
/*  715 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  716 */     Methods.clearGrid(Grid.sol);
/*  717 */     RoundaboutsSolve.drawRoundabouts(g2, Grid.sol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  723 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  725 */     String st = solName;
/*  726 */     int w = fm.stringWidth(st);
/*  727 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  728 */     loadRoundabouts(solName + ".roundabouts");
/*  729 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  730 */     drawRoundabouts(g2, Grid.sol);
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/*  734 */     Methods.havePuzzle = false;
/*  735 */     Grid.clearGrid();
/*  736 */     Grid.xSz = Op.getInt(Op.RA.RaAcross.ordinal(), Op.ra);
/*  737 */     Grid.ySz = Op.getInt(Op.RA.RaDown.ordinal(), Op.ra);
/*      */   }
/*      */   
/*      */   boolean createPath() {
/*  741 */     int count = 0, vect[] = new int[400];
/*  742 */     Random r = new Random();
/*      */     
/*  744 */     makeGrid(); int i;
/*  745 */     for (i = 0; i < Grid.xSz; i++) {
/*  746 */       if (i < Grid.xSz - 1) { Grid.copy[i][0] = Grid.copy[i][0] | 0x1; Grid.copy[i][Grid.ySz - 1] = Grid.copy[i][Grid.ySz - 1] | 0x1; }
/*  747 */        if (i > 0) { Grid.copy[i][0] = Grid.copy[i][0] | 0x4; Grid.copy[i][Grid.ySz - 1] = Grid.copy[i][Grid.ySz - 1] | 0x4; }
/*      */     
/*  749 */     }  int j; for (j = 0; j < Grid.ySz; j++) {
/*  750 */       if (j < Grid.ySz - 1) { Grid.copy[0][j] = Grid.copy[0][j] | 0x2; Grid.copy[Grid.xSz - 1][j] = Grid.copy[Grid.xSz - 1][j] | 0x2; }
/*  751 */        if (j > 0) { Grid.copy[0][j] = Grid.copy[0][j] | 0x8; Grid.copy[Grid.xSz - 1][j] = Grid.copy[Grid.xSz - 1][j] | 0x8; }
/*      */     
/*      */     }  while (true) {
/*      */       int y;
/*  755 */       for (i = 0; i < (y = Grid.xSz * Grid.ySz); ) { vect[i] = i; i++; }
/*  756 */        for (i = 0; i < y; i++) {
/*  757 */         j = r.nextInt(y);
/*  758 */         int k = vect[i]; vect[i] = vect[j]; vect[j] = k;
/*      */       } 
/*      */       int deltaCount;
/*  761 */       for (int x = 0; x < y; x++) {
/*  762 */         if (Def.building == 2) return false; 
/*  763 */         i = vect[x] % Grid.xSz;
/*  764 */         j = vect[x] / Grid.xSz;
/*  765 */         if (i < Grid.xSz - 1 && (Grid.copy[i][j] & 0x1) > 0 && (Grid.copy[i + 1][j] & 0x4) > 0) {
/*  766 */           if (r.nextInt(2) == 0) {
/*  767 */             if (j < Grid.ySz - 1 && Grid.copy[i][j + 1] == 0 && Grid.copy[i + 1][j + 1] == 0 && (Grid.copy[i][j] & 0x2) == 0 && (Grid.copy[i + 1][j] & 0x2) == 0) {
/*  768 */               Grid.copy[i][j] = Grid.copy[i][j] ^ 0x3; Grid.copy[i + 1][j] = Grid.copy[i + 1][j] ^ 0x6;
/*  769 */               Grid.copy[i][j + 1] = 9; Grid.copy[i + 1][j + 1] = 12;
/*  770 */               deltaCount++;
/*      */             }
/*      */           
/*      */           }
/*  774 */           else if (j > 0 && Grid.copy[i][j - 1] == 0 && Grid.copy[i + 1][j - 1] == 0 && (Grid.copy[i][j] & 0x8) == 0 && (Grid.copy[i + 1][j] & 0x8) == 0) {
/*  775 */             Grid.copy[i][j] = Grid.copy[i][j] ^ 0x9; Grid.copy[i + 1][j] = Grid.copy[i + 1][j] ^ 0xC;
/*  776 */             Grid.copy[i][j - 1] = 3; Grid.copy[i + 1][j - 1] = 6;
/*  777 */             deltaCount++;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  782 */         if (j < Grid.ySz - 1 && (Grid.copy[i][j] & 0x2) > 0 && (Grid.copy[i][j + 1] & 0x8) > 0) {
/*  783 */           if (r.nextInt(2) == 0) {
/*  784 */             if (i < Grid.xSz - 1 && Grid.copy[i + 1][j] == 0 && Grid.copy[i + 1][j + 1] == 0 && (Grid.copy[i][j] & 0x1) == 0 && (Grid.copy[i][j + 1] & 0x1) == 0) {
/*  785 */               Grid.copy[i][j] = Grid.copy[i][j] ^ 0x3; Grid.copy[i][j + 1] = Grid.copy[i][j + 1] ^ 0x9;
/*  786 */               Grid.copy[i + 1][j] = 6; Grid.copy[i + 1][j + 1] = 12;
/*  787 */               deltaCount++;
/*      */             }
/*      */           
/*      */           }
/*  791 */           else if (i > 0 && Grid.copy[i - 1][j] == 0 && Grid.copy[i - 1][j + 1] == 0 && (Grid.copy[i][j] & 0x4) == 0 && (Grid.copy[i][j + 1] & 0x4) == 0) {
/*  792 */             Grid.copy[i][j] = Grid.copy[i][j] ^ 0x6; Grid.copy[i][j + 1] = Grid.copy[i][j + 1] ^ 0xC;
/*  793 */             Grid.copy[i - 1][j] = 3; Grid.copy[i - 1][j + 1] = 9;
/*  794 */             deltaCount++;
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/*  799 */       if (deltaCount == 0) return false; 
/*  800 */       count += deltaCount;
/*  801 */       if (count == (Grid.xSz - 2) * (Grid.ySz - 2) / 2) return true; 
/*      */     } 
/*      */   }
/*      */   
/*      */   void updateCell(int x, int y, int dir, int chainUpdate) {
/*  806 */     if ((Grid.copy[x][y] & dir) == 0) {
/*  807 */       Grid.copy[x][y] = Grid.copy[x][y] | dir;
/*  808 */       Grid.control[x][y] = (byte)(Grid.control[x][y] + 1);
/*  809 */       this.segmentCount++;
/*  810 */       Grid.scratch[x][y] = chainUpdate;
/*      */     } 
/*      */   }
/*      */   
/*      */   void updateRoundabouts(int x, int y, int dir) {
/*  815 */     int xUpdate = 0, yUpdate = 0, dirUpdate = 0, chainUpdate = 0;
/*  816 */     switch (dir) { case 1:
/*  817 */         xUpdate = x + 1; yUpdate = y; dirUpdate = 4; break;
/*  818 */       case 2: xUpdate = x; yUpdate = y + 1; dirUpdate = 8; break;
/*  819 */       case 4: xUpdate = x - 1; yUpdate = y; dirUpdate = 1; break;
/*  820 */       case 8: xUpdate = x; yUpdate = y - 1; dirUpdate = 2;
/*      */         break; }
/*      */     
/*  823 */     if (Grid.control[x][y] == 0 && Grid.control[xUpdate][yUpdate] == 0) {
/*  824 */       chainUpdate = ++this.chainNum;
/*  825 */     } else if (Grid.scratch[x][y] != Grid.scratch[xUpdate][yUpdate]) {
/*  826 */       chainUpdate = Grid.scratch[x][y];
/*  827 */       int chainReplace = Grid.scratch[xUpdate][yUpdate];
/*  828 */       if (chainUpdate < chainReplace) {
/*  829 */         int i = chainUpdate;
/*  830 */         chainUpdate = chainReplace;
/*  831 */         chainReplace = i;
/*      */       } 
/*  833 */       if (chainReplace != 0)
/*  834 */         for (int j = 0; j < Grid.ySz; j++) {
/*  835 */           for (int i = 0; i < Grid.xSz; i++)
/*  836 */           { if (Grid.scratch[i][j] == chainReplace)
/*  837 */               Grid.scratch[i][j] = chainUpdate;  } 
/*      */         }  
/*  839 */     }  updateCell(x, y, dir, chainUpdate);
/*  840 */     updateCell(xUpdate, yUpdate, dirUpdate, chainUpdate);
/*      */   }
/*      */   
/*      */   int signature(int x, int y) {
/*  844 */     int sig = 0;
/*      */     
/*  846 */     if (Grid.control[x][y] == 2) return sig; 
/*  847 */     if (Grid.control[x][y] == 1) sig |= (Grid.copy[x][y] & 0xF) * 16; 
/*  848 */     if (x == Grid.xSz - 1 || Grid.control[x + 1][y] == 2) sig |= 0x1; 
/*  849 */     if (y == Grid.ySz - 1 || Grid.control[x][y + 1] == 2) sig |= 0x2; 
/*  850 */     if (x == 0 || Grid.control[x - 1][y] == 2) sig |= 0x4; 
/*  851 */     if (y == 0 || Grid.control[x][y - 1] == 2) sig |= 0x8; 
/*  852 */     if ((Grid.copy[x][y] & 0xF0) > 0) {
/*  853 */       if (x < Grid.xSz - 1 && (Grid.copy[x + 1][y] & 0x10) > 0) sig |= 0x1; 
/*  854 */       if (y < Grid.ySz - 1 && (Grid.copy[x][y + 1] & 0x10) > 0) sig |= 0x2; 
/*  855 */       if (x > 0 && (Grid.copy[x - 1][y] & 0x10) > 0) sig |= 0x4; 
/*  856 */       if (y > 0 && (Grid.copy[x][y - 1] & 0x10) > 0) sig |= 0x8; 
/*      */     } 
/*  858 */     if (this.segmentCount != 2 * (Grid.xSz * Grid.ySz - 1)) {
/*  859 */       if (x < Grid.xSz - 1) if ((((Grid.scratch[x][y] == Grid.scratch[x + 1][y]) ? 1 : 0) & ((Grid.scratch[x][y] != 0) ? 1 : 0)) != 0) sig |= 0x1;  
/*  860 */       if (y < Grid.ySz - 1) if ((((Grid.scratch[x][y] == Grid.scratch[x][y + 1]) ? 1 : 0) & ((Grid.scratch[x][y] != 0) ? 1 : 0)) != 0) sig |= 0x2;  
/*  861 */       if (x > 0) if ((((Grid.scratch[x][y] == Grid.scratch[x - 1][y]) ? 1 : 0) & ((Grid.scratch[x][y] != 0) ? 1 : 0)) != 0) sig |= 0x4;  
/*  862 */       if (y > 0) if ((((Grid.scratch[x][y] == Grid.scratch[x][y - 1]) ? 1 : 0) & ((Grid.scratch[x][y] != 0) ? 1 : 0)) != 0) sig |= 0x8;  
/*      */     } 
/*  864 */     return sig;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean cellBlocked() {
/*  869 */     boolean found = false;
/*      */     
/*  871 */     for (int j = 0; j < Grid.ySz; j++) {
/*  872 */       for (int i = 0; i < Grid.xSz; ) {
/*  873 */         int dir1, dir2, sign1, sign2; switch (signature(i, j)) { case 12:
/*  874 */             dir1 = 1; dir2 = 2; sign1 = 1; sign2 = 1; break;
/*  875 */           case 3: dir1 = 4; dir2 = 8; sign1 = -1; sign2 = -1; break;
/*  876 */           case 6: dir1 = 1; dir2 = 8; sign1 = 1; sign2 = -1; break;
/*  877 */           case 9: dir1 = 4; dir2 = 2; sign1 = -1; sign2 = 1; break;
/*      */           default:
/*      */             i++; continue; }
/*  880 */          updateRoundabouts(i, j, dir1);
/*  881 */         if ((Grid.copy[i][j] & 0x10) == 0)
/*  882 */           for (int v = 1; (Grid.copy[i + sign1 * v][j] & 0x10) == 0; v++)
/*  883 */             updateRoundabouts(i + sign1 * v, j, dir1);  
/*  884 */         updateRoundabouts(i, j, dir2);
/*  885 */         if ((Grid.copy[i][j] & 0x10) == 0)
/*  886 */           for (int v = 1; (Grid.copy[i][j + sign2 * v] & 0x10) == 0; v++)
/*  887 */             updateRoundabouts(i, j + sign2 * v, dir2);  
/*  888 */         found = true;
/*      */       } 
/*  890 */     }  return found;
/*      */   }
/*      */   
/*      */   boolean looseEnds() {
/*  894 */     int sign1 = 0, sign2 = 0;
/*  895 */     boolean found = false;
/*      */     
/*  897 */     for (int j = 0; j < Grid.ySz; j++) {
/*  898 */       for (int i = 0; i < Grid.xSz; i++) {
/*  899 */         if (Grid.control[i][j] == 1 && (
/*  900 */           Grid.copy[i][j] & 0x10) <= 0) {
/*      */           
/*  902 */           int sig = signature(i, j);
/*  903 */           int mode = ((sig & 0xF0) / 16 + (sig & 0xF) * 4) % 15;
/*  904 */           int dir = 0;
/*  905 */           switch (sig & 0xF) { case 14:
/*  906 */               dir = 1; sign1 = 1; sign2 = 0; break;
/*  907 */             case 13: dir = 2; sign1 = 0; sign2 = 1; break;
/*  908 */             case 11: dir = 4; sign1 = -1; sign2 = 0; break;
/*  909 */             case 7: dir = 8; sign1 = 0; sign2 = -1; break; }
/*      */           
/*  911 */           if (dir > 0) {
/*  912 */             updateRoundabouts(i, j, dir);
/*  913 */             if (mode == 1)
/*  914 */               for (int v = 1; (Grid.copy[i + sign1 * v][j + sign2 * v] & 0x10) == 0; v++) {
/*  915 */                 updateRoundabouts(i + sign1 * v, j + sign2 * v, dir);
/*      */               } 
/*  917 */             found = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*  921 */     }  return found;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean finishRoundabout() {
/*  926 */     boolean found = false;
/*      */     
/*  928 */     for (int j = 0; j < Grid.ySz; j++) {
/*  929 */       for (int i = 0; i < Grid.xSz; i++) {
/*  930 */         if (Grid.control[i][j] != 2 && (
/*  931 */           Grid.copy[i][j] & 0x10) > 0 && Grid.control[i][j] == 1) {
/*  932 */           switch (Grid.copy[i][j] & 0xF) {
/*      */             case 1:
/*      */             case 4:
/*  935 */               if (j == 0 || Grid.control[i][j - 1] == 2) { updateRoundabouts(i, j, 2); break; }
/*      */               
/*  937 */               if (j == Grid.ySz - 1 || Grid.control[i][j + 1] == 2) updateRoundabouts(i, j, 8); 
/*      */               break;
/*      */             case 2:
/*      */             case 8:
/*  941 */               if (i == 0 || Grid.control[i - 1][j] == 2) { updateRoundabouts(i, j, 1); break; }
/*      */               
/*  943 */               if (i == Grid.xSz - 1 || Grid.control[i + 1][j] == 2) updateRoundabouts(i, j, 4);  break;
/*      */           } 
/*  945 */           if (Grid.control[i][j] == 2) found = true; 
/*      */         } 
/*      */       } 
/*  948 */     }  return found;
/*      */   }
/*      */   
/*      */   boolean solveRoundabouts() {
/*      */     boolean found;
/*  953 */     this.segmentCount = this.chainNum = 0;
/*      */     
/*      */     do {
/*  956 */       found = false;
/*  957 */       if (cellBlocked()) found = true; 
/*  958 */       if (finishRoundabout()) found = true; 
/*  959 */       if (!looseEnds()) continue;  found = true;
/*  960 */     } while (found);
/*      */ 
/*      */     
/*  963 */     return (this.segmentCount == Grid.xSz * Grid.ySz * 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void attachRoundabouts() {
/*  969 */     Random r = new Random();
/*      */     
/*  971 */     int i = r.nextInt(Grid.xSz);
/*  972 */     int j = r.nextInt(Grid.ySz);
/*  973 */     int dir = ((Grid.copy[i][j] & 0x1) > 0) ? 1 : (((Grid.copy[i][j] & 0x2) > 0) ? 2 : 4);
/*      */     
/*  975 */     boolean insert = true;
/*  976 */     while ((Grid.copy[i][j] & 0x10) <= 0) {
/*      */       
/*  978 */       int nextDir = Grid.copy[i][j] ^ dir;
/*  979 */       if (nextDir != dir * 4 % 15) {
/*  980 */         if (insert)
/*  981 */           Grid.copy[i][j] = Grid.copy[i][j] | 0x10; 
/*  982 */         insert = !insert;
/*      */       } 
/*  984 */       switch (nextDir) { case 1:
/*  985 */           i++; break;
/*  986 */         case 2: j++; break;
/*  987 */         case 4: i--; break;
/*  988 */         case 8: j--; break; }
/*      */       
/*  990 */       dir = nextDir * 4 % 15;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void multiBuild() {
/*  995 */     String title = Methods.puzzleTitle;
/*  996 */     int[] sizeDef = { 6, 6, 8, 8, 10, 12, 14 };
/*      */ 
/*      */     
/*  999 */     int saveRoundaboutsSize = Op.getInt(Op.RA.RaAcross.ordinal(), Op.ra);
/*      */ 
/*      */     
/* 1002 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1003 */     Calendar c = Calendar.getInstance();
/*      */     
/* 1005 */     for (this.hmCount = 1; this.hmCount <= this.howMany; this.hmCount++) {
/* 1006 */       if (this.startPuz > 9999999) { try {
/* 1007 */           c.setTime(sdf.parse("" + this.startPuz));
/* 1008 */         } catch (ParseException ex) {}
/* 1009 */         this.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 1012 */       Methods.puzzleTitle = "ROUNDABOUTS Puzzle : " + this.startPuz;
/* 1013 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/* 1014 */         Grid.xSz = Grid.ySz = sizeDef[(this.startPuz - 1) % 7];
/* 1015 */         Op.setInt(Op.RA.RaAcross.ordinal(), Grid.xSz, Op.ra);
/* 1016 */         Op.setInt(Op.RA.RaDown.ordinal(), Grid.xSz, Op.ra);
/*      */       } 
/*      */       
/* 1019 */       Methods.buildProgress(jfRoundabouts, Op.ra[Op.RA.RaPuz
/* 1020 */             .ordinal()] = "" + this.startPuz + ".roundabouts");
/* 1021 */       buildRoundabouts();
/* 1022 */       restoreFrame();
/* 1023 */       Wait.shortWait(100);
/* 1024 */       if (Def.building == 2)
/*      */         return; 
/* 1026 */       this.startPuz++;
/*      */     } 
/* 1028 */     this.howMany = 1;
/* 1029 */     Methods.puzzleTitle = title;
/*      */ 
/*      */     
/* 1032 */     Op.setInt(Op.RA.RaAcross.ordinal(), saveRoundaboutsSize, Op.ra);
/* 1033 */     Op.setInt(Op.RA.RaDown.ordinal(), saveRoundaboutsSize, Op.ra);
/*      */   }
/*      */ 
/*      */   
/*      */   private void buildRoundabouts() {
/* 1038 */     for (int count = 0;; count++) {
/* 1039 */       while (!createPath())
/* 1040 */       { if (Def.building == 2)
/* 1041 */           return;  }  attachRoundabouts();
/* 1042 */       for (int j = 0; j < Grid.ySz; j++) {
/* 1043 */         for (int i = 0; i < Grid.xSz; i++)
/* 1044 */           Grid.copy[i][j] = Grid.copy[i][j] & 0xF0; 
/* 1045 */       }  if (solveRoundabouts())
/*      */         break; 
/* 1047 */       if (this.howMany == 1 && count % 50 == 0)
/* 1048 */         restoreFrame(); 
/*      */     } 
/* 1050 */     saveRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void updateGrid(MouseEvent e) {
/* 1054 */     int x = e.getX(), y = e.getY();
/*      */     
/* 1056 */     if (Def.building == 1)
/* 1057 */       return;  if (x < Grid.xOrg || y < Grid.yOrg)
/* 1058 */       return;  x = (x - Grid.xOrg) / Grid.xCell;
/* 1059 */     y = (y - Grid.yOrg) / Grid.yCell;
/* 1060 */     if (x >= Grid.xSz || y >= Grid.ySz)
/* 1061 */       return;  Grid.xCur = x; Grid.yCur = y;
/* 1062 */     Grid.copy[x][y] = Grid.copy[x][y] ^ 0x10;
/* 1063 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\RoundaboutsBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */