/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class RoundaboutsSolve extends JPanel {
/*  26 */   String roundaboutsSolve = "<div>A Crossword Express <b>ROUNDABOUTS</b> puzzle consists of a square or rectangular array of squares in which some of the squares contain a circular roundabout. The puzzle is solved by drawing a path which passes through the center of every square without crossing over itself until it returns to the square in which it started. The path must change direction at every roundabout, and it must also change direction exactly once in the intervening squares between ROUNDABOUTS. There is a single unique solution which can be found without recourse to guessing.<p/>Solving the puzzle is a point and click mouse operation. A single click near the boundary between two cells will draw a path segment between the centers of the two cells. A second click can be used to remove the path segment if you believe you have made a mistake.<br/><br/></div><span class='m'>Menu Functions</span><ul>  <li/><span class='s'>File Menu</span>  <ul>    <li/><span>Load a Puzzle</span><br/>      Use this option to choose the puzzle you want to solve from the pool of ROUNDABOUTS puzzles currently available on your computer.<p/>    <li/><span>Quit Solving</span><br/>      Returns you to the ROUNDABOUTS Construction screen.  </ul>  <li/><span class='s'>View Menu</span>  <ul>    <li/><span>Display Options</span><br/>      This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will       be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.  </ul>  <li/><span class='s'>Tasks Menu</span>  <ul>    <li/><span>Undo</span><br/>      This option will undo in reverse order, each of the operations you have done on the puzzle.<p/>    <li/><span>Reveal Errors</span><br/>      If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/>    <li/><span>Reveal Solution</span><br/>      The entire solution can be seen by selecting this option.<p/>    <li/><span>Begin Again</span><br/>      You can restart the entire solution process at any time by selecting this option.  </ul>  <li/><span class='s'>Help Menu</span>  <ul>    <li/><span>Roundabouts Help</span><br/>      Displays the Help screen which you are now reading.  </ul></ul></body>";
/*     */ 
/*     */   
/*     */   static JFrame jfSolveRoundabouts;
/*     */ 
/*     */   
/*     */   static JMenuBar menuBar;
/*     */ 
/*     */   
/*     */   JMenu menu;
/*     */ 
/*     */   
/*     */   JMenu submenu;
/*     */ 
/*     */   
/*     */   JMenuItem menuItem;
/*     */ 
/*     */   
/*     */   static JPanel pp;
/*     */ 
/*     */   
/*     */   static int panelW;
/*     */ 
/*     */   
/*     */   static int panelH;
/*     */ 
/*     */   
/*     */   static JLabel jl1;
/*     */ 
/*     */   
/*     */   static JLabel jl2;
/*     */   
/*     */   Timer myTimer;
/*     */   
/*     */   Runnable solveThread;
/*     */   
/*     */   int memMode;
/*     */   
/*     */   Thread thread;
/*     */ 
/*     */   
/*     */   RoundaboutsSolve(JFrame jf) {
/*  68 */     this.memMode = Def.puzzleMode;
/*  69 */     Def.puzzleMode = 151;
/*     */     
/*  71 */     jfSolveRoundabouts = new JFrame("Roundabouts");
/*  72 */     jfSolveRoundabouts.setSize(Op.getInt(Op.RA.RaW.ordinal(), Op.ra), Op.getInt(Op.RA.RaH.ordinal(), Op.ra));
/*  73 */     int frameX = (jf.getX() + jfSolveRoundabouts.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveRoundabouts.getWidth() - 10) : jf.getX();
/*  74 */     jfSolveRoundabouts.setLocation(frameX, jf.getY());
/*  75 */     jfSolveRoundabouts.setLayout((LayoutManager)null);
/*  76 */     jfSolveRoundabouts.setDefaultCloseOperation(0);
/*  77 */     jfSolveRoundabouts
/*  78 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/*  80 */             int oldw = Op.getInt(Op.RA.RaW.ordinal(), Op.ra);
/*  81 */             int oldh = Op.getInt(Op.RA.RaH.ordinal(), Op.ra);
/*  82 */             Methods.frameResize(RoundaboutsSolve.jfSolveRoundabouts, oldw, oldh, 500, 580);
/*  83 */             Op.setInt(Op.RA.RaW.ordinal(), RoundaboutsSolve.jfSolveRoundabouts.getWidth(), Op.ra);
/*  84 */             Op.setInt(Op.RA.RaH.ordinal(), RoundaboutsSolve.jfSolveRoundabouts.getHeight(), Op.ra);
/*  85 */             RoundaboutsSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  89 */     jfSolveRoundabouts
/*  90 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  92 */             if (Def.selecting)
/*  93 */               return;  Op.saveOptions("roundabouts.opt", Op.ra);
/*  94 */             RoundaboutsSolve.this.restoreIfDone();
/*  95 */             RoundaboutsSolve.saveRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*  96 */             CrosswordExpress.transfer(150, RoundaboutsSolve.jfSolveRoundabouts);
/*     */           }
/*     */         });
/*     */     
/* 100 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 103 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if (Grid.sol[i][j] != (Grid.copy[i][j] & 0xF))
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveRoundabouts);
/*     */       });
/* 111 */     jl1 = new JLabel(); jfSolveRoundabouts.add(jl1);
/* 112 */     jl2 = new JLabel(); jfSolveRoundabouts.add(jl2);
/*     */ 
/*     */     
/* 115 */     menuBar = new JMenuBar();
/* 116 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 117 */     jfSolveRoundabouts.setJMenuBar(menuBar);
/*     */     
/* 119 */     this.menu = new JMenu("File");
/* 120 */     menuBar.add(this.menu);
/* 121 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 122 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 123 */     this.menu.add(this.menuItem);
/* 124 */     this.menuItem
/* 125 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*     */           new Select(jfSolveRoundabouts, "roundabouts", "roundabouts", Op.ra, Op.RA.RaPuz.ordinal(), false);
/*     */         });
/* 133 */     this.menuItem = new JMenuItem("Quit Solving");
/* 134 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 135 */     this.menu.add(this.menuItem);
/* 136 */     this.menuItem
/* 137 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("roundabouts.opt", Op.ra);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(150, jfSolveRoundabouts);
/*     */         });
/* 146 */     this.menu = new JMenu("View");
/* 147 */     menuBar.add(this.menu);
/* 148 */     this.menuItem = new JMenuItem("Display Options");
/* 149 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 150 */     this.menu.add(this.menuItem);
/* 151 */     this.menuItem
/* 152 */       .addActionListener(ae -> {
/*     */           RoundaboutsBuild.printOptions(jfSolveRoundabouts, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 159 */     this.menu = new JMenu("Tasks");
/* 160 */     menuBar.add(this.menu);
/*     */     
/* 162 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 167 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 169 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 170 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 171 */     this.menu.add(this.menuItem);
/* 172 */     this.menuItem
/* 173 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveRoundabouts);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 184 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 185 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 186 */     this.menu.add(this.menuItem);
/* 187 */     this.menuItem
/* 188 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++) {
/*     */                 Grid.sol[i][j] = Grid.copy[i][j];
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveRoundabouts);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 200 */     this.menuItem = new JMenuItem("Begin again");
/* 201 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 202 */     this.menu.add(this.menuItem);
/* 203 */     this.menuItem
/* 204 */       .addActionListener(ae -> {
/*     */           Methods.clearGrid(Grid.sol);
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 211 */     this.menu = new JMenu("Help");
/* 212 */     menuBar.add(this.menu);
/* 213 */     this.menuItem = new JMenuItem("Roundabouts Help");
/* 214 */     this.menu.add(this.menuItem);
/* 215 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 216 */     this.menuItem
/* 217 */       .addActionListener(ae -> Methods.cweHelp(jfSolveRoundabouts, null, "Solving Roundabouts Puzzles", this.roundaboutsSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     loadRoundabouts(Op.ra[Op.RA.RaPuz.ordinal()]);
/* 224 */     pp = new RoundaboutsSolvePP(0, 37);
/* 225 */     jfSolveRoundabouts.add(pp);
/*     */     
/* 227 */     pp
/* 228 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 230 */             RoundaboutsSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 235 */     if (Def.isMac) {
/* 236 */       pp
/* 237 */         .addMouseMotionListener(new MouseAdapter() {
/*     */             public void mouseMoved(MouseEvent e) {
/* 239 */               if (Def.isMac) {
/* 240 */                 RoundaboutsSolve.jfSolveRoundabouts.setResizable((RoundaboutsSolve.jfSolveRoundabouts.getWidth() - e.getX() < Def.insets.right + 15 && RoundaboutsSolve.jfSolveRoundabouts
/* 241 */                     .getHeight() - e.getY() < Def.insets.top + RoundaboutsSolve.menuBar.getHeight() + 52));
/*     */               }
/*     */             }
/*     */           });
/*     */     }
/* 246 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 250 */     jfSolveRoundabouts.setVisible(true);
/* 251 */     panelW = jfSolveRoundabouts.getWidth() - Def.extraW;
/* 252 */     panelH = jfSolveRoundabouts.getHeight() - Def.extraH + menuBar.getHeight();
/* 253 */     pp.setSize(panelW, panelH);
/* 254 */     jfSolveRoundabouts.requestFocusInWindow();
/* 255 */     pp.repaint();
/* 256 */     Methods.infoPanel(jl1, jl2, "Solve Roundabouts", "Puzzle : " + Op.ra[Op.RA.RaPuz.ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 260 */     int i = (width - inset) / Grid.xSz;
/* 261 */     int j = (height - inset) / Grid.ySz;
/* 262 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 263 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/* 264 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveRoundabouts(String roundaboutsName) {
/*     */     try {
/* 270 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("roundabouts/" + roundaboutsName));
/* 271 */       dataOut.writeInt(Grid.xSz);
/* 272 */       dataOut.writeInt(Grid.ySz);
/* 273 */       dataOut.writeByte(Methods.noReveal);
/* 274 */       dataOut.writeByte(Methods.noErrors);
/* 275 */       for (int i = 0; i < 54; i++)
/* 276 */         dataOut.writeByte(0); 
/* 277 */       for (int j = 0; j < Grid.ySz; j++) {
/* 278 */         for (int k = 0; k < Grid.xSz; k++) {
/* 279 */           dataOut.writeInt(Grid.copy[k][j]);
/* 280 */           dataOut.writeInt(Grid.sol[k][j]);
/*     */         } 
/* 282 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 283 */       dataOut.writeUTF(Methods.author);
/* 284 */       dataOut.writeUTF(Methods.copyright);
/* 285 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 286 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 287 */       dataOut.close();
/*     */     }
/* 289 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadRoundabouts(String roundaboutsName) {
/*     */     try {
/* 297 */       File fl = new File("roundabouts/" + roundaboutsName);
/* 298 */       if (!fl.exists()) {
/* 299 */         fl = new File("roundabouts/");
/* 300 */         String[] s = fl.list(); int k;
/* 301 */         for (k = 0; k < s.length && (
/* 302 */           s[k].lastIndexOf(".roundabouts") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 304 */         roundaboutsName = s[k];
/* 305 */         Op.ra[Op.RA.RaPuz.ordinal()] = roundaboutsName;
/*     */       } 
/*     */ 
/*     */       
/* 309 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("roundabouts/" + roundaboutsName));
/* 310 */       Grid.xSz = dataIn.readInt();
/* 311 */       Grid.ySz = dataIn.readInt();
/* 312 */       Methods.noReveal = dataIn.readByte();
/* 313 */       Methods.noErrors = dataIn.readByte(); int i;
/* 314 */       for (i = 0; i < 54; i++)
/* 315 */         dataIn.readByte(); 
/* 316 */       for (int j = 0; j < Grid.ySz; j++) {
/* 317 */         for (i = 0; i < Grid.xSz; i++) {
/* 318 */           Grid.copy[i][j] = dataIn.readInt();
/* 319 */           Grid.sol[i][j] = dataIn.readInt();
/*     */         } 
/* 321 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 322 */       Methods.author = dataIn.readUTF();
/* 323 */       Methods.copyright = dataIn.readUTF();
/* 324 */       Methods.puzzleNumber = dataIn.readUTF();
/* 325 */       Methods.puzzleNotes = dataIn.readUTF();
/* 326 */       dataIn.close();
/*     */     }
/* 328 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawRoundabouts(Graphics2D g2, int[][] puzzleArray) {
/* 336 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 24.0F, 2, 2);
/* 337 */     g2.setStroke(normalStroke);
/*     */     
/* 339 */     RenderingHints rh = g2.getRenderingHints();
/* 340 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 341 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 342 */     g2.setRenderingHints(rh);
/*     */     
/*     */     int j;
/* 345 */     for (j = 0; j < Grid.ySz; j++) {
/* 346 */       for (int i = 0; i < Grid.xSz; i++) {
/* 347 */         g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaCell.ordinal(), Op.ra) : 16777215));
/* 348 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/* 349 */         g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaGrid.ordinal(), Op.ra) : 0));
/*     */       } 
/*     */     } 
/*     */     
/* 353 */     for (j = 0; j < Grid.ySz + 1; j++)
/* 354 */       g2.drawLine(Grid.xOrg, Grid.yOrg + j * Grid.yCell, Grid.xOrg + Grid.xSz * Grid.xCell, Grid.yOrg + j * Grid.yCell); 
/* 355 */     for (j = 0; j < Grid.xSz + 1; j++) {
/* 356 */       g2.drawLine(Grid.xOrg + j * Grid.xCell, Grid.yOrg, Grid.xOrg + j * Grid.xCell, Grid.yOrg + Grid.xSz * Grid.yCell);
/*     */     }
/*     */     
/* 359 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaCircle.ordinal(), Op.ra) : 16777215));
/* 360 */     for (j = 0; j < Grid.ySz; j++) {
/* 361 */       for (int i = 0; i < Grid.xSz; i++) {
/* 362 */         if ((Grid.copy[i][j] & 0x10) > 0) {
/* 363 */           g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaCircle.ordinal(), Op.ra) : 16777215));
/* 364 */           g2.fillArc(Grid.xOrg + i * Grid.xCell + Grid.xCell / 4, Grid.yOrg + j * Grid.yCell + Grid.xCell / 4, Grid.xCell / 2, Grid.xCell / 2, 0, 360);
/* 365 */           g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.RA.RaGrid.ordinal(), Op.ra) : 0));
/* 366 */           g2.drawArc(Grid.xOrg + i * Grid.xCell + Grid.xCell / 4, Grid.yOrg + j * Grid.yCell + Grid.xCell / 4, Grid.xCell / 2, Grid.xCell / 2, 0, 360);
/*     */         } 
/*     */       } 
/*     */     } 
/* 370 */     for (j = 0; j < Grid.ySz; j++) {
/* 371 */       for (int i = 0; i < Grid.xSz; i++) {
/* 372 */         int xc = Grid.xOrg + i * Grid.xCell + Grid.xCell / 2;
/* 373 */         int yc = Grid.yOrg + j * Grid.yCell + Grid.yCell / 2;
/* 374 */         if ((Grid.sol[i][j] & 0x1) > 0) {
/* 375 */           if (Def.dispWithColor.booleanValue())
/* 376 */           { if (Def.dispErrors.booleanValue() && (Grid.copy[i][j] & 0x1) == 0) {
/* 377 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaError.ordinal(), Op.ra)));
/*     */             } else {
/*     */               
/* 380 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaPath.ordinal(), Op.ra)));
/*     */             }  }
/* 382 */           else { g2.setColor(Def.COLOR_BLACK); }
/* 383 */            g2.drawLine(xc, yc, xc + Grid.xCell, yc);
/*     */         } 
/* 385 */         if ((Grid.sol[i][j] & 0x2) > 0) {
/* 386 */           if (Def.dispWithColor.booleanValue())
/* 387 */           { if (Def.dispErrors.booleanValue() && (Grid.copy[i][j] & 0x2) == 0) {
/* 388 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaError.ordinal(), Op.ra)));
/*     */             } else {
/*     */               
/* 391 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaPath.ordinal(), Op.ra)));
/*     */             }  }
/* 393 */           else { g2.setColor(Def.COLOR_BLACK); }
/* 394 */            g2.drawLine(xc, yc, xc, yc + Grid.yCell);
/*     */         } 
/* 396 */         if ((Grid.sol[i][j] & 0x4) > 0) {
/* 397 */           if (Def.dispWithColor.booleanValue())
/* 398 */           { if (Def.dispErrors.booleanValue() && (Grid.copy[i][j] & 0x4) == 0) {
/* 399 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaError.ordinal(), Op.ra)));
/*     */             } else {
/*     */               
/* 402 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaPath.ordinal(), Op.ra)));
/*     */             }  }
/* 404 */           else { g2.setColor(Def.COLOR_BLACK); }
/* 405 */            g2.drawLine(xc, yc, xc - Grid.xCell, yc);
/*     */         } 
/* 407 */         if ((Grid.sol[i][j] & 0x8) > 0) {
/* 408 */           if (Def.dispWithColor.booleanValue())
/* 409 */           { if (Def.dispErrors.booleanValue() && (Grid.copy[i][j] & 0x8) == 0) {
/* 410 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaError.ordinal(), Op.ra)));
/*     */             } else {
/*     */               
/* 413 */               g2.setColor(new Color(Op.getColorInt(Op.RA.RaPath.ordinal(), Op.ra)));
/*     */             }  }
/* 415 */           else { g2.setColor(Def.COLOR_BLACK); }
/* 416 */            g2.drawLine(xc, yc, xc, yc - Grid.yCell);
/*     */         } 
/*     */       } 
/*     */     } 
/* 420 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */ 
/*     */   
/*     */   void restoreIfDone() {
/* 425 */     for (int j = 0; j < Grid.ySz - 1; j++) {
/* 426 */       for (int i = 0; i < Grid.xSz - 1; i++)
/* 427 */       { if (Grid.sol[i][j] != (Grid.copy[i][j] & 0xF))
/*     */           return;  } 
/* 429 */     }  Methods.clearGrid(Grid.sol);
/*     */   }
/*     */   
/*     */   void updateGrid(MouseEvent e) {
/* 433 */     int mouseX = e.getX(), mouseY = e.getY();
/*     */ 
/*     */ 
/*     */     
/* 437 */     if (mouseX < Grid.xOrg) mouseX = Grid.xOrg + 1; 
/* 438 */     if (mouseY < Grid.yOrg) mouseY = Grid.yOrg + 1; 
/* 439 */     int x = Grid.xOrg + Grid.xSz * Grid.xCell; if (mouseX >= x) mouseX = x - 1; 
/* 440 */     int y = Grid.yOrg + Grid.ySz * Grid.yCell; if (mouseY >= y) mouseY = y - 1; 
/* 441 */     x = (mouseX - Grid.xOrg) / Grid.xCell;
/* 442 */     y = (mouseY - Grid.yOrg) / Grid.yCell;
/* 443 */     int xl = (mouseX - Grid.xOrg) % Grid.xCell;
/* 444 */     int yl = (mouseY - Grid.yOrg) % Grid.yCell;
/* 445 */     boolean tl = (xl + yl < Grid.xCell);
/* 446 */     boolean tr = (xl > yl);
/* 447 */     int dir = tl ? (tr ? 8 : 4) : (tr ? 1 : 2);
/* 448 */     switch (dir) {
/*     */       case 1:
/* 450 */         if (x == Grid.xSz - 1)
/* 451 */           break;  Grid.sol[x][y] = Grid.sol[x][y] ^ 0x1;
/* 452 */         Grid.sol[x + 1][y] = Grid.sol[x + 1][y] ^ 0x4;
/*     */         break;
/*     */       case 2:
/* 455 */         if (y == Grid.ySz - 1)
/* 456 */           break;  Grid.sol[x][y] = Grid.sol[x][y] ^ 0x2;
/* 457 */         Grid.sol[x][y + 1] = Grid.sol[x][y + 1] ^ 0x8;
/*     */         break;
/*     */       case 4:
/* 460 */         if (x == 0)
/* 461 */           break;  Grid.sol[x][y] = Grid.sol[x][y] ^ 0x4;
/* 462 */         Grid.sol[x - 1][y] = Grid.sol[x - 1][y] ^ 0x1;
/*     */         break;
/*     */       case 8:
/* 465 */         if (y == 0)
/* 466 */           break;  Grid.sol[x][y] = Grid.sol[x][y] ^ 0x8;
/* 467 */         Grid.sol[x][y - 1] = Grid.sol[x][y - 1] ^ 0x2;
/*     */         break;
/*     */     } 
/* 470 */     (new Thread(this.solveThread)).start();
/* 471 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\RoundaboutsSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */