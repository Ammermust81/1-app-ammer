/*     */ package crosswordexpress;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class Select extends JPanel {
/*     */   static JDialog jdlgSelect;
/*     */   static JPanel pp;
/*     */   DefaultListModel<String> lmPuz;
/*     */   final JList<String> jlPuz;
/*     */   
/*     */   Select(final JFrame jfCWE, String folder, String ext, final String[] op, final int indx, final boolean selSol) {
/*  21 */     Def.selecting = true;
/*  22 */     Def.dispCursor = Boolean.valueOf(false);
/*  23 */     Def.dispGuideDigits = Boolean.valueOf(false);
/*  24 */     jfCWE.setEnabled(false);
/*  25 */     this.inFolder = System.getProperty("user.dir") + "/" + folder;
/*  26 */     this.selPuz = op[indx];
/*     */     
/*  28 */     jdlgSelect = new JDialog(jfCWE);
/*  29 */     Insets insets = jfCWE.getInsets();
/*  30 */     jdlgSelect.setSize(615 + insets.left + insets.right, 498 + insets.top + insets.bottom);
/*  31 */     jdlgSelect.setLocation(jfCWE.getX(), jfCWE.getY());
/*  32 */     jdlgSelect.setLayout((LayoutManager)null);
/*  33 */     jdlgSelect.setDefaultCloseOperation(0);
/*  34 */     jdlgSelect.toFront();
/*  35 */     jdlgSelect.setVisible(true);
/*  36 */     jdlgSelect.setResizable(false);
/*     */     
/*  38 */     jdlgSelect
/*  39 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  41 */             if (Def.building == 1)
/*  42 */               return;  Def.selecting = false;
/*  43 */             jfCWE.setEnabled(true);
/*  44 */             if (!selSol) Select.restorePuzFrame(); 
/*  45 */             Select.jdlgSelect.dispose();
/*  46 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/*  50 */     Methods.closeHelp();
/*     */     
/*  52 */     this.lmPuz = new DefaultListModel<>();
/*  53 */     this.jlPuz = new JList<>(this.lmPuz);
/*  54 */     this.jlPuz.setFont(new Font("SansSerif", 1, 14));
/*  55 */     this.jspPuz = new JScrollPane(this.jlPuz);
/*  56 */     this.jspPuz.setSize(170, 486);
/*  57 */     this.jspPuz.setLocation(5, 5);
/*  58 */     this.jspPuz.setBorder(BorderFactory.createLineBorder(Def.COLOR_SELECTFRAME, 2));
/*  59 */     this.jspPuz.setHorizontalScrollBarPolicy(31);
/*  60 */     jdlgSelect.add(this.jspPuz);
/*     */     
/*  62 */     File fl = new File(this.inFolder);
/*  63 */     String[] s = fl.list();
/*  64 */     for (this.i = 0; this.i < s.length; this.i++) {
/*  65 */       if (s[this.i].contains(ext) && !s[this.i].startsWith("."))
/*  66 */         this.lmPuz.addElement(" " + s[this.i]); 
/*  67 */     }  this.jlPuz.setSelectedValue(" " + op[indx], true);
/*     */     
/*  69 */     this.jlPuz
/*  70 */       .addListSelectionListener(le -> {
/*     */           if (!this.jlPuz.getValueIsAdjusting()) {
/*     */             this.selPuz = ((String)this.jlPuz.getSelectedValue()).trim();
/*     */             
/*     */             loadPuz(this.selPuz);
/*     */             
/*     */             pp.repaint();
/*     */             this.jlPuz.requestFocus();
/*     */           } 
/*     */         });
/*  80 */     JLabel jl = new JLabel("<html><font size=5>Preview");
/*  81 */     jl.setForeground(Def.COLOR_LABEL);
/*  82 */     jl.setSize(425, 20);
/*  83 */     jl.setLocation(175, 5);
/*  84 */     jl.setHorizontalAlignment(0);
/*  85 */     jdlgSelect.add(jl);
/*     */     
/*  87 */     Action doOK = new AbstractAction("Select this Puzzle") {
/*     */         public void actionPerformed(ActionEvent e) {
/*  89 */           if (selSol) Select.loadPuz(op[indx]); 
/*  90 */           op[indx] = Select.this.selPuz;
/*  91 */           jfCWE.setEnabled(true);
/*  92 */           if (!selSol) Select.restorePuzFrame(); 
/*  93 */           Def.dispCursor = Boolean.valueOf(true);
/*  94 */           Def.dispGuideDigits = Boolean.valueOf(true);
/*  95 */           Select.jdlgSelect.dispose();
/*  96 */           Def.selecting = false;
/*     */         }
/*     */       };
/*  99 */     JButton jbOK = Methods.newButton("doOK", doOK, 83, 180, 465, 197, 26);
/* 100 */     jdlgSelect.add(jbOK);
/*     */     
/* 102 */     Action doCancel = new AbstractAction("Cancel") {
/*     */         public void actionPerformed(ActionEvent e) {
/* 104 */           Select.loadPuz(op[indx]);
/* 105 */           Def.selecting = false;
/* 106 */           jfCWE.setEnabled(true);
/* 107 */           Def.dispCursor = Boolean.valueOf(true);
/* 108 */           if (!selSol) Select.restorePuzFrame(); 
/* 109 */           Select.jdlgSelect.dispose();
/*     */         }
/*     */       };
/* 112 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 388, 465, 107, 26);
/* 113 */     jdlgSelect.add(jbCancel);
/*     */     
/* 115 */     pp = new SelectPP();
/* 116 */     jdlgSelect.add(pp);
/* 117 */     pp.repaint();
/* 118 */     this.jlPuz.requestFocus();
/*     */   }
/*     */   JScrollPane jspPuz; final String inFolder; String selPuz; int i;
/*     */   static void restorePuzFrame() {
/* 122 */     switch (Def.puzzleMode) { case 10:
/* 123 */         AcrosticBuild.restoreFrame(); break;
/* 124 */       case 11: AcrosticSolve.restoreFrame(); break;
/* 125 */       case 20: AkariBuild.restoreFrame(); break;
/* 126 */       case 21: AkariSolve.restoreFrame(""); break;
/* 127 */       case 30: CodewordSolve.restoreFrame(); break;
/*     */       case 4: case 7:
/*     */       case 12:
/* 130 */         CrosswordBuild.restoreFrame(); break;
/* 131 */       case 220: DevanagariBuild.restoreFrame(); break;
/* 132 */       case 5: CrosswordSolve.loadSolvePuzzle(); break;
/* 133 */       case 210: WordsquareBuild.restoreFrame(); break;
/* 134 */       case 40: DominoBuild.restoreFrame(); break;
/* 135 */       case 41: DominoSolve.restoreFrame(); break;
/* 136 */       case 50: DoubletBuild.restoreFrame(); break;
/* 137 */       case 51: DoubletSolve.restoreFrame(); break;
/* 138 */       case 13: FreeformBuild.restoreFrame(1); break;
/* 139 */       case 60: FillinSolve.restoreFrame(); break;
/* 140 */       case 70: FillominoBuild.restoreFrame(); break;
/* 141 */       case 71: FillominoSolve.restoreFrame(); break;
/* 142 */       case 72: FindAQuote.restoreFrame(); break;
/* 143 */       case 6: FreeformBuild.restoreFrame(1); break;
/* 144 */       case 80: FutoshikiBuild.restoreFrame(); break;
/* 145 */       case 81: FutoshikiSolve.restoreFrame(); break;
/* 146 */       case 90: GokigenBuild.restoreFrame(); break;
/* 147 */       case 91: GokigenSolve.restoreFrame(""); break;
/* 148 */       case 100: KakuroBuild.restoreFrame(); break;
/* 149 */       case 101: KakuroSolve.restoreFrame(); break;
/* 150 */       case 110: KendokuBuild.restoreFrame(); break;
/* 151 */       case 111: KendokuSolve.restoreFrame(); break;
/* 152 */       case 112: KsudokuBuild.restoreFrame(); break;
/* 153 */       case 113: KsudokuSolve.restoreFrame(""); break;
/* 154 */       case 120: LadderwordBuild.restoreFrame(); break;
/* 155 */       case 121: LadderwordSolve.restoreFrame(); break;
/* 156 */       case 130: LetterdropBuild.restoreFrame(); break;
/* 157 */       case 131: LetterdropSolve.restoreFrame(); break;
/* 158 */       case 230: MarupekeBuild.restoreFrame(); break;
/* 159 */       case 231: MarupekeSolve.restoreFrame(); break;
/* 160 */       case 132: MinesweeperBuild.restoreFrame(); break;
/* 161 */       case 133: MinesweeperSolve.restoreFrame(""); break;
/* 162 */       case 134: OuroborosBuild.restoreFrame(); break;
/* 163 */       case 135: OuroborosSolve.restoreFrame(); break;
/* 164 */       case 140: PyramidwordBuild.restoreFrame(); break;
/* 165 */       case 150: RoundaboutsBuild.restoreFrame(); break;
/* 166 */       case 151: RoundaboutsSolve.restoreFrame(); break;
/* 167 */       case 160: SikakuBuild.restoreFrame(); break;
/* 168 */       case 161: SikakuSolve.restoreFrame(); break;
/* 169 */       case 170: SlitherlinkBuild.restoreFrame(); break;
/* 170 */       case 171: SlitherlinkSolve.restoreFrame(); break;
/* 171 */       case 180: SudokuBuild.restoreFrame(); break;
/* 172 */       case 181: SudokuSolve.restoreFrame(""); break;
/* 173 */       case 182: TatamiBuild.restoreFrame(); break;
/* 174 */       case 183: TatamiSolve.restoreFrame(); break;
/* 175 */       case 190: TentsBuild.restoreFrame(); break;
/* 176 */       case 191: TentsSolve.restoreFrame(); break;
/* 177 */       case 141: PyramidwordSolve.restoreFrame(); break;
/* 178 */       case 200: WordsearchBuild.restoreFrame(); break;
/* 179 */       case 201: WordsearchSolve.restoreFrame(); break;
/* 180 */       case 202: WordsearchBuild.restoreFrame();
/*     */         break; }
/*     */   
/*     */   }
/*     */   static void drawPuz(Graphics g) {
/* 185 */     switch (Def.puzzleMode) { case 10:
/* 186 */         AcrosticBuild.drawAcrosticParagraph((Graphics2D)g); break;
/* 187 */       case 11: AcrosticSolve.drawAcrosticParagraph((Graphics2D)g); break;
/* 188 */       case 20: AkariBuild.drawAkari((Graphics2D)g, Grid.puzzle); break;
/* 189 */       case 21: AkariSolve.drawAkari((Graphics2D)g, Grid.puzzle); break;
/* 190 */       case 30: CrosswordBuild.drawCrossword((Graphics2D)g); break;
/*     */       case 4: case 7:
/*     */       case 12:
/* 193 */         CrosswordBuild.drawCrossword((Graphics2D)g); break;
/* 194 */       case 220: DevanagariBuild.drawDevanagari((Graphics2D)g, "l"); break;
/* 195 */       case 5: CrosswordSolve.drawCrossword((Graphics2D)g); break;
/* 196 */       case 210: WordsquareBuild.drawWordsquare((Graphics2D)g, ""); break;
/* 197 */       case 40: DominoBuild.drawDomino((Graphics2D)g, Grid.letter); break;
/* 198 */       case 41: DominoSolve.drawDomino((Graphics2D)g, Grid.letter); break;
/* 199 */       case 50: DoubletBuild.drawDoublet((Graphics2D)g); break;
/* 200 */       case 51: DoubletSolve.drawDoublet((Graphics2D)g); break;
/*     */       case 13: case 60:
/* 202 */         CrosswordSolve.drawCrossword((Graphics2D)g); break;
/* 203 */       case 70: FillominoBuild.drawFillomino((Graphics2D)g, Grid.copy); break;
/* 204 */       case 71: FillominoSolve.drawFillomino((Graphics2D)g, Grid.sol); break;
/* 205 */       case 72: FindAQuote.drawFindAQuote((Graphics2D)g); break;
/* 206 */       case 6: FreeformBuild.drawCrossword((Graphics2D)g); break;
/* 207 */       case 80: FutoshikiBuild.drawFutoshiki((Graphics2D)g, Grid.sol); break;
/* 208 */       case 81: FutoshikiSolve.drawFutoshiki((Graphics2D)g, Grid.sol); break;
/* 209 */       case 90: GokigenBuild.drawGokigen((Graphics2D)g, Grid.copy); break;
/* 210 */       case 91: GokigenSolve.drawGokigen((Graphics2D)g, Grid.sol); break;
/* 211 */       case 100: KakuroBuild.drawKakuro((Graphics2D)g, Grid.letter); break;
/* 212 */       case 101: KakuroSolve.drawKakuro((Graphics2D)g, Grid.sol); break;
/* 213 */       case 110: KendokuBuild.drawKendoku((Graphics2D)g, Grid.letter); break;
/* 214 */       case 111: KendokuSolve.drawKendoku((Graphics2D)g, Grid.sol); break;
/* 215 */       case 112: KsudokuBuild.drawKsudoku((Graphics2D)g, "BS"); break;
/* 216 */       case 113: KsudokuBuild.drawKsudoku((Graphics2D)g, "G"); break;
/* 217 */       case 120: LadderwordBuild.drawLadderword((Graphics2D)g); break;
/* 218 */       case 121: LadderwordSolve.drawLadderword((Graphics2D)g); break;
/* 219 */       case 130: LetterdropBuild.drawLetterdrop((Graphics2D)g); break;
/* 220 */       case 131: LetterdropSolve.drawLetterdrop((Graphics2D)g); break;
/* 221 */       case 230: MarupekeBuild.drawMarupeke((Graphics2D)g, Grid.puz); break;
/* 222 */       case 231: MarupekeBuild.drawMarupeke((Graphics2D)g, Grid.puz); break;
/* 223 */       case 132: MinesweeperBuild.drawMinesweeper((Graphics2D)g, Grid.letter); break;
/* 224 */       case 133: MinesweeperSolve.drawMinesweeper((Graphics2D)g, Grid.letter); break;
/* 225 */       case 134: OuroborosBuild.drawOuroboros((Graphics2D)g, 1); break;
/* 226 */       case 135: OuroborosBuild.drawOuroboros((Graphics2D)g, 1); break;
/* 227 */       case 140: PyramidwordBuild.drawPyramidword((Graphics2D)g); break;
/* 228 */       case 141: PyramidwordSolve.drawPyramidword((Graphics2D)g); break;
/* 229 */       case 150: RoundaboutsBuild.drawRoundabouts((Graphics2D)g, Grid.sol); break;
/* 230 */       case 151: RoundaboutsSolve.drawRoundabouts((Graphics2D)g, Grid.sol); break;
/* 231 */       case 160: SikakuBuild.drawSikaku((Graphics2D)g, Grid.letter); break;
/* 232 */       case 161: SikakuSolve.drawSikaku((Graphics2D)g, Grid.letter); break;
/* 233 */       case 170: SlitherlinkBuild.drawSlitherlink((Graphics2D)g, Grid.letter); break;
/* 234 */       case 171: SlitherlinkSolve.drawSlitherlink((Graphics2D)g, Grid.letter); break;
/* 235 */       case 180: SudokuBuild.drawSudoku((Graphics2D)g, "P"); break;
/* 236 */       case 181: SudokuBuild.drawSudoku((Graphics2D)g, "G"); break;
/* 237 */       case 182: TatamiBuild.drawTatami((Graphics2D)g, Grid.letter); break;
/* 238 */       case 183: TatamiSolve.drawTatami((Graphics2D)g, Grid.sol); break;
/* 239 */       case 190: TentsBuild.drawTents((Graphics2D)g, Grid.copy); break;
/* 240 */       case 191: TentsSolve.drawTents((Graphics2D)g, Grid.copy); break;
/* 241 */       case 200: WordsearchBuild.drawWordsearch((Graphics2D)g); break;
/* 242 */       case 201: WordsearchSolve.drawWordsearch((Graphics2D)g); break;
/* 243 */       case 202: WordsearchBuild.drawWordsearch((Graphics2D)g);
/*     */         break; }
/*     */   
/*     */   }
/*     */   static void loadPuz(String puz) {
/* 248 */     switch (Def.puzzleMode) { case 10:
/* 249 */         AcrosticBuild.loadAcrostic(puz); break;
/* 250 */       case 11: AcrosticSolve.loadAcrostic(puz); break;
/* 251 */       case 20: AkariBuild.loadAkari(puz); break;
/* 252 */       case 21: AkariSolve.loadAkari(puz); break;
/* 253 */       case 30: CodewordSolve.loadCodeword(Op.cw[Op.CW.CwDic.ordinal()], puz); break;
/*     */       case 4: case 7:
/*     */       case 12:
/* 256 */         CrosswordBuild.loadCrossword(puz); break;
/* 257 */       case 220: DevanagariBuild.loadDevanagari(puz); break;
/* 258 */       case 5: CrosswordSolve.loadCrossword(puz); break;
/* 259 */       case 210: WordsquareBuild.loadWordsquare(puz); break;
/* 260 */       case 40: DominoBuild.loadDomino(puz); break;
/* 261 */       case 41: DominoSolve.loadDomino(puz); break;
/* 262 */       case 50: DoubletBuild.loadDoublet(puz); break;
/* 263 */       case 51: DoubletSolve.loadDoublet(puz); break;
/* 264 */       case 60: FillinSolve.loadFillin(Op.fl[Op.FL.FlDic.ordinal()], puz); FillinSolve.updateWordList(); break;
/* 265 */       case 70: FillominoBuild.loadFillomino(puz); break;
/* 266 */       case 71: FillominoSolve.loadFillomino(puz); break;
/* 267 */       case 72: FindAQuote.loadFindAQuote(puz); break;
/*     */       case 6: case 13:
/* 269 */         FreeformBuild.loadCrossword(puz); break;
/* 270 */       case 80: FutoshikiBuild.loadFutoshiki(puz); break;
/* 271 */       case 81: FutoshikiSolve.loadFutoshiki(puz); break;
/* 272 */       case 90: GokigenBuild.loadGokigen(puz); break;
/* 273 */       case 91: GokigenSolve.loadGokigen(puz); break;
/* 274 */       case 100: KakuroBuild.loadKakuro(puz); break;
/* 275 */       case 101: KakuroSolve.loadKakuro(puz); break;
/* 276 */       case 110: KendokuBuild.loadKendoku(puz); break;
/* 277 */       case 111: KendokuSolve.loadKendoku(puz); break;
/* 278 */       case 112: KsudokuBuild.loadKsudoku(puz); KsudokuBuild.buildVirtualCages(); break;
/* 279 */       case 113: KsudokuBuild.loadKsudoku(puz); KsudokuBuild.buildVirtualCages(); break;
/* 280 */       case 120: LadderwordBuild.loadLadderword(puz); break;
/* 281 */       case 121: LadderwordSolve.loadLadderword(puz); break;
/* 282 */       case 130: LetterdropBuild.loadLetterdrop(puz); break;
/* 283 */       case 131: LetterdropSolve.loadLetterdrop(puz); break;
/* 284 */       case 230: MarupekeBuild.loadMarupeke(puz); break;
/* 285 */       case 231: MarupekeBuild.loadMarupeke(puz); break;
/* 286 */       case 132: MinesweeperBuild.loadMinesweeper(puz); break;
/* 287 */       case 133: MinesweeperSolve.loadMinesweeper(puz); break;
/* 288 */       case 134: OuroborosBuild.loadOuroboros(puz); break;
/* 289 */       case 135: OuroborosBuild.loadOuroboros(puz); break;
/* 290 */       case 140: PyramidwordBuild.loadPyramidword(puz); break;
/* 291 */       case 141: PyramidwordSolve.loadPyramidword(puz); break;
/* 292 */       case 150: RoundaboutsBuild.loadRoundabouts(puz); break;
/* 293 */       case 151: RoundaboutsSolve.loadRoundabouts(puz); break;
/* 294 */       case 160: SikakuBuild.loadSikaku(puz); break;
/* 295 */       case 161: SikakuSolve.loadSikaku(puz); break;
/* 296 */       case 170: SlitherlinkBuild.loadSlitherlink(puz); break;
/* 297 */       case 171: SlitherlinkSolve.loadSlitherlink(puz); break;
/* 298 */       case 180: SudokuBuild.loadSudoku(puz); break;
/* 299 */       case 181: SudokuSolve.loadSudoku(puz); SudokuSolve.recalculateStatus(); break;
/* 300 */       case 182: TatamiBuild.loadTatami(puz); break;
/* 301 */       case 183: TatamiSolve.loadTatami(puz); break;
/* 302 */       case 190: TentsBuild.loadTents(puz); break;
/* 303 */       case 191: TentsSolve.loadTents(puz); break;
/* 304 */       case 200: WordsearchBuild.loadWordsearch(puz); break;
/* 305 */       case 201: WordsearchSolve.loadWordsearch(puz); break;
/* 306 */       case 202: WordsearchBuild.loadWordsearch(puz);
/*     */         break; }
/*     */   
/*     */   }
/*     */   static void setSizesAndOffsets() {
/* 311 */     int w = 430, h = 430;
/* 312 */     switch (Def.puzzleMode) { case 10:
/* 313 */         AcrosticBuild.adjustParagraph(0, 0, w, h, 10); break;
/* 314 */       case 11: AcrosticSolve.adjustParagraph(0, 0, w, h, 10); break;
/* 315 */       case 20: AkariBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 316 */       case 21: AkariSolve.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 317 */       case 30: CodewordSolve.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/*     */       case 4: case 7:
/*     */       case 12:
/* 320 */         CrosswordBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 321 */       case 220: DevanagariBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 322 */       case 5: CrosswordSolve.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 323 */       case 210: WordsquareBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 324 */       case 40: DominoBuild.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 325 */       case 41: DominoSolve.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 326 */       case 50: DoubletBuild.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 327 */       case 51: DoubletSolve.setSizesAndOffsets(0, 0, w, h, 10); break;
/*     */       case 60: case 61:
/* 329 */         FillinSolve.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 330 */       case 70: FillominoBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 331 */       case 71: FillominoSolve.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 332 */       case 72: FindAQuote.setSizesAndOffsets(0, 0, w, h, 10); break;
/*     */       case 6: case 13:
/* 334 */         FreeformBuild.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 335 */       case 80: FutoshikiBuild.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 336 */       case 81: FutoshikiSolve.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 337 */       case 90: GokigenBuild.setSizesAndOffsets(0, 0, w, h); break;
/* 338 */       case 91: GokigenSolve.setSizesAndOffsets(0, 0, w, h); break;
/* 339 */       case 100: KakuroBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 340 */       case 101: KakuroSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 341 */       case 110: KendokuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 342 */       case 111: KendokuSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 343 */       case 112: KsudokuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 344 */       case 113: KsudokuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 345 */       case 120: LadderwordBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 346 */       case 121: LadderwordSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 347 */       case 130: LetterdropBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 348 */       case 131: LetterdropSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 349 */       case 230: MarupekeBuild.setSizesAndOffsets(0, 0, w, h, 10); break;
/* 350 */       case 231: MarupekeSolve.setSizesAndOffsets(0, 0, w, h, 10, true); break;
/* 351 */       case 132: MinesweeperBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 352 */       case 133: MinesweeperSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 353 */       case 134: OuroborosBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 354 */       case 135: OuroborosBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 355 */       case 140: PyramidwordBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 356 */       case 141: PyramidwordSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 357 */       case 150: RoundaboutsBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 358 */       case 151: RoundaboutsSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 359 */       case 160: SikakuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 360 */       case 161: SikakuSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 361 */       case 170: SlitherlinkBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 362 */       case 171: SlitherlinkSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 363 */       case 180: SudokuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 364 */       case 181: SudokuBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 365 */       case 182: TatamiBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 366 */       case 183: TatamiSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 367 */       case 190: TentsBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 368 */       case 191: TentsSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 369 */       case 200: WordsearchBuild.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 370 */       case 201: WordsearchSolve.setSizesAndOffsets(0, 0, w, h, 20); break;
/* 371 */       case 202: WordsearchBuild.setSizesAndOffsets(0, 0, w, h, 20);
/*     */         break; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Select.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */