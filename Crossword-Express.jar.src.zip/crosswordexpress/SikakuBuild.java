/*      */ package crosswordexpress;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.util.Random;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class SikakuBuild extends JPanel {
/*      */   static JFrame jfSikaku;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   23 */   int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); int hmCount; boolean adjustmentsMade;
/*      */   boolean sixpack;
/*   25 */   static String rules = "Cover the entire area of the puzzle with squares or rectangles so that each square or rectangle contains just one of the numbers and has an area equal to that number. This puzzle has a single unique solution.";
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*   30 */     Op.updateOption(Op.SK.SkW.ordinal(), "500", Op.sk);
/*   31 */     Op.updateOption(Op.SK.SkH.ordinal(), "580", Op.sk);
/*   32 */     Op.updateOption(Op.SK.SkAcross.ordinal(), "13", Op.sk);
/*   33 */     Op.updateOption(Op.SK.SkDown.ordinal(), "13", Op.sk);
/*   34 */     Op.updateOption(Op.SK.SkCell.ordinal(), "DDFFDD", Op.sk);
/*   35 */     Op.updateOption(Op.SK.SkGrid.ordinal(), "AAAAAA", Op.sk);
/*   36 */     Op.updateOption(Op.SK.SkBorder.ordinal(), "000099", Op.sk);
/*   37 */     Op.updateOption(Op.SK.SkNumber.ordinal(), "CC0033", Op.sk);
/*   38 */     Op.updateOption(Op.SK.SkError.ordinal(), "FF0000", Op.sk);
/*   39 */     Op.updateOption(Op.SK.SkPuz.ordinal(), "sample.sikaku", Op.sk);
/*   40 */     Op.updateOption(Op.SK.SkNumberFont.ordinal(), "SansSerif", Op.sk);
/*   41 */     Op.updateOption(Op.SK.SkPuzColor.ordinal(), "false", Op.sk);
/*   42 */     Op.updateOption(Op.SK.SkSolColor.ordinal(), "false", Op.sk);
/*      */   }
/*      */   
/*   45 */   String sikakuHelp = "<div>A SIKAKU puzzle consists of a square or rectangular grid in which some of the cells contain a one or two digit number. To complete the puzzle, a Solver must divide the puzzle into a number of rectangles so that each rectangle contains exactly one of the numbers, and that number must be equal to the area of the rectangle which contains it. Each puzzle has a unique solution which does no require any guesswork to achieve. The Crossword Express SIKAKU construction function allows you to build puzzles either manually or automatically in sizes from 5x5 up to 20x20.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of SIKAKU puzzles currently available on your computer.<p/><li/><span>Save</span><br/>If you have done some manual editing of the puzzle, this option will save those changes under the existing file name.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>sikaku</b> folder along with all of the Sikaku puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b><p/><li/><span>Test Puzzle Validity</span><br/>Manual construction of a SIKAKU puzzle is not recommended. You should only attempt this if you have a valid puzzle (possibly one published i a magazine) which you would like to enter into the program. Simply move the cursor cell around the puzzle, and type the required values into the appropriate cells. Selecting the <b>Test Puzzle Validity</b> option will check the validity of the puzzle. If it has a unique solution, it will be saved, and you will be advised of this. If not, you will receive a message that the puzzle is not valid.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Print a Sikaku KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted SIKAKU puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Sikaku Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></build>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   String sikakuOptions = "<div>Before you give the command to build the <b>Sikaku</b> puzzle, you can set some options which the program will use during the construction process.</div><br/><ul><li/>Sikaku puzzles can be made in sizes ranging from 5x5 up to 20x20. This can be controlled using the <b>Puzzle Size</b> Combo-box.<p/><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> checkbox will disable it.</ul></build>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SikakuBuild(JFrame jf, boolean auto, int hm, int start) {
/*  139 */     Def.puzzleMode = 160;
/*  140 */     Def.building = 0;
/*  141 */     Def.dispCursor = Boolean.valueOf(true);
/*  142 */     makeGrid();
/*      */     
/*  144 */     jfSikaku = new JFrame("Sikaku");
/*  145 */     if (Op.getInt(Op.SK.SkH.ordinal(), Op.sk) > Methods.scrH - 200) {
/*  146 */       int diff = Op.getInt(Op.SK.SkH.ordinal(), Op.sk) - Op.getInt(Op.SK.SkW.ordinal(), Op.sk);
/*  147 */       Op.setInt(Op.SK.SkH.ordinal(), Methods.scrH - 200, Op.sk);
/*  148 */       Op.setInt(Op.SK.SkW.ordinal(), Methods.scrH - 200 + diff, Op.sk);
/*      */     } 
/*  150 */     jfSikaku.setSize(Op.getInt(Op.SK.SkW.ordinal(), Op.sk), Op.getInt(Op.SK.SkH.ordinal(), Op.sk));
/*  151 */     int frameX = (jf.getX() + jfSikaku.getWidth() > Methods.scrW) ? (Methods.scrW - jfSikaku.getWidth() - 10) : jf.getX();
/*  152 */     jfSikaku.setLocation(frameX, jf.getY());
/*  153 */     jfSikaku.setLayout((LayoutManager)null);
/*  154 */     jfSikaku.setDefaultCloseOperation(0);
/*  155 */     jfSikaku
/*  156 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  158 */             int oldw = Op.getInt(Op.SK.SkW.ordinal(), Op.sk);
/*  159 */             int oldh = Op.getInt(Op.SK.SkH.ordinal(), Op.sk);
/*  160 */             Methods.frameResize(SikakuBuild.jfSikaku, oldw, oldh, 500, 580);
/*  161 */             Op.setInt(Op.SK.SkW.ordinal(), SikakuBuild.jfSikaku.getWidth(), Op.sk);
/*  162 */             Op.setInt(Op.SK.SkH.ordinal(), SikakuBuild.jfSikaku.getHeight(), Op.sk);
/*  163 */             SikakuBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  167 */     jfSikaku
/*  168 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  170 */             if (Def.building == 1 || Def.selecting)
/*  171 */               return;  Op.saveOptions("sikaku.opt", Op.sk);
/*  172 */             CrosswordExpress.transfer(1, SikakuBuild.jfSikaku);
/*      */           }
/*      */         });
/*      */     
/*  176 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  179 */     Runnable buildThread = () -> {
/*      */         if (this.howMany == 1) {
/*      */           buildSikaku();
/*      */         } else {
/*      */           multiBuild();
/*      */           
/*      */           if (this.sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfSikaku.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfSikaku);
/*      */           Grid.clearGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfSikaku, "sikaku", Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  205 */     jl1 = new JLabel(); jfSikaku.add(jl1);
/*  206 */     jl2 = new JLabel(); jfSikaku.add(jl2);
/*      */ 
/*      */     
/*  209 */     menuBar = new JMenuBar();
/*  210 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  211 */     jfSikaku.setJMenuBar(menuBar);
/*      */     
/*  213 */     this.menu = new JMenu("File");
/*  214 */     menuBar.add(this.menu);
/*  215 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  216 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  217 */     this.menu.add(this.menuItem);
/*  218 */     this.menuItem
/*  219 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfSikaku, "sikaku", "sikaku", Op.sk, Op.SK.SkPuz.ordinal(), false);
/*      */         });
/*  226 */     this.menuItem = new JMenuItem("Save");
/*  227 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  228 */     this.menu.add(this.menuItem);
/*  229 */     this.menuItem
/*  230 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */           Methods.puzzleSaved(jfSikaku, "sikaku", Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */         });
/*  237 */     this.menuItem = new JMenuItem("SaveAs");
/*  238 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  239 */     this.menu.add(this.menuItem);
/*  240 */     this.menuItem
/*  241 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSikaku, Op.sk[Op.SK.SkPuz.ordinal()].substring(0, Op.sk[Op.SK.SkPuz.ordinal()].indexOf(".sikaku")), "sikaku", ".sikaku");
/*      */           if (Methods.clickedOK) {
/*      */             saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfSikaku, "sikaku", Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  252 */     this.menuItem = new JMenuItem("Quit Construction");
/*  253 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  254 */     this.menu.add(this.menuItem);
/*  255 */     this.menuItem
/*  256 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("sikaku.opt", Op.sk);
/*      */           CrosswordExpress.transfer(1, jfSikaku);
/*      */         });
/*  264 */     this.menu = new JMenu("Build");
/*  265 */     menuBar.add(this.menu);
/*  266 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  267 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  268 */     this.menu.add(this.menuItem);
/*  269 */     this.menuItem
/*  270 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSikaku, Op.sk[Op.SK.SkPuz.ordinal()].substring(0, Op.sk[Op.SK.SkPuz.ordinal()].indexOf(".sikaku")), "sikaku", ".sikaku");
/*      */           if (Methods.clickedOK) {
/*      */             Op.sk[Op.SK.SkPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  281 */     this.menuItem = new JMenuItem("Build Options");
/*  282 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  283 */     this.menu.add(this.menuItem);
/*  284 */     this.menuItem
/*  285 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           sikakuOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (this.howMany > 1)
/*      */               Op.sk[Op.SK.SkPuz.ordinal()] = "" + this.startPuz + ".sikaku"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  296 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  297 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  298 */     this.menu.add(this.buildMenuItem);
/*  299 */     this.buildMenuItem
/*  300 */       .addActionListener(ae -> {
/*      */           if (Op.sk[Op.SK.SkPuz.ordinal()].length() == 0 && this.howMany == 1) {
/*      */             Methods.noName(jfSikaku);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  316 */     this.menuItem = new JMenuItem("Test Puzzle Validity");
/*  317 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(84, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  318 */     this.menu.add(this.menuItem);
/*  319 */     this.menuItem
/*  320 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           if (sikakuUniqueTest()) {
/*      */             Methods.havePuzzle = true;
/*      */             for (int j = 0; j < Grid.ySz; j++) {
/*      */               for (int i = 0; i < Grid.xSz; i++) {
/*      */                 Grid.sol[i][j] = 0;
/*      */               }
/*      */             } 
/*      */             saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfSikaku, "sikaku", Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */           } else {
/*      */             JOptionPane.showMessageDialog(jfSikaku, "<html>The design of this puzzle is invalid.<br>Please refer to Help for further information.");
/*      */             Methods.clearGrid(Grid.copy);
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  340 */     this.menu = new JMenu("View");
/*  341 */     menuBar.add(this.menu);
/*  342 */     this.menuItem = new JMenuItem("Display Options");
/*  343 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  344 */     this.menu.add(this.menuItem);
/*  345 */     this.menuItem
/*  346 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfSikaku, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  354 */     this.menu = new JMenu("Export");
/*  355 */     menuBar.add(this.menu);
/*  356 */     this.menuItem = new JMenuItem("Print a Sikaku KDP puzzle book.");
/*  357 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  358 */     this.menu.add(this.menuItem);
/*  359 */     this.menuItem
/*  360 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfSikaku, 160, 6);
/*      */         });
/*  367 */     this.menu = new JMenu("Tasks");
/*  368 */     menuBar.add(this.menu);
/*  369 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  370 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  371 */     this.menu.add(this.menuItem);
/*  372 */     this.menuItem
/*  373 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfSikaku, Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */         });
/*  379 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  380 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  381 */     this.menu.add(this.menuItem);
/*  382 */     this.menuItem
/*  383 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(161, jfSikaku);
/*      */           } else {
/*      */             Methods.noPuzzle(jfSikaku, "Solve");
/*      */           } 
/*      */         });
/*  392 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  393 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  394 */     this.menu.add(this.menuItem);
/*  395 */     this.menuItem
/*  396 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfSikaku, Op.sk[Op.SK.SkPuz.ordinal()], "sikaku", pp)) {
/*      */             makeGrid();
/*      */             loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  407 */     this.menu = new JMenu("Help");
/*  408 */     menuBar.add(this.menu);
/*  409 */     this.menuItem = new JMenuItem("Sikaku Help");
/*  410 */     this.menu.add(this.menuItem);
/*  411 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  412 */     this.menuItem
/*  413 */       .addActionListener(ae -> Methods.cweHelp(jfSikaku, null, "Building Sikaku Puzzles", this.sikakuHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  418 */     pp = new SikakuPP(0, 37);
/*  419 */     jfSikaku.add(pp);
/*      */     
/*  421 */     pp
/*  422 */       .addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent e) {
/*  424 */             SikakuBuild.updateGrid(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  429 */     pp
/*  430 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  432 */             if (Def.isMac) {
/*  433 */               SikakuBuild.jfSikaku.setResizable((SikakuBuild.jfSikaku.getWidth() - e.getX() < 15 && SikakuBuild.jfSikaku
/*  434 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  439 */     jfSikaku
/*  440 */       .addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent e) {
/*  442 */             SikakuBuild.this.handleKeyPressed(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  447 */     loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*  448 */     restoreFrame();
/*      */ 
/*      */     
/*  451 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  457 */     this.myTimer = new Timer(1000, timerAL);
/*      */     
/*  459 */     if (auto) {
/*  460 */       this.sixpack = true;
/*  461 */       this.howMany = hm; this.startPuz = start;
/*  462 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  467 */     jfSikaku.setVisible(true);
/*  468 */     Insets insets = jfSikaku.getInsets();
/*  469 */     panelW = jfSikaku.getWidth() - insets.left + insets.right;
/*  470 */     panelH = jfSikaku.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  471 */     pp.setSize(panelW, panelH);
/*  472 */     jfSikaku.requestFocusInWindow();
/*  473 */     pp.repaint();
/*  474 */     Methods.infoPanel(jl1, jl2, "Build Sikaku", "Puzzle : " + Op.sk[Op.SK.SkPuz.ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  478 */     int i = (width - inset) / Grid.xSz;
/*  479 */     int j = (height - inset) / Grid.ySz;
/*  480 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  481 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/*  482 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sikakuOptions() {
/*  488 */     final JDialog jdlgSikaku = new JDialog(jfSikaku, "Sikaku Options", true);
/*  489 */     jdlgSikaku.setSize(270, 291);
/*  490 */     jdlgSikaku.setResizable(false);
/*  491 */     jdlgSikaku.setLayout((LayoutManager)null);
/*  492 */     jdlgSikaku.setLocation(jfSikaku.getX(), jfSikaku.getY());
/*      */     
/*  494 */     jdlgSikaku
/*  495 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  497 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  501 */     Methods.closeHelp();
/*      */     
/*  503 */     JLabel jlSize = new JLabel("Puzzle Size:");
/*  504 */     jlSize.setForeground(Def.COLOR_LABEL);
/*  505 */     jlSize.setSize(120, 20);
/*  506 */     jlSize.setLocation(10, 15);
/*  507 */     jlSize.setHorizontalAlignment(4);
/*  508 */     jdlgSikaku.add(jlSize);
/*      */     
/*  510 */     final JComboBox<Integer> jcbbSize = new JComboBox<>();
/*  511 */     for (int i = 5; i <= 20; i++)
/*  512 */       jcbbSize.addItem(Integer.valueOf(i)); 
/*  513 */     jcbbSize.setSize(50, 20);
/*  514 */     jcbbSize.setLocation(140, 15);
/*  515 */     jdlgSikaku.add(jcbbSize);
/*  516 */     jcbbSize.setBackground(Def.COLOR_BUTTONBG);
/*  517 */     jcbbSize.setSelectedIndex(Op.getInt(Op.SK.SkAcross.ordinal(), Op.sk) - 5);
/*      */     
/*  519 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgSikaku, 10, 55, this.howMany, this.startPuz, true);
/*      */     
/*  521 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  523 */           Grid.xSz = Grid.ySz = jcbbSize.getSelectedIndex() + 5;
/*  524 */           Op.setInt(Op.SK.SkAcross.ordinal(), Grid.xSz, Op.sk);
/*  525 */           Op.setInt(Op.SK.SkDown.ordinal(), Grid.xSz, Op.sk);
/*  526 */           SikakuBuild.this.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  527 */           SikakuBuild.this.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  528 */           Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(hmp.jcbVaryDiff.isSelected()), Op.sx);
/*  529 */           Methods.clickedOK = true;
/*  530 */           jdlgSikaku.dispose();
/*  531 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  534 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 13, 169, 80, 26);
/*  535 */     jdlgSikaku.add(jbOK);
/*      */     
/*  537 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  539 */           Methods.clickedOK = false;
/*  540 */           jdlgSikaku.dispose();
/*  541 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  544 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 13, 204, 80, 26);
/*  545 */     jdlgSikaku.add(jbCancel);
/*      */     
/*  547 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  549 */           Methods.cweHelp(null, jdlgSikaku, "Sikaku Options", SikakuBuild.this.sikakuOptions);
/*      */         }
/*      */       };
/*  552 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 169, 150, 61);
/*  553 */     jdlgSikaku.add(jbHelp);
/*      */     
/*  555 */     jdlgSikaku.getRootPane().setDefaultButton(jbOK);
/*  556 */     Methods.setDialogSize(jdlgSikaku, 260, 240);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  560 */     String[] colorLabel = { "Cell Color", "Grid Color", "Border Color", "Number Color", "Error Color" };
/*  561 */     int[] colorInt = { Op.SK.SkCell.ordinal(), Op.SK.SkGrid.ordinal(), Op.SK.SkBorder.ordinal(), Op.SK.SkNumber.ordinal(), Op.SK.SkError.ordinal() };
/*  562 */     String[] fontLabel = { "Select Number Font" };
/*  563 */     int[] fontInt = { Op.SK.SkNumberFont.ordinal() };
/*  564 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  565 */     int[] checkInt = { Op.SK.SkPuzColor.ordinal(), Op.SK.SkSolColor.ordinal() };
/*  566 */     Methods.stdPrintOptions(jf, "Sikaku " + type, Op.sk, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveSikaku(String sikakuName) {
/*      */     try {
/*  575 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("sikaku/" + sikakuName));
/*  576 */       dataOut.writeInt(Grid.xSz);
/*  577 */       dataOut.writeInt(Grid.ySz);
/*  578 */       dataOut.writeByte(Methods.noReveal);
/*  579 */       dataOut.writeByte(Methods.noErrors);
/*  580 */       for (int i = 0; i < 54; i++)
/*  581 */         dataOut.writeByte(0); 
/*  582 */       for (int j = 0; j < Grid.ySz; j++) {
/*  583 */         for (int k = 0; k < Grid.xSz; k++) {
/*  584 */           dataOut.writeChar(Grid.mode[k][j]);
/*  585 */           dataOut.writeChar(Grid.letter[k][j]);
/*  586 */           dataOut.writeInt(Grid.sol[k][j]);
/*  587 */           dataOut.writeInt(Grid.copy[k][j]);
/*      */         } 
/*  589 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  590 */       dataOut.writeUTF(Methods.author);
/*  591 */       dataOut.writeUTF(Methods.copyright);
/*  592 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  593 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  594 */       dataOut.close();
/*      */     }
/*  596 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadSikaku(String sikakuName) {
/*      */     
/*  605 */     try { File fl = new File("sikaku/" + sikakuName);
/*  606 */       if (!fl.exists()) {
/*      */         
/*  608 */         fl = new File("sikaku/");
/*  609 */         String[] s = fl.list(); int k;
/*  610 */         for (k = 0; k < s.length && (
/*  611 */           s[k].lastIndexOf(".sikaku") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  613 */         if (k == s.length) { makeGrid(); return; }
/*  614 */          sikakuName = s[k];
/*  615 */         Op.sk[Op.SK.SkPuz.ordinal()] = sikakuName;
/*      */       } 
/*      */ 
/*      */       
/*  619 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("sikaku/" + sikakuName));
/*  620 */       Grid.xSz = dataIn.readInt();
/*  621 */       Grid.ySz = dataIn.readInt();
/*  622 */       Methods.noReveal = dataIn.readByte();
/*  623 */       Methods.noErrors = dataIn.readByte(); int i;
/*  624 */       for (i = 0; i < 54; i++)
/*  625 */         dataIn.readByte(); 
/*  626 */       for (int j = 0; j < Grid.ySz; j++) {
/*  627 */         for (i = 0; i < Grid.xSz; i++) {
/*  628 */           Grid.mode[i][j] = dataIn.readChar();
/*  629 */           Grid.letter[i][j] = dataIn.readChar();
/*  630 */           Grid.sol[i][j] = dataIn.readInt();
/*  631 */           Grid.copy[i][j] = dataIn.readInt();
/*      */         } 
/*  633 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  634 */       Methods.author = dataIn.readUTF();
/*  635 */       Methods.copyright = dataIn.readUTF();
/*  636 */       Methods.puzzleNumber = dataIn.readUTF();
/*  637 */       Methods.puzzleNotes = dataIn.readUTF();
/*  638 */       dataIn.close(); }
/*      */     
/*  640 */     catch (IOException exc) { return; }
/*  641 */      Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawSikaku(Graphics2D g2, int[][] puzzleArray) {
/*  647 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  648 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/*  649 */     RenderingHints rh = g2.getRenderingHints();
/*  650 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  651 */     g2.setRenderingHints(rh);
/*  652 */     g2.setStroke(normalStroke);
/*      */ 
/*      */     
/*  655 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkCell.ordinal(), Op.sk) : 16777215));
/*  656 */     for (int j = 0; j < Grid.ySz; j++) {
/*  657 */       for (int k = 0; k < Grid.xSz; k++) {
/*  658 */         if (Grid.mode[k][j] == 0)
/*  659 */           g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */       } 
/*      */     } 
/*  662 */     for (int pass = 0; pass < 2; pass++) {
/*  663 */       for (int k = 0; k < Grid.ySz; k++) {
/*  664 */         for (int m = 0; m < Grid.xSz; m++) {
/*  665 */           if (Grid.mode[m][k] == 0) {
/*  666 */             int x = Grid.xOrg + m * Grid.xCell;
/*  667 */             int y = Grid.yOrg + k * Grid.yCell;
/*      */             
/*  669 */             if (Def.dispWithColor.booleanValue()) {
/*  670 */               g2.setColor(new Color((pass == 0) ? Op.getColorInt(Op.SK.SkGrid.ordinal(), Op.sk) : Op.getColorInt(Op.SK.SkBorder.ordinal(), Op.sk)));
/*      */             } else {
/*  672 */               g2.setColor(new Color((pass == 0) ? 16777215 : 0));
/*  673 */             }  g2.setStroke((pass == 0) ? normalStroke : wideStroke);
/*  674 */             for (int c = 3; c < 768; c *= 4) {
/*  675 */               int t = Grid.copy[m][k] & c;
/*  676 */               if ((pass == 0 && t == 0) || (pass == 1 && t != 0))
/*  677 */                 switch (c) { case 3:
/*  678 */                     g2.drawLine(x, y, x + Grid.xCell, y); break;
/*  679 */                   case 12: g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); break;
/*  680 */                   case 48: g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); break;
/*  681 */                   case 192: g2.drawLine(x, y + Grid.yCell, x, y); break; }
/*      */                  
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  687 */     }  g2.setStroke(wideStroke);
/*  688 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkBorder.ordinal(), Op.sk) : 0));
/*  689 */     g2.drawRect(Grid.xOrg, Grid.yOrg, Grid.xSz * Grid.xCell, Grid.ySz * Grid.yCell);
/*      */ 
/*      */     
/*  692 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkNumber.ordinal(), Op.sk) : 0));
/*  693 */     g2.setFont(new Font(Op.sk[Op.SK.SkNumberFont.ordinal()], 0, 6 * Grid.yCell / 10));
/*  694 */     FontMetrics fm = g2.getFontMetrics();
/*  695 */     for (int i = 0; i < Grid.ySz; i++) {
/*  696 */       for (int k = 0; k < Grid.xSz; k++) {
/*  697 */         int val = puzzleArray[k][i];
/*  698 */         if (val != 0) {
/*  699 */           int w = fm.stringWidth("" + val);
/*  700 */           g2.drawString("" + val, Grid.xOrg + k * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + i * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  705 */     if (Def.dispCursor.booleanValue()) {
/*  706 */       g2.setColor(Def.COLOR_RED);
/*  707 */       g2.setStroke(wideStroke);
/*  708 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */     } 
/*      */     
/*  711 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  715 */     loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*  716 */     setSizesAndOffsets(left, top, width, height, 0);
/*  717 */     SikakuSolve.clearSolution();
/*  718 */     Def.dispWithColor = Op.getBool(Op.SK.SkPuzColor.ordinal(), Op.sk);
/*  719 */     SikakuSolve.drawSikaku(g2, Grid.letter);
/*  720 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  724 */     loadSikaku(solutionPuzzle);
/*  725 */     setSizesAndOffsets(left, top, width, height, 0);
/*  726 */     Def.dispWithColor = Op.getBool(Op.SK.SkSolColor.ordinal(), Op.sk);
/*  727 */     drawSikaku(g2, Grid.letter);
/*  728 */     Def.dispWithColor = Boolean.valueOf(true);
/*  729 */     loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  733 */     loadSikaku(solutionPuzzle);
/*  734 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  735 */     loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  741 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  743 */     String st = Op.sx[Op.SX.SxSk.ordinal()];
/*  744 */     if (st.length() < 3) st = "SIKAKU"; 
/*  745 */     int w = fm.stringWidth(st);
/*  746 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  747 */     SikakuSolve.loadSikaku(puzName + ".sikaku");
/*  748 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  749 */     SikakuSolve.clearSolution();
/*  750 */     SikakuSolve.drawSikaku(g2, Grid.letter);
/*  751 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/*  752 */       st = rules;
/*      */     } else {
/*  754 */       st = Op.sk[Op.SK.SkRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/*  755 */     }  if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/*  756 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  762 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  764 */     String st = Op.sx[Op.SX.SxSk.ordinal()];
/*  765 */     if (st.length() < 3) st = "SIKAKU"; 
/*  766 */     int w = fm.stringWidth(st);
/*  767 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  768 */     loadSikaku(solName + ".sikaku");
/*  769 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  770 */     drawSikaku(g2, Grid.letter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  776 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  778 */     String st = puzName;
/*  779 */     int w = fm.stringWidth(st);
/*  780 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  781 */     SikakuSolve.loadSikaku(puzName + ".sikaku");
/*  782 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  783 */     SikakuSolve.clearSolution();
/*  784 */     SikakuSolve.drawSikaku(g2, Grid.letter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  790 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  792 */     String st = solName;
/*  793 */     int w = fm.stringWidth(st);
/*  794 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  795 */     loadSikaku(solName + ".sikaku");
/*  796 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  797 */     drawSikaku(g2, Grid.letter);
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/*  801 */     Methods.havePuzzle = false;
/*  802 */     Grid.clearGrid();
/*  803 */     Grid.xSz = Op.getInt(Op.SK.SkAcross.ordinal(), Op.sk);
/*  804 */     Grid.ySz = Op.getInt(Op.SK.SkDown.ordinal(), Op.sk);
/*      */   }
/*      */   
/*      */   void UpdateSikakuCell(int x, int y, int side) {
/*  808 */     int[] inc = { 1, 4, 16, 64 };
/*      */     
/*  810 */     if (x < 0 || y < 0 || x >= Grid.xSz || y >= Grid.ySz)
/*  811 */       return;  Grid.copy[x][y] = Grid.copy[x][y] | inc[side];
/*      */   }
/*      */   
/*      */   void UpdateSikaku(int x, int y, int side) {
/*  815 */     UpdateSikakuCell(x, y, side);
/*  816 */     switch (side) { case 0:
/*  817 */         UpdateSikakuCell(x, --y, 2); break;
/*  818 */       case 1: UpdateSikakuCell(++x, y, 3); break;
/*  819 */       case 2: UpdateSikakuCell(x, ++y, 0); break;
/*  820 */       case 3: UpdateSikakuCell(--x, y, 1);
/*      */         break; }
/*      */   
/*      */   }
/*      */   int scanArea(int top, int lft, int bot, int rgt) {
/*  825 */     int count = 0, specCount = 0;
/*  826 */     for (int j = top; j <= bot; j++) {
/*  827 */       for (int i = lft; i <= rgt; i++) {
/*  828 */         if (i < 0 || i >= Grid.xSz || j < 0 || j >= Grid.ySz || Grid.status[i][j] > 0) {
/*  829 */           return 0;
/*      */         }
/*  831 */         if (Grid.letter[i][j] > 0) count++; 
/*  832 */         if (Grid.scratch[i][j] > 0) specCount++; 
/*      */       } 
/*  834 */     }  if (count == 1) {
/*  835 */       if (specCount > 0) {
/*  836 */         return 2;
/*      */       }
/*  838 */       return 1;
/*  839 */     }  return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean solveSikaku() {
/*  844 */     int svi = 0, svj = 0, svm = 0, svn = 0, svx = 0, svy = 0, cellCount = 0;
/*      */     
/*      */     int j;
/*  847 */     for (j = 0; j < Grid.ySz; j++) {
/*  848 */       for (int i = 0; i < Grid.xSz; i++) {
/*  849 */         Grid.copy[i][j] = 0; Grid.status[i][j] = 0;
/*      */       } 
/*      */     }  while (true) {
/*  852 */       boolean found = false;
/*  853 */       for (j = 0; j < Grid.ySz; j++) {
/*  854 */         for (int i = 0; i < Grid.xSz; i++)
/*  855 */           Grid.scratch[i][j] = 0; 
/*      */       } 
/*  857 */       for (j = 0; j < Grid.ySz; j++) {
/*  858 */         for (int i = 0; i < Grid.xSz; i++) {
/*  859 */           int area; if ((area = Grid.letter[i][j]) > 0 && Grid.status[i][j] == 0) {
/*  860 */             int m; int count; for (count = 0, m = 1; m <= area; m++) {
/*  861 */               if (area % m == 0) {
/*  862 */                 int n = area / m;
/*  863 */                 for (int x = 0; x < m; x++) {
/*  864 */                   for (int y = 0; y < n; y++) {
/*  865 */                     int ret = scanArea(j - y, i - x, j - y + n - 1, i - x + m - 1);
/*  866 */                     if (ret > 0) {
/*  867 */                       svi = i; svj = j; svx = x; svy = y; svm = m; svn = n;
/*  868 */                       count++;
/*  869 */                       for (int w = j - y; w < j - y + n; w++)
/*  870 */                       { for (int v = i - x; v < i - x + m; v++)
/*  871 */                           Grid.scratch[v][w] = (Grid.scratch[v][w] == 0) ? (m + 100 * n) : -1;  } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*  876 */             }  if (count == 1) {
/*  877 */               found = true;
/*  878 */               for (int y = svj - svy; y < svj - svy + svn; y++) {
/*  879 */                 for (int x = svi - svx; x < svi - svx + svm; x++)
/*  880 */                 { Grid.status[x][y] = 1;
/*  881 */                   if (y == svj - svy) UpdateSikaku(x, y, 0); 
/*  882 */                   if (x == svi - svx + svm - 1) UpdateSikaku(x, y, 1); 
/*  883 */                   if (y == svj - svy + svn - 1) UpdateSikaku(x, y, 2); 
/*  884 */                   if (x == svi - svx) UpdateSikaku(x, y, 3); 
/*  885 */                   cellCount++; } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  890 */       }  for (j = 0; j < Grid.ySz; j++) {
/*  891 */         for (int i = 0; i < Grid.xSz; i++) {
/*  892 */           int area; if ((area = Grid.letter[i][j]) > 0 && Grid.status[i][j] == 0) {
/*  893 */             int m; int count; for (count = 0, m = 1; m <= area; m++) {
/*  894 */               if (area % m == 0) {
/*  895 */                 int n = area / m;
/*  896 */                 for (int x = 0; x < m; x++) {
/*  897 */                   for (int y = 0; y < n; y++) {
/*  898 */                     int ret = scanArea(j - y, i - x, j - y + n - 1, i - x + m - 1);
/*  899 */                     if (ret == 2) {
/*  900 */                       svi = i; svj = j; svx = x; svy = y; svm = m; svn = n;
/*  901 */                       m = area + 1;
/*  902 */                       x = m; y = n;
/*  903 */                       count = 1;
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*  908 */             }  if (count == 1) {
/*  909 */               found = true;
/*  910 */               for (int y = svj - svy; y < svj - svy + svn; y++) {
/*  911 */                 for (int x = svi - svx; x < svi - svx + svm; x++)
/*  912 */                 { Grid.status[x][y] = 1;
/*  913 */                   if (y == svj - svy) UpdateSikaku(x, y, 0); 
/*  914 */                   if (x == svi - svx + svm - 1) UpdateSikaku(x, y, 1); 
/*  915 */                   if (y == svj - svy + svn - 1) UpdateSikaku(x, y, 2); 
/*  916 */                   if (x == svi - svx) UpdateSikaku(x, y, 3); 
/*  917 */                   cellCount++; } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  922 */       }  if (cellCount == Grid.xSz * Grid.ySz)
/*  923 */         break;  if (!found) return false; 
/*      */     } 
/*  925 */     return true;
/*      */   }
/*      */   
/*      */   private boolean sikakuUniqueTest() {
/*  929 */     return solveSikaku();
/*      */   }
/*      */ 
/*      */   
/*      */   int placeOneRectangle(int x, int y, int w, int h, int numVacant, int rectNum) {
/*  934 */     Random rn = new Random();
/*  935 */     int[] factors = { 607, 706, 508, 805, 410, 1004, 606, 409, 904, 507, 705, 408, 804, 506, 605, 310, 1003, 407, 704, 309, 903, 505, 406, 604, 308, 803, 307, 703, 405, 504, 210, 1002, 306, 603, 209, 902, 404, 208, 802, 305, 503, 207, 702, 304, 403, 206, 602, 205, 502, 110, 1001, 303, 109, 901, 204, 402, 108, 801, 107, 701, 203, 302, 106, 601, 105, 501, 202, 104, 401, 103, 301, 102, 201, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  943 */     int[] start = { 0, 73, 71, 69, 66, 64, 60, 58, 54, 51, 47, 47, 43, 43, 41, 39, 36, 36, 32, 32, 28, 26, 26, 26, 22, 21, 21, 19, 17, 17, 13, 13, 11, 9, 9, 9, 6, 6, 6, 6, 2, 2, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  949 */     int k = numVacant / (rectNum / 2 + 5);
/*  950 */     if (k > 42) k = 42; 
/*  951 */     if (k < 3) k = 5;
/*      */     
/*  953 */     int scan = rn.nextInt(10);
/*  954 */     for (int v = start[k];; v++) {
/*  955 */       int z = factors[v];
/*  956 */       if (z == 101)
/*  957 */         return -1; 
/*  958 */       int hr = z / 100, wr = z % 100;
/*  959 */       if (wr <= w && hr <= h) {
/*  960 */         if (scan > 0 && rectNum == 1) {
/*  961 */           scan--;
/*      */         } else {
/*      */           
/*  964 */           if (rectNum == 1) {
/*  965 */             if (w > wr) x += rn.nextInt(w - wr); 
/*  966 */             if (h > hr) y += rn.nextInt(h - hr);
/*      */           
/*      */           } else {
/*  969 */             switch (rn.nextInt(4)) {
/*      */               case 1:
/*  971 */                 x += w - wr; break;
/*  972 */               case 2: x += w - wr; y += h - hr; break;
/*  973 */               case 3: y += h - hr; break;
/*      */             } 
/*      */           } 
/*  976 */           for (int j = 0; j < hr; j++) {
/*  977 */             for (int i = 0; i < wr; i++)
/*  978 */               Grid.letter[x + i][y + j] = rectNum; 
/*  979 */           }  return numVacant - wr * hr;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   int placeRectangles() {
/*  986 */     int rectNum = 0;
/*  987 */     Random rn = new Random();
/*      */     
/*      */     int j;
/*  990 */     for (j = 0; j < Grid.ySz; j++) {
/*  991 */       for (int i = 0; i < Grid.xSz; i++)
/*  992 */         Grid.letter[i][j] = 0; 
/*  993 */     }  int numVacant = Grid.xSz * Grid.ySz;
/*      */     
/*  995 */     numVacant = placeOneRectangle(0, 0, Grid.xSz, Grid.ySz, numVacant, ++rectNum);
/*      */     
/*  997 */     while (numVacant > 0) {
/*      */       int i; do {
/*  999 */         i = rn.nextInt(Grid.xSz); j = rn.nextInt(Grid.ySz);
/* 1000 */       } while (Grid.letter[i][j] != 0);
/*      */ 
/*      */ 
/*      */       
/* 1004 */       int b = j, t = b, l = i, r = l; int mask;
/* 1005 */       for (int m = 1; mask != 15; ) {
/* 1006 */         m = (m == 8) ? 1 : (m * 2);
/* 1007 */         switch (m) { case 1:
/* 1008 */             t--; break;
/* 1009 */           case 2: l--; break;
/* 1010 */           case 4: b++; break;
/* 1011 */           case 8: r++; break; }
/*      */         
/* 1013 */         if (t >= 0 && l >= 0 && b < Grid.ySz && r < Grid.xSz) {
/* 1014 */           boolean occupied; for (occupied = false, j = t; j <= b; j++) {
/* 1015 */             for (i = l; i <= r; i++)
/* 1016 */             { if (Grid.letter[i][j] != 0)
/* 1017 */                 occupied = true;  } 
/* 1018 */           }  if (!occupied) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 1022 */         switch (m) { case 1:
/* 1023 */             t++; break;
/* 1024 */           case 2: l++; break;
/* 1025 */           case 4: b--; break;
/* 1026 */           case 8: r--; break; }
/*      */         
/* 1028 */         mask |= m;
/*      */       } 
/* 1030 */       numVacant = placeOneRectangle(l, t, r - l + 1, b - t + 1, numVacant, ++rectNum);
/* 1031 */       if (numVacant == -1)
/* 1032 */         return 0; 
/*      */     } 
/* 1034 */     return rectNum;
/*      */   }
/*      */   
/*      */   private void multiBuild() {
/* 1038 */     String title = Methods.puzzleTitle;
/* 1039 */     int[] sizeDef = { 6, 8, 10, 12, 14, 16, 18 };
/*      */     
/* 1041 */     int savexSz = Op.getInt(Op.SK.SkAcross.ordinal(), Op.sk);
/* 1042 */     int saveySz = Op.getInt(Op.SK.SkDown.ordinal(), Op.sk);
/*      */     
/* 1044 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1045 */     Calendar c = Calendar.getInstance();
/*      */     
/* 1047 */     for (this.hmCount = 1; this.hmCount <= this.howMany; this.hmCount++) {
/* 1048 */       if (this.startPuz > 9999999) { try {
/* 1049 */           c.setTime(sdf.parse("" + this.startPuz));
/* 1050 */         } catch (ParseException ex) {}
/* 1051 */         this.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 1054 */       Methods.puzzleTitle = "SIKAKU Puzzle : " + this.startPuz;
/* 1055 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/* 1056 */         Op.setInt(Op.SK.SkAcross.ordinal(), sizeDef[(this.startPuz - 1) % 7], Op.sk);
/* 1057 */         Op.setInt(Op.SK.SkDown.ordinal(), sizeDef[(this.startPuz - 1) % 7], Op.sk);
/*      */       } 
/*      */       
/* 1060 */       Methods.buildProgress(jfSikaku, Op.sk[Op.SK.SkPuz
/* 1061 */             .ordinal()] = "" + this.startPuz + ".sikaku");
/* 1062 */       buildSikaku();
/* 1063 */       restoreFrame();
/* 1064 */       Wait.shortWait(100);
/* 1065 */       if (Def.building == 2)
/*      */         return; 
/* 1067 */       this.startPuz++;
/*      */     } 
/* 1069 */     this.howMany = 1;
/* 1070 */     Methods.puzzleTitle = title;
/*      */     
/* 1072 */     Op.setInt(Op.SK.SkAcross.ordinal(), savexSz, Op.sk);
/* 1073 */     Op.setInt(Op.SK.SkDown.ordinal(), saveySz, Op.sk);
/*      */   }
/*      */   
/*      */   private void buildSikaku() {
/* 1077 */     int[] t = new int[100], l = new int[100], b = new int[100], r = new int[100];
/* 1078 */     Random rn = new Random();
/*      */     
/*      */     while (true) {
/* 1081 */       makeGrid(); int res;
/* 1082 */       for (res = 0; res == 0; res = placeRectangles()); int rect;
/* 1083 */       for (rect = 1; rect <= res; rect++) {
/* 1084 */         int y; for (y = 0; y < Grid.ySz; y++) {
/* 1085 */           for (int x = 0; x < Grid.xSz; x++) {
/* 1086 */             if (Grid.letter[x][y] == rect)
/* 1087 */             { t[rect] = y; l[rect] = x;
/* 1088 */               x = Grid.xSz; y = Grid.ySz; } 
/*      */           } 
/* 1090 */         }  for (y = Grid.ySz - 1; y >= 0; y--) {
/* 1091 */           for (int x = Grid.xSz - 1; x >= 0; x--) {
/* 1092 */             if (Grid.letter[x][y] == rect) {
/* 1093 */               b[rect] = y; r[rect] = x;
/* 1094 */               x = -1; y = -1;
/*      */             } 
/*      */           } 
/*      */         } 
/* 1098 */       }  int k; for (k = 0; k < 20; k++) {
/* 1099 */         int y; for (y = 0; y < Grid.ySz; y++) {
/* 1100 */           for (int x = 0; x < Grid.xSz; x++)
/* 1101 */           { Grid.mode[x][y] = 0; Grid.letter[x][y] = 0; } 
/* 1102 */         }  for (rect = 1; rect <= res; rect++) {
/* 1103 */           int x = r[rect] - l[rect] + 1; y = b[rect] - t[rect] + 1;
/* 1104 */           Grid.letter[t[rect] + rn.nextInt(y)][l[rect] + rn.nextInt(x)] = x * y;
/*      */         } 
/* 1106 */         if (solveSikaku())
/*      */           break; 
/*      */       } 
/* 1109 */       if (k < 20)
/* 1110 */         break;  if (Def.building == 2)
/*      */         return; 
/*      */     } 
/* 1113 */     saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void updateGrid(MouseEvent e) {
/* 1117 */     int mouseX = e.getX(), mouseY = e.getY();
/*      */     
/* 1119 */     if (Def.building == 1)
/*      */       return; 
/* 1121 */     if (mouseX < Grid.xOrg) mouseX = Grid.xOrg + 1; 
/* 1122 */     if (mouseY < Grid.yOrg) mouseY = Grid.yOrg + 1; 
/* 1123 */     int x = Grid.xOrg + Grid.xSz * Grid.xCell; if (mouseX >= x) mouseX = x - 1; 
/* 1124 */     int y = Grid.yOrg + Grid.ySz * Grid.yCell; if (mouseY >= y) mouseY = y - 1; 
/* 1125 */     x = (mouseX - Grid.xOrg) / Grid.xCell;
/* 1126 */     y = (mouseY - Grid.yOrg) / Grid.yCell;
/* 1127 */     if (Grid.mode[x][y] != 0)
/* 1128 */       return;  Grid.xCur = x;
/* 1129 */     Grid.yCur = y;
/* 1130 */     restoreFrame();
/*      */   }
/*      */   void handleKeyPressed(KeyEvent e) {
/*      */     char ch;
/* 1134 */     if (Def.building == 1)
/* 1135 */       return;  if (e.isAltDown())
/* 1136 */       return;  switch (e.getKeyCode()) { case 38:
/* 1137 */         if (Grid.yCur > 0 && Grid.mode[Grid.xCur][Grid.yCur - 1] == 0) Grid.yCur--;  break;
/* 1138 */       case 40: if (Grid.yCur < Grid.ySz - 1 && Grid.mode[Grid.xCur][Grid.yCur + 1] == 0) Grid.yCur++;  break;
/* 1139 */       case 37: if (Grid.xCur > 0 && Grid.mode[Grid.xCur - 1][Grid.yCur] == 0) Grid.xCur--;  break;
/* 1140 */       case 39: if (Grid.xCur < Grid.xSz - 1 && Grid.mode[Grid.xCur + 1][Grid.yCur] == 0) Grid.xCur++;  break;
/* 1141 */       case 36: for (Grid.xCur = 0; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.xCur++); break;
/* 1142 */       case 35: for (Grid.xCur = Grid.xSz - 1; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.xCur--); break;
/* 1143 */       case 33: for (Grid.yCur = 0; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.yCur++); break;
/* 1144 */       case 34: for (Grid.yCur = Grid.ySz - 1; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.yCur--); break;
/*      */       case 8:
/*      */       case 32:
/*      */       case 127:
/* 1148 */         Grid.letter[Grid.xCur][Grid.yCur] = 0;
/*      */         break;
/*      */       default:
/* 1151 */         ch = e.getKeyChar();
/* 1152 */         if (ch >= '0' && ch <= '9') {
/* 1153 */           int val = 10 * Grid.letter[Grid.xCur][Grid.yCur] + ch - 48;
/* 1154 */           if (val < 100)
/* 1155 */             Grid.letter[Grid.xCur][Grid.yCur] = val; 
/*      */         } 
/*      */         break; }
/*      */     
/* 1159 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SikakuBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */