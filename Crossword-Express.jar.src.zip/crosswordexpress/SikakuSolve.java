/*     */ package crosswordexpress;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class SikakuSolve extends JPanel {
/*  27 */   String sikakuSolve = "<div>A SIKAKU puzzle consists of a square or rectangular grid in which some of the cells contain a one or two digit number. To complete the puzzle, a Solver must divide the puzzle into a number of rectangles so that each rectangle contains exactly one of the numbers, and that number must be equal to the area of the rectangle which contains it.<p/>Solving the puzzle is a purely mouse operation. When you have determined where one of the rectangles must be located, mouse click into one of the corner cells of the rectangle, and drag to the cell in the opposite corner. A red outline will show you the rectangle you have selected in this way. When you release the mouse, the outline of the selected rectangle will change to black.<p/>If you make a mistake, you can remove individual segments of the outline of a rectangle by pointing to any point near the center of that segment and clicking the mouse.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose the puzzle you want to solve from the pool of SIKAKU puzzles currently available on your computer.<p/><li/><span>Quit Solving</span><br/>Returns you to the SIKAKU Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Sikaku Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */   
/*     */   static JFrame jfSolveSikaku;
/*     */   
/*     */   static JMenuBar menuBar;
/*     */   
/*     */   JMenu menu;
/*     */   
/*     */   JMenu submenu;
/*     */   
/*     */   JMenuItem menuItem;
/*     */   
/*     */   static JPanel pp;
/*     */   
/*     */   static int panelW;
/*     */   
/*     */   static int panelH;
/*     */   
/*     */   static JLabel jl1;
/*     */   
/*     */   static JLabel jl2;
/*     */   
/*     */   Timer myTimer;
/*     */   
/*     */   static Runnable solveThread;
/*     */   
/*     */   static int memMode;
/*     */   
/*     */   static int mouseXdown;
/*     */   
/*     */   static int mouseYdown;
/*     */   
/*     */   static int x1;
/*     */   
/*     */   static int x2;
/*     */   
/*     */   static int y1;
/*     */   
/*     */   static int y2;
/*     */   
/*     */   SikakuSolve(JFrame jf) {
/*  68 */     memMode = Def.puzzleMode;
/*  69 */     Def.puzzleMode = 161;
/*     */     
/*  71 */     Grid.clearGrid();
/*     */     
/*  73 */     jfSolveSikaku = new JFrame("Sikaku");
/*  74 */     jfSolveSikaku.setSize(Op.getInt(Op.SK.SkW.ordinal(), Op.sk), Op.getInt(Op.SK.SkH.ordinal(), Op.sk));
/*  75 */     int frameX = (jf.getX() + jfSolveSikaku.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveSikaku.getWidth() - 10) : jf.getX();
/*  76 */     jfSolveSikaku.setLocation(frameX, jf.getY());
/*  77 */     jfSolveSikaku.setLayout((LayoutManager)null);
/*  78 */     jfSolveSikaku.setDefaultCloseOperation(0);
/*  79 */     jfSolveSikaku
/*  80 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/*  82 */             int oldw = Op.getInt(Op.SK.SkW.ordinal(), Op.sk);
/*  83 */             int oldh = Op.getInt(Op.SK.SkH.ordinal(), Op.sk);
/*  84 */             Methods.frameResize(SikakuSolve.jfSolveSikaku, oldw, oldh, 500, 580);
/*  85 */             Op.setInt(Op.SK.SkW.ordinal(), SikakuSolve.jfSolveSikaku.getWidth(), Op.sk);
/*  86 */             Op.setInt(Op.SK.SkH.ordinal(), SikakuSolve.jfSolveSikaku.getHeight(), Op.sk);
/*  87 */             SikakuSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  91 */     jfSolveSikaku
/*  92 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  94 */             if (Def.selecting)
/*  95 */               return;  Op.saveOptions("sikaku.opt", Op.sk);
/*  96 */             SikakuSolve.this.restoreIfDone();
/*  97 */             SikakuSolve.saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*  98 */             CrosswordExpress.transfer(160, SikakuSolve.jfSolveSikaku);
/*     */           }
/*     */         });
/*     */     
/* 102 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 105 */     solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if ((Grid.sol[i][j] & 0x55) != (Grid.copy[i][j] & 0x55))
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveSikaku);
/*     */       });
/* 113 */     jl1 = new JLabel(); jfSolveSikaku.add(jl1);
/* 114 */     jl2 = new JLabel(); jfSolveSikaku.add(jl2);
/*     */ 
/*     */     
/* 117 */     menuBar = new JMenuBar();
/* 118 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 119 */     jfSolveSikaku.setJMenuBar(menuBar);
/*     */     
/* 121 */     this.menu = new JMenu("File");
/* 122 */     menuBar.add(this.menu);
/* 123 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 124 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 125 */     this.menu.add(this.menuItem);
/* 126 */     this.menuItem
/* 127 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*     */           new Select(jfSolveSikaku, "sikaku", "sikaku", Op.sk, Op.SK.SkPuz.ordinal(), false);
/*     */         });
/* 135 */     this.menuItem = new JMenuItem("Quit Solving");
/* 136 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 137 */     this.menu.add(this.menuItem);
/* 138 */     this.menuItem
/* 139 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("sikaku.opt", Op.sk);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(160, jfSolveSikaku);
/*     */         });
/* 148 */     this.menu = new JMenu("View");
/* 149 */     menuBar.add(this.menu);
/* 150 */     this.menuItem = new JMenuItem("Display Options");
/* 151 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 152 */     this.menu.add(this.menuItem);
/* 153 */     this.menuItem
/* 154 */       .addActionListener(ae -> {
/*     */           SikakuBuild.printOptions(jfSolveSikaku, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 161 */     this.menu = new JMenu("Tasks");
/* 162 */     menuBar.add(this.menu);
/*     */     
/* 164 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 169 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 171 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 172 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 173 */     this.menu.add(this.menuItem);
/* 174 */     this.menuItem
/* 175 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSikaku);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 186 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 187 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 188 */     this.menu.add(this.menuItem);
/* 189 */     this.menuItem
/* 190 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++) {
/*     */                 Grid.sol[i][j] = Grid.copy[i][j];
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSikaku);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 202 */     this.menuItem = new JMenuItem("Begin again");
/* 203 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 204 */     this.menu.add(this.menuItem);
/* 205 */     this.menuItem
/* 206 */       .addActionListener(ae -> {
/*     */           clearSolution();
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 213 */     this.menu = new JMenu("Help");
/* 214 */     menuBar.add(this.menu);
/* 215 */     this.menuItem = new JMenuItem("Sikaku Help");
/* 216 */     this.menu.add(this.menuItem);
/* 217 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 218 */     this.menuItem
/* 219 */       .addActionListener(ae -> Methods.cweHelp(jfSolveSikaku, null, "Solving Sikaku Puzzles", this.sikakuSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     loadSikaku(Op.sk[Op.SK.SkPuz.ordinal()]);
/* 226 */     pp = new SikakuSolvePP(0, 37);
/* 227 */     jfSolveSikaku.add(pp);
/*     */     
/* 229 */     pp
/* 230 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 232 */             if (Def.isMac) {
/* 233 */               SikakuSolve.jfSolveSikaku.setResizable((SikakuSolve.jfSolveSikaku.getWidth() - e.getX() < 15 && SikakuSolve.jfSolveSikaku
/* 234 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 239 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 243 */     jfSolveSikaku.setVisible(true);
/* 244 */     Insets insets = jfSolveSikaku.getInsets();
/* 245 */     panelW = jfSolveSikaku.getWidth() - insets.left + insets.right;
/* 246 */     panelH = jfSolveSikaku.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 247 */     pp.setSize(panelW, panelH);
/* 248 */     jfSolveSikaku.requestFocusInWindow();
/* 249 */     pp.repaint();
/* 250 */     Methods.infoPanel(jl1, jl2, "Solve Sikaku", "Puzzle : " + Op.sk[Op.SK.SkPuz.ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 254 */     int i = (width - inset) / Grid.xSz;
/* 255 */     int j = (height - inset) / Grid.ySz;
/* 256 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 257 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/* 258 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveSikaku(String sikakuName) {
/*     */     try {
/* 264 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("sikaku/" + sikakuName));
/* 265 */       dataOut.writeInt(Grid.xSz);
/* 266 */       dataOut.writeInt(Grid.ySz);
/* 267 */       dataOut.writeByte(Methods.noReveal);
/* 268 */       dataOut.writeByte(Methods.noErrors);
/* 269 */       for (int i = 0; i < 54; i++)
/* 270 */         dataOut.writeByte(0); 
/* 271 */       for (int j = 0; j < Grid.ySz; j++) {
/* 272 */         for (int k = 0; k < Grid.xSz; k++) {
/* 273 */           dataOut.writeChar(Grid.mode[k][j]);
/* 274 */           dataOut.writeChar(Grid.letter[k][j]);
/* 275 */           dataOut.writeInt(Grid.sol[k][j]);
/* 276 */           dataOut.writeInt(Grid.copy[k][j]);
/*     */         } 
/* 278 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 279 */       dataOut.writeUTF(Methods.author);
/* 280 */       dataOut.writeUTF(Methods.copyright);
/* 281 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 282 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 283 */       dataOut.close();
/*     */     }
/* 285 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadSikaku(String sikakuName) {
/*     */     try {
/* 293 */       File fl = new File("sikaku/" + sikakuName);
/* 294 */       if (!fl.exists()) {
/*     */         
/* 296 */         fl = new File("sikaku/");
/* 297 */         String[] s = fl.list(); int m;
/* 298 */         for (m = 0; m < s.length && (
/* 299 */           s[m].lastIndexOf(".sikaku") == -1 || s[m].charAt(0) == '.'); m++);
/*     */         
/* 301 */         sikakuName = s[m];
/* 302 */         Op.sk[Op.SK.SkPuz.ordinal()] = sikakuName;
/*     */       } 
/*     */ 
/*     */       
/* 306 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("sikaku/" + sikakuName));
/* 307 */       Grid.xSz = dataIn.readInt();
/* 308 */       Grid.ySz = dataIn.readInt();
/* 309 */       Methods.noReveal = dataIn.readByte();
/* 310 */       Methods.noErrors = dataIn.readByte(); int k;
/* 311 */       for (k = 0; k < 54; k++)
/* 312 */         dataIn.readByte(); 
/* 313 */       for (int j = 0; j < Grid.ySz; j++) {
/* 314 */         for (k = 0; k < Grid.xSz; k++) {
/* 315 */           Grid.mode[k][j] = dataIn.readChar();
/* 316 */           Grid.letter[k][j] = dataIn.readChar();
/* 317 */           Grid.sol[k][j] = dataIn.readInt();
/* 318 */           Grid.copy[k][j] = dataIn.readInt();
/*     */         } 
/* 320 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 321 */       Methods.author = dataIn.readUTF();
/* 322 */       Methods.copyright = dataIn.readUTF();
/* 323 */       Methods.puzzleNumber = dataIn.readUTF();
/* 324 */       Methods.puzzleNotes = dataIn.readUTF();
/* 325 */       dataIn.close();
/*     */     }
/* 327 */     catch (IOException exc) {
/*     */       return;
/*     */     } 
/*     */     int i;
/* 331 */     for (i = 0; i < Grid.xSz; i++) {
/* 332 */       updateSikakuCell(i, 0, 0, true);
/* 333 */       updateSikakuCell(i, Grid.ySz - 1, 2, true);
/*     */     } 
/* 335 */     for (i = 0; i < Grid.ySz; i++) {
/* 336 */       updateSikakuCell(0, i, 3, true);
/* 337 */       updateSikakuCell(Grid.xSz - 1, i, 1, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void drawSikaku(Graphics2D g2, int[][] puzzleArray) {
/* 343 */     boolean isError = false;
/*     */     
/* 345 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/* 346 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/* 347 */     RenderingHints rh = g2.getRenderingHints();
/* 348 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 349 */     g2.setRenderingHints(rh);
/* 350 */     g2.setStroke(normalStroke);
/*     */     
/* 352 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkCell.ordinal(), Op.sk) : 16777215));
/* 353 */     for (int j = 0; j < Grid.ySz; j++) {
/* 354 */       for (int k = 0; k < Grid.xSz; k++) {
/* 355 */         if (Grid.mode[k][j] == 0)
/* 356 */           g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*     */       } 
/* 358 */     }  for (int pass = 0; pass < 2; pass++) {
/* 359 */       for (int k = 0; k < Grid.ySz; k++) {
/* 360 */         for (int m = 0; m < Grid.xSz; m++) {
/* 361 */           if (Grid.mode[m][k] == 0) {
/* 362 */             int x = Grid.xOrg + m * Grid.xCell;
/* 363 */             int y = Grid.yOrg + k * Grid.yCell;
/*     */             
/* 365 */             for (int c = 3; c < 768; c *= 4)
/* 366 */             { int t = Grid.sol[m][k] & c;
/* 367 */               int v = Grid.copy[m][k] & c;
/* 368 */               if (Def.dispWithColor.booleanValue()) {
/* 369 */                 if (t == 0) {
/* 370 */                   g2.setColor(new Color(Op.getColorInt(Op.SK.SkGrid.ordinal(), Op.sk)));
/*     */                 }
/* 372 */                 else if (Def.dispErrors.booleanValue()) {
/* 373 */                   if ((t & 0x55) != 0) {
/* 374 */                     if ((v & 0x55) != 0) {
/* 375 */                       g2.setColor(new Color(Op.getColorInt(Op.SK.SkBorder.ordinal(), Op.sk)));
/*     */                     } else {
/* 377 */                       g2.setColor(new Color(Op.getColorInt(Op.SK.SkError.ordinal(), Op.sk)));
/* 378 */                       isError = true;
/*     */                     } 
/*     */                   }
/* 381 */                   if ((t & 0xAA) != 0)
/* 382 */                     if ((v & 0x55) != 0) {
/* 383 */                       g2.setColor(new Color(Op.getColorInt(Op.SK.SkError.ordinal(), Op.sk)));
/* 384 */                       isError = true;
/*     */                     } else {
/*     */                       
/* 387 */                       g2.setColor(new Color(Op.getColorInt(Op.SK.SkError.ordinal(), Op.sk)));
/*     */                     }  
/*     */                 } else {
/* 390 */                   g2.setColor(new Color(((t & 0xAA) != 0) ? 16777215 : Op.getColorInt(Op.SK.SkBorder.ordinal(), Op.sk)));
/*     */                 } 
/*     */               } else {
/* 393 */                 g2.setColor(Def.COLOR_BLACK);
/* 394 */               }  g2.setStroke((t == 0) ? normalStroke : wideStroke);
/* 395 */               if ((pass == 0 && t == 0) || (pass == 1 && t != 0))
/* 396 */                 switch (c) { case 3:
/* 397 */                     g2.drawLine(x, y, x + Grid.xCell, y); break;
/* 398 */                   case 12: g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); break;
/* 399 */                   case 48: g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); break;
/* 400 */                   case 192: g2.drawLine(x, y + Grid.yCell, x, y); break; }   } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 404 */     }  if (!isError) Def.dispErrors = Boolean.valueOf(false);
/*     */ 
/*     */     
/* 407 */     g2.setStroke(wideStroke);
/* 408 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkBorder.ordinal(), Op.sk) : 0));
/* 409 */     g2.drawRect(Grid.xOrg, Grid.yOrg, Grid.xSz * Grid.xCell, Grid.ySz * Grid.yCell);
/*     */ 
/*     */     
/* 412 */     g2.setStroke(wideStroke);
/* 413 */     g2.setColor(Def.COLOR_RED);
/* 414 */     if (x1 != x2 || y1 != y2) {
/* 415 */       g2.drawRect(Grid.xOrg + x1 * Grid.xCell, Grid.yOrg + y1 * Grid.yCell, (x2 - x1 + 1) * Grid.xCell, (y2 - y1 + 1) * Grid.yCell);
/*     */     }
/*     */     
/* 418 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SK.SkNumber.ordinal(), Op.sk) : 0));
/* 419 */     g2.setFont(new Font(Op.sk[Op.SK.SkNumberFont.ordinal()], 0, 6 * Grid.yCell / 10));
/* 420 */     FontMetrics fm = g2.getFontMetrics();
/* 421 */     for (int i = 0; i < Grid.ySz; i++) {
/* 422 */       for (int k = 0; k < Grid.xSz; k++) {
/* 423 */         int val = puzzleArray[k][i];
/* 424 */         if (val != 0) {
/* 425 */           int w = fm.stringWidth("" + val);
/* 426 */           g2.drawString("" + val, Grid.xOrg + k * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + i * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*     */         } 
/*     */       } 
/*     */     } 
/* 430 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void clearSolution() {
/* 436 */     Methods.clearGrid(Grid.sol);
/*     */     
/*     */     int i;
/* 439 */     for (i = 0; i < Grid.xSz; i++) {
/* 440 */       updateSikakuCell(i, 0, 0, true);
/* 441 */       updateSikakuCell(i, Grid.ySz - 1, 2, true);
/*     */     } 
/* 443 */     for (i = 0; i < Grid.ySz; i++) {
/* 444 */       updateSikakuCell(0, i, 3, true);
/* 445 */       updateSikakuCell(Grid.xSz - 1, i, 1, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   void restoreIfDone() {
/* 450 */     for (int j = 0; j < Grid.ySz; j++) {
/* 451 */       for (int i = 0; i < Grid.xSz; i++)
/* 452 */       { if ((Grid.sol[i][j] & 0x55) != (Grid.copy[i][j] & 0x55))
/*     */           return;  } 
/* 454 */     }  clearSolution();
/*     */   }
/*     */   
/*     */   static void updateSikakuCell(int x, int y, int side, boolean set) {
/* 458 */     int[] mask = { 3, 12, 48, 192, 252, 243, 207, 63 };
/* 459 */     int[] inc = { 1, 4, 16, 64 };
/*     */     
/* 461 */     if (x < 0 || y < 0 || x >= Grid.xSz || y >= Grid.ySz)
/* 462 */       return;  if (set) {
/* 463 */       Grid.sol[x][y] = Grid.sol[x][y] | inc[side];
/*     */       return;
/*     */     } 
/* 466 */     if ((Grid.sol[x][y] & mask[side]) != 0) {
/* 467 */       Grid.sol[x][y] = Grid.sol[x][y] & mask[side + 4];
/*     */     } else {
/* 469 */       Grid.sol[x][y] = Grid.sol[x][y] | inc[side];
/*     */     } 
/*     */   }
/*     */   static void updateSikaku(int x, int y, int side, boolean set) {
/* 473 */     updateSikakuCell(x, y, side, set);
/*     */     
/* 475 */     switch (side) { case 0:
/* 476 */         updateSikakuCell(x, --y, 2, set); break;
/* 477 */       case 1: updateSikakuCell(++x, y, 3, set); break;
/* 478 */       case 2: updateSikakuCell(x, ++y, 0, set); break;
/* 479 */       case 3: updateSikakuCell(--x, y, 1, set);
/*     */         break; }
/*     */   
/*     */   }
/*     */   static void mousePressed(MouseEvent e) {
/* 484 */     mouseXdown = e.getX();
/* 485 */     mouseYdown = e.getY();
/*     */   }
/*     */   
/*     */   static boolean setDragCoordinates(MouseEvent e) {
/* 489 */     int mouseX = e.getX(), mouseY = e.getY();
/*     */     
/* 491 */     if (mouseXdown < Grid.xOrg || mouseYdown < Grid.yOrg) return false; 
/* 492 */     x1 = (mouseXdown - Grid.xOrg) / Grid.xCell;
/* 493 */     y1 = (mouseYdown - Grid.yOrg) / Grid.yCell;
/* 494 */     if (x1 >= Grid.xSz || y1 >= Grid.ySz) return false;
/*     */     
/* 496 */     if (mouseX < Grid.xOrg || mouseY < Grid.yOrg) return false; 
/* 497 */     x2 = (mouseX - Grid.xOrg) / Grid.xCell;
/* 498 */     y2 = (mouseY - Grid.yOrg) / Grid.yCell;
/* 499 */     if (x2 >= Grid.xSz || y2 >= Grid.ySz) return false;
/*     */     
/* 501 */     if (x1 > x2) { int i = x1; x1 = x2; x2 = i; }
/* 502 */      if (y1 > y2) { int i = y1; y1 = y2; y2 = i; }
/* 503 */      return true;
/*     */   }
/*     */   
/*     */   static void mouseReleased(MouseEvent e) {
/* 507 */     int loc[] = new int[4], mouseX = e.getX(), mouseY = e.getY();
/*     */     
/* 509 */     if (mouseXdown == mouseX && mouseYdown == mouseY) {
/*     */       
/* 511 */       if (mouseX < Grid.xOrg) mouseX = Grid.xOrg + 1; 
/* 512 */       if (mouseY < Grid.yOrg) mouseY = Grid.yOrg + 1; 
/* 513 */       int x = Grid.xOrg + Grid.xSz * Grid.xCell; if (mouseX >= x) mouseX = x - 1; 
/* 514 */       int y = Grid.yOrg + Grid.ySz * Grid.yCell; if (mouseY >= y) mouseY = y - 1; 
/* 515 */       x = (mouseX - Grid.xOrg) / Grid.xCell;
/* 516 */       y = (mouseY - Grid.yOrg) / Grid.yCell;
/* 517 */       if (Grid.mode[x][y] != 0)
/* 518 */         return;  loc[0] = (mouseY - Grid.yOrg) % Grid.yCell;
/* 519 */       loc[3] = (mouseX - Grid.xOrg) % Grid.xCell;
/* 520 */       loc[1] = Grid.xCell - loc[3];
/* 521 */       loc[2] = Grid.yCell - loc[0]; int best;
/* 522 */       for (int min = 1000, i = 0; i < 4; i++) {
/* 523 */         if (loc[i] < min) {
/* 524 */           min = loc[i];
/* 525 */           best = i;
/*     */         } 
/* 527 */       }  updateSikaku(x, y, best, false);
/*     */     
/*     */     }
/* 530 */     else if (setDragCoordinates(e)) {
/* 531 */       if (x1 == x2 && y1 == y2)
/* 532 */         return;  int i; for (i = x1; i <= x2; i++) {
/* 533 */         updateSikaku(i, y1, 0, true);
/* 534 */         updateSikaku(i, y2, 2, true);
/*     */       } 
/* 536 */       for (i = y1; i <= y2; i++) {
/* 537 */         updateSikaku(x1, i, 3, true);
/* 538 */         updateSikaku(x2, i, 1, true);
/*     */       } 
/*     */     } 
/*     */     
/* 542 */     x1 = x2 = 0; y1 = y2 = 0;
/* 543 */     (new Thread(solveThread)).start();
/* 544 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void mouseDragged(MouseEvent e) {
/* 548 */     if (!setDragCoordinates(e))
/* 549 */       return;  restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SikakuSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */