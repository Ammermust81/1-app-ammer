/*      */ package crosswordexpress;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextField;
/*      */ 
/*      */ public class Sixpack extends JPanel {
/*      */   static JFrame jfSixpack;
/*      */   static int frameX;
/*      */   static int frameY;
/*      */   static JTextField jtfStart;
/*      */   static JTextField jtfPh;
/*      */   static JTextField jtfSh;
/*      */   static JTextField jtfAk;
/*      */   static JTextField jtfDm;
/*      */   static JTextField jtfFi;
/*      */   static JTextField jtfFu;
/*   25 */   static JLabel jlChart = null; static JTextField jtfGk; static JTextField jtfKk; static JTextField jtfKe; static JTextField jtfMa; static JTextField jtfMs; static JTextField jtfRa; static JTextField jtfSk; static JTextField jtfSl; static JTextField jtfSu; static JTextField jtfTe; static JTextField jtfTt;
/*      */   static JTextArea jtaRule;
/*      */   static JTextArea jtaLang;
/*      */   static JPanel kbp;
/*      */   static JDialog jdlgRules;
/*      */   static int kdppuzzle;
/*   31 */   static JLabel[] jlP = new JLabel[6];
/*   32 */   JComboBox[] jcbbP = new JComboBox[6]; static JComboBox<String> jcbbL; static JComboBox<String> jcbbD; static JLabel jlK; JCheckBox jcbVaryDiff; JCheckBox jcbPrintPuzColor; JCheckBox jcbPrintSolColor;
/*      */   JCheckBox jcbPuzM;
/*      */   JCheckBox jcbSolM;
/*      */   JCheckBox jcbPuzK;
/*      */   JCheckBox jcbSolK;
/*   37 */   static int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); static int hmPuz; static int whichPuz;
/*      */   static Timer myTimer;
/*   39 */   static JRadioButton[] jrbExportMode = new JRadioButton[5];
/*      */   static boolean puzSol;
/*      */   static boolean puzM;
/*      */   static boolean solM;
/*   43 */   static int[] selModes = new int[] { 1, 2, 3, 4, 5, 6 }; JButton jbNewCus; JButton jbPrintT; JButton jbPrintM; JButton jbPrintKdpSpPuzzles; JButton jbPrintKdpSpSolutions; JButton jbPrintK; JButton jbBuild;
/*      */   JButton jbQuit;
/*      */   JButton jbHelp;
/*   46 */   static String[] puzType = new String[] { "", " Akari", " Domino", " Fillomino", " Futoshiki", " Gokigen", " Kakuro", " Kendoku", " Marupeke", " Minesweeper", " Roundabouts", " Sikaku", " Slitherlink", " Sudoku", " Tatami", " Tents" };
/*      */ 
/*      */ 
/*      */   
/*   50 */   static int[] puzMode = new int[] { -1, 20, 40, 70, 80, 90, 100, 110, 230, 132, 150, 160, 170, 180, 182, 190 };
/*      */ 
/*      */ 
/*      */   
/*   54 */   static String[] rule = new String[] { AkariBuild.rules, DominoBuild.rules, FillominoBuild.rules, FutoshikiBuild.rules, GokigenBuild.rules, KakuroBuild.rules, KendokuBuild.rules, MarupekeBuild.rules, MinesweeperBuild.rules, RoundaboutsBuild.rules, SikakuBuild.rules, SlitherlinkBuild.rules, SudokuBuild.rules, TatamiBuild.rules, TentsBuild.rules };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*   60 */     Op.updateOption(Op.SX.SxRuleLang.ordinal(), "", Op.sx);
/*   61 */     Op.updateOption(Op.SX.SxRuleLangIndex.ordinal(), "0", Op.sx);
/*   62 */     Op.updateOption(Op.SX.SxDateFormat.ordinal(), "", Op.sx);
/*   63 */     Op.updateOption(Op.SX.SxDateFormatIndex.ordinal(), "0", Op.sx);
/*   64 */     Op.updateOption(Op.SX.SxPuzA.ordinal(), "0", Op.sx);
/*   65 */     Op.updateOption(Op.SX.SxPuzB.ordinal(), "0", Op.sx);
/*   66 */     Op.updateOption(Op.SX.SxPuzC.ordinal(), "0", Op.sx);
/*   67 */     Op.updateOption(Op.SX.SxPuzD.ordinal(), "0", Op.sx);
/*   68 */     Op.updateOption(Op.SX.SxPuzE.ordinal(), "0", Op.sx);
/*   69 */     Op.updateOption(Op.SX.SxPuzF.ordinal(), "0", Op.sx);
/*   70 */     Op.updateOption(Op.SX.SxW.ordinal(), "715", Op.sx);
/*   71 */     Op.updateOption(Op.SX.SxH.ordinal(), "915", Op.sx);
/*   72 */     Op.updateOption(Op.SX.SxPuzColor.ordinal(), "false", Op.sx);
/*   73 */     Op.updateOption(Op.SX.SxSolColor.ordinal(), "false", Op.sx);
/*   74 */     Op.updateOption(Op.SX.VaryDiff.ordinal(), "false", Op.sx);
/*   75 */     Op.updateOption(Op.SX.SxInstructions.ordinal(), "false", Op.sx);
/*      */   }
/*      */   
/*   78 */   String graphicExportOptions = "<div>This function allows you to export a puzzle to the System Clipboard, or to a Graphics file. The layout of the exported puzzle will be the same as depicted in the Print Preview panel. The Options you can change before exporting the puzzle are as follows:-</div><ul><li/><span>Export Mode.</span> The default Export Mode is the <b>PNG</b> format, but you can select any of the other modes by selecting the appropriate radio button. The modes currently supported are <b>BMP, GIF, JPG, PNG</b> and <b>System Clipboard.</b> All exports will be done using a resolution of 72 PPI except for <b>PNG</b> exports which will use the current resolution value set for normal puzzle export operations.<p/><li/><span>Graphic width:</span> The default export width is set to 150mm, but you can change this to whatever value suits your requirements. The height of the graphic will be automatically scaled to maintain the correct size ratio.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   91 */   String sixpackHelp = "<div>A Six-pack Puzzle is not really a puzzle in its own right. It is a collection of six puzzles selected from the extensive list of puzzles which can be made using Crossword Express. This list of puzzles will grow over time with a potential target of some twenty puzzles. The controls used in Building and Printing a Six-pack puzzle are as follows:</div><br/><ul><li/><b>Select the Puzzles: </b>This panel contains a set of six combo boxes each containing a list of all of the puzzles available for use in six-pack puzzles. Select a different puzzle type from each of the combo boxes.<p/><li/><b>Edit Rules: </b>If you are building Sixpack puzzles in a language other than English, you will want to create a rule in that language to attach to the puzzle. This button will take you to a dialog which contains all of the facilities needed to take care of that.<p/><li/><b>Select Rule Language: </b>This Combo Box provides the means of selecting the language you intend to use for the rules that will be attached to the puzzle you are about to print.<p/><li/><b>Multi Puzzle Control</b><ul><li/><b>How many puzzles: </b>If you want to build or print a number of sixpack puzzles, simply type a number into this input field. When you issue the Build or Print command, Crossword Express will process that number of puzzles.<p/><li/><b>ID of 1st Puzzle: </b>The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is processed, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be processed in a single operation using this feature. If you prefer not to use the date numbering approach, you can simply enter a numerical value which must be less than eight digits.<p/><li/><b>Vary Difficulty on 7 day cycle: </b>Publishers of daily newspapers may wish to have puzzles which vary in difficulty over the course of each week. Selecting this check-box will vary the difficulty with the easiest being on Monday (number 1, and every 7th puzzle thereafter) and the hardest on Sunday (number 7, and every 7th puzzle thereafter).<p/><li/><b>Build all Puzzles</b> Clicking this button will result in the creation of a series of puzzles in accordance with the options selected above.</ul><li/><b>Sixpack Options</b><ul><li/><b>Print with Color: </b>Normally, Six-pack puzzles and solutions will be printed in black and white, but if you are producing puzzles for a color publication, you can elect to have them printed in full color. Check boxes are provided to allow independent control of this function for puzzles and solutions. These options work for both standard sixpack puzzles and for the printing of KDP puzzle booklets.<p/><li/><b>Print Puzzle Rules: </b>Checking this box will result in a brief set of Rules being printed immediately below each of the puzzles.<p/><li/><b>Print Puz & Sol on same page: </b>Checking this box will result in both Puzzle and Solution being printed on a single page. If left unchecked, Puzzle and Solution will be printed on separate pages.<p/></ul><li/><b>Export Standard Sixpack </b><br><b>Export Puzzle</b> and <b>Export Solution</b> give you the option of exporting either the puzzles or the solutions for a given six-pack puzzle. The puzzle exported will be selected by reference to the <b>ID of 1st puzzle</b> value. In either case, a dialog will appear in which you can choose to export to a graphics file in one of the formats <b>BMP, GIF, JPG, or PNG</b>, or to the system Clipboard. If exporting to a graphics file, the PNG format is recommended, as these files are rendered with a significantly higher resolution.<p/><li/><b>Print Standard Sixpack Puzzles: </b>Clicking this button will result in the printing of the requested number of puzzles in the standard <b>Sixpack</b> format. Each odd numbered page will contain one set of six puzzles, while each even numbered page will contain the solutions for the puzzles on the immediately preceding page. Normally you should print to a PDF file (use Primo PDF or similar in the case of Windows).<p/><li/><b>Print KDP Sixpack</b><br>Separate buttons are provided to print KDP publication ready PDF files of Puzzles or Solutions.<p/><li/>If you are creating puzzles in languages other than English, you may want to change some of the headings used in the published puzzles. An edit field is provided for each of these headings, and for the names of each of the fifteen available puzzle types. If nothing is entered in these fields, the default English names will be used.<p/></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   static String sixpackRulesHelp = "<div>Each of the puzzles within a Sixpack puzzle can be associated with a set of rules which explain what must be done to complete the solution of the puzzle. Naturally, Crossword Express users would like these rules to be expressed in the language of the person who will be solving the puzzle. The <b>Edit Sixpack Rules</b> dialog provides a simple editing environment which allows the rules for each puzzle type to be entered and saved in five different languages in addition to the default language which is English. Following are the controls and input fields required to achieve this.</div><br/><ul><li/><b>Select Puzzle Type : </b>Use this Combo Box to select the puzzle type whose Rule set you want to edit.<p/><li/><b>Select the Language : </b>Use this Combo Box to select the language of the Rule you will be editing.<p/><li/><b>Edit Rule : </b>This button places the English Rule into the English display field, and sets you up to begin entering or editing the <b>Other</b> Language Rule.<p/><li/><b>Save Rule : </b>Make a permanent copy of the Rule you have just edited into the Options file for Sixpack puzzles.<p/><li/><b>Edit Language Names : </b>This button gives you a small dialog in which you can enter the names of the <b>Other</b> languages you will be using.<p/><li/><b>English Language Rule display field : </b>This field displays the text of the English Rule to assist you with the translation process as you enter the <b>Other</b> Language Rule.<p/><li/><b>Other Language Rule input field : </b>Enter the translated rule for each language into this field.<p/><li/><b>Attach Auxiliary Keyboard : </b>If you are entering a rule in a language which uses a different alphabet to that used by English, you can use this button to obtain access to a simulated keyboard which contains every chatacter in the Unicode specification.<p/><li/><b>Detach Auxiliary Keyboard : </b>When you no longer need the auxiliary keyboard, this button will disconnect it<p/><li/><b>OK : </b>Exit the <b>Edit Sixpack Rules</b> dialog, making sure that the most recently edited Other Language rule has been saved to the Sixpack Options file.<p/><li/><b>Quit : </b>Exit the <b>Edit Sixpack Rules</b> dialog. The current Other Language rule will not be saved, even if you have made changes to it.<p/></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Sixpack(JFrame jfCWE) {
/*      */     int i;
/*  190 */     for (i = 0; i < 6; i++) {
/*  191 */       for (int j = 1; j < puzType.length; j++) {
/*  192 */         if (Op.getInt(Op.SX.SxPuzA.ordinal() + i, Op.sx) == puzMode[j])
/*  193 */           selModes[i] = j; 
/*      */       } 
/*  195 */     }  Def.dispCursor = Boolean.valueOf(false);
/*  196 */     Def.puzzleMode = 8;
/*  197 */     Methods.havePuzzle = true;
/*      */     
/*  199 */     jfSixpack = new JFrame("Sixpack");
/*  200 */     jfSixpack.setSize(Op.getInt(Op.SX.SxW.ordinal(), Op.sx), Op.getInt(Op.SX.SxH.ordinal(), Op.sx));
/*  201 */     int frameX = (jfCWE.getX() + jfSixpack.getWidth() > Methods.scrW) ? (Methods.scrW - jfSixpack.getWidth() - 10) : jfCWE.getX();
/*  202 */     jfSixpack.setLocation(frameX, jfCWE.getY());
/*  203 */     jfSixpack.setLayout((LayoutManager)null);
/*  204 */     jfSixpack.setDefaultCloseOperation(0);
/*  205 */     jfSixpack
/*  206 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  208 */             Sixpack.saveAllOptions();
/*  209 */             Sixpack.jfSixpack.dispose();
/*  210 */             CrosswordExpress.jfCWE.setVisible(true);
/*  211 */             Methods.closeHelp();
/*  212 */             Def.puzzleMode = 1;
/*  213 */             Def.dispCursor = Boolean.valueOf(true);
/*      */           }
/*      */         });
/*      */     
/*  217 */     Methods.closeHelp();
/*      */     
/*  219 */     JPanel jpLeft = new JPanel();
/*  220 */     jpLeft.setLayout((LayoutManager)null);
/*  221 */     jpLeft.setSize(245, 900);
/*  222 */     jpLeft.setLocation(5, 5);
/*  223 */     jpLeft.setOpaque(true);
/*  224 */     jpLeft.setBorder(BorderFactory.createEmptyBorder());
/*  225 */     jfSixpack.add(jpLeft);
/*      */     
/*  227 */     JPanel jpPuzzles = new JPanel();
/*  228 */     jpPuzzles.setLayout((LayoutManager)null);
/*  229 */     jpPuzzles.setSize(225, 215);
/*  230 */     jpPuzzles.setLocation(5, 5);
/*  231 */     jpPuzzles.setBackground(new Color(13873029));
/*  232 */     jpPuzzles.setOpaque(true);
/*  233 */     jpPuzzles.setBorder(BorderFactory.createEtchedBorder());
/*  234 */     jpLeft.add(jpPuzzles);
/*      */     
/*  236 */     JLabel jl = new JLabel("Select the Puzzles");
/*  237 */     jl.setForeground(Def.COLOR_LABEL);
/*  238 */     jl.setSize(225, 20);
/*  239 */     jl.setLocation(5, 5);
/*  240 */     jl.setHorizontalAlignment(0);
/*  241 */     jpPuzzles.add(jl);
/*      */     
/*  243 */     for (i = 0; i < 6; i++) {
/*  244 */       jlP[i] = new JLabel("Puzzle " + (i + 1) + ":");
/*  245 */       jlP[i].setForeground(Def.COLOR_LABEL);
/*  246 */       jlP[i].setSize(65, 20);
/*  247 */       jlP[i].setLocation(5, 30 + i * 30);
/*  248 */       jlP[i].setHorizontalAlignment(4);
/*  249 */       jpPuzzles.add(jlP[i]);
/*      */       
/*  251 */       this.jcbbP[i] = new JComboBox<>(puzType);
/*  252 */       this.jcbbP[i].setSize(135, 23);
/*  253 */       this.jcbbP[i].setLocation(80, 30 + i * 30);
/*  254 */       this.jcbbP[i].setBackground(Def.COLOR_BUTTONBG);
/*  255 */       jpPuzzles.add(this.jcbbP[i]);
/*      */       
/*  257 */       this.jcbbP[i].setSelectedIndex(selModes[i]);
/*      */     } 
/*      */     
/*  260 */     JButton jbEditRules = Methods.cweButton("Edit Puzzle Rules", 5, 230, 225, 26, null);
/*  261 */     jbEditRules.addActionListener(e -> {
/*      */           Methods.closeHelp();
/*      */           sixpackRules();
/*      */         });
/*  265 */     jpLeft.add(jbEditRules);
/*      */     
/*  267 */     JPanel jpSRL = new JPanel();
/*  268 */     jpSRL.setLayout((LayoutManager)null);
/*  269 */     jpSRL.setSize(225, 60);
/*  270 */     jpSRL.setLocation(5, 266);
/*  271 */     jpSRL.setOpaque(true);
/*  272 */     jpSRL.setBorder(BorderFactory.createEtchedBorder());
/*  273 */     jpLeft.add(jpSRL);
/*      */     
/*  275 */     jl = new JLabel("Select Rule Language");
/*  276 */     jl.setForeground(Def.COLOR_LABEL);
/*  277 */     jl.setSize(225, 20);
/*  278 */     jl.setLocation(5, 3);
/*  279 */     jl.setHorizontalAlignment(0);
/*  280 */     jpSRL.add(jl);
/*      */     
/*  282 */     jcbbL = new JComboBox<>();
/*  283 */     jcbbL.setSize(165, 23);
/*  284 */     jcbbL.setLocation(30, 26);
/*  285 */     jcbbL.setBackground(Def.COLOR_BUTTONBG);
/*  286 */     jcbbL.addItem("English");
/*  287 */     for (i = 0; i < 5; i++)
/*  288 */       jcbbL.addItem(Op.sx[Op.SX.SxLang1.ordinal() + i]); 
/*  289 */     jcbbL.setSelectedIndex(Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx));
/*  290 */     jpSRL.add(jcbbL);
/*      */     
/*  292 */     JPanel jpMPC = new JPanel();
/*  293 */     jpMPC.setLayout((LayoutManager)null);
/*  294 */     jpMPC.setSize(225, 150);
/*  295 */     jpMPC.setLocation(5, 356);
/*  296 */     jpMPC.setBackground(new Color(13873029));
/*  297 */     jpMPC.setOpaque(true);
/*  298 */     jpMPC.setBorder(BorderFactory.createEtchedBorder());
/*  299 */     jpLeft.add(jpMPC);
/*      */     
/*  301 */     JLabel jlMulti = new JLabel("Multi Puzzle Control");
/*  302 */     jlMulti.setForeground(Def.COLOR_LABEL);
/*  303 */     jlMulti.setSize(225, 20);
/*  304 */     jlMulti.setLocation(5, 3);
/*  305 */     jlMulti.setHorizontalAlignment(0);
/*  306 */     jpMPC.add(jlMulti);
/*      */     
/*  308 */     JLabel jlHowMany = new JLabel("How many puzzles:");
/*  309 */     jlHowMany.setForeground(Def.COLOR_LABEL);
/*  310 */     jlHowMany.setSize(120, 20);
/*  311 */     jlHowMany.setLocation(5, 28);
/*  312 */     jlHowMany.setHorizontalAlignment(4);
/*  313 */     jpMPC.add(jlHowMany);
/*      */     
/*  315 */     JTextField jtfHowMany = new JTextField("1", 30);
/*  316 */     jtfHowMany.setSize(50, 20);
/*  317 */     jtfHowMany.setLocation(150, 28);
/*  318 */     jtfHowMany.selectAll();
/*  319 */     jtfHowMany.setHorizontalAlignment(4);
/*  320 */     jpMPC.add(jtfHowMany);
/*      */     
/*  322 */     JLabel jlStart = new JLabel("ID of 1st puzzle:");
/*  323 */     jlStart.setForeground(Def.COLOR_LABEL);
/*  324 */     jlStart.setSize(120, 20);
/*  325 */     jlStart.setLocation(5, 55);
/*  326 */     jlStart.setHorizontalAlignment(2);
/*  327 */     jpMPC.add(jlStart);
/*      */     
/*  329 */     jtfStart = new JTextField("" + startPuz, 30);
/*  330 */     jtfStart.setSize(74, 20);
/*  331 */     jtfStart.setLocation(140, 55);
/*  332 */     jtfStart.selectAll();
/*  333 */     jtfStart.setHorizontalAlignment(2);
/*  334 */     jpMPC.add(jtfStart);
/*      */     
/*  336 */     this.jcbVaryDiff = new JCheckBox("Vary Difficulty on 7 day cycle", false);
/*  337 */     this.jcbVaryDiff.setForeground(Def.COLOR_LABEL);
/*  338 */     this.jcbVaryDiff.setOpaque(false);
/*  339 */     this.jcbVaryDiff.setSize(225, 20);
/*  340 */     this.jcbVaryDiff.setLocation(5, 80);
/*  341 */     jpMPC.add(this.jcbVaryDiff);
/*      */     
/*  343 */     this.jbBuild = Methods.cweButton("Build all Puzzles", 10, 108, 205, 30, null);
/*  344 */     this.jbBuild.addActionListener(e -> {
/*      */           hmPuz = Integer.parseInt(paramJTextField.getText());
/*      */           startPuz = Integer.parseInt(jtfStart.getText());
/*      */           Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(this.jcbVaryDiff.isSelected()), Op.sx);
/*      */           if (hmPuz > 1) {
/*      */             for (int k = 0; k < 6; k++) {
/*      */               Op.setInt(Op.SX.SxPuzA.ordinal() + k, puzMode[this.jcbbP[k].getSelectedIndex()], Op.sx);
/*      */             }
/*      */             whichPuz = 0;
/*      */             buildAll();
/*      */           } 
/*      */         });
/*  356 */     jpMPC.add(this.jbBuild);
/*      */     
/*  358 */     JPanel jpMisc = new JPanel();
/*  359 */     jpMisc.setLayout((LayoutManager)null);
/*  360 */     jpMisc.setSize(225, 183);
/*  361 */     jpMisc.setLocation(5, 537);
/*  362 */     jpMisc.setOpaque(true);
/*  363 */     jpMisc.setBorder(BorderFactory.createEtchedBorder());
/*  364 */     jpLeft.add(jpMisc);
/*      */     
/*  366 */     JLabel jlOpts = new JLabel("Sixpack Options");
/*  367 */     jlOpts.setForeground(Def.COLOR_LABEL);
/*  368 */     jlOpts.setSize(225, 20);
/*  369 */     jlOpts.setLocation(5, 3);
/*  370 */     jlOpts.setHorizontalAlignment(0);
/*  371 */     jpMisc.add(jlOpts);
/*      */     
/*  373 */     this.jcbPrintPuzColor = new JCheckBox("Print Puzzle with Color", false);
/*  374 */     this.jcbPrintPuzColor.setForeground(Def.COLOR_LABEL);
/*  375 */     this.jcbPrintPuzColor.setOpaque(false);
/*  376 */     this.jcbPrintPuzColor.setSize(225, 20);
/*  377 */     this.jcbPrintPuzColor.setLocation(5, 28);
/*  378 */     jpMisc.add(this.jcbPrintPuzColor);
/*      */     
/*  380 */     this.jcbPrintSolColor = new JCheckBox("Print Solution with Color", false);
/*  381 */     this.jcbPrintSolColor.setForeground(Def.COLOR_LABEL);
/*  382 */     this.jcbPrintSolColor.setOpaque(false);
/*  383 */     this.jcbPrintSolColor.setSize(225, 20);
/*  384 */     this.jcbPrintSolColor.setLocation(5, 49);
/*  385 */     jpMisc.add(this.jcbPrintSolColor);
/*      */     
/*  387 */     JCheckBox jcbPrintInst = new JCheckBox("Print Puzzle Rules", false);
/*  388 */     jcbPrintInst.setForeground(Def.COLOR_LABEL);
/*  389 */     jcbPrintInst.setOpaque(false);
/*  390 */     jcbPrintInst.setSize(225, 20);
/*  391 */     jcbPrintInst.setLocation(5, 70);
/*  392 */     jpMisc.add(jcbPrintInst);
/*      */     
/*  394 */     JCheckBox jcbPrintPuzSol = new JCheckBox("Print Puz & Sol on same page", false);
/*  395 */     jcbPrintPuzSol.setForeground(Def.COLOR_LABEL);
/*  396 */     jcbPrintPuzSol.setOpaque(false);
/*  397 */     jcbPrintPuzSol.setSize(225, 20);
/*  398 */     jcbPrintPuzSol.setLocation(5, 91);
/*  399 */     jpMisc.add(jcbPrintPuzSol);
/*      */     
/*  401 */     String[] dateFormat = { "Norwegian", "English", "USA", "Puzzle number" };
/*  402 */     jl = new JLabel("Select Date Format");
/*  403 */     jl.setForeground(Def.COLOR_LABEL);
/*  404 */     jl.setSize(225, 20);
/*  405 */     jl.setLocation(5, 123);
/*  406 */     jl.setHorizontalAlignment(0);
/*  407 */     jpMisc.add(jl);
/*      */     
/*  409 */     jcbbD = new JComboBox<>(dateFormat);
/*  410 */     jcbbD.setSize(165, 23);
/*  411 */     jcbbD.setLocation(30, 146);
/*  412 */     jcbbD.setBackground(Def.COLOR_BUTTONBG);
/*  413 */     jcbbD.setSelectedIndex(Op.getInt(Op.SX.SxDateFormatIndex.ordinal(), Op.sx));
/*  414 */     jpMisc.add(jcbbD);
/*      */     
/*  416 */     JPanel jpExp = new JPanel();
/*  417 */     jpExp.setLayout((LayoutManager)null);
/*  418 */     jpExp.setSize(225, 100);
/*  419 */     jpExp.setLocation(252, 160);
/*  420 */     jpExp.setOpaque(true);
/*  421 */     jpExp.setBorder(BorderFactory.createEtchedBorder());
/*  422 */     jfSixpack.add(jpExp);
/*      */     
/*  424 */     JLabel jlExp = new JLabel("Export Standard Sixpack");
/*  425 */     jlExp.setForeground(Def.COLOR_LABEL);
/*  426 */     jlExp.setSize(225, 20);
/*  427 */     jlExp.setLocation(5, 3);
/*  428 */     jlExp.setHorizontalAlignment(0);
/*  429 */     jpExp.add(jlExp);
/*      */     
/*  431 */     JButton jbExportP = Methods.cweButton("Export Puzzle", 10, 25, 205, 30, null);
/*  432 */     jbExportP.addActionListener(e -> {
/*      */           Op.setBool(Op.SX.SxPuzColor.ordinal(), Boolean.valueOf(this.jcbPrintPuzColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxSolColor.ordinal(), Boolean.valueOf(this.jcbPrintSolColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxInstructions.ordinal(), Boolean.valueOf(paramJCheckBox1.isSelected()), Op.sx);
/*      */           puzSol = paramJCheckBox2.isSelected();
/*      */           getTitles();
/*      */           exportGraphic('P');
/*      */         });
/*  440 */     jpExp.add(jbExportP);
/*      */     
/*  442 */     JButton jbExportS = Methods.cweButton("Export Solution", 10, 60, 205, 30, null);
/*  443 */     jbExportS.addActionListener(e -> {
/*      */           Op.setBool(Op.SX.SxPuzColor.ordinal(), Boolean.valueOf(this.jcbPrintPuzColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxSolColor.ordinal(), Boolean.valueOf(this.jcbPrintSolColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxInstructions.ordinal(), Boolean.valueOf(paramJCheckBox1.isSelected()), Op.sx);
/*      */           puzSol = paramJCheckBox2.isSelected();
/*      */           getTitles();
/*      */           exportGraphic('S');
/*      */         });
/*  451 */     jpExp.add(jbExportS);
/*      */     
/*  453 */     this.jbPrintT = Methods.cweButton("Print Standard Sixpack Puzzles", 252, 310, 225, 30, null);
/*  454 */     this.jbPrintT.addActionListener(e -> {
/*      */           Op.setBool(Op.SX.SxPuzColor.ordinal(), Boolean.valueOf(this.jcbPrintPuzColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxSolColor.ordinal(), Boolean.valueOf(this.jcbPrintSolColor.isSelected()), Op.sx);
/*      */           Op.setBool(Op.SX.SxInstructions.ordinal(), Boolean.valueOf(paramJCheckBox1.isSelected()), Op.sx);
/*      */           puzSol = paramJCheckBox2.isSelected();
/*      */           getTitles();
/*      */           hmPuz = Integer.parseInt(paramJTextField.getText());
/*      */           startPuz = Integer.parseInt(jtfStart.getText());
/*      */           for (int k = 0; k < 6; k++) {
/*      */             Op.setInt(Op.SX.SxPuzA.ordinal() + k, puzMode[this.jcbbP[k].getSelectedIndex()], Op.sx);
/*      */           }
/*      */           Def.puzzleMode = 8;
/*      */           printProcessT();
/*      */           jfSixpack.requestFocus();
/*      */         });
/*  469 */     jfSixpack.add(this.jbPrintT);
/*      */     
/*  471 */     JPanel jpPrintSixpack = new JPanel();
/*  472 */     jpPrintSixpack.setLayout((LayoutManager)null);
/*  473 */     jpPrintSixpack.setSize(225, 100);
/*  474 */     jpPrintSixpack.setLocation(252, 380);
/*  475 */     jpPrintSixpack.setBackground(new Color(13873029));
/*  476 */     jpPrintSixpack.setOpaque(true);
/*  477 */     jpPrintSixpack.setBorder(BorderFactory.createEtchedBorder());
/*  478 */     jfSixpack.add(jpPrintSixpack);
/*      */     
/*  480 */     JLabel jlPrintSixpack = new JLabel("Print KDP Sixpack");
/*  481 */     jlPrintSixpack.setForeground(Def.COLOR_LABEL);
/*  482 */     jlPrintSixpack.setSize(225, 20);
/*  483 */     jlPrintSixpack.setLocation(5, 3);
/*  484 */     jlPrintSixpack.setHorizontalAlignment(0);
/*  485 */     jpPrintSixpack.add(jlPrintSixpack);
/*      */     
/*  487 */     this.jbPrintKdpSpPuzzles = Methods.cweButton("Print the Puzzles", 10, 25, 205, 30, null);
/*  488 */     this.jbPrintKdpSpPuzzles.addActionListener(e -> {
/*      */           getKDPdetails(paramJCheckBox1, paramJCheckBox2, paramJTextField);
/*      */           printProcessMpuz();
/*      */           jfSixpack.requestFocus();
/*      */         });
/*  493 */     jpPrintSixpack.add(this.jbPrintKdpSpPuzzles);
/*      */     
/*  495 */     this.jbPrintKdpSpSolutions = Methods.cweButton("Print the Solutions", 10, 60, 205, 30, null);
/*  496 */     this.jbPrintKdpSpSolutions.addActionListener(e -> {
/*      */           getKDPdetails(paramJCheckBox1, paramJCheckBox2, paramJTextField);
/*      */           printProcessMsol();
/*      */           jfSixpack.requestFocus();
/*      */         });
/*  501 */     jpPrintSixpack.add(this.jbPrintKdpSpSolutions);
/*      */     
/*  503 */     this.jbQuit = Methods.cweButton("Quit", 252, 520, 225, 30, null);
/*  504 */     this.jbQuit.addActionListener(e -> {
/*      */           saveAllOptions();
/*      */           jfSixpack.dispose();
/*      */           CrosswordExpress.jfCWE.setVisible(true);
/*      */           Def.puzzleMode = 1;
/*      */           Methods.closeHelp();
/*      */           Def.dispCursor = Boolean.valueOf(true);
/*      */         });
/*  512 */     jfSixpack.add(this.jbQuit);
/*      */     
/*  514 */     this.jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 252, 560, 225, 60, new ImageIcon("graphics/help.png"));
/*  515 */     this.jbHelp.addActionListener(e -> Methods.cweHelp(jfSixpack, null, "Building Sixpack Puzzles", this.sixpackHelp));
/*      */ 
/*      */     
/*  518 */     jfSixpack.add(this.jbHelp);
/*      */     
/*  520 */     JLabel jlPh = new JLabel("Puzzle Heading for Printing");
/*  521 */     jlPh.setForeground(Def.COLOR_LABEL);
/*  522 */     jlPh.setSize(205, 20);
/*  523 */     jlPh.setLocation(500, 10);
/*  524 */     jlPh.setHorizontalAlignment(0);
/*  525 */     jfSixpack.add(jlPh);
/*  526 */     jtfPh = new JTextField();
/*  527 */     jtfPh.setSize(205, 25);
/*  528 */     jtfPh.setLocation(500, 32);
/*  529 */     jtfPh.setText(Op.sx[Op.SX.SxPuzTitle.ordinal()]);
/*  530 */     jtfPh.setBackground(new Color(16777215));
/*  531 */     jtfPh.setFont(new Font("SansSerif", 0, 14));
/*  532 */     jfSixpack.add(jtfPh);
/*      */     
/*  534 */     JLabel jlSh = new JLabel("Solution Heading for Printing");
/*  535 */     jlSh.setForeground(Def.COLOR_LABEL);
/*  536 */     jlSh.setSize(205, 20);
/*  537 */     jlSh.setLocation(500, 60);
/*  538 */     jlSh.setHorizontalAlignment(0);
/*  539 */     jfSixpack.add(jlSh);
/*  540 */     jtfSh = new JTextField();
/*  541 */     jtfSh.setSize(205, 25);
/*  542 */     jtfSh.setLocation(500, 82);
/*  543 */     jtfSh.setText(Op.sx[Op.SX.SxSolTitle.ordinal()]);
/*  544 */     jtfSh.setBackground(new Color(16777215));
/*  545 */     jtfSh.setFont(new Font("SansSerif", 0, 14));
/*  546 */     jfSixpack.add(jtfSh);
/*      */     
/*  548 */     JLabel jlAk = new JLabel("Other name for Akari");
/*  549 */     jlAk.setForeground(Def.COLOR_LABEL);
/*  550 */     jlAk.setSize(205, 20);
/*  551 */     jlAk.setLocation(500, 110);
/*  552 */     jlAk.setHorizontalAlignment(0);
/*  553 */     jfSixpack.add(jlAk);
/*  554 */     jtfAk = new JTextField();
/*  555 */     jtfAk.setSize(205, 25);
/*  556 */     jtfAk.setLocation(500, 132);
/*  557 */     jtfAk.setText(Op.sx[Op.SX.SxAk.ordinal()]);
/*  558 */     jtfAk.setBackground(new Color(16777215));
/*  559 */     jtfAk.setFont(new Font("SansSerif", 0, 14));
/*  560 */     jfSixpack.add(jtfAk);
/*      */     
/*  562 */     JLabel jlDm = new JLabel("Other name for Domino");
/*  563 */     jlDm.setForeground(Def.COLOR_LABEL);
/*  564 */     jlDm.setSize(205, 20);
/*  565 */     jlDm.setLocation(500, 160);
/*  566 */     jlDm.setHorizontalAlignment(0);
/*  567 */     jfSixpack.add(jlDm);
/*  568 */     jtfDm = new JTextField();
/*  569 */     jtfDm.setSize(205, 25);
/*  570 */     jtfDm.setLocation(500, 182);
/*  571 */     jtfDm.setText(Op.sx[Op.SX.SxDm.ordinal()]);
/*  572 */     jtfDm.setBackground(new Color(16777215));
/*  573 */     jtfDm.setFont(new Font("SansSerif", 0, 14));
/*  574 */     jfSixpack.add(jtfDm);
/*      */     
/*  576 */     JLabel jlFi = new JLabel("Other name for Fillomino");
/*  577 */     jlFi.setForeground(Def.COLOR_LABEL);
/*  578 */     jlFi.setSize(205, 20);
/*  579 */     jlFi.setLocation(500, 210);
/*  580 */     jlFi.setHorizontalAlignment(0);
/*  581 */     jfSixpack.add(jlFi);
/*  582 */     jtfFi = new JTextField();
/*  583 */     jtfFi.setSize(205, 25);
/*  584 */     jtfFi.setLocation(500, 232);
/*  585 */     jtfFi.setText(Op.sx[Op.SX.SxFi.ordinal()]);
/*  586 */     jtfFi.setBackground(new Color(16777215));
/*  587 */     jtfFi.setFont(new Font("SansSerif", 0, 14));
/*  588 */     jfSixpack.add(jtfFi);
/*      */     
/*  590 */     JLabel jlFu = new JLabel("Other name for Futoshiki");
/*  591 */     jlFu.setForeground(Def.COLOR_LABEL);
/*  592 */     jlFu.setSize(205, 20);
/*  593 */     jlFu.setLocation(500, 260);
/*  594 */     jlFu.setHorizontalAlignment(0);
/*  595 */     jfSixpack.add(jlFu);
/*  596 */     jtfFu = new JTextField();
/*  597 */     jtfFu.setSize(205, 25);
/*  598 */     jtfFu.setLocation(500, 282);
/*  599 */     jtfFu.setText(Op.sx[Op.SX.SxFu.ordinal()]);
/*  600 */     jtfFu.setBackground(new Color(16777215));
/*  601 */     jtfFu.setFont(new Font("SansSerif", 0, 14));
/*  602 */     jfSixpack.add(jtfFu);
/*      */     
/*  604 */     JLabel jlGk = new JLabel("Other name for Gokigen");
/*  605 */     jlGk.setForeground(Def.COLOR_LABEL);
/*  606 */     jlGk.setSize(205, 20);
/*  607 */     jlGk.setLocation(500, 310);
/*  608 */     jlGk.setHorizontalAlignment(0);
/*  609 */     jfSixpack.add(jlGk);
/*  610 */     jtfGk = new JTextField();
/*  611 */     jtfGk.setSize(205, 25);
/*  612 */     jtfGk.setLocation(500, 332);
/*  613 */     jtfGk.setText(Op.sx[Op.SX.SxGk.ordinal()]);
/*  614 */     jtfGk.setBackground(new Color(16777215));
/*  615 */     jtfGk.setFont(new Font("SansSerif", 0, 14));
/*  616 */     jfSixpack.add(jtfGk);
/*      */     
/*  618 */     JLabel jlKk = new JLabel("Other name for Kakuro");
/*  619 */     jlKk.setForeground(Def.COLOR_LABEL);
/*  620 */     jlKk.setSize(205, 20);
/*  621 */     jlKk.setLocation(500, 360);
/*  622 */     jlKk.setHorizontalAlignment(0);
/*  623 */     jfSixpack.add(jlKk);
/*  624 */     jtfKk = new JTextField();
/*  625 */     jtfKk.setSize(205, 25);
/*  626 */     jtfKk.setLocation(500, 382);
/*  627 */     jtfKk.setText(Op.sx[Op.SX.SxKk.ordinal()]);
/*  628 */     jtfKk.setBackground(new Color(16777215));
/*  629 */     jtfKk.setFont(new Font("SansSerif", 0, 14));
/*  630 */     jfSixpack.add(jtfKk);
/*      */     
/*  632 */     JLabel jlKe = new JLabel("Other name for Kendoku");
/*  633 */     jlKe.setForeground(Def.COLOR_LABEL);
/*  634 */     jlKe.setSize(205, 20);
/*  635 */     jlKe.setLocation(500, 410);
/*  636 */     jlKe.setHorizontalAlignment(0);
/*  637 */     jfSixpack.add(jlKe);
/*  638 */     jtfKe = new JTextField();
/*  639 */     jtfKe.setSize(205, 25);
/*  640 */     jtfKe.setLocation(500, 432);
/*  641 */     jtfKe.setText(Op.sx[Op.SX.SxKe.ordinal()]);
/*  642 */     jtfKe.setBackground(new Color(16777215));
/*  643 */     jtfKe.setFont(new Font("SansSerif", 0, 14));
/*  644 */     jfSixpack.add(jtfKe);
/*      */     
/*  646 */     JLabel jlMa = new JLabel("Other name for Marupeke");
/*  647 */     jlMa.setForeground(Def.COLOR_LABEL);
/*  648 */     jlMa.setSize(205, 20);
/*  649 */     jlMa.setLocation(500, 460);
/*  650 */     jlMa.setHorizontalAlignment(0);
/*  651 */     jfSixpack.add(jlMa);
/*  652 */     jtfMa = new JTextField();
/*  653 */     jtfMa.setSize(205, 25);
/*  654 */     jtfMa.setLocation(500, 482);
/*  655 */     jtfMa.setText(Op.sx[Op.SX.SxMa.ordinal()]);
/*  656 */     jtfMa.setBackground(new Color(16777215));
/*  657 */     jtfMa.setFont(new Font("SansSerif", 0, 14));
/*  658 */     jfSixpack.add(jtfMa);
/*      */     
/*  660 */     JLabel jlMs = new JLabel("Other name for Minesweeper");
/*  661 */     jlMs.setForeground(Def.COLOR_LABEL);
/*  662 */     jlMs.setSize(205, 20);
/*  663 */     jlMs.setLocation(500, 510);
/*  664 */     jlMs.setHorizontalAlignment(0);
/*  665 */     jfSixpack.add(jlMs);
/*  666 */     jtfMs = new JTextField();
/*  667 */     jtfMs.setSize(205, 25);
/*  668 */     jtfMs.setLocation(500, 532);
/*  669 */     jtfMs.setText(Op.sx[Op.SX.SxMs.ordinal()]);
/*  670 */     jtfMs.setBackground(new Color(16777215));
/*  671 */     jtfMs.setFont(new Font("SansSerif", 0, 14));
/*  672 */     jfSixpack.add(jtfMs);
/*      */     
/*  674 */     JLabel jlRa = new JLabel("Other name for Roundabouts");
/*  675 */     jlRa.setForeground(Def.COLOR_LABEL);
/*  676 */     jlRa.setSize(205, 20);
/*  677 */     jlRa.setLocation(500, 560);
/*  678 */     jlRa.setHorizontalAlignment(0);
/*  679 */     jfSixpack.add(jlRa);
/*  680 */     jtfRa = new JTextField();
/*  681 */     jtfRa.setSize(205, 25);
/*  682 */     jtfRa.setLocation(500, 582);
/*  683 */     jtfRa.setText(Op.sx[Op.SX.SxRa.ordinal()]);
/*  684 */     jtfRa.setBackground(new Color(16777215));
/*  685 */     jtfRa.setFont(new Font("SansSerif", 0, 14));
/*  686 */     jfSixpack.add(jtfRa);
/*      */     
/*  688 */     JLabel jlSk = new JLabel("Other name for Sikaku");
/*  689 */     jlSk.setForeground(Def.COLOR_LABEL);
/*  690 */     jlSk.setSize(205, 20);
/*  691 */     jlSk.setLocation(500, 610);
/*  692 */     jlSk.setHorizontalAlignment(0);
/*  693 */     jfSixpack.add(jlSk);
/*  694 */     jtfSk = new JTextField();
/*  695 */     jtfSk.setSize(205, 25);
/*  696 */     jtfSk.setLocation(500, 632);
/*  697 */     jtfSk.setText(Op.sx[Op.SX.SxSk.ordinal()]);
/*  698 */     jtfSk.setBackground(new Color(16777215));
/*  699 */     jtfSk.setFont(new Font("SansSerif", 0, 14));
/*  700 */     jfSixpack.add(jtfSk);
/*      */     
/*  702 */     JLabel jlSl = new JLabel("Other name for Slitherlink");
/*  703 */     jlSl.setForeground(Def.COLOR_LABEL);
/*  704 */     jlSl.setSize(205, 20);
/*  705 */     jlSl.setLocation(500, 660);
/*  706 */     jlSl.setHorizontalAlignment(0);
/*  707 */     jfSixpack.add(jlSl);
/*  708 */     jtfSl = new JTextField();
/*  709 */     jtfSl.setSize(205, 25);
/*  710 */     jtfSl.setLocation(500, 682);
/*  711 */     jtfSl.setText(Op.sx[Op.SX.SxSl.ordinal()]);
/*  712 */     jtfSl.setBackground(new Color(16777215));
/*  713 */     jtfSl.setFont(new Font("SansSerif", 0, 14));
/*  714 */     jfSixpack.add(jtfSl);
/*      */     
/*  716 */     JLabel jlSu = new JLabel("Other name for Sudoku");
/*  717 */     jlSu.setForeground(Def.COLOR_LABEL);
/*  718 */     jlSu.setSize(205, 20);
/*  719 */     jlSu.setLocation(500, 710);
/*  720 */     jlSu.setHorizontalAlignment(0);
/*  721 */     jfSixpack.add(jlSu);
/*  722 */     jtfSu = new JTextField();
/*  723 */     jtfSu.setSize(205, 25);
/*  724 */     jtfSu.setLocation(500, 732);
/*  725 */     jtfSu.setText(Op.sx[Op.SX.SxSu.ordinal()]);
/*  726 */     jtfSu.setBackground(new Color(16777215));
/*  727 */     jtfSu.setFont(new Font("SansSerif", 0, 14));
/*  728 */     jfSixpack.add(jtfSu);
/*      */     
/*  730 */     JLabel jlTt = new JLabel("Other name for Tatami");
/*  731 */     jlTt.setForeground(Def.COLOR_LABEL);
/*  732 */     jlTt.setSize(205, 20);
/*  733 */     jlTt.setLocation(500, 760);
/*  734 */     jlTt.setHorizontalAlignment(0);
/*  735 */     jfSixpack.add(jlTt);
/*  736 */     jtfTt = new JTextField();
/*  737 */     jtfTt.setSize(205, 25);
/*  738 */     jtfTt.setLocation(500, 782);
/*  739 */     jtfTt.setText(Op.sx[Op.SX.SxTt.ordinal()]);
/*  740 */     jtfTt.setBackground(new Color(16777215));
/*  741 */     jtfTt.setFont(new Font("SansSerif", 0, 14));
/*  742 */     jfSixpack.add(jtfTt);
/*      */     
/*  744 */     JLabel jlTe = new JLabel("Other name for Tents");
/*  745 */     jlTe.setForeground(Def.COLOR_LABEL);
/*  746 */     jlTe.setSize(205, 20);
/*  747 */     jlTe.setLocation(500, 810);
/*  748 */     jlTe.setHorizontalAlignment(0);
/*  749 */     jfSixpack.add(jlTe);
/*  750 */     jtfTe = new JTextField();
/*  751 */     jtfTe.setSize(205, 25);
/*  752 */     jtfTe.setLocation(500, 832);
/*  753 */     jtfTe.setText(Op.sx[Op.SX.SxTe.ordinal()]);
/*  754 */     jtfTe.setBackground(new Color(16777215));
/*  755 */     jtfTe.setFont(new Font("SansSerif", 0, 14));
/*  756 */     jfSixpack.add(jtfTe);
/*      */ 
/*      */ 
/*      */     
/*  760 */     ActionListener timerAL = ae -> {
/*      */         myTimer.stop();
/*      */         buildAll();
/*      */       };
/*  764 */     myTimer = new Timer(1000, timerAL);
/*      */ 
/*      */     
/*  767 */     Methods.setFrameSize(jfSixpack, 715, 880);
/*  768 */     jfSixpack.setResizable(false);
/*      */   }
/*      */   
/*      */   final void getKDPdetails(JCheckBox jcbPrintInst, JCheckBox jcbPrintPuzSol, JTextField jtfHowMany) {
/*  772 */     Op.setBool(Op.SX.SxPuzColor.ordinal(), Boolean.valueOf(this.jcbPrintPuzColor.isSelected()), Op.sx);
/*  773 */     Op.setBool(Op.SX.SxSolColor.ordinal(), Boolean.valueOf(this.jcbPrintSolColor.isSelected()), Op.sx);
/*  774 */     Op.setBool(Op.SX.SxInstructions.ordinal(), Boolean.valueOf(jcbPrintInst.isSelected()), Op.sx);
/*  775 */     puzSol = jcbPrintPuzSol.isSelected();
/*  776 */     getTitles();
/*  777 */     hmPuz = Integer.parseInt(jtfHowMany.getText());
/*  778 */     startPuz = Integer.parseInt(jtfStart.getText());
/*      */     
/*  780 */     for (int k = 0; k < 6; k++)
/*  781 */       Op.setInt(Op.SX.SxPuzA.ordinal() + k, puzMode[this.jcbbP[k].getSelectedIndex()], Op.sx); 
/*  782 */     Def.puzzleMode = 8;
/*      */   }
/*      */   
/*      */   static void getTitles() {
/*  786 */     Op.setInt(Op.SX.SxRuleLangIndex.ordinal(), jcbbL.getSelectedIndex(), Op.sx);
/*  787 */     Op.sx[Op.SX.SxRuleLang.ordinal()] = jcbbL.getSelectedItem().toString();
/*  788 */     Op.setInt(Op.SX.SxDateFormatIndex.ordinal(), jcbbD.getSelectedIndex(), Op.sx);
/*  789 */     Op.sx[Op.SX.SxDateFormat.ordinal()] = jcbbD.getSelectedItem().toString();
/*  790 */     Op.sx[Op.SX.SxPuzTitle.ordinal()] = jtfPh.getText();
/*  791 */     Op.sx[Op.SX.SxSolTitle.ordinal()] = jtfSh.getText();
/*  792 */     Op.sx[Op.SX.SxAk.ordinal()] = jtfAk.getText();
/*  793 */     Op.sx[Op.SX.SxDm.ordinal()] = jtfDm.getText();
/*  794 */     Op.sx[Op.SX.SxFi.ordinal()] = jtfFi.getText();
/*  795 */     Op.sx[Op.SX.SxFu.ordinal()] = jtfFu.getText();
/*  796 */     Op.sx[Op.SX.SxGk.ordinal()] = jtfGk.getText();
/*  797 */     Op.sx[Op.SX.SxKk.ordinal()] = jtfKk.getText();
/*  798 */     Op.sx[Op.SX.SxKe.ordinal()] = jtfKe.getText();
/*  799 */     Op.sx[Op.SX.SxMa.ordinal()] = jtfMa.getText();
/*  800 */     Op.sx[Op.SX.SxMs.ordinal()] = jtfMs.getText();
/*  801 */     Op.sx[Op.SX.SxRa.ordinal()] = jtfRa.getText();
/*  802 */     Op.sx[Op.SX.SxSk.ordinal()] = jtfSk.getText();
/*  803 */     Op.sx[Op.SX.SxSl.ordinal()] = jtfSl.getText();
/*  804 */     Op.sx[Op.SX.SxSu.ordinal()] = jtfSu.getText();
/*  805 */     Op.sx[Op.SX.SxTt.ordinal()] = jtfTt.getText();
/*  806 */     Op.sx[Op.SX.SxTe.ordinal()] = jtfTe.getText();
/*      */   }
/*      */   
/*      */   static void saveAllOptions() {
/*  810 */     Op.saveOptions("sixpack.opt", Op.sx);
/*  811 */     Op.saveOptions("akari.opt", Op.ak);
/*  812 */     Op.saveOptions("domino.opt", Op.dm);
/*  813 */     Op.saveOptions("fillomino.opt", Op.fi);
/*  814 */     Op.saveOptions("futoshiki.opt", Op.fu);
/*  815 */     Op.saveOptions("gokigen.opt", Op.gk);
/*  816 */     Op.saveOptions("kakuro.opt", Op.kk);
/*  817 */     Op.saveOptions("kendoku.opt", Op.ke);
/*  818 */     Op.saveOptions("marupeke.opt", Op.ma);
/*  819 */     Op.saveOptions("minesweeper.opt", Op.ms);
/*  820 */     Op.saveOptions("roundabouts.opt", Op.ra);
/*  821 */     Op.saveOptions("sikaku.opt", Op.sk);
/*  822 */     Op.saveOptions("slitherlink.opt", Op.sl);
/*  823 */     Op.saveOptions("sudoku.opt", Op.su);
/*  824 */     Op.saveOptions("tatami.opt", Op.tt);
/*  825 */     Op.saveOptions("tents.opt", Op.te);
/*      */   }
/*      */   
/*      */   public static void trigger() {
/*  829 */     whichPuz++; for (; whichPuz < 6; whichPuz++) {
/*  830 */       if (Op.getInt(Op.SX.SxPuzA.ordinal() + whichPuz, Op.sx) > 0) {
/*  831 */         myTimer.start();
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void buildAll() {
/*  838 */     switch (Op.getInt(Op.SX.SxPuzA.ordinal() + whichPuz, Op.sx)) { case 20:
/*  839 */         new AkariBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  840 */       case 40: new DominoBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  841 */       case 70: new FillominoBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  842 */       case 80: new FutoshikiBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  843 */       case 90: new GokigenBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  844 */       case 100: new KakuroBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  845 */       case 110: new KendokuBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  846 */       case 230: new MarupekeBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  847 */       case 132: new MinesweeperBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  848 */       case 150: new RoundaboutsBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  849 */       case 160: new SikakuBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  850 */       case 170: new SlitherlinkBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  851 */       case 180: new SudokuBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  852 */       case 182: new TatamiBuild(jfSixpack, true, hmPuz, startPuz); return;
/*  853 */       case 190: new TentsBuild(jfSixpack, true, hmPuz, startPuz);
/*      */         break; }
/*      */   
/*      */   }
/*      */   
/*      */   static void sixpackRules() {
/*  859 */     JLabel jlE = new JLabel(), jlO = new JLabel();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  864 */     jdlgRules = new JDialog(jfSixpack, "Edit Sixpack Rules", true);
/*  865 */     jdlgRules.setSize(300, 595);
/*  866 */     jdlgRules.setResizable(false);
/*  867 */     jdlgRules.setLayout((LayoutManager)null);
/*  868 */     jdlgRules.setLocation(jfSixpack.getX(), jfSixpack.getY());
/*      */     
/*  870 */     JLabel jlP = new JLabel("Select Puzzle Type");
/*  871 */     jlP.setForeground(Def.COLOR_LABEL);
/*  872 */     jlP.setSize(200, 20);
/*  873 */     jlP.setLocation(10, 5);
/*  874 */     jlP.setHorizontalAlignment(0);
/*  875 */     jdlgRules.add(jlP);
/*  876 */     JComboBox<String> jcbbPuz = new JComboBox<>(); int i;
/*  877 */     for (i = 1; i < puzType.length; i++)
/*  878 */       jcbbPuz.addItem(puzType[i]); 
/*  879 */     jcbbPuz.setSize(200, 23);
/*  880 */     jcbbPuz.setLocation(10, 28);
/*  881 */     jcbbPuz.setBackground(Def.COLOR_BUTTONBG);
/*  882 */     jdlgRules.add(jcbbPuz);
/*      */     
/*  884 */     JLabel jlL = new JLabel("Select the Language");
/*  885 */     jlL.setForeground(Def.COLOR_LABEL);
/*  886 */     jlL.setSize(200, 20);
/*  887 */     jlL.setLocation(10, 55);
/*  888 */     jlL.setHorizontalAlignment(0);
/*  889 */     jdlgRules.add(jlL);
/*      */     
/*  891 */     JComboBox<String> jcbbLang = new JComboBox<>();
/*  892 */     for (i = 1; i < 6; i++)
/*  893 */       jcbbLang.addItem(Op.sx[Op.SX.SxLang1.ordinal() + i - 1]); 
/*  894 */     jcbbLang.setSize(200, 23);
/*  895 */     jcbbLang.setLocation(10, 78);
/*  896 */     jcbbLang.setBackground(Def.COLOR_BUTTONBG);
/*  897 */     jdlgRules.add(jcbbLang);
/*      */     
/*  899 */     JButton jbEdit = Methods.cweButton("Edit Rule", 10, 120, 90, 26, null);
/*  900 */     jbEdit.addActionListener(e -> { jtaRule.setText(rule[paramJComboBox1.getSelectedIndex()]); switch (paramJComboBox1.getSelectedIndex()) { case 0: jtaLang.setText(Op.ak[Op.AK.AkRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 1: jtaLang.setText(Op.dm[Op.DM.DmRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 2: jtaLang.setText(Op.fi[Op.FI.FiRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 3: jtaLang.setText(Op.fu[Op.FU.FuRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 4: jtaLang.setText(Op.gk[Op.GK.GkRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 5: jtaLang.setText(Op.kk[Op.KK.KkRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 6:
/*      */               jtaLang.setText(Op.ke[Op.KE.KeRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 7:
/*      */               jtaLang.setText(Op.ma[Op.MA.MaRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 8:
/*      */               jtaLang.setText(Op.ms[Op.MS.MsRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 9:
/*      */               jtaLang.setText(Op.ra[Op.RA.RaRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 10:
/*      */               jtaLang.setText(Op.sk[Op.SK.SkRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 11:
/*      */               jtaLang.setText(Op.sl[Op.SL.SlRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 12:
/*      */               jtaLang.setText(Op.su[Op.SU.SuRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 13:
/*      */               jtaLang.setText(Op.tt[Op.TT.TtRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break;
/*      */             case 14:
/*  923 */               jtaLang.setText(Op.te[Op.TE.TeRule1.ordinal() + paramJComboBox2.getSelectedIndex()]); break; }  paramJLabel1.setText("English language rule for" + paramJComboBox1.getSelectedItem() + " puzzles."); paramJLabel2.setText(paramJComboBox2.getSelectedItem() + " language rule for" + paramJComboBox1.getSelectedItem() + " puzzles."); jtaLang.requestFocusInWindow(); }); jdlgRules.add(jbEdit);
/*      */     
/*  925 */     JButton jbSave = Methods.cweButton("Save Rule", 120, 120, 90, 26, null);
/*  926 */     jbSave.addActionListener(e -> { switch (paramJComboBox1.getSelectedIndex()) { case 0: Op.ak[Op.AK.AkRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 1: Op.dm[Op.DM.DmRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 2: Op.fi[Op.FI.FiRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 3: Op.fu[Op.FU.FuRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 4: Op.gk[Op.GK.GkRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 5: Op.kk[Op.KK.KkRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 6: Op.ke[Op.KE.KeRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 7: Op.ma[Op.MA.MaRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 8: Op.ms[Op.MS.MsRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 9:
/*      */               Op.ra[Op.RA.RaRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 10:
/*      */               Op.sk[Op.SK.SkRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 11:
/*      */               Op.sl[Op.SL.SlRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 12:
/*      */               Op.su[Op.SU.SuRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 13:
/*      */               Op.tt[Op.TT.TtRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break;
/*      */             case 14:
/*  946 */               Op.te[Op.TE.TeRule1.ordinal() + paramJComboBox2.getSelectedIndex()] = jtaLang.getText(); break; }  jtaLang.setText(""); }); jdlgRules.add(jbSave);
/*      */     
/*  948 */     JButton jbLangNames = Methods.cweButton("Edit Language Names", 10, 160, 200, 26, null);
/*  949 */     jbLangNames.addActionListener(e -> {
/*      */           editLanguageNames();
/*      */           paramJComboBox.removeAllItems();
/*      */           for (int i = 0; i < 5; i++)
/*      */             paramJComboBox.addItem(Op.sx[Op.SX.SxLang1.ordinal() + i]); 
/*      */           Methods.closeHelp();
/*      */         });
/*  956 */     jdlgRules.add(jbLangNames);
/*      */     
/*  958 */     JButton jbAttach = Methods.cweButton("Attach Auxiliary Keyboard", 220, 559, 190, 26, null);
/*  959 */     jbAttach.addActionListener(e -> {
/*      */           Methods.setDialogSize(jdlgRules, 1205, 595);
/*      */           jtaLang.requestFocusInWindow();
/*      */         });
/*  963 */     jdlgRules.add(jbAttach);
/*      */     
/*  965 */     JButton jbDetach = Methods.cweButton("Detach Auxiliary Keyboard", 430, 559, 190, 26, null);
/*  966 */     jbDetach.addActionListener(e -> {
/*      */           Methods.setDialogSize(jdlgRules, 635, 595);
/*      */           jtaLang.requestFocusInWindow();
/*      */         });
/*  970 */     jdlgRules.add(jbDetach);
/*      */     
/*  972 */     jdlgRules
/*  973 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  975 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  980 */     JButton jbOK = Methods.cweButton("OK", 10, 382, 90, 26, null);
/*  981 */     jbOK.addActionListener(e -> {
/*      */           jdlgRules.dispose();
/*      */           Methods.closeHelp();
/*      */         });
/*  985 */     jdlgRules.add(jbOK);
/*      */     
/*  987 */     JButton jbQuit = Methods.cweButton("Quit", 120, 382, 90, 26, null);
/*  988 */     jbQuit.addActionListener(e -> {
/*      */           jdlgRules.dispose();
/*      */           Methods.closeHelp();
/*      */         });
/*  992 */     jdlgRules.add(jbQuit);
/*      */     
/*  994 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 10, 417, 200, 61, new ImageIcon("graphics/help.png"));
/*  995 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, jdlgRules, "Edit Sixpack Rules", sixpackRulesHelp));
/*      */ 
/*      */     
/*  998 */     jdlgRules.add(jbHelp);
/*      */     
/* 1000 */     jlE.setForeground(Def.COLOR_LABEL);
/* 1001 */     jlE.setSize(500, 20);
/* 1002 */     jlE.setLocation(220, 5);
/* 1003 */     jlE.setHorizontalAlignment(2);
/* 1004 */     jdlgRules.add(jlE);
/* 1005 */     jtaRule = new JTextArea();
/* 1006 */     jtaRule.setLineWrap(true);
/* 1007 */     jtaRule.setWrapStyleWord(true);
/* 1008 */     jtaRule.setBackground(new Color(15658734));
/* 1009 */     jtaRule.setEditable(false);
/* 1010 */     jtaRule.setBorder(BorderFactory.createLineBorder(new Color(15658734), 4));
/* 1011 */     JScrollPane jscrlp = new JScrollPane(jtaRule);
/* 1012 */     jscrlp.setSize(400, 248);
/* 1013 */     jscrlp.setLocation(220, 26);
/* 1014 */     jdlgRules.add(jscrlp);
/* 1015 */     jtaRule.setFont(new Font("SansSerif", 0, 16));
/*      */     
/* 1017 */     jlO.setForeground(Def.COLOR_LABEL);
/* 1018 */     jlO.setSize(500, 20);
/* 1019 */     jlO.setLocation(220, 281);
/* 1020 */     jlO.setHorizontalAlignment(2);
/* 1021 */     jdlgRules.add(jlO);
/* 1022 */     jtaLang = new JTextArea();
/* 1023 */     jtaLang.setLineWrap(true);
/* 1024 */     jtaLang.setWrapStyleWord(true);
/* 1025 */     jtaLang.setBackground(Def.COLOR_WHITE);
/* 1026 */     jtaLang.setBorder(BorderFactory.createLineBorder(Def.COLOR_WHITE, 4));
/* 1027 */     JScrollPane jscrll = new JScrollPane(jtaLang);
/* 1028 */     jscrll.setSize(400, 248);
/* 1029 */     jscrll.setLocation(220, 303);
/* 1030 */     jdlgRules.add(jscrll);
/* 1031 */     jtaLang.setFont(new Font("SansSerif", 0, 16));
/*      */ 
/*      */     
/* 1034 */     SpinnerNumberModel spm = new SpinnerNumberModel(0, 0, 255, 1);
/* 1035 */     JSpinner jspink = new JSpinner(spm);
/* 1036 */     jspink.setSize(50, 24);
/* 1037 */     jspink.setLocation(1145, 0);
/* 1038 */     jspink.setValue(Integer.valueOf(AuxKB.base = 0));
/* 1039 */     jdlgRules.add(jspink);
/* 1040 */     JLabel jlT = new JLabel("Select Keyboard");
/* 1041 */     jlT.setSize(160, 21);
/* 1042 */     jlT.setLocation(970, 2);
/* 1043 */     jlT.setHorizontalAlignment(4);
/* 1044 */     jdlgRules.add(jlT);
/*      */     
/* 1046 */     jspink
/* 1047 */       .addChangeListener(ce -> {
/*      */           AuxKB.base = (byte)paramSpinnerNumberModel.getNumber().intValue();
/*      */           
/*      */           kbp.repaint();
/*      */           
/*      */           jlChart.setText(AuxKB.getAlphabetName());
/*      */           jtaLang.requestFocusInWindow();
/*      */         });
/* 1055 */     jlChart = new JLabel(AuxKB.getAlphabetName());
/* 1056 */     jlChart.setSize(300, 16);
/* 1057 */     jlChart.setLocation(635, 5);
/* 1058 */     jlChart.setHorizontalAlignment(2);
/* 1059 */     jdlgRules.add(jlChart);
/*      */     
/* 1061 */     kbp = new AuxKB(635, 25, jdlgRules);
/* 1062 */     kbp.addMouseListener(new MouseAdapter() { public void mousePressed(MouseEvent e) {
/* 1063 */             AuxKB.getCharacter(e, Sixpack.jtaLang, null);
/*      */           } }
/*      */       );
/* 1066 */     Methods.setDialogSize(jdlgRules, 635, 595);
/* 1067 */     jdlgRules.requestFocusInWindow();
/*      */   }
/*      */   
/*      */   static void editLanguageNames() {
/* 1071 */     JTextField[] jtfLangName = new JTextField[5];
/*      */ 
/*      */     
/* 1074 */     JDialog jdlgLangNames = new JDialog(jdlgRules, "Language Names", true);
/* 1075 */     jdlgLangNames.setSize(200, 185);
/* 1076 */     jdlgLangNames.setResizable(false);
/* 1077 */     jdlgLangNames.setLayout((LayoutManager)null);
/* 1078 */     jdlgLangNames.setLocation(jdlgRules.getX() + 10, jdlgRules.getY() + 160 + 20);
/*      */     
/* 1080 */     Font font = new Font("SansSerif", 0, 15);
/* 1081 */     for (int i = 0; i < 5; i++) {
/* 1082 */       jtfLangName[i] = new JTextField(Op.sx[Op.SX.SxLang1.ordinal() + i], 20);
/* 1083 */       jtfLangName[i].setFont(font);
/* 1084 */       jtfLangName[i].setSize(180, 23);
/* 1085 */       jtfLangName[i].setLocation(10, 5 + 28 * i);
/* 1086 */       jtfLangName[i].selectAll();
/* 1087 */       jtfLangName[i].setHorizontalAlignment(2);
/* 1088 */       jdlgLangNames.add(jtfLangName[i]);
/*      */     } 
/*      */     
/* 1091 */     JButton jbSave = Methods.cweButton("Save", 10, 150, 80, 26, null);
/* 1092 */     jbSave.addActionListener(e -> {
/*      */           jcbbL.removeAllItems();
/*      */           jcbbL.addItem("English");
/*      */           for (int i = 0; i < 5; i++) {
/*      */             Op.sx[Op.SX.SxLang1.ordinal() + i] = paramArrayOfJTextField[i].getText();
/*      */             jcbbL.addItem(paramArrayOfJTextField[i].getText());
/*      */           } 
/*      */           paramJDialog.dispose();
/*      */         });
/* 1101 */     jdlgLangNames.add(jbSave);
/*      */     
/* 1103 */     JButton jbQuit = Methods.cweButton("Quit", 110, 150, 80, 26, null);
/* 1104 */     jbQuit.addActionListener(e -> paramJDialog.dispose());
/*      */ 
/*      */     
/* 1107 */     jdlgLangNames.add(jbQuit);
/*      */     
/* 1109 */     Methods.setDialogSize(jdlgLangNames, 200, 185);
/*      */   }
/*      */   
/* 1112 */   static String[] month = new String[] { "januar", "februar", "mars", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "desember" };
/*      */   
/* 1114 */   static String[] mnth = new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
/*      */   static void drawSixpackPuzzleT(Graphics2D g2, int left, int top, int width, String puzName) {
/* 1116 */     int columns = 3, items = 6, mth = 0;
/*      */     
/* 1118 */     String dateString = "";
/*      */     
/* 1120 */     RenderingHints rh = g2.getRenderingHints();
/* 1121 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1122 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1123 */     g2.setRenderingHints(rh);
/*      */     
/* 1125 */     int rows = items / columns;
/* 1126 */     int v = width * 10 / (11 * columns + 1);
/* 1127 */     int g = v / 10;
/* 1128 */     int textGap = Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue() ? (2 * g) : 0;
/*      */     
/* 1130 */     g2.setColor(new Color(16777215));
/* 1131 */     g2.fillRect(left, top, g + columns * (v + g), 3 * g + g / 2 + rows * (v + g + textGap));
/* 1132 */     g2.setColor(Def.COLOR_BLACK);
/* 1133 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1134 */     g2.drawRect(left, top, g + columns * (v + g), 3 * g + g / 2 + rows * (v + g + textGap));
/* 1135 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/* 1136 */     g2.drawLine(left, top + 3 * g + textGap + g / 2 + v, left + g + columns * (v + g), top + 3 * g + textGap + g / 2 + v);
/*      */     
/* 1138 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1139 */     FontMetrics fm = g2.getFontMetrics();
/* 1140 */     if (Op.getInt(Op.SX.SxDateFormatIndex.ordinal(), Op.sx) < 3)
/* 1141 */       mth = Integer.parseInt(puzName.substring(4, 6)) - 1; 
/* 1142 */     switch (Op.getInt(Op.SX.SxDateFormatIndex.ordinal(), Op.sx)) { case 0:
/* 1143 */         dateString = puzName.substring((puzName.charAt(6) == '0') ? 7 : 6, 8) + ". " + month[mth]; break;
/* 1144 */       case 1: dateString = puzName; break;
/* 1145 */       case 2: dateString = mnth[mth] + " " + puzName.substring(6) + ", " + puzName.substring(0, 4); break;
/* 1146 */       case 3: dateString = puzName; break; }
/*      */     
/* 1148 */     String st = ((jtfPh.getText().length() > 3) ? (jtfPh.getText() + " ") : Def.sixpackPuz) + dateString;
/* 1149 */     int w = fm.stringWidth(st);
/* 1150 */     g2.setColor(Def.COLOR_WHITE);
/* 1151 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1153 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1154 */     Def.dispWithColor = Op.getBool(Op.SX.SxPuzColor.ordinal(), Op.sx);
/* 1155 */     for (int i = 0; i < items; i++) {
/* 1156 */       int x = left + g + i % columns * (v + g);
/* 1157 */       int y = top + 3 * g + i / columns * (v + 2 * g + textGap);
/* 1158 */       g2.setColor(Def.COLOR_BLACK);
/* 1159 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1160 */       switch (Op.getInt(Op.SX.SxPuzA.ordinal() + i, Op.sx)) { case 20:
/* 1161 */           AkariBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1162 */         case 40: DominoBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1163 */         case 70: FillominoBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1164 */         case 80: FutoshikiBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1165 */         case 90: GokigenBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1166 */         case 100: KakuroBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1167 */         case 110: KendokuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1168 */         case 230: MarupekeBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1169 */         case 132: MinesweeperBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1170 */         case 150: RoundaboutsBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1171 */         case 160: SikakuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1172 */         case 170: SlitherlinkBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1173 */         case 180: SudokuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1174 */         case 182: TatamiBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1175 */         case 190: TentsBuild.printSixpackPuz(g2, x, y, v, g, puzName); break; }
/*      */     
/*      */     } 
/* 1178 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void drawSixpackSolutionT(Graphics2D g2, int left, int top, int width, String solName) {
/* 1182 */     int columns = 3, items = 6, mth = 0;
/*      */     
/* 1184 */     String dateString = "";
/*      */     
/* 1186 */     RenderingHints rh = g2.getRenderingHints();
/* 1187 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1188 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1189 */     g2.setRenderingHints(rh);
/*      */     
/* 1191 */     int rows = items / columns;
/* 1192 */     int v = width * 10 / (11 * columns + 1);
/* 1193 */     int g = v / 10;
/*      */     
/* 1195 */     g2.setColor(new Color(16777215));
/* 1196 */     g2.fillRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1197 */     g2.setColor(Def.COLOR_BLACK);
/* 1198 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1199 */     g2.drawRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1200 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/*      */     
/* 1202 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1203 */     FontMetrics fm = g2.getFontMetrics();
/* 1204 */     if (Op.getInt(Op.SX.SxDateFormatIndex.ordinal(), Op.sx) < 3)
/* 1205 */       mth = Integer.parseInt(solName.substring(4, 6)) - 1; 
/* 1206 */     switch (Op.getInt(Op.SX.SxDateFormatIndex.ordinal(), Op.sx)) { case 0:
/* 1207 */         dateString = solName.substring((solName.charAt(6) == '0') ? 7 : 6, 8) + ". " + month[mth]; break;
/* 1208 */       case 1: dateString = solName; break;
/* 1209 */       case 2: dateString = mnth[mth] + " " + solName.substring(6) + ", " + solName.substring(0, 4); break;
/* 1210 */       case 3: dateString = solName; break; }
/*      */     
/* 1212 */     String st = ((jtfSh.getText().length() > 3) ? (jtfSh.getText() + " ") : Def.sixpackPuz) + dateString;
/* 1213 */     int w = fm.stringWidth(st);
/* 1214 */     g2.setColor(Def.COLOR_WHITE);
/* 1215 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1217 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1218 */     Def.dispSolArray = Boolean.valueOf(false);
/* 1219 */     Def.dispWithColor = Op.getBool(Op.SX.SxSolColor.ordinal(), Op.sx);
/* 1220 */     for (int i = 0; i < items; i++) {
/* 1221 */       int x = left + g + i % columns * (v + g);
/* 1222 */       int y = top + 3 * g + i / columns * (v + 2 * g);
/* 1223 */       g2.setColor(Def.COLOR_BLACK);
/* 1224 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1225 */       switch (Op.getInt(Op.SX.SxPuzA.ordinal() + i, Op.sx)) { case 20:
/* 1226 */           AkariBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1227 */         case 40: DominoBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1228 */         case 70: FillominoBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1229 */         case 80: FutoshikiBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1230 */         case 90: GokigenBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1231 */         case 100: KakuroBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1232 */         case 110: KendokuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1233 */         case 230: MarupekeBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1234 */         case 132: MinesweeperBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1235 */         case 150: RoundaboutsBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1236 */         case 160: SikakuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1237 */         case 170: SlitherlinkBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1238 */         case 180: SudokuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1239 */         case 182: TatamiBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1240 */         case 190: TentsBuild.printSixpackSol(g2, x, y, v, g, solName); break; }
/*      */     
/*      */     } 
/* 1243 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void drawSixpackPuzzleM(Graphics2D g2, int left, int top, int width, String puzName) {
/* 1247 */     int rows = 3, columns = 2, items = 6, textGap = 0;
/*      */ 
/*      */ 
/*      */     
/* 1251 */     RenderingHints rh = g2.getRenderingHints();
/* 1252 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1253 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1254 */     g2.setRenderingHints(rh);
/*      */     
/* 1256 */     int v = width * 10 / (11 * columns + 1);
/* 1257 */     int g = v / 10;
/* 1258 */     textGap = Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue() ? (2 * g) : 0;
/*      */     
/* 1260 */     g2.setColor(new Color(16777215));
/* 1261 */     g2.fillRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1262 */     g2.setColor(Def.COLOR_BLACK);
/* 1263 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1264 */     g2.drawRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1265 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/*      */ 
/*      */     
/* 1268 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1269 */     FontMetrics fm = g2.getFontMetrics();
/* 1270 */     String st = jtfPh.getText() + " " + puzName;
/* 1271 */     int w = fm.stringWidth(st);
/* 1272 */     g2.setColor(Def.COLOR_WHITE);
/* 1273 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1275 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1276 */     Def.dispWithColor = Op.getBool(Op.SX.SxPuzColor.ordinal(), Op.sx);
/* 1277 */     for (int i = 0; i < items; i++) {
/* 1278 */       int x = left + g + i % columns * (v + g);
/* 1279 */       int y = top + 3 * g + i / columns * (v + 2 * g + textGap);
/* 1280 */       g2.setColor(Def.COLOR_BLACK);
/* 1281 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1282 */       switch (Op.getInt(Op.SX.SxPuzA.ordinal() + i, Op.sx)) { case 20:
/* 1283 */           AkariBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1284 */         case 40: DominoBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1285 */         case 70: FillominoBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1286 */         case 80: FutoshikiBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1287 */         case 90: GokigenBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1288 */         case 100: KakuroBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1289 */         case 110: KendokuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1290 */         case 230: MarupekeBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1291 */         case 132: MinesweeperBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1292 */         case 150: RoundaboutsBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1293 */         case 160: SikakuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1294 */         case 170: SlitherlinkBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1295 */         case 180: SudokuBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1296 */         case 182: TatamiBuild.printSixpackPuz(g2, x, y, v, g, puzName); break;
/* 1297 */         case 190: TentsBuild.printSixpackPuz(g2, x, y, v, g, puzName); break; }
/*      */     
/*      */     } 
/* 1300 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void drawSixpackSolutionM(Graphics2D g2, int left, int top, int width, String solName) {
/* 1304 */     int rows = 3, columns = 2, items = 6;
/*      */ 
/*      */ 
/*      */     
/* 1308 */     RenderingHints rh = g2.getRenderingHints();
/* 1309 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1310 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1311 */     g2.setRenderingHints(rh);
/*      */     
/* 1313 */     int v = width * 10 / (11 * columns + 1);
/* 1314 */     int g = v / 10;
/*      */     
/* 1316 */     g2.setColor(new Color(16777215));
/* 1317 */     g2.fillRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1318 */     g2.setColor(Def.COLOR_BLACK);
/* 1319 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1320 */     g2.drawRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1321 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/*      */     
/* 1323 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1324 */     FontMetrics fm = g2.getFontMetrics();
/* 1325 */     String st = jtfSh.getText() + " " + solName;
/* 1326 */     int w = fm.stringWidth(st);
/* 1327 */     g2.setColor(Def.COLOR_WHITE);
/* 1328 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1330 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1331 */     Def.dispSolArray = Boolean.valueOf(false);
/* 1332 */     Def.dispWithColor = Op.getBool(Op.SX.SxSolColor.ordinal(), Op.sx);
/* 1333 */     for (int i = 0; i < items; i++) {
/* 1334 */       int x = left + g + i % columns * (v + g);
/* 1335 */       int y = top + 3 * g + i / columns * (v + 2 * g);
/* 1336 */       g2.setColor(Def.COLOR_BLACK);
/* 1337 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1338 */       switch (Op.getInt(Op.SX.SxPuzA.ordinal() + i, Op.sx)) { case 20:
/* 1339 */           AkariBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1340 */         case 40: DominoBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1341 */         case 70: FillominoBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1342 */         case 80: FutoshikiBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1343 */         case 90: GokigenBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1344 */         case 100: KakuroBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1345 */         case 110: KendokuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1346 */         case 230: MarupekeBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1347 */         case 132: MinesweeperBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1348 */         case 150: RoundaboutsBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1349 */         case 160: SikakuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1350 */         case 170: SlitherlinkBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1351 */         case 180: SudokuBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1352 */         case 182: TatamiBuild.printSixpackSol(g2, x, y, v, g, solName); break;
/* 1353 */         case 190: TentsBuild.printSixpackSol(g2, x, y, v, g, solName); break; }
/*      */     
/*      */     } 
/* 1356 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void drawStdPuzK(Graphics2D g2, int left, int top, int width, int page, int puzType) {
/* 1360 */     int rows = 3, columns = 2, items = 6;
/*      */ 
/*      */ 
/*      */     
/* 1364 */     RenderingHints rh = g2.getRenderingHints();
/* 1365 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1366 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1367 */     g2.setRenderingHints(rh);
/*      */     
/* 1369 */     int v = width * 10 / (11 * columns + 1);
/* 1370 */     int g = v / 10;
/*      */     
/* 1372 */     g2.setColor(new Color(16777215));
/* 1373 */     g2.fillRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1374 */     g2.setColor(Def.COLOR_BLACK);
/* 1375 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1376 */     g2.drawRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1377 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/*      */     
/* 1379 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1380 */     FontMetrics fm = g2.getFontMetrics();
/* 1381 */     String st = jtfPh.getText() + " " + (page + 1);
/* 1382 */     int w = fm.stringWidth(st);
/* 1383 */     g2.setColor(Def.COLOR_WHITE);
/* 1384 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1386 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1387 */     Def.dispWithColor = Op.getBool(Op.SX.SxPuzColor.ordinal(), Op.sx);
/* 1388 */     for (int i = 0; i < items; i++) {
/* 1389 */       int x = left + g + i % columns * (v + g);
/* 1390 */       int y = top + 3 * g + i / columns * (v + 2 * g);
/* 1391 */       g2.setColor(Def.COLOR_BLACK);
/* 1392 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1393 */       switch (puzType) { case 20:
/* 1394 */           AkariBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1395 */         case 40: DominoBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1396 */         case 70: FillominoBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1397 */         case 80: FutoshikiBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1398 */         case 90: GokigenBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1399 */         case 100: KakuroBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1400 */         case 110: KendokuBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1401 */         case 230: MarupekeBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1402 */         case 132: MinesweeperBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1403 */         case 150: RoundaboutsBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1404 */         case 160: SikakuBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1405 */         case 170: SlitherlinkBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1406 */         case 180: SudokuBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1407 */         case 182: TatamiBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1408 */         case 190: TentsBuild.printKDPPuz(g2, x, y, v, g, "" + (page * 6 + i + 1)); break; }
/*      */     
/*      */     } 
/* 1411 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void drawStdSolK(Graphics2D g2, int left, int top, int width, int page, int puzType) {
/* 1415 */     int rows = 3, columns = 2, items = 6;
/*      */ 
/*      */ 
/*      */     
/* 1419 */     RenderingHints rh = g2.getRenderingHints();
/* 1420 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1421 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1422 */     g2.setRenderingHints(rh);
/*      */     
/* 1424 */     int v = width * 10 / (11 * columns + 1);
/* 1425 */     int g = v / 10;
/*      */     
/* 1427 */     g2.setColor(new Color(16777215));
/* 1428 */     g2.fillRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1429 */     g2.setColor(Def.COLOR_BLACK);
/* 1430 */     g2.setStroke(new BasicStroke(1.0F, 2, 0));
/* 1431 */     g2.drawRect(left, top, g + columns * (v + g), 2 * g + rows * (v + 2 * g));
/* 1432 */     g2.fillRect(left, top, g + columns * (v + g), 5 * g / 3);
/*      */     
/* 1434 */     g2.setFont(new Font("SansSerif", 1, g));
/* 1435 */     FontMetrics fm = g2.getFontMetrics();
/* 1436 */     String st = jtfSh.getText() + " " + (page + 1);
/* 1437 */     int w = fm.stringWidth(st);
/* 1438 */     g2.setColor(Def.COLOR_WHITE);
/* 1439 */     g2.drawString(st, left + (g + columns * (v + g) - w) / 2, top + (5 * g / 3 + fm.getAscent()) / 2);
/*      */     
/* 1441 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 1442 */     Def.dispSolArray = Boolean.valueOf(false);
/* 1443 */     Def.dispWithColor = Op.getBool(Op.SX.SxSolColor.ordinal(), Op.sx);
/*      */     
/* 1445 */     for (int i = 0; i < items; i++) {
/* 1446 */       int x = left + g + i % columns * (v + g);
/* 1447 */       int y = top + 3 * g + i / columns * (v + 2 * g);
/* 1448 */       g2.setColor(Def.COLOR_BLACK);
/* 1449 */       g2.setFont(new Font("SansSerif", 1, 3 * g / 4));
/* 1450 */       switch (puzType) { case 20:
/* 1451 */           AkariBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1452 */         case 40: DominoBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1453 */         case 70: FillominoBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1454 */         case 80: FutoshikiBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1455 */         case 90: GokigenBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1456 */         case 100: KakuroBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1457 */         case 110: KendokuBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1458 */         case 230: MarupekeBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1459 */         case 132: MinesweeperBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1460 */         case 150: RoundaboutsBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1461 */         case 160: SikakuBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1462 */         case 170: SlitherlinkBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1463 */         case 180: SudokuBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1464 */         case 182: TatamiBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1)); break;
/* 1465 */         case 190: TentsBuild.printKDPSol(g2, x, y, v, g, "" + (page * 6 + i + 1));
/*      */           break; }
/*      */     
/*      */     } 
/* 1469 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   private void exportGraphic(char printMode) {
/* 1473 */     String[] ext = { "bmp", "gif", "jpg", "png" };
/*      */     
/* 1475 */     JDialog jdlgExport = new JDialog(jfSixpack, "Export Puzzle to a Graphics File", true);
/* 1476 */     jdlgExport.setSize(312, 265);
/* 1477 */     jdlgExport.setResizable(false);
/* 1478 */     jdlgExport.setLayout((LayoutManager)null);
/* 1479 */     jdlgExport.setLocation(jfSixpack.getX(), jfSixpack.getY());
/*      */     
/* 1481 */     jdlgExport
/* 1482 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/* 1484 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/* 1488 */     Methods.closeHelp();
/*      */     
/* 1490 */     JPanel jpExportMode = new JPanel();
/* 1491 */     jpExportMode.setLayout((LayoutManager)null);
/* 1492 */     jpExportMode.setSize(290, 80);
/* 1493 */     jpExportMode.setLocation(10, 10);
/* 1494 */     jpExportMode.setOpaque(true);
/* 1495 */     jpExportMode.setBorder(BorderFactory.createEtchedBorder());
/* 1496 */     jdlgExport.add(jpExportMode);
/*      */     
/* 1498 */     JLabel jl = new JLabel("Export Mode");
/* 1499 */     jl.setForeground(Def.COLOR_LABEL);
/* 1500 */     jl.setSize(270, 20);
/* 1501 */     jl.setLocation(5, 3);
/* 1502 */     jl.setHorizontalAlignment(0);
/* 1503 */     jpExportMode.add(jl);
/*      */     
/* 1505 */     ButtonGroup bgExportMode = new ButtonGroup();
/* 1506 */     jrbExportMode[0] = new JRadioButton();
/* 1507 */     jrbExportMode[0].setForeground(Def.COLOR_LABEL);
/* 1508 */     jrbExportMode[0].setOpaque(false);
/* 1509 */     jrbExportMode[0].setSize(65, 20);
/* 1510 */     jrbExportMode[0].setLocation(10, 25);
/* 1511 */     jrbExportMode[0].setText("BMP");
/* 1512 */     jpExportMode.add(jrbExportMode[0]);
/* 1513 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[0]);
/*      */     
/* 1515 */     jrbExportMode[1] = new JRadioButton();
/* 1516 */     jrbExportMode[1].setForeground(Def.COLOR_LABEL);
/* 1517 */     jrbExportMode[1].setOpaque(false);
/* 1518 */     jrbExportMode[1].setSize(65, 20);
/* 1519 */     jrbExportMode[1].setLocation(80, 25);
/* 1520 */     jrbExportMode[1].setText("GIF");
/* 1521 */     jpExportMode.add(jrbExportMode[1]);
/* 1522 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[1]);
/*      */     
/* 1524 */     jrbExportMode[2] = new JRadioButton();
/* 1525 */     jrbExportMode[2].setForeground(Def.COLOR_LABEL);
/* 1526 */     jrbExportMode[2].setOpaque(false);
/* 1527 */     jrbExportMode[2].setSize(65, 20);
/* 1528 */     jrbExportMode[2].setLocation(150, 25);
/* 1529 */     jrbExportMode[2].setText("JPG");
/* 1530 */     jpExportMode.add(jrbExportMode[2]);
/* 1531 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[2]);
/*      */     
/* 1533 */     jrbExportMode[3] = new JRadioButton();
/* 1534 */     jrbExportMode[3].setForeground(Def.COLOR_LABEL);
/* 1535 */     jrbExportMode[3].setOpaque(false);
/* 1536 */     jrbExportMode[3].setSize(65, 20);
/* 1537 */     jrbExportMode[3].setLocation(220, 25);
/* 1538 */     jrbExportMode[3].setText("PNG");
/* 1539 */     jpExportMode.add(jrbExportMode[3]);
/* 1540 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[3]);
/*      */     
/* 1542 */     jrbExportMode[4] = new JRadioButton();
/* 1543 */     jrbExportMode[4].setForeground(Def.COLOR_LABEL);
/* 1544 */     jrbExportMode[4].setOpaque(false);
/* 1545 */     jrbExportMode[4].setSize(250, 20);
/* 1546 */     jrbExportMode[4].setLocation(10, 50);
/* 1547 */     jrbExportMode[4].setText("Export to System Clipboard");
/* 1548 */     jpExportMode.add(jrbExportMode[4]);
/* 1549 */     if (bgExportMode != null) bgExportMode.add(jrbExportMode[4]);
/*      */     
/* 1551 */     jrbExportMode[3].setSelected(true);
/*      */     
/* 1553 */     jl = new JLabel("Default graphic width is : 150 mm");
/* 1554 */     jl.setForeground(Def.COLOR_LABEL);
/* 1555 */     jl.setSize(300, 16);
/* 1556 */     jl.setLocation(10, 100);
/* 1557 */     jl.setHorizontalAlignment(0);
/* 1558 */     jdlgExport.add(jl);
/*      */     
/* 1560 */     JLabel jlWidth = new JLabel("Graphic width:");
/* 1561 */     jlWidth.setForeground(Def.COLOR_LABEL);
/* 1562 */     jlWidth.setSize(160, 20);
/* 1563 */     jlWidth.setLocation(10, 120);
/* 1564 */     jlWidth.setHorizontalAlignment(4);
/* 1565 */     jdlgExport.add(jlWidth);
/*      */     
/* 1567 */     JTextField jtfWidth = new JTextField("150", 15);
/* 1568 */     jtfWidth.setSize(55, 20);
/* 1569 */     jtfWidth.setLocation(180, 122);
/* 1570 */     jtfWidth.selectAll();
/* 1571 */     jtfWidth.setHorizontalAlignment(2);
/* 1572 */     jdlgExport.add(jtfWidth);
/*      */     
/* 1574 */     JButton jbOK = Methods.cweButton("Export", 13, 158, 100, 26, null);
/* 1575 */     jbOK.addActionListener(e -> {
/*      */           String path = "";
/*      */           
/*      */           int mode = 0;
/*      */           
/*      */           while (mode < 5 && !jrbExportMode[mode].isSelected()) {
/*      */             mode++;
/*      */           }
/*      */           int x1 = Integer.parseInt(paramJTextField.getText());
/*      */           x1 = (int)(x1 * 2.83D);
/*      */           if (mode == 3) {
/*      */             x1 = x1 * Op.getInt(Op.MSC.Ppi.ordinal(), Op.msc) / 72;
/*      */           }
/*      */           int y1 = ((paramChar == 'P') ? (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue() ? 90 : 80) : 80) * x1 / 100;
/*      */           BufferedImage bufferedImage = new BufferedImage(x1, y1, 1);
/*      */           Graphics2D g2 = bufferedImage.createGraphics();
/*      */           g2.setColor(Def.COLOR_WHITE);
/*      */           g2.fillRect(0, 0, x1, y1);
/*      */           hmPuz = 1;
/*      */           startPuz = Integer.parseInt(jtfStart.getText());
/*      */           for (int i = 0; i < 6; i++) {
/*      */             Op.setInt(Op.SX.SxPuzA.ordinal() + i, puzMode[this.jcbbP[i].getSelectedIndex()], Op.sx);
/*      */           }
/*      */           if (paramChar == 'P') {
/*      */             drawSixpackPuzzleT(g2, 10, 10, x1 - 20, "" + startPuz);
/*      */           } else {
/*      */             drawSixpackSolutionT(g2, 10, 10, x1 - 20, "" + startPuz);
/*      */           } 
/*      */           if (mode == 4) {
/*      */             Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/*      */             ImageTransferable selection = new ImageTransferable(bufferedImage);
/*      */             clipboard.setContents(selection, null);
/*      */             JOptionPane.showMessageDialog(jfSixpack, "The puzzle has been exported to the Clipboard, and is now ready for Pasting into other applications.", "Export Completed", 1);
/*      */           } else {
/*      */             JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/");
/*      */             chooser.setDialogTitle("Export a Sixpack " + ((paramChar == 'P') ? "Puzzle" : "Solution"));
/*      */             chooser.setFileFilter(new FileNameExtensionFilter("BMP GIF JPG PNG", new String[] { paramArrayOfString[mode] }));
/*      */             chooser.setSelectedFile(new File(((paramChar == 'P') ? "puzzle" : "solution") + "." + paramArrayOfString[mode]));
/*      */             if (chooser.showSaveDialog(jfSixpack) == 0) {
/*      */               path = chooser.getSelectedFile().getAbsolutePath();
/*      */               if (mode == 3) {
/*      */                 try {
/*      */                   Print.saveGridImage(path, paramArrayOfString[mode], bufferedImage);
/* 1618 */                 } catch (IOException iox) {}
/*      */               } else {
/*      */                 try {
/*      */                   File file = new File(path);
/*      */ 
/*      */                   
/*      */                   ImageIO.write(bufferedImage, paramArrayOfString[mode], file);
/* 1625 */                 } catch (IOException V) {}
/*      */               } 
/*      */               Methods.puzzleSaved(paramJDialog, path.substring(0, path.lastIndexOf('/')), path.substring(path.lastIndexOf('/') + 1));
/*      */             } 
/*      */           } 
/*      */           paramJDialog.dispose();
/*      */           Methods.closeHelp();
/*      */         });
/* 1633 */     jdlgExport.add(jbOK);
/*      */     
/* 1635 */     JButton jbCancel = Methods.cweButton("Cancel", 13, 193, 100, 26, null);
/* 1636 */     jbCancel.addActionListener(e -> {
/*      */           Methods.clickedOK = false;
/*      */           paramJDialog.dispose();
/*      */           Methods.closeHelp();
/*      */         });
/* 1641 */     jdlgExport.add(jbCancel);
/*      */     
/* 1643 */     this.jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 140, 158, 160, 61, new ImageIcon("graphics/help.png"));
/* 1644 */     this.jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Graphic Export Options", this.graphicExportOptions));
/*      */ 
/*      */     
/* 1647 */     jdlgExport.add(this.jbHelp);
/*      */     
/* 1649 */     Methods.setDialogSize(jdlgExport, 310, 229);
/*      */   }
/*      */   
/*      */   private void printProcessT() {
/* 1653 */     PrinterJob job = PrinterJob.getPrinterJob();
/* 1654 */     job.setPrintable(new PrintSixpackT());
/* 1655 */     if (job.printDialog()) {
/* 1656 */       try { job.print(); }
/* 1657 */       catch (Exception pe) {}
/*      */     }
/*      */   }
/*      */   
/*      */   private void printProcessMpuz() {
/* 1662 */     PrinterJob job = PrinterJob.getPrinterJob();
/* 1663 */     job.setPrintable(new PrintSixpackMpuz());
/* 1664 */     if (job.printDialog()) {
/* 1665 */       try { job.print(); }
/* 1666 */       catch (Exception pe) {}
/*      */     }
/*      */   }
/*      */   
/*      */   private void printProcessMsol() {
/* 1671 */     PrinterJob job = PrinterJob.getPrinterJob();
/* 1672 */     job.setPrintable(new PrintSixpackMsol());
/* 1673 */     if (job.printDialog())
/* 1674 */       try { job.print(); }
/* 1675 */       catch (Exception pe) {} 
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Sixpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */