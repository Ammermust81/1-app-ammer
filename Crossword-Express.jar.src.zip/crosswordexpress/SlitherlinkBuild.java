/*      */ package crosswordexpress;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class SlitherlinkBuild extends JPanel {
/*      */   static JFrame jfSlitherlink;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   24 */   int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); int hmCount;
/*      */   boolean sixpack;
/*      */   boolean adjustmentsMade;
/*   27 */   static String rules = "Join selected dots with horizontal and vertical lines to form a single loop which does not cross over itself. If a cell contains a number, then that number of sides of the cell must be included within the loop. The puzzle has a unique solution, and no guessing is required to complete the solution.";
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*   32 */     Op.updateOption(Op.SL.SlW.ordinal(), "500", Op.sl);
/*   33 */     Op.updateOption(Op.SL.SlH.ordinal(), "580", Op.sl);
/*   34 */     Op.updateOption(Op.SL.SlAcross.ordinal(), "10", Op.sl);
/*   35 */     Op.updateOption(Op.SL.SlDown.ordinal(), "10", Op.sl);
/*   36 */     Op.updateOption(Op.SL.SlLine.ordinal(), "004444", Op.sl);
/*   37 */     Op.updateOption(Op.SL.SlBg.ordinal(), "DDEEDD", Op.sl);
/*   38 */     Op.updateOption(Op.SL.SlGrid.ordinal(), "FFFFFF", Op.sl);
/*   39 */     Op.updateOption(Op.SL.SlNumber.ordinal(), "660033", Op.sl);
/*   40 */     Op.updateOption(Op.SL.SlError.ordinal(), "FF0000", Op.sl);
/*   41 */     Op.updateOption(Op.SL.SlPuz.ordinal(), "sample.slitherlink", Op.sl);
/*   42 */     Op.updateOption(Op.SL.SlTemplate.ordinal(), "", Op.sl);
/*   43 */     Op.updateOption(Op.SL.SlFont.ordinal(), "SansSerif", Op.sl);
/*   44 */     Op.updateOption(Op.SL.SlPuzColor.ordinal(), "false", Op.sl);
/*   45 */     Op.updateOption(Op.SL.SlSolColor.ordinal(), "false", Op.sl);
/*   46 */     Op.updateOption(Op.SL.SlSym.ordinal(), "true", Op.sl);
/*      */   }
/*      */   
/*   49 */   String slitherlinkHelp = "<div>Crossword Express <b>SLITHERLINK</b> puzzles are normally built on a rectangular grid (although other shapes are possible). The grid is defined by an array of dots which represent the corners of the cells within the grid. Some of the cells in this grid contain a single digit number between 0 and 3 inclusive. The remaining cells are blank.</div><br/><div>To solve such a puzzle, the solver must join selected dots with horizontal and vertical lines so that a single loop is formed which does not cross over itself. If a cell contains a number, then that number of sides of the cell must be included within the loop.</div><br/> <div>The puzzles have unique solutions, and no guessing is required to complete the solution.<br/> To make a SlitherLink puzzle, proceed as follows:-</div><p/><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span'>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of SLITHERLINK puzzles currently available on your computer.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>slitherlink</b> folder along with all of the Slitherlink puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option.If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Print a Slitherlink KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted SLITHERLINK puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Slitherlink Help</span><br/>Displays the Help screen which you are now reading.<p/></ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   String slitherlinkOptions = "<ul><li/>To specify the size or shape of the <b>SlitherLink</b> puzzle you can:-<ul><li/>Enter values for the number of cells Across and Down. This will result in a rectangular puzzle. <b>OR</b><p/><li/><b>Select a Template: </b> You can use the <b>Grid Maintenance</b> function to create Templates in any shape you desire. Please study the Grid Maintenance Help for instructions on how to do this.</ul><li/>If you check the <b>Make symmetrical puzzle</b> check-box, the puzzle will be built with the guide digits distributed across the puzzle in a symmetrical pattern.<p/><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> check-box will disable it.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SlitherlinkBuild(JFrame jf, boolean auto, int hm, int start) {
/*  143 */     Def.puzzleMode = 170;
/*  144 */     Def.dispCursor = Boolean.valueOf(true);
/*  145 */     Def.building = 0;
/*  146 */     makeGrid();
/*      */     
/*  148 */     jfSlitherlink = new JFrame("Slitherlink");
/*  149 */     if (Op.getInt(Op.SL.SlH.ordinal(), Op.sl) > Methods.scrH - 200) {
/*  150 */       int diff = Op.getInt(Op.SL.SlH.ordinal(), Op.sl) - Op.getInt(Op.SL.SlW.ordinal(), Op.sl);
/*  151 */       Op.setInt(Op.SL.SlH.ordinal(), Methods.scrH - 200, Op.sl);
/*  152 */       Op.setInt(Op.SL.SlW.ordinal(), Methods.scrH - 200 + diff, Op.sl);
/*      */     } 
/*  154 */     jfSlitherlink.setSize(Op.getInt(Op.SL.SlW.ordinal(), Op.sl), Op.getInt(Op.SL.SlH.ordinal(), Op.sl));
/*  155 */     int frameX = (jf.getX() + jfSlitherlink.getWidth() > Methods.scrW) ? (Methods.scrW - jfSlitherlink.getWidth() - 10) : jf.getX();
/*  156 */     jfSlitherlink.setLocation(frameX, jf.getY());
/*  157 */     jfSlitherlink.setLayout((LayoutManager)null);
/*  158 */     jfSlitherlink.setDefaultCloseOperation(0);
/*  159 */     jfSlitherlink
/*  160 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  162 */             int oldw = Op.getInt(Op.SL.SlW.ordinal(), Op.sl);
/*  163 */             int oldh = Op.getInt(Op.SL.SlH.ordinal(), Op.sl);
/*  164 */             Methods.frameResize(SlitherlinkBuild.jfSlitherlink, oldw, oldh, 500, 580);
/*  165 */             Op.setInt(Op.SL.SlW.ordinal(), SlitherlinkBuild.jfSlitherlink.getWidth(), Op.sl);
/*  166 */             Op.setInt(Op.SL.SlH.ordinal(), SlitherlinkBuild.jfSlitherlink.getHeight(), Op.sl);
/*  167 */             SlitherlinkBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  171 */     jfSlitherlink
/*  172 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  174 */             if (Def.building == 1 || Def.selecting)
/*  175 */               return;  Op.saveOptions("slitherlink.opt", Op.sl);
/*  176 */             CrosswordExpress.transfer(1, SlitherlinkBuild.jfSlitherlink);
/*      */           }
/*      */         });
/*      */     
/*  180 */     Methods.closeHelp();
/*      */     
/*  182 */     Runnable buildThread = () -> {
/*      */         if (this.howMany == 1) {
/*      */           buildSlitherLink();
/*      */         } else {
/*      */           multiBuild();
/*      */           
/*      */           if (this.sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfSlitherlink.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfSlitherlink);
/*      */           Grid.clearGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfSlitherlink, "slitherlink", Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  208 */     jl1 = new JLabel(); jfSlitherlink.add(jl1);
/*  209 */     jl2 = new JLabel(); jfSlitherlink.add(jl2);
/*      */ 
/*      */     
/*  212 */     menuBar = new JMenuBar();
/*  213 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  214 */     jfSlitherlink.setJMenuBar(menuBar);
/*      */     
/*  216 */     this.menu = new JMenu("File");
/*  217 */     menuBar.add(this.menu);
/*  218 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  219 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  220 */     this.menu.add(this.menuItem);
/*  221 */     this.menuItem
/*  222 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfSlitherlink, "slitherlink", "slitherlink", Op.sl, Op.SL.SlPuz.ordinal(), false);
/*      */         });
/*  229 */     this.menuItem = new JMenuItem("SaveAs");
/*  230 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  231 */     this.menu.add(this.menuItem);
/*  232 */     this.menuItem
/*  233 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSlitherlink, Op.sl[Op.SL.SlPuz.ordinal()].substring(0, Op.sl[Op.SL.SlPuz.ordinal()].indexOf(".slitherlink")), "slitherlink", ".slitherlink");
/*      */           if (Methods.clickedOK) {
/*      */             saveSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfSlitherlink, "slitherlink", Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  244 */     this.menuItem = new JMenuItem("Quit Construction");
/*  245 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  246 */     this.menu.add(this.menuItem);
/*  247 */     this.menuItem
/*  248 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("slitherlink.opt", Op.sl);
/*      */           CrosswordExpress.transfer(1, jfSlitherlink);
/*      */         });
/*  256 */     this.menu = new JMenu("Build");
/*  257 */     menuBar.add(this.menu);
/*  258 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  259 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  260 */     this.menu.add(this.menuItem);
/*  261 */     this.menuItem
/*  262 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSlitherlink, Op.sl[Op.SL.SlPuz.ordinal()].substring(0, Op.sl[Op.SL.SlPuz.ordinal()].indexOf(".slitherlink")), "slitherlink", ".slitherlink");
/*      */           if (Methods.clickedOK) {
/*      */             Op.sl[Op.SL.SlPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  273 */     this.menuItem = new JMenuItem("Build Options");
/*  274 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  275 */     this.menu.add(this.menuItem);
/*  276 */     this.menuItem
/*  277 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           slitherlinkOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (this.howMany > 1)
/*      */               Op.sl[Op.SL.SlPuz.ordinal()] = "" + this.startPuz + ".slitherlink"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  288 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  289 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  290 */     this.menu.add(this.buildMenuItem);
/*  291 */     this.buildMenuItem
/*  292 */       .addActionListener(ae -> {
/*      */           if (Op.sl[Op.SL.SlPuz.ordinal()].length() == 0 && this.howMany == 1) {
/*      */             Methods.noName(jfSlitherlink);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             this.thread.start();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             Def.building = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  341 */     this.menu = new JMenu("View");
/*  342 */     menuBar.add(this.menu);
/*  343 */     this.menuItem = new JMenuItem("Display Options");
/*  344 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  345 */     this.menu.add(this.menuItem);
/*  346 */     this.menuItem
/*  347 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfSlitherlink, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  355 */     this.menu = new JMenu("Export");
/*  356 */     menuBar.add(this.menu);
/*  357 */     this.menuItem = new JMenuItem("Print a Slitherlink KDP puzzle book.");
/*  358 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  359 */     this.menu.add(this.menuItem);
/*  360 */     this.menuItem
/*  361 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfSlitherlink, 170, 6);
/*      */         });
/*  368 */     this.menu = new JMenu("Tasks");
/*  369 */     menuBar.add(this.menu);
/*  370 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  371 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  372 */     this.menu.add(this.menuItem);
/*  373 */     this.menuItem
/*  374 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfSlitherlink, Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */         });
/*  380 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  381 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  382 */     this.menu.add(this.menuItem);
/*  383 */     this.menuItem
/*  384 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(171, jfSlitherlink);
/*      */           } else {
/*      */             Methods.noPuzzle(jfSlitherlink, "Solve");
/*      */           } 
/*      */         });
/*  393 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  394 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  395 */     this.menu.add(this.menuItem);
/*  396 */     this.menuItem
/*  397 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfSlitherlink, Op.sl[Op.SL.SlPuz.ordinal()], "slitherlink", pp)) {
/*      */             makeGrid();
/*      */             loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  408 */     this.menu = new JMenu("Help");
/*  409 */     menuBar.add(this.menu);
/*  410 */     this.menuItem = new JMenuItem("Slitherlink Help");
/*  411 */     this.menu.add(this.menuItem);
/*  412 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  413 */     this.menuItem
/*  414 */       .addActionListener(ae -> Methods.cweHelp(jfSlitherlink, null, "Building Slitherlink Puzzles", this.slitherlinkHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  419 */     pp = new SlitherlinkPP(0, 37);
/*  420 */     jfSlitherlink.add(pp);
/*      */     
/*  422 */     pp
/*  423 */       .addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent e) {
/*  425 */             SlitherlinkBuild.updateGrid(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  430 */     pp
/*  431 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  433 */             if (Def.isMac) {
/*  434 */               SlitherlinkBuild.jfSlitherlink.setResizable((SlitherlinkBuild.jfSlitherlink.getWidth() - e.getX() < 15 && SlitherlinkBuild.jfSlitherlink
/*  435 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  440 */     jfSlitherlink
/*  441 */       .addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent e) {
/*  443 */             SlitherlinkBuild.this.handleKeyPressed(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  448 */     loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*  449 */     restoreFrame();
/*      */ 
/*      */ 
/*      */     
/*  453 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  459 */     this.myTimer = new Timer(1000, timerAL);
/*      */     
/*  461 */     if (auto) {
/*  462 */       this.sixpack = true;
/*  463 */       this.howMany = hm; this.startPuz = start;
/*  464 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  469 */     jfSlitherlink.setVisible(true);
/*  470 */     Insets insets = jfSlitherlink.getInsets();
/*  471 */     panelW = jfSlitherlink.getWidth() - insets.left + insets.right;
/*  472 */     panelH = jfSlitherlink.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  473 */     pp.setSize(panelW, panelH);
/*  474 */     jfSlitherlink.requestFocusInWindow();
/*  475 */     pp.repaint();
/*  476 */     Methods.infoPanel(jl1, jl2, "Build Slitherlink", "Puzzle : " + Op.sl[Op.SL.SlPuz.ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  480 */     int i = (width - inset) / (Grid.xSz + 1);
/*  481 */     int j = (height - inset) / (Grid.ySz + 1);
/*  482 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  483 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : (10 + Grid.xCell / 2));
/*  484 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : (10 + Grid.yCell / 2));
/*      */   }
/*      */   
/*      */   private void slitherlinkOptions() {
/*  488 */     final JDialog jdlgSlitherlink = new JDialog(jfSlitherlink, "Slitherlink Options", true);
/*  489 */     jdlgSlitherlink.setSize(270, 382);
/*  490 */     jdlgSlitherlink.setResizable(false);
/*  491 */     jdlgSlitherlink.setLayout((LayoutManager)null);
/*  492 */     jdlgSlitherlink.setLocation(jfSlitherlink.getX(), jfSlitherlink.getY());
/*      */     
/*  494 */     jdlgSlitherlink
/*  495 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  497 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  501 */     Methods.closeHelp();
/*      */     
/*  503 */     Op.sl[Op.SL.SlTemplate.ordinal()] = "";
/*      */     
/*  505 */     JPanel jpSlitherlink = new JPanel();
/*  506 */     jpSlitherlink.setLayout((LayoutManager)null);
/*  507 */     jpSlitherlink.setLocation(10, 10);
/*  508 */     jpSlitherlink.setSize(240, 125);
/*  509 */     jpSlitherlink.setOpaque(true);
/*  510 */     jpSlitherlink.setBorder(BorderFactory.createEtchedBorder());
/*  511 */     jdlgSlitherlink.add(jpSlitherlink);
/*      */     
/*  513 */     JLabel jl = new JLabel("EITHER:");
/*  514 */     jl.setForeground(Def.COLOR_LABEL);
/*  515 */     jl.setSize(55, 20);
/*  516 */     jl.setLocation(10, 10);
/*  517 */     jl.setHorizontalAlignment(2);
/*  518 */     jpSlitherlink.add(jl);
/*      */     
/*  520 */     JLabel jlAcross = new JLabel("Cells Across:");
/*  521 */     jlAcross.setForeground(Def.COLOR_LABEL);
/*  522 */     jlAcross.setSize(100, 20);
/*  523 */     jlAcross.setLocation(65, 10);
/*  524 */     jlAcross.setHorizontalAlignment(4);
/*  525 */     jpSlitherlink.add(jlAcross);
/*      */     
/*  527 */     final JTextField jtfAcross = new JTextField("" + Grid.xSz, 15);
/*  528 */     jtfAcross.setSize(55, 20);
/*  529 */     jtfAcross.setLocation(175, 10);
/*  530 */     jtfAcross.selectAll();
/*  531 */     jtfAcross.setHorizontalAlignment(4);
/*  532 */     jpSlitherlink.add(jtfAcross);
/*      */     
/*  534 */     JLabel jlDown = new JLabel("Cells Down:");
/*  535 */     jlDown.setForeground(Def.COLOR_LABEL);
/*  536 */     jlDown.setSize(100, 20);
/*  537 */     jlDown.setLocation(65, 40);
/*  538 */     jlDown.setHorizontalAlignment(4);
/*  539 */     jpSlitherlink.add(jlDown);
/*      */     
/*  541 */     final JTextField jtfDown = new JTextField("" + Grid.ySz, 15);
/*  542 */     jtfDown.setSize(55, 20);
/*  543 */     jtfDown.setLocation(175, 40);
/*  544 */     jtfDown.selectAll();
/*  545 */     jtfDown.setHorizontalAlignment(4);
/*  546 */     jpSlitherlink.add(jtfDown);
/*      */     
/*  548 */     jl = new JLabel("OR:");
/*  549 */     jl.setForeground(Def.COLOR_LABEL);
/*  550 */     jl.setSize(40, 20);
/*  551 */     jl.setLocation(10, 70);
/*  552 */     jl.setHorizontalAlignment(2);
/*  553 */     jpSlitherlink.add(jl);
/*      */     
/*  555 */     final JLabel jlTemplate = new JLabel("");
/*  556 */     jlAcross.setForeground(Def.COLOR_LABEL);
/*  557 */     jlTemplate.setSize(140, 20);
/*  558 */     jlTemplate.setLocation(50, 98);
/*  559 */     jlTemplate.setHorizontalAlignment(0);
/*  560 */     jpSlitherlink.add(jlTemplate);
/*      */     
/*  562 */     Action doTemplate = new AbstractAction("Select a Template") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  564 */           String oldName = Op.sl[Op.SL.SlTemplate.ordinal()];
/*  565 */           SlitherlinkBuild.makeGrid();
/*  566 */           Def.dispSolArray = Boolean.valueOf(true);
/*  567 */           Def.puzzleMode = 2;
/*  568 */           Def.dispNullCells = Boolean.valueOf(true);
/*      */           
/*  570 */           JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/grids");
/*  571 */           chooser.setFileFilter(new FileNameExtensionFilter("Template", new String[] { "template" }));
/*  572 */           File fl = new File(Op.sl[Op.SL.SlTemplate.ordinal()]);
/*  573 */           if (fl != null)
/*  574 */             chooser.setSelectedFile(fl); 
/*  575 */           chooser.setAccessory(new Preview(chooser));
/*  576 */           if (chooser.showDialog(SlitherlinkBuild.jfSlitherlink, "Select Template") == 0) {
/*  577 */             Op.sl[Op.SL.SlTemplate.ordinal()] = chooser.getSelectedFile().getName();
/*  578 */             fl = new File("grids/" + Op.sl[Op.SL.SlTemplate.ordinal()]);
/*  579 */             if (!fl.exists()) {
/*  580 */               JOptionPane.showMessageDialog(SlitherlinkBuild.jfSlitherlink, "There is no file by that name!");
/*  581 */               Op.sl[Op.SL.SlTemplate.ordinal()] = oldName;
/*      */             } 
/*      */           } 
/*      */           
/*  585 */           Def.puzzleMode = 170;
/*  586 */           Def.dispNullCells = Boolean.valueOf(false);
/*  587 */           Def.dispSolArray = Boolean.valueOf(false);
/*  588 */           if (Op.sl[Op.SL.SlTemplate.ordinal()].length() > 0) {
/*  589 */             Grid.loadGrid(Op.sl[Op.SL.SlTemplate.ordinal()]);
/*  590 */             jlTemplate.setText(Op.sl[Op.SL.SlTemplate.ordinal()]);
/*      */           } else {
/*      */             
/*  593 */             Grid.clearGrid();
/*      */           }  }
/*      */       };
/*  596 */     JButton jbSelectTemplate = Methods.newButton("doTemplate", doTemplate, 83, 45, 68, 185, 26);
/*  597 */     jpSlitherlink.add(jbSelectTemplate);
/*      */     
/*  599 */     final JCheckBox jcbSym = new JCheckBox("Build a Symmetrical Puzzle", Op.getBool(Op.SL.SlSym.ordinal(), Op.sl).booleanValue());
/*  600 */     jcbSym.setForeground(Def.COLOR_LABEL);
/*  601 */     jcbSym.setOpaque(false);
/*  602 */     jcbSym.setSize(290, 20);
/*  603 */     jcbSym.setLocation(10, 138);
/*  604 */     jdlgSlitherlink.add(jcbSym);
/*      */     
/*  606 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgSlitherlink, 10, 161, this.howMany, this.startPuz, true);
/*      */     
/*  608 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  610 */           Op.setInt(Op.SL.SlAcross.ordinal(), Integer.parseInt(jtfAcross.getText()), Op.sl);
/*  611 */           if (Op.getInt(Op.SL.SlAcross.ordinal(), Op.sl) < 5) Op.setInt(Op.SL.SlAcross.ordinal(), 5, Op.sl); 
/*  612 */           if (Op.getInt(Op.SL.SlAcross.ordinal(), Op.sl) > 50) Op.setInt(Op.SL.SlAcross.ordinal(), 50, Op.sl); 
/*  613 */           Op.setInt(Op.SL.SlDown.ordinal(), Integer.parseInt(jtfDown.getText()), Op.sl);
/*  614 */           if (Op.getInt(Op.SL.SlDown.ordinal(), Op.sl) < 5) Op.setInt(Op.SL.SlDown.ordinal(), 5, Op.sl); 
/*  615 */           if (Op.getInt(Op.SL.SlDown.ordinal(), Op.sl) > 50) Op.setInt(Op.SL.SlDown.ordinal(), 50, Op.sl); 
/*  616 */           Op.setBool(Op.SL.SlSym.ordinal(), Boolean.valueOf(jcbSym.isSelected()), Op.sl);
/*  617 */           SlitherlinkBuild.this.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  618 */           SlitherlinkBuild.this.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  619 */           Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(hmp.jcbVaryDiff.isSelected()), Op.sx);
/*  620 */           Methods.clickedOK = true;
/*  621 */           jdlgSlitherlink.dispose();
/*  622 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  625 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 278, 80, 26);
/*  626 */     jdlgSlitherlink.add(jbOK);
/*      */     
/*  628 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  630 */           Methods.clickedOK = false;
/*  631 */           jdlgSlitherlink.dispose();
/*  632 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  635 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 313, 80, 26);
/*  636 */     jdlgSlitherlink.add(jbCancel);
/*      */     
/*  638 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  640 */           Methods.cweHelp(null, jdlgSlitherlink, "Slitherlink Options", SlitherlinkBuild.this.slitherlinkOptions);
/*      */         }
/*      */       };
/*  643 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 278, 150, 61);
/*  644 */     jdlgSlitherlink.add(jbHelp);
/*      */     
/*  646 */     jdlgSlitherlink.getRootPane().setDefaultButton(jbOK);
/*  647 */     Methods.setDialogSize(jdlgSlitherlink, 260, 349);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  651 */     String[] colorLabel = { "Line Color", "Background Color", "Grid Color", "Number Color", "Error Color" };
/*  652 */     int[] colorInt = { Op.SL.SlLine.ordinal(), Op.SL.SlBg.ordinal(), Op.SL.SlGrid.ordinal(), Op.SL.SlNumber.ordinal(), Op.SL.SlError.ordinal() };
/*  653 */     String[] fontLabel = { "Puzzle Font" };
/*  654 */     int[] fontInt = { Op.SL.SlFont.ordinal() };
/*  655 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  656 */     int[] checkInt = { Op.SL.SlPuzColor.ordinal(), Op.SL.SlSolColor.ordinal() };
/*  657 */     Methods.stdPrintOptions(jf, "Slitherlink " + type, Op.sl, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveSlitherlink(String slitherlinkName) {
/*      */     try {
/*  666 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("slitherlink/" + slitherlinkName));
/*  667 */       dataOut.writeInt(Grid.xSz);
/*  668 */       dataOut.writeInt(Grid.ySz);
/*  669 */       dataOut.writeByte(Methods.noReveal);
/*  670 */       dataOut.writeByte(Methods.noErrors);
/*  671 */       for (int i = 0; i < 54; i++)
/*  672 */         dataOut.writeByte(0); 
/*  673 */       for (int j = 0; j < Grid.ySz; j++) {
/*  674 */         for (int k = 0; k < Grid.xSz; k++) {
/*  675 */           dataOut.writeInt(Grid.status[k][j]);
/*  676 */           dataOut.writeChar(Grid.letter[k][j]);
/*  677 */           dataOut.writeInt(Grid.iSol[k][j]);
/*  678 */           dataOut.writeInt(Grid.mode[k][j]);
/*      */         } 
/*  680 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  681 */       dataOut.writeUTF(Methods.author);
/*  682 */       dataOut.writeUTF(Methods.copyright);
/*  683 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  684 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  685 */       dataOut.close();
/*      */     }
/*  687 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadSlitherlink(String slitherlinkName) {
/*      */     
/*  695 */     try { File fl = new File("slitherlink/" + slitherlinkName);
/*  696 */       if (!fl.exists()) {
/*      */         
/*  698 */         fl = new File("slitherlink/");
/*  699 */         String[] s = fl.list(); int k;
/*  700 */         for (k = 0; k < s.length && (
/*  701 */           s[k].lastIndexOf(".slitherlink") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  703 */         if (k == s.length) { makeGrid(); return; }
/*  704 */          slitherlinkName = s[k];
/*  705 */         Op.sl[Op.SL.SlPuz.ordinal()] = slitherlinkName;
/*      */       } 
/*      */ 
/*      */       
/*  709 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("slitherlink/" + slitherlinkName));
/*  710 */       Grid.xSz = dataIn.readInt();
/*  711 */       Grid.ySz = dataIn.readInt();
/*  712 */       Methods.noReveal = dataIn.readByte();
/*  713 */       Methods.noErrors = dataIn.readByte(); int i;
/*  714 */       for (i = 0; i < 54; i++)
/*  715 */         dataIn.readByte(); 
/*  716 */       for (int j = 0; j < Grid.ySz; j++) {
/*  717 */         for (i = 0; i < Grid.xSz; i++) {
/*  718 */           Grid.status[i][j] = dataIn.readInt();
/*  719 */           Grid.letter[i][j] = dataIn.readChar();
/*  720 */           Grid.iSol[i][j] = dataIn.readInt();
/*  721 */           Grid.mode[i][j] = dataIn.readInt();
/*      */         } 
/*  723 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  724 */       Methods.author = dataIn.readUTF();
/*  725 */       Methods.copyright = dataIn.readUTF();
/*  726 */       Methods.puzzleNumber = dataIn.readUTF();
/*  727 */       Methods.puzzleNotes = dataIn.readUTF();
/*  728 */       dataIn.close(); }
/*      */     
/*  730 */     catch (IOException exc) { return; }
/*  731 */      Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawSlitherlink(Graphics2D g2, int[][] puzzleArray) {
/*  738 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  739 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/*  740 */     g2.setStroke(normalStroke);
/*      */     
/*  742 */     RenderingHints rh = g2.getRenderingHints();
/*  743 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  744 */     g2.setRenderingHints(rh);
/*      */     
/*  746 */     g2.setStroke(wideStroke);
/*  747 */     int margin = Grid.xCell / 2;
/*  748 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlBg.ordinal(), Op.sl) : 16777215));
/*  749 */     g2.fillRect(Grid.xOrg - margin, Grid.yOrg - margin, Grid.xCell * Grid.xSz + 2 * margin, Grid.yCell * Grid.ySz + 2 * margin);
/*  750 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlLine.ordinal(), Op.sl) : 0));
/*  751 */     g2.drawRect(Grid.xOrg - margin, Grid.yOrg - margin, Grid.xCell * Grid.xSz + 2 * margin, Grid.yCell * Grid.ySz + 2 * margin);
/*      */     
/*  753 */     if (!Def.dispWithColor.booleanValue()) {
/*  754 */       g2.setColor(Def.COLOR_LIGHTGRAY);
/*  755 */       for (int i = 0; i < Grid.ySz; i++) {
/*  756 */         boolean shade = false;
/*  757 */         for (int k = 0; k < Grid.xSz; k++) {
/*  758 */           if ((Grid.status[k][i] & 0xC0) == 64)
/*  759 */             shade = !shade; 
/*  760 */           if (shade) {
/*  761 */             g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + i * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  766 */     for (int pass = 0; pass < 2; pass++) {
/*  767 */       for (int i = 0; i < Grid.ySz; i++) {
/*  768 */         for (int k = 0; k < Grid.xSz; k++) {
/*  769 */           if (Grid.mode[k][i] == 0) {
/*  770 */             int x = Grid.xOrg + k * Grid.xCell;
/*  771 */             int y = Grid.yOrg + i * Grid.yCell; int c;
/*  772 */             for (c = 3; c < 768; c *= 4) {
/*  773 */               int v = Grid.status[k][i] & c;
/*  774 */               if (pass == 0) {
/*  775 */                 if (v != 0 || Methods.havePuzzle)
/*  776 */                   continue;  g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlGrid.ordinal(), Op.sl) : 0));
/*      */               } else {
/*      */                 
/*  779 */                 if ((v & 0x55) == 0)
/*  780 */                   continue;  g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlLine.ordinal(), Op.sl) : 0));
/*      */               } 
/*  782 */               switch (c) { case 3:
/*  783 */                   g2.drawLine(x, y, x + Grid.xCell, y); break;
/*  784 */                 case 12: g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); break;
/*  785 */                 case 48: g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); break;
/*  786 */                 case 192: g2.drawLine(x, y + Grid.yCell, x, y); break; }  continue;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  791 */     }  g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlNumber.ordinal(), Op.sl) : 0));
/*  792 */     g2.setFont(new Font(Op.sl[Op.SL.SlFont.ordinal()], 0, 8 * Grid.yCell / 10));
/*  793 */     FontMetrics fm = g2.getFontMetrics();
/*  794 */     for (int j = 0; j < Grid.ySz; j++) {
/*  795 */       for (int i = 0; i < Grid.xSz; i++) {
/*  796 */         char ch = (char)puzzleArray[i][j];
/*  797 */         if (ch != '\000') {
/*  798 */           int w = fm.stringWidth("" + ch);
/*  799 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*      */         } 
/*      */       } 
/*      */     } 
/*  803 */     if (Def.dispCursor.booleanValue()) {
/*  804 */       g2.setColor(Def.COLOR_RED);
/*  805 */       g2.setStroke(wideStroke);
/*  806 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */     } 
/*      */     
/*  809 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  813 */     loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*  814 */     setSizesAndOffsets(left, top, width, height, 0);
/*  815 */     Methods.clearGrid(Grid.iSol);
/*  816 */     Def.dispWithColor = Op.getBool(Op.SL.SlPuzColor.ordinal(), Op.sl);
/*  817 */     SlitherlinkSolve.drawSlitherlink(g2, Grid.letter);
/*  818 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  822 */     loadSlitherlink(solutionPuzzle);
/*  823 */     setSizesAndOffsets(left, top, width, height, 0);
/*  824 */     Def.dispWithColor = Op.getBool(Op.SL.SlSolColor.ordinal(), Op.sl);
/*  825 */     drawSlitherlink(g2, Grid.letter);
/*  826 */     Def.dispWithColor = Boolean.valueOf(true);
/*  827 */     loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  831 */     loadSlitherlink(solutionPuzzle);
/*  832 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  833 */     loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  839 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  841 */     String st = Op.sx[Op.SX.SxSl.ordinal()];
/*  842 */     if (st.length() < 3) st = "SLITHERLINK"; 
/*  843 */     int w = fm.stringWidth(st);
/*  844 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  845 */     SlitherlinkSolve.loadSlitherlink(puzName + ".slitherlink");
/*  846 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  847 */     Methods.clearGrid(Grid.iSol);
/*  848 */     SlitherlinkSolve.drawSlitherlink(g2, Grid.letter);
/*  849 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/*  850 */       st = rules;
/*      */     } else {
/*  852 */       st = Op.sl[Op.SL.SlRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/*  853 */     }  if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/*  854 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  860 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  862 */     String st = Op.sx[Op.SX.SxSl.ordinal()];
/*  863 */     if (st.length() < 3) st = "SLITHERLINK"; 
/*  864 */     int w = fm.stringWidth(st);
/*  865 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  866 */     loadSlitherlink(solName + ".slitherlink");
/*  867 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  868 */     drawSlitherlink(g2, Grid.letter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  874 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  876 */     String st = puzName;
/*  877 */     int w = fm.stringWidth(st);
/*  878 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  879 */     SlitherlinkSolve.loadSlitherlink(puzName + ".slitherlink");
/*  880 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  881 */     Methods.clearGrid(Grid.iSol);
/*  882 */     SlitherlinkSolve.drawSlitherlink(g2, Grid.letter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  888 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  890 */     String st = solName;
/*  891 */     int w = fm.stringWidth(st);
/*  892 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  893 */     loadSlitherlink(solName + ".slitherlink");
/*  894 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  895 */     drawSlitherlink(g2, Grid.letter);
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/*  899 */     Methods.havePuzzle = false;
/*  900 */     Grid.clearGrid();
/*  901 */     if (Op.sl[Op.SL.SlTemplate.ordinal()].length() > 0) {
/*  902 */       Grid.loadGrid(Op.sl[Op.SL.SlTemplate.ordinal()]);
/*      */     } else {
/*  904 */       Grid.xSz = Op.getInt(Op.SL.SlAcross.ordinal(), Op.sl);
/*  905 */       Grid.ySz = Op.getInt(Op.SL.SlDown.ordinal(), Op.sl);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean pathExists() {
/*  910 */     int[] na = new int[4], xa = new int[4], ya = new int[4], ia = new int[4];
/*  911 */     int count = 0;
/*      */     
/*  913 */     for (int y = 0; y < Grid.ySz; y++) {
/*  914 */       for (int x = 0; x < Grid.xSz; x++) {
/*  915 */         int val = getPointStats(x, y, xa, ya, na, ia) / 256;
/*  916 */         if (val == 1)
/*  917 */           return false; 
/*  918 */         if (val == 2)
/*  919 */           count++; 
/*      */       } 
/*  921 */     }  return (count > 0);
/*      */   }
/*      */   
/*      */   int getPointStats(int x, int y, int[] xa, int[] ya, int[] na, int[] ia) {
/*  925 */     int full = 0, pending = 0;
/*      */     
/*  927 */     na[3] = -1; na[2] = -1; na[1] = -1; na[0] = -1;
/*      */     
/*  929 */     if (x != Grid.xSz) {
/*  930 */       if (y != Grid.ySz && Grid.status[x][y] != 255) {
/*  931 */         xa[0] = x; ya[0] = y; na[0] = Grid.iSol[x][y] & 0x3;
/*  932 */         ia[0] = 0;
/*      */       }
/*  934 */       else if (y > 0 && Grid.status[x][y - 1] != 255) {
/*  935 */         xa[0] = x; ya[0] = y - 1; na[0] = Grid.iSol[x][y - 1] & 0x30;
/*  936 */         ia[0] = 2;
/*      */       } 
/*  938 */       if (na[0] != -1)
/*  939 */         if (na[0] == 0) { pending++; }
/*  940 */         else if ((na[0] & 0x55) != 0) { full++; }
/*      */          
/*  942 */     }  if (y != Grid.ySz) {
/*  943 */       if (x != 0 && Grid.status[x - 1][y] != 255) {
/*  944 */         xa[1] = x - 1; ya[1] = y; na[1] = Grid.iSol[x - 1][y] & 0xC;
/*  945 */         ia[1] = 1;
/*      */       }
/*  947 */       else if (Grid.status[x][y] != 255) {
/*  948 */         xa[1] = x; ya[1] = y; na[1] = Grid.iSol[x][y] & 0xC0;
/*  949 */         ia[1] = 3;
/*      */       } 
/*  951 */       if (na[1] != -1)
/*  952 */         if (na[1] == 0) { pending++; }
/*  953 */         else if ((na[1] & 0x55) != 0) { full++; }
/*      */          
/*  955 */     }  if (x != 0) {
/*  956 */       if (y != 0 && Grid.status[x - 1][y - 1] != 255) {
/*  957 */         xa[2] = x - 1; ya[2] = y - 1; na[2] = Grid.iSol[x - 1][y - 1] & 0x30;
/*  958 */         ia[2] = 2;
/*      */       }
/*  960 */       else if (Grid.status[x - 1][y] != 255) {
/*  961 */         xa[2] = x - 1; ya[2] = y; na[2] = Grid.iSol[x - 1][y] & 0x3;
/*  962 */         ia[2] = 0;
/*      */       } 
/*  964 */       if (na[2] != -1)
/*  965 */         if (na[2] == 0) { pending++; }
/*  966 */         else if ((na[2] & 0x55) != 0) { full++; }
/*      */          
/*  968 */     }  if (y != 0) {
/*  969 */       if (x != Grid.xSz && Grid.status[x][y - 1] != 255) {
/*  970 */         xa[3] = x; ya[3] = y - 1; na[3] = Grid.iSol[x][y - 1] & 0xC0;
/*  971 */         ia[3] = 3;
/*      */       }
/*  973 */       else if (x != 0 && Grid.status[x - 1][y - 1] != 255) {
/*  974 */         xa[3] = x - 1; ya[3] = y - 1; na[3] = Grid.iSol[x - 1][y - 1] & 0xC;
/*  975 */         ia[3] = 1;
/*      */       } 
/*  977 */       if (na[3] != -1)
/*  978 */         if (na[3] == 0) { pending++; }
/*  979 */         else if ((na[3] & 0x55) != 0) { full++; }
/*      */          
/*  981 */     }  return full * 256 + pending;
/*      */   }
/*      */   
/*      */   void adjust(int x, int y, int d, int mask) {
/*  985 */     int[] xinc = { 0, 1, 0, -1 }, yinc = { -1, 0, 1, 0 };
/*  986 */     int[] c = { 3, 12, 48, 192 }, side = { 48, 192, 3, 12 };
/*      */ 
/*      */     
/*  989 */     if (x >= 0 && y >= 0 && x < Grid.xSz && y < Grid.ySz && Grid.status[x][y] != 255 && (
/*  990 */       Grid.iSol[x][y] & c[d]) == 0) {
/*  991 */       Grid.iSol[x][y] = Grid.iSol[x][y] | c[d] & mask;
/*  992 */       this.adjustmentsMade = true;
/*      */     } 
/*      */ 
/*      */     
/*  996 */     x += xinc[d]; y += yinc[d];
/*  997 */     if (x >= 0 && y >= 0 && x < Grid.xSz && y < Grid.ySz && Grid.status[x][y] != 255 && (
/*  998 */       Grid.iSol[x][y] & side[d]) == 0) {
/*  999 */       Grid.iSol[x][y] = Grid.iSol[x][y] | side[d] & mask;
/* 1000 */       this.adjustmentsMade = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   boolean solveSlitherlink(int mode) {
/* 1006 */     int[] na = new int[4], xa = new int[4], ya = new int[4], ia = new int[4];
/* 1007 */     int xNew = 0, yNew = 0;
/*      */     
/* 1009 */     if ((mode & 0x1) != 0) {
/* 1010 */       int i; for (i = 1; i < Grid.ySz; i++) {
/* 1011 */         for (int x = 0; x < Grid.xSz; x++) {
/* 1012 */           if (Grid.letter[x][i] == 51 && Grid.letter[x][i - 1] == 51) {
/* 1013 */             adjust(x, i, 0, 85);
/* 1014 */             adjust(x, i, 2, 85);
/* 1015 */             adjust(x, i - 1, 0, 85);
/* 1016 */             adjust(x - 1, i, 0, 170);
/* 1017 */             adjust(x + 1, i, 0, 170);
/*      */           } 
/*      */         } 
/* 1020 */       }  for (i = 0; i < Grid.ySz; i++) {
/* 1021 */         for (int x = 1; x < Grid.xSz; x++) {
/* 1022 */           if (Grid.letter[x][i] == 51 && Grid.letter[x - 1][i] == 51) {
/* 1023 */             adjust(x, i, 1, 85);
/* 1024 */             adjust(x, i, 3, 85);
/* 1025 */             adjust(x - 1, i, 3, 85);
/* 1026 */             adjust(x, i - 1, 3, 170);
/* 1027 */             adjust(x, i + 1, 3, 170);
/*      */           } 
/*      */         } 
/* 1030 */       }  for (i = 1; i < Grid.ySz; i++) {
/* 1031 */         for (int x = 0; x < Grid.xSz - 1; x++) {
/* 1032 */           if (Grid.letter[x][i] == 51 && Grid.letter[x + 1][i - 1] == 51) {
/* 1033 */             adjust(x, i, 2, 85);
/* 1034 */             adjust(x, i, 3, 85);
/* 1035 */             adjust(x + 1, i - 1, 0, 85);
/* 1036 */             adjust(x + 1, i - 1, 1, 85);
/* 1037 */             if (x == 0 && i == 1) {
/* 1038 */               adjust(x, i, 1, 170);
/* 1039 */               adjust(x + 1, i - 1, 2, 170);
/*      */             } 
/* 1041 */             if (x == Grid.xSz - 2 && i == Grid.ySz - 1) {
/* 1042 */               adjust(x, i, 0, 170);
/* 1043 */               adjust(x + 1, i - 1, 3, 170);
/*      */             } 
/*      */           } 
/*      */         } 
/* 1047 */       }  for (i = 1; i < Grid.ySz; i++) {
/* 1048 */         for (int x = 1; x < Grid.xSz; x++) {
/* 1049 */           if (Grid.letter[x][i] == 51 && Grid.letter[x - 1][i - 1] == 51) {
/* 1050 */             adjust(x, i, 1, 85);
/* 1051 */             adjust(x, i, 2, 85);
/* 1052 */             adjust(x - 1, i - 1, 0, 85);
/* 1053 */             adjust(x - 1, i - 1, 3, 85);
/* 1054 */             if (x == Grid.xSz - 1 && i == 1) {
/* 1055 */               adjust(x, i, 3, 170);
/* 1056 */               adjust(x - 1, i - 1, 2, 170);
/*      */             } 
/* 1058 */             if (x == 1 && i == Grid.ySz - 1) {
/* 1059 */               adjust(x, i, 0, 170);
/* 1060 */               adjust(x - 1, i - 1, 1, 170);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1065 */     }  this.adjustmentsMade = false;
/*      */     
/*      */     int y;
/* 1068 */     for (y = 0; y < Grid.ySz; y++) {
/* 1069 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1070 */         if (Grid.letter[x][y] == 49) {
/* 1071 */           if (x > 0 && y > 0 && ((Grid.iSol[x - 1][y - 1] & 0x3C) == 36 || (Grid.iSol[x - 1][y - 1] & 0x3C) == 24)) {
/* 1072 */             adjust(x, y, 1, 170);
/* 1073 */             adjust(x, y, 2, 170);
/*      */           } 
/* 1075 */           if (x < Grid.xSz - 1 && y > 0 && ((Grid.iSol[x + 1][y - 1] & 0xF0) == 144 || (Grid.iSol[x + 1][y - 1] & 0xF0) == 96)) {
/* 1076 */             adjust(x, y, 2, 170);
/* 1077 */             adjust(x, y, 3, 170);
/*      */           } 
/* 1079 */           if (x < Grid.xSz - 1 && y < Grid.ySz - 1 && ((Grid.iSol[x + 1][y + 1] & 0xC3) == 66 || (Grid.iSol[x + 1][y + 1] & 0xC3) == 129)) {
/* 1080 */             adjust(x, y, 0, 170);
/* 1081 */             adjust(x, y, 3, 170);
/*      */           } 
/* 1083 */           if (x < 0 && y < Grid.ySz - 1 && ((Grid.iSol[x - 1][y + 1] & 0xF) == 9 || (Grid.iSol[x - 1][y + 1] & 0xF) == 6)) {
/* 1084 */             adjust(x, y, 0, 170);
/* 1085 */             adjust(x, y, 1, 170);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1091 */     for (y = 0; y < Grid.ySz; y++) {
/* 1092 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1093 */         if (Grid.letter[x][y] == 51) {
/* 1094 */           if (x > 0 && y > 0 && ((Grid.iSol[x - 1][y - 1] & 0x3C) == 36 || (Grid.iSol[x - 1][y - 1] & 0x3C) == 24)) {
/* 1095 */             adjust(x, y, 1, 85);
/* 1096 */             adjust(x, y, 2, 85);
/*      */           } 
/* 1098 */           if (x < Grid.xSz - 1 && y > 0 && ((Grid.iSol[x + 1][y - 1] & 0xF0) == 144 || (Grid.iSol[x + 1][y - 1] & 0xF0) == 96)) {
/* 1099 */             adjust(x, y, 2, 85);
/* 1100 */             adjust(x, y, 3, 85);
/*      */           } 
/* 1102 */           if (x < Grid.xSz - 1 && y < Grid.ySz - 1 && ((Grid.iSol[x + 1][y + 1] & 0xC3) == 66 || (Grid.iSol[x + 1][y + 1] & 0xC3) == 129)) {
/* 1103 */             adjust(x, y, 0, 85);
/* 1104 */             adjust(x, y, 3, 85);
/*      */           } 
/* 1106 */           if (x < 0 && y < Grid.ySz - 1 && ((Grid.iSol[x - 1][y + 1] & 0xF) == 9 || (Grid.iSol[x - 1][y + 1] & 0xF) == 6)) {
/* 1107 */             adjust(x, y, 0, 85);
/* 1108 */             adjust(x, y, 1, 85);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1114 */     for (y = 0; y < Grid.ySz; y++) {
/* 1115 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1116 */         if (Grid.letter[x][y] == 50) {
/* 1117 */           if (x < Grid.xSz - 1 && Grid.letter[x + 1][y] == 49) {
/* 1118 */             if ((x == 0 || Grid.mode[x - 1][y] != 0 || (Grid.iSol[x - 1][y] & 0x3) == 2) && (y == 0 || Grid.mode[x][y - 1] != 0 || (Grid.iSol[x][y - 1] & 0xCC) == 136)) {
/* 1119 */               adjust(x, y, 0, 85); adjust(x, y, 3, 85); adjust(x + 1, y, 0, 85);
/* 1120 */               adjust(x, y, 1, 170); adjust(x, y, 2, 170); adjust(x + 1, y, 1, 170); adjust(x + 1, y, 2, 170);
/*      */             } 
/* 1122 */             if ((x == 0 || Grid.mode[x - 1][y] != 0 || (Grid.iSol[x - 1][y] & 0x30) == 32) && (y == Grid.ySz - 1 || Grid.mode[x][y + 1] != 0 || (Grid.iSol[x][y + 1] & 0xCC) == 136)) {
/* 1123 */               adjust(x, y, 2, 85); adjust(x, y, 3, 85); adjust(x + 1, y, 2, 85);
/* 1124 */               adjust(x, y, 1, 170); adjust(x, y, 0, 170); adjust(x + 1, y, 0, 170); adjust(x + 1, y, 1, 170);
/*      */             } 
/*      */           } 
/* 1127 */           if (x > 0 && Grid.letter[x - 1][y] == 49) {
/* 1128 */             if ((x == Grid.xSz - 1 || Grid.mode[x + 1][y] != 0 || (Grid.iSol[x + 1][y] & 0x3) == 2) && (y == 0 || Grid.mode[x][y - 1] != 0 || (Grid.iSol[x][y - 1] & 0xCC) == 136)) {
/* 1129 */               adjust(x, y, 0, 85); adjust(x, y, 1, 85); adjust(x - 1, y, 0, 85);
/* 1130 */               adjust(x, y, 3, 170); adjust(x, y, 2, 170); adjust(x - 1, y, 3, 170); adjust(x - 1, y, 2, 170);
/*      */             } 
/* 1132 */             if ((x == Grid.xSz - 1 || Grid.mode[x + 1][y] != 0 || (Grid.iSol[x + 1][y] & 0x30) == 32) && (y == Grid.ySz - 1 || Grid.mode[x][y + 1] != 0 || (Grid.iSol[x][y + 1] & 0xCC) == 136)) {
/* 1133 */               adjust(x, y, 1, 85); adjust(x, y, 2, 85); adjust(x - 1, y, 2, 85);
/* 1134 */               adjust(x, y, 0, 170); adjust(x, y, 3, 170); adjust(x - 1, y, 0, 170); adjust(x - 1, y, 3, 170);
/*      */             } 
/*      */           } 
/* 1137 */           if (y < Grid.ySz - 1 && Grid.letter[x][y + 1] == 49) {
/* 1138 */             if ((y == 0 || Grid.mode[x][y - 1] != 0 || (Grid.iSol[x][y - 1] & 0xC0) == 128) && (x == 0 || Grid.mode[x - 1][y] != 0 || (Grid.iSol[x - 1][y] & 0x33) == 34)) {
/* 1139 */               adjust(x, y, 0, 85); adjust(x, y, 3, 85); adjust(x, y + 1, 3, 85);
/* 1140 */               adjust(x, y, 1, 170); adjust(x, y, 2, 170); adjust(x, y + 1, 1, 170); adjust(x, y + 1, 2, 170);
/*      */             } 
/* 1142 */             if ((y == 0 || Grid.mode[x][y - 1] != 0 || (Grid.iSol[x][y - 1] & 0xC) == 8) && (x == Grid.xSz - 1 || Grid.mode[x + 1][y] != 0 || (Grid.iSol[x + 1][y] & 0x33) == 34)) {
/* 1143 */               adjust(x, y, 0, 85); adjust(x, y, 1, 85); adjust(x, y + 1, 1, 85);
/* 1144 */               adjust(x, y, 3, 170); adjust(x, y, 2, 170); adjust(x, y + 1, 3, 170); adjust(x, y + 1, 2, 170);
/*      */             } 
/*      */           } 
/* 1147 */           if (y > 0 && Grid.letter[x][y - 1] == 49) {
/* 1148 */             if ((y == Grid.ySz - 1 || Grid.mode[x][y + 1] != 0 || (Grid.iSol[x][y + 1] & 0xC0) == 128) && (x == 0 || Grid.mode[x - 1][y] != 0 || (Grid.iSol[x - 1][y] & 0x33) == 34)) {
/* 1149 */               adjust(x, y, 2, 85); adjust(x, y, 3, 85); adjust(x, y - 1, 3, 85);
/* 1150 */               adjust(x, y, 1, 170); adjust(x, y, 0, 170); adjust(x, y - 1, 1, 170); adjust(x, y - 1, 0, 170);
/*      */             } 
/* 1152 */             if ((y == Grid.ySz - 1 || Grid.mode[x][y + 1] != 0 || (Grid.iSol[x][y + 1] & 0xC) == 8) && (x == Grid.xSz - 1 || Grid.mode[x + 1][y] != 0 || (Grid.iSol[x + 1][y] & 0x33) == 34)) {
/* 1153 */               adjust(x, y, 1, 85); adjust(x, y, 2, 85); adjust(x, y - 1, 1, 85);
/* 1154 */               adjust(x, y, 0, 170); adjust(x, y, 3, 170); adjust(x, y - 1, 0, 170); adjust(x, y + 1, 3, 170);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1159 */     }  for (y = 0; y < Grid.ySz; y++) {
/* 1160 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1161 */         if (Grid.status[x][y] != 255 && Grid.letter[x][y] != 32) {
/*      */           
/* 1163 */           int i = getCellStats(x, y);
/* 1164 */           int full = i / 256, pending = i % 256;
/*      */           
/* 1166 */           if (Character.digit(Grid.letter[x][y], 10) == full) {
/* 1167 */             int c; for (i = 0, c = 3; c < 768; c *= 4, i++) {
/* 1168 */               if ((Grid.iSol[x][y] & c) == 0)
/* 1169 */                 adjust(x, y, i, 170); 
/*      */             } 
/* 1171 */           }  if (Character.digit(Grid.letter[x][y], 10) == full + pending) {
/* 1172 */             int c; for (i = 0, c = 3; c < 768; c *= 4, i++)
/* 1173 */             { if ((Grid.iSol[x][y] & c) == 0)
/* 1174 */                 adjust(x, y, i, 85);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1178 */     }  for (y = 0; y < Grid.ySz; y++) {
/* 1179 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1180 */         if (Grid.letter[x][y] == 49) {
/* 1181 */           if (Grid.letter[x + 1][y] == 49 && (
/* 1182 */             y == 0 || y == Grid.ySz - 1 || (Grid.iSol[x][y - 1] & 0xC) == 8 || (Grid.iSol[x][y + 1] & 0xC) == 8))
/* 1183 */             adjust(x, y, 1, 170); 
/* 1184 */           if (Grid.letter[x][y + 1] == 49 && (
/* 1185 */             x == 0 || x == Grid.xSz - 1 || (Grid.iSol[x - 1][y] & 0x30) == 32 || (Grid.iSol[x + 1][y] & 0x30) == 32))
/* 1186 */             adjust(x, y, 2, 170); 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1190 */     for (y = 0; y < Grid.ySz; y++) {
/* 1191 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1192 */         if (Grid.letter[x][y] == 49 && Grid.letter[x + 1][y] == 51) {
/* 1193 */           if (y == 0 || (Grid.iSol[x][y - 1] & 0xC) == 8)
/* 1194 */             adjust(x + 1, y, 0, 85); 
/* 1195 */           if (y == Grid.ySz - 1 || (Grid.iSol[x][y + 1] & 0xC) == 8)
/* 1196 */             adjust(x + 1, y, 2, 85); 
/*      */         } 
/* 1198 */         if (Grid.letter[x][y] == 49 && Grid.letter[x][y + 1] == 51) {
/* 1199 */           if (x == 0 || (Grid.iSol[x - 1][y] & 0x30) == 32)
/* 1200 */             adjust(x, y + 1, 3, 85); 
/* 1201 */           if (x == Grid.xSz - 1 || (Grid.iSol[x + 1][y] & 0x30) == 32)
/* 1202 */             adjust(x, y + 1, 1, 85); 
/*      */         } 
/* 1204 */         if (Grid.letter[x][y] == 51 && Grid.letter[x + 1][y] == 49) {
/* 1205 */           if (y == 0 || (Grid.iSol[x][y - 1] & 0xC) == 8)
/* 1206 */             adjust(x, y, 0, 85); 
/* 1207 */           if (y == Grid.ySz - 1 || (Grid.iSol[x][y + 1] & 0xC) == 8)
/* 1208 */             adjust(x, y, 2, 85); 
/*      */         } 
/* 1210 */         if (Grid.letter[x][y] == 51 && Grid.letter[x][y + 1] == 49) {
/* 1211 */           if (x == 0 || (Grid.iSol[x - 1][y] & 0x30) == 32)
/* 1212 */             adjust(x, y, 3, 85); 
/* 1213 */           if (x == Grid.xSz - 1 || (Grid.iSol[x + 1][y] & 0x30) == 32)
/* 1214 */             adjust(x, y, 1, 85); 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1218 */     for (y = 0; y <= Grid.ySz; y++) {
/* 1219 */       for (int x = 0; x <= Grid.xSz; x++) {
/* 1220 */         int i = getPointStats(x, y, xa, ya, na, ia);
/* 1221 */         int full = i / 256, pending = i % 256;
/*      */         
/* 1223 */         if ((full == 2 && pending != 0) || (pending == 1 && full == 0))
/* 1224 */           for (i = 0; i < 4; i++) {
/* 1225 */             if (na[i] == 0)
/* 1226 */               adjust(xa[i], ya[i], ia[i], 170); 
/*      */           }  
/* 1228 */         if (pending == 1 && full == 1)
/* 1229 */           for (i = 0; i < 4; i++) {
/* 1230 */             if (na[i] == 0)
/* 1231 */               adjust(xa[i], ya[i], ia[i], 85); 
/*      */           }  
/* 1233 */         for (i = 0; i < 4; i++) {
/* 1234 */           if (pending == 2 && full == 0 && na[i] == 0 && na[(i + 1) % 4] == 0 && Grid.letter[xa[i]][ya[i]] == 49)
/* 1235 */             adjust(xa[i], ya[i], i, 170); 
/*      */         } 
/* 1237 */         for (i = 0; i < 4; i++) {
/* 1238 */           if (pending == 2 && full == 0 && na[i] == 0 && na[(i + 1) % 4] == 0 && Grid.letter[xa[i]][ya[i]] == 51)
/* 1239 */             adjust(xa[i], ya[i], i, 85); 
/*      */         } 
/*      */       } 
/* 1242 */     }  if ((mode & 0x2) != 0) {
/*      */       int singles; int triples;
/* 1244 */       for (singles = triples = y = 0; y <= Grid.ySz; y++) {
/* 1245 */         for (int x = 0; x <= Grid.xSz; x++) {
/* 1246 */           int i = getPointStats(x, y, xa, ya, na, ia);
/* 1247 */           int full = i / 256;
/* 1248 */           if (full == 1)
/* 1249 */             singles++; 
/* 1250 */           if (full == 3)
/* 1251 */             triples++; 
/*      */         } 
/*      */       } 
/* 1254 */       if (triples == 0)
/* 1255 */         for (y = 0; y <= Grid.ySz; y++) {
/* 1256 */           for (int x = 0; x <= Grid.xSz; x++) {
/* 1257 */             int i = getPointStats(x, y, xa, ya, na, ia);
/* 1258 */             int full = i / 256;
/* 1259 */             if (full == 1) {
/* 1260 */               int xTrace = x, yTrace = y, xLast = 100, yLast = 100;
/*      */               while (true) {
/* 1262 */                 for (i = 0; i < 4; i++) {
/* 1263 */                   if (na[i] != -1 && (na[i] & 0x55) != 0) {
/* 1264 */                     xNew = xTrace; yNew = yTrace;
/* 1265 */                     switch (i) { case 0:
/* 1266 */                         xNew++; break;
/* 1267 */                       case 1: yNew++; break;
/* 1268 */                       case 2: xNew--; break;
/* 1269 */                       case 3: yNew--; break; }
/*      */                     
/* 1271 */                     if (xNew != xLast || yNew != yLast) {
/*      */                       break;
/*      */                     }
/*      */                   } 
/*      */                 } 
/* 1276 */                 xLast = xTrace; yLast = yTrace;
/* 1277 */                 xTrace = xNew; yTrace = yNew;
/* 1278 */                 i = getPointStats(xTrace, yTrace, xa, ya, na, ia);
/* 1279 */                 full = i / 256;
/* 1280 */                 if (full == 1) {
/* 1281 */                   if ((xTrace == x && yTrace == y + 1) || (yTrace == y && xTrace == x + 1))
/*      */                   {
/* 1283 */                     adjust(x, y, (x == xTrace) ? 3 : 0, (singles == 2) ? 85 : 170); }  break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }  
/*      */     } 
/* 1290 */     return this.adjustmentsMade;
/*      */   }
/*      */   int getCellStats(int x, int y) {
/*      */     int c;
/*      */     int full;
/*      */     int pending;
/* 1296 */     for (full = pending = 0, c = 3; c < 768; c *= 4) {
/* 1297 */       int n = Grid.iSol[x][y] & c;
/* 1298 */       if (n == 0) { pending++; }
/* 1299 */       else if ((n & 0x55) != 0) { full++; }
/*      */     
/* 1301 */     }  return full * 256 + pending;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createPath() {
/*      */     // Byte code:
/*      */     //   0: new java/util/Random
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_1
/*      */     //   8: bipush #13
/*      */     //   10: anewarray [I
/*      */     //   13: dup
/*      */     //   14: iconst_0
/*      */     //   15: iconst_4
/*      */     //   16: newarray int
/*      */     //   18: dup
/*      */     //   19: iconst_0
/*      */     //   20: iconst_0
/*      */     //   21: iastore
/*      */     //   22: dup
/*      */     //   23: iconst_1
/*      */     //   24: iconst_1
/*      */     //   25: iastore
/*      */     //   26: dup
/*      */     //   27: iconst_2
/*      */     //   28: iconst_2
/*      */     //   29: iastore
/*      */     //   30: dup
/*      */     //   31: iconst_3
/*      */     //   32: iconst_3
/*      */     //   33: iastore
/*      */     //   34: aastore
/*      */     //   35: dup
/*      */     //   36: iconst_1
/*      */     //   37: iconst_5
/*      */     //   38: newarray int
/*      */     //   40: dup
/*      */     //   41: iconst_0
/*      */     //   42: iconst_0
/*      */     //   43: iastore
/*      */     //   44: dup
/*      */     //   45: iconst_1
/*      */     //   46: iconst_0
/*      */     //   47: iastore
/*      */     //   48: dup
/*      */     //   49: iconst_2
/*      */     //   50: iconst_1
/*      */     //   51: iastore
/*      */     //   52: dup
/*      */     //   53: iconst_3
/*      */     //   54: iconst_2
/*      */     //   55: iastore
/*      */     //   56: dup
/*      */     //   57: iconst_4
/*      */     //   58: iconst_3
/*      */     //   59: iastore
/*      */     //   60: aastore
/*      */     //   61: dup
/*      */     //   62: iconst_2
/*      */     //   63: iconst_5
/*      */     //   64: newarray int
/*      */     //   66: dup
/*      */     //   67: iconst_0
/*      */     //   68: iconst_1
/*      */     //   69: iastore
/*      */     //   70: dup
/*      */     //   71: iconst_1
/*      */     //   72: iconst_1
/*      */     //   73: iastore
/*      */     //   74: dup
/*      */     //   75: iconst_2
/*      */     //   76: iconst_0
/*      */     //   77: iastore
/*      */     //   78: dup
/*      */     //   79: iconst_3
/*      */     //   80: iconst_3
/*      */     //   81: iastore
/*      */     //   82: dup
/*      */     //   83: iconst_4
/*      */     //   84: iconst_2
/*      */     //   85: iastore
/*      */     //   86: aastore
/*      */     //   87: dup
/*      */     //   88: iconst_3
/*      */     //   89: iconst_5
/*      */     //   90: newarray int
/*      */     //   92: dup
/*      */     //   93: iconst_0
/*      */     //   94: iconst_2
/*      */     //   95: iastore
/*      */     //   96: dup
/*      */     //   97: iconst_1
/*      */     //   98: iconst_2
/*      */     //   99: iastore
/*      */     //   100: dup
/*      */     //   101: iconst_2
/*      */     //   102: iconst_0
/*      */     //   103: iastore
/*      */     //   104: dup
/*      */     //   105: iconst_3
/*      */     //   106: iconst_1
/*      */     //   107: iastore
/*      */     //   108: dup
/*      */     //   109: iconst_4
/*      */     //   110: iconst_3
/*      */     //   111: iastore
/*      */     //   112: aastore
/*      */     //   113: dup
/*      */     //   114: iconst_4
/*      */     //   115: iconst_5
/*      */     //   116: newarray int
/*      */     //   118: dup
/*      */     //   119: iconst_0
/*      */     //   120: iconst_3
/*      */     //   121: iastore
/*      */     //   122: dup
/*      */     //   123: iconst_1
/*      */     //   124: iconst_3
/*      */     //   125: iastore
/*      */     //   126: dup
/*      */     //   127: iconst_2
/*      */     //   128: iconst_0
/*      */     //   129: iastore
/*      */     //   130: dup
/*      */     //   131: iconst_3
/*      */     //   132: iconst_1
/*      */     //   133: iastore
/*      */     //   134: dup
/*      */     //   135: iconst_4
/*      */     //   136: iconst_2
/*      */     //   137: iastore
/*      */     //   138: aastore
/*      */     //   139: dup
/*      */     //   140: iconst_5
/*      */     //   141: bipush #6
/*      */     //   143: newarray int
/*      */     //   145: dup
/*      */     //   146: iconst_0
/*      */     //   147: iconst_0
/*      */     //   148: iastore
/*      */     //   149: dup
/*      */     //   150: iconst_1
/*      */     //   151: iconst_0
/*      */     //   152: iastore
/*      */     //   153: dup
/*      */     //   154: iconst_2
/*      */     //   155: iconst_1
/*      */     //   156: iastore
/*      */     //   157: dup
/*      */     //   158: iconst_3
/*      */     //   159: iconst_1
/*      */     //   160: iastore
/*      */     //   161: dup
/*      */     //   162: iconst_4
/*      */     //   163: iconst_2
/*      */     //   164: iastore
/*      */     //   165: dup
/*      */     //   166: iconst_5
/*      */     //   167: iconst_3
/*      */     //   168: iastore
/*      */     //   169: aastore
/*      */     //   170: dup
/*      */     //   171: bipush #6
/*      */     //   173: bipush #6
/*      */     //   175: newarray int
/*      */     //   177: dup
/*      */     //   178: iconst_0
/*      */     //   179: iconst_1
/*      */     //   180: iastore
/*      */     //   181: dup
/*      */     //   182: iconst_1
/*      */     //   183: iconst_1
/*      */     //   184: iastore
/*      */     //   185: dup
/*      */     //   186: iconst_2
/*      */     //   187: iconst_2
/*      */     //   188: iastore
/*      */     //   189: dup
/*      */     //   190: iconst_3
/*      */     //   191: iconst_2
/*      */     //   192: iastore
/*      */     //   193: dup
/*      */     //   194: iconst_4
/*      */     //   195: iconst_3
/*      */     //   196: iastore
/*      */     //   197: dup
/*      */     //   198: iconst_5
/*      */     //   199: iconst_0
/*      */     //   200: iastore
/*      */     //   201: aastore
/*      */     //   202: dup
/*      */     //   203: bipush #7
/*      */     //   205: bipush #6
/*      */     //   207: newarray int
/*      */     //   209: dup
/*      */     //   210: iconst_0
/*      */     //   211: iconst_2
/*      */     //   212: iastore
/*      */     //   213: dup
/*      */     //   214: iconst_1
/*      */     //   215: iconst_2
/*      */     //   216: iastore
/*      */     //   217: dup
/*      */     //   218: iconst_2
/*      */     //   219: iconst_3
/*      */     //   220: iastore
/*      */     //   221: dup
/*      */     //   222: iconst_3
/*      */     //   223: iconst_3
/*      */     //   224: iastore
/*      */     //   225: dup
/*      */     //   226: iconst_4
/*      */     //   227: iconst_0
/*      */     //   228: iastore
/*      */     //   229: dup
/*      */     //   230: iconst_5
/*      */     //   231: iconst_1
/*      */     //   232: iastore
/*      */     //   233: aastore
/*      */     //   234: dup
/*      */     //   235: bipush #8
/*      */     //   237: bipush #6
/*      */     //   239: newarray int
/*      */     //   241: dup
/*      */     //   242: iconst_0
/*      */     //   243: iconst_3
/*      */     //   244: iastore
/*      */     //   245: dup
/*      */     //   246: iconst_1
/*      */     //   247: iconst_3
/*      */     //   248: iastore
/*      */     //   249: dup
/*      */     //   250: iconst_2
/*      */     //   251: iconst_0
/*      */     //   252: iastore
/*      */     //   253: dup
/*      */     //   254: iconst_3
/*      */     //   255: iconst_0
/*      */     //   256: iastore
/*      */     //   257: dup
/*      */     //   258: iconst_4
/*      */     //   259: iconst_1
/*      */     //   260: iastore
/*      */     //   261: dup
/*      */     //   262: iconst_5
/*      */     //   263: iconst_2
/*      */     //   264: iastore
/*      */     //   265: aastore
/*      */     //   266: dup
/*      */     //   267: bipush #9
/*      */     //   269: bipush #7
/*      */     //   271: newarray int
/*      */     //   273: dup
/*      */     //   274: iconst_0
/*      */     //   275: iconst_0
/*      */     //   276: iastore
/*      */     //   277: dup
/*      */     //   278: iconst_1
/*      */     //   279: iconst_0
/*      */     //   280: iastore
/*      */     //   281: dup
/*      */     //   282: iconst_2
/*      */     //   283: iconst_1
/*      */     //   284: iastore
/*      */     //   285: dup
/*      */     //   286: iconst_3
/*      */     //   287: iconst_1
/*      */     //   288: iastore
/*      */     //   289: dup
/*      */     //   290: iconst_4
/*      */     //   291: iconst_2
/*      */     //   292: iastore
/*      */     //   293: dup
/*      */     //   294: iconst_5
/*      */     //   295: iconst_2
/*      */     //   296: iastore
/*      */     //   297: dup
/*      */     //   298: bipush #6
/*      */     //   300: iconst_3
/*      */     //   301: iastore
/*      */     //   302: aastore
/*      */     //   303: dup
/*      */     //   304: bipush #10
/*      */     //   306: bipush #7
/*      */     //   308: newarray int
/*      */     //   310: dup
/*      */     //   311: iconst_0
/*      */     //   312: iconst_1
/*      */     //   313: iastore
/*      */     //   314: dup
/*      */     //   315: iconst_1
/*      */     //   316: iconst_1
/*      */     //   317: iastore
/*      */     //   318: dup
/*      */     //   319: iconst_2
/*      */     //   320: iconst_2
/*      */     //   321: iastore
/*      */     //   322: dup
/*      */     //   323: iconst_3
/*      */     //   324: iconst_2
/*      */     //   325: iastore
/*      */     //   326: dup
/*      */     //   327: iconst_4
/*      */     //   328: iconst_3
/*      */     //   329: iastore
/*      */     //   330: dup
/*      */     //   331: iconst_5
/*      */     //   332: iconst_3
/*      */     //   333: iastore
/*      */     //   334: dup
/*      */     //   335: bipush #6
/*      */     //   337: iconst_0
/*      */     //   338: iastore
/*      */     //   339: aastore
/*      */     //   340: dup
/*      */     //   341: bipush #11
/*      */     //   343: bipush #7
/*      */     //   345: newarray int
/*      */     //   347: dup
/*      */     //   348: iconst_0
/*      */     //   349: iconst_2
/*      */     //   350: iastore
/*      */     //   351: dup
/*      */     //   352: iconst_1
/*      */     //   353: iconst_2
/*      */     //   354: iastore
/*      */     //   355: dup
/*      */     //   356: iconst_2
/*      */     //   357: iconst_3
/*      */     //   358: iastore
/*      */     //   359: dup
/*      */     //   360: iconst_3
/*      */     //   361: iconst_3
/*      */     //   362: iastore
/*      */     //   363: dup
/*      */     //   364: iconst_4
/*      */     //   365: iconst_0
/*      */     //   366: iastore
/*      */     //   367: dup
/*      */     //   368: iconst_5
/*      */     //   369: iconst_0
/*      */     //   370: iastore
/*      */     //   371: dup
/*      */     //   372: bipush #6
/*      */     //   374: iconst_1
/*      */     //   375: iastore
/*      */     //   376: aastore
/*      */     //   377: dup
/*      */     //   378: bipush #12
/*      */     //   380: bipush #7
/*      */     //   382: newarray int
/*      */     //   384: dup
/*      */     //   385: iconst_0
/*      */     //   386: iconst_3
/*      */     //   387: iastore
/*      */     //   388: dup
/*      */     //   389: iconst_1
/*      */     //   390: iconst_3
/*      */     //   391: iastore
/*      */     //   392: dup
/*      */     //   393: iconst_2
/*      */     //   394: iconst_0
/*      */     //   395: iastore
/*      */     //   396: dup
/*      */     //   397: iconst_3
/*      */     //   398: iconst_0
/*      */     //   399: iastore
/*      */     //   400: dup
/*      */     //   401: iconst_4
/*      */     //   402: iconst_1
/*      */     //   403: iastore
/*      */     //   404: dup
/*      */     //   405: iconst_5
/*      */     //   406: iconst_1
/*      */     //   407: iastore
/*      */     //   408: dup
/*      */     //   409: bipush #6
/*      */     //   411: iconst_2
/*      */     //   412: iastore
/*      */     //   413: aastore
/*      */     //   414: astore #7
/*      */     //   416: iconst_0
/*      */     //   417: dup
/*      */     //   418: istore #5
/*      */     //   420: istore #6
/*      */     //   422: iload #5
/*      */     //   424: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   427: if_icmpge -> 493
/*      */     //   430: iconst_0
/*      */     //   431: istore #4
/*      */     //   433: iload #4
/*      */     //   435: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   438: if_icmpge -> 487
/*      */     //   441: getstatic crosswordexpress/Grid.mode : [[I
/*      */     //   444: iload #4
/*      */     //   446: aaload
/*      */     //   447: iload #5
/*      */     //   449: iaload
/*      */     //   450: ifeq -> 456
/*      */     //   453: goto -> 481
/*      */     //   456: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   459: iload #4
/*      */     //   461: aaload
/*      */     //   462: iload #5
/*      */     //   464: iconst_0
/*      */     //   465: iastore
/*      */     //   466: getstatic crosswordexpress/Grid.status : [[I
/*      */     //   469: iload #4
/*      */     //   471: aaload
/*      */     //   472: iload #5
/*      */     //   474: iaload
/*      */     //   475: ifne -> 481
/*      */     //   478: iinc #6, 1
/*      */     //   481: iinc #4, 1
/*      */     //   484: goto -> 433
/*      */     //   487: iinc #5, 1
/*      */     //   490: goto -> 422
/*      */     //   493: aload_1
/*      */     //   494: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   497: invokevirtual nextInt : (I)I
/*      */     //   500: istore #4
/*      */     //   502: aload_1
/*      */     //   503: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   506: invokevirtual nextInt : (I)I
/*      */     //   509: istore #5
/*      */     //   511: getstatic crosswordexpress/Grid.mode : [[I
/*      */     //   514: iload #4
/*      */     //   516: aaload
/*      */     //   517: iload #5
/*      */     //   519: iaload
/*      */     //   520: ifeq -> 526
/*      */     //   523: goto -> 493
/*      */     //   526: getstatic crosswordexpress/Grid.status : [[I
/*      */     //   529: iload #4
/*      */     //   531: aaload
/*      */     //   532: iload #5
/*      */     //   534: iaload
/*      */     //   535: ifne -> 493
/*      */     //   538: iconst_0
/*      */     //   539: istore_2
/*      */     //   540: iload_2
/*      */     //   541: iconst_4
/*      */     //   542: if_icmpge -> 564
/*      */     //   545: iload #4
/*      */     //   547: iload #5
/*      */     //   549: aload #7
/*      */     //   551: iconst_0
/*      */     //   552: aaload
/*      */     //   553: iload_2
/*      */     //   554: iinc #2, 1
/*      */     //   557: iaload
/*      */     //   558: invokestatic UpdateSlitherLink : (III)V
/*      */     //   561: goto -> 540
/*      */     //   564: iconst_0
/*      */     //   565: istore_3
/*      */     //   566: iload_3
/*      */     //   567: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   570: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   573: imul
/*      */     //   574: iconst_4
/*      */     //   575: imul
/*      */     //   576: if_icmpge -> 1176
/*      */     //   579: aload_1
/*      */     //   580: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   583: invokevirtual nextInt : (I)I
/*      */     //   586: istore #4
/*      */     //   588: aload_1
/*      */     //   589: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   592: invokevirtual nextInt : (I)I
/*      */     //   595: istore #5
/*      */     //   597: getstatic crosswordexpress/Grid.status : [[I
/*      */     //   600: iload #4
/*      */     //   602: aaload
/*      */     //   603: iload #5
/*      */     //   605: iaload
/*      */     //   606: ifeq -> 612
/*      */     //   609: goto -> 1170
/*      */     //   612: getstatic crosswordexpress/Grid.mode : [[I
/*      */     //   615: iload #4
/*      */     //   617: aaload
/*      */     //   618: iload #5
/*      */     //   620: iaload
/*      */     //   621: ifeq -> 627
/*      */     //   624: goto -> 1170
/*      */     //   627: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   630: iload #4
/*      */     //   632: aaload
/*      */     //   633: iload #5
/*      */     //   635: iaload
/*      */     //   636: lookupswitch default -> 1170, 1 -> 712, 4 -> 768, 5 -> 924, 16 -> 818, 20 -> 984, 64 -> 869, 65 -> 1103, 80 -> 1041
/*      */     //   712: iload #5
/*      */     //   714: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   717: iconst_1
/*      */     //   718: isub
/*      */     //   719: if_icmpeq -> 740
/*      */     //   722: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   725: iload #4
/*      */     //   727: aaload
/*      */     //   728: iload #5
/*      */     //   730: iconst_1
/*      */     //   731: iadd
/*      */     //   732: iaload
/*      */     //   733: sipush #204
/*      */     //   736: iand
/*      */     //   737: ifne -> 1170
/*      */     //   740: iconst_0
/*      */     //   741: istore_3
/*      */     //   742: iconst_0
/*      */     //   743: istore_2
/*      */     //   744: iload_2
/*      */     //   745: iconst_5
/*      */     //   746: if_icmpge -> 1170
/*      */     //   749: iload #4
/*      */     //   751: iload #5
/*      */     //   753: aload #7
/*      */     //   755: iconst_1
/*      */     //   756: aaload
/*      */     //   757: iload_2
/*      */     //   758: iinc #2, 1
/*      */     //   761: iaload
/*      */     //   762: invokestatic UpdateSlitherLink : (III)V
/*      */     //   765: goto -> 744
/*      */     //   768: iload #4
/*      */     //   770: ifeq -> 790
/*      */     //   773: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   776: iload #4
/*      */     //   778: iconst_1
/*      */     //   779: isub
/*      */     //   780: aaload
/*      */     //   781: iload #5
/*      */     //   783: iaload
/*      */     //   784: bipush #51
/*      */     //   786: iand
/*      */     //   787: ifne -> 1170
/*      */     //   790: iconst_0
/*      */     //   791: istore_3
/*      */     //   792: iconst_0
/*      */     //   793: istore_2
/*      */     //   794: iload_2
/*      */     //   795: iconst_5
/*      */     //   796: if_icmpge -> 1170
/*      */     //   799: iload #4
/*      */     //   801: iload #5
/*      */     //   803: aload #7
/*      */     //   805: iconst_2
/*      */     //   806: aaload
/*      */     //   807: iload_2
/*      */     //   808: iinc #2, 1
/*      */     //   811: iaload
/*      */     //   812: invokestatic UpdateSlitherLink : (III)V
/*      */     //   815: goto -> 794
/*      */     //   818: iload #5
/*      */     //   820: ifeq -> 841
/*      */     //   823: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   826: iload #4
/*      */     //   828: aaload
/*      */     //   829: iload #5
/*      */     //   831: iconst_1
/*      */     //   832: isub
/*      */     //   833: iaload
/*      */     //   834: sipush #204
/*      */     //   837: iand
/*      */     //   838: ifne -> 1170
/*      */     //   841: iconst_0
/*      */     //   842: istore_3
/*      */     //   843: iconst_0
/*      */     //   844: istore_2
/*      */     //   845: iload_2
/*      */     //   846: iconst_5
/*      */     //   847: if_icmpge -> 1170
/*      */     //   850: iload #4
/*      */     //   852: iload #5
/*      */     //   854: aload #7
/*      */     //   856: iconst_3
/*      */     //   857: aaload
/*      */     //   858: iload_2
/*      */     //   859: iinc #2, 1
/*      */     //   862: iaload
/*      */     //   863: invokestatic UpdateSlitherLink : (III)V
/*      */     //   866: goto -> 845
/*      */     //   869: iload #4
/*      */     //   871: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   874: iconst_1
/*      */     //   875: isub
/*      */     //   876: if_icmpeq -> 896
/*      */     //   879: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   882: iload #4
/*      */     //   884: iconst_1
/*      */     //   885: iadd
/*      */     //   886: aaload
/*      */     //   887: iload #5
/*      */     //   889: iaload
/*      */     //   890: bipush #51
/*      */     //   892: iand
/*      */     //   893: ifne -> 1170
/*      */     //   896: iconst_0
/*      */     //   897: istore_3
/*      */     //   898: iconst_0
/*      */     //   899: istore_2
/*      */     //   900: iload_2
/*      */     //   901: iconst_5
/*      */     //   902: if_icmpge -> 1170
/*      */     //   905: iload #4
/*      */     //   907: iload #5
/*      */     //   909: aload #7
/*      */     //   911: iconst_4
/*      */     //   912: aaload
/*      */     //   913: iload_2
/*      */     //   914: iinc #2, 1
/*      */     //   917: iaload
/*      */     //   918: invokestatic UpdateSlitherLink : (III)V
/*      */     //   921: goto -> 900
/*      */     //   924: iload #4
/*      */     //   926: ifeq -> 957
/*      */     //   929: iload #5
/*      */     //   931: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   934: iconst_1
/*      */     //   935: isub
/*      */     //   936: if_icmpeq -> 957
/*      */     //   939: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   942: iload #4
/*      */     //   944: iconst_1
/*      */     //   945: isub
/*      */     //   946: aaload
/*      */     //   947: iload #5
/*      */     //   949: iconst_1
/*      */     //   950: iadd
/*      */     //   951: iaload
/*      */     //   952: iconst_5
/*      */     //   953: iand
/*      */     //   954: ifne -> 1170
/*      */     //   957: iconst_0
/*      */     //   958: istore_2
/*      */     //   959: iload_2
/*      */     //   960: bipush #6
/*      */     //   962: if_icmpge -> 1170
/*      */     //   965: iload #4
/*      */     //   967: iload #5
/*      */     //   969: aload #7
/*      */     //   971: iconst_5
/*      */     //   972: aaload
/*      */     //   973: iload_2
/*      */     //   974: iinc #2, 1
/*      */     //   977: iaload
/*      */     //   978: invokestatic UpdateSlitherLink : (III)V
/*      */     //   981: goto -> 959
/*      */     //   984: iload #4
/*      */     //   986: ifeq -> 1013
/*      */     //   989: iload #5
/*      */     //   991: ifeq -> 1013
/*      */     //   994: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   997: iload #4
/*      */     //   999: iconst_1
/*      */     //   1000: isub
/*      */     //   1001: aaload
/*      */     //   1002: iload #5
/*      */     //   1004: iconst_1
/*      */     //   1005: isub
/*      */     //   1006: iaload
/*      */     //   1007: bipush #20
/*      */     //   1009: iand
/*      */     //   1010: ifne -> 1170
/*      */     //   1013: iconst_0
/*      */     //   1014: istore_2
/*      */     //   1015: iload_2
/*      */     //   1016: bipush #6
/*      */     //   1018: if_icmpge -> 1170
/*      */     //   1021: iload #4
/*      */     //   1023: iload #5
/*      */     //   1025: aload #7
/*      */     //   1027: bipush #6
/*      */     //   1029: aaload
/*      */     //   1030: iload_2
/*      */     //   1031: iinc #2, 1
/*      */     //   1034: iaload
/*      */     //   1035: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1038: goto -> 1015
/*      */     //   1041: iload #4
/*      */     //   1043: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   1046: iconst_1
/*      */     //   1047: isub
/*      */     //   1048: if_icmpeq -> 1075
/*      */     //   1051: iload #5
/*      */     //   1053: ifeq -> 1075
/*      */     //   1056: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   1059: iload #4
/*      */     //   1061: iconst_1
/*      */     //   1062: iadd
/*      */     //   1063: aaload
/*      */     //   1064: iload #5
/*      */     //   1066: iconst_1
/*      */     //   1067: isub
/*      */     //   1068: iaload
/*      */     //   1069: bipush #80
/*      */     //   1071: iand
/*      */     //   1072: ifne -> 1170
/*      */     //   1075: iconst_0
/*      */     //   1076: istore_2
/*      */     //   1077: iload_2
/*      */     //   1078: bipush #6
/*      */     //   1080: if_icmpge -> 1170
/*      */     //   1083: iload #4
/*      */     //   1085: iload #5
/*      */     //   1087: aload #7
/*      */     //   1089: bipush #7
/*      */     //   1091: aaload
/*      */     //   1092: iload_2
/*      */     //   1093: iinc #2, 1
/*      */     //   1096: iaload
/*      */     //   1097: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1100: goto -> 1077
/*      */     //   1103: iload #4
/*      */     //   1105: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   1108: iconst_1
/*      */     //   1109: isub
/*      */     //   1110: if_icmpeq -> 1142
/*      */     //   1113: iload #5
/*      */     //   1115: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   1118: iconst_1
/*      */     //   1119: isub
/*      */     //   1120: if_icmpeq -> 1142
/*      */     //   1123: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   1126: iload #4
/*      */     //   1128: iconst_1
/*      */     //   1129: iadd
/*      */     //   1130: aaload
/*      */     //   1131: iload #5
/*      */     //   1133: iconst_1
/*      */     //   1134: iadd
/*      */     //   1135: iaload
/*      */     //   1136: bipush #65
/*      */     //   1138: iand
/*      */     //   1139: ifne -> 1170
/*      */     //   1142: iconst_0
/*      */     //   1143: istore_2
/*      */     //   1144: iload_2
/*      */     //   1145: bipush #6
/*      */     //   1147: if_icmpge -> 1170
/*      */     //   1150: iload #4
/*      */     //   1152: iload #5
/*      */     //   1154: aload #7
/*      */     //   1156: bipush #8
/*      */     //   1158: aaload
/*      */     //   1159: iload_2
/*      */     //   1160: iinc #2, 1
/*      */     //   1163: iaload
/*      */     //   1164: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1167: goto -> 1144
/*      */     //   1170: iinc #3, 1
/*      */     //   1173: goto -> 566
/*      */     //   1176: iconst_0
/*      */     //   1177: istore_3
/*      */     //   1178: iload_3
/*      */     //   1179: iload #6
/*      */     //   1181: bipush #6
/*      */     //   1183: idiv
/*      */     //   1184: if_icmpge -> 1415
/*      */     //   1187: aload_1
/*      */     //   1188: getstatic crosswordexpress/Grid.xSz : I
/*      */     //   1191: invokevirtual nextInt : (I)I
/*      */     //   1194: istore #4
/*      */     //   1196: aload_1
/*      */     //   1197: getstatic crosswordexpress/Grid.ySz : I
/*      */     //   1200: invokevirtual nextInt : (I)I
/*      */     //   1203: istore #5
/*      */     //   1205: getstatic crosswordexpress/Grid.status : [[I
/*      */     //   1208: iload #4
/*      */     //   1210: aaload
/*      */     //   1211: iload #5
/*      */     //   1213: iaload
/*      */     //   1214: ifeq -> 1220
/*      */     //   1217: goto -> 1178
/*      */     //   1220: getstatic crosswordexpress/Grid.mode : [[I
/*      */     //   1223: iload #4
/*      */     //   1225: aaload
/*      */     //   1226: iload #5
/*      */     //   1228: iaload
/*      */     //   1229: ifeq -> 1235
/*      */     //   1232: goto -> 1178
/*      */     //   1235: getstatic crosswordexpress/Grid.iSol : [[I
/*      */     //   1238: iload #4
/*      */     //   1240: aaload
/*      */     //   1241: iload #5
/*      */     //   1243: iaload
/*      */     //   1244: lookupswitch default -> 1412, 21 -> 1288, 69 -> 1381, 81 -> 1350, 84 -> 1319
/*      */     //   1288: iinc #3, 1
/*      */     //   1291: iconst_0
/*      */     //   1292: istore_2
/*      */     //   1293: iload_2
/*      */     //   1294: bipush #7
/*      */     //   1296: if_icmpge -> 1412
/*      */     //   1299: iload #4
/*      */     //   1301: iload #5
/*      */     //   1303: aload #7
/*      */     //   1305: bipush #9
/*      */     //   1307: aaload
/*      */     //   1308: iload_2
/*      */     //   1309: iinc #2, 1
/*      */     //   1312: iaload
/*      */     //   1313: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1316: goto -> 1293
/*      */     //   1319: iinc #3, 1
/*      */     //   1322: iconst_0
/*      */     //   1323: istore_2
/*      */     //   1324: iload_2
/*      */     //   1325: bipush #7
/*      */     //   1327: if_icmpge -> 1412
/*      */     //   1330: iload #4
/*      */     //   1332: iload #5
/*      */     //   1334: aload #7
/*      */     //   1336: bipush #10
/*      */     //   1338: aaload
/*      */     //   1339: iload_2
/*      */     //   1340: iinc #2, 1
/*      */     //   1343: iaload
/*      */     //   1344: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1347: goto -> 1324
/*      */     //   1350: iinc #3, 1
/*      */     //   1353: iconst_0
/*      */     //   1354: istore_2
/*      */     //   1355: iload_2
/*      */     //   1356: bipush #7
/*      */     //   1358: if_icmpge -> 1412
/*      */     //   1361: iload #4
/*      */     //   1363: iload #5
/*      */     //   1365: aload #7
/*      */     //   1367: bipush #11
/*      */     //   1369: aaload
/*      */     //   1370: iload_2
/*      */     //   1371: iinc #2, 1
/*      */     //   1374: iaload
/*      */     //   1375: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1378: goto -> 1355
/*      */     //   1381: iinc #3, 1
/*      */     //   1384: iconst_0
/*      */     //   1385: istore_2
/*      */     //   1386: iload_2
/*      */     //   1387: bipush #7
/*      */     //   1389: if_icmpge -> 1412
/*      */     //   1392: iload #4
/*      */     //   1394: iload #5
/*      */     //   1396: aload #7
/*      */     //   1398: bipush #12
/*      */     //   1400: aaload
/*      */     //   1401: iload_2
/*      */     //   1402: iinc #2, 1
/*      */     //   1405: iaload
/*      */     //   1406: invokestatic UpdateSlitherLink : (III)V
/*      */     //   1409: goto -> 1386
/*      */     //   1412: goto -> 1178
/*      */     //   1415: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1305	-> 0
/*      */     //   #1307	-> 8
/*      */     //   #1323	-> 416
/*      */     //   #1324	-> 430
/*      */     //   #1325	-> 441
/*      */     //   #1326	-> 456
/*      */     //   #1327	-> 466
/*      */     //   #1328	-> 478
/*      */     //   #1324	-> 481
/*      */     //   #1323	-> 487
/*      */     //   #1332	-> 493
/*      */     //   #1333	-> 511
/*      */     //   #1334	-> 526
/*      */     //   #1335	-> 538
/*      */     //   #1340	-> 564
/*      */     //   #1341	-> 579
/*      */     //   #1342	-> 597
/*      */     //   #1343	-> 612
/*      */     //   #1344	-> 627
/*      */     //   #1346	-> 712
/*      */     //   #1347	-> 740
/*      */     //   #1350	-> 768
/*      */     //   #1351	-> 790
/*      */     //   #1354	-> 818
/*      */     //   #1355	-> 841
/*      */     //   #1358	-> 869
/*      */     //   #1359	-> 896
/*      */     //   #1362	-> 924
/*      */     //   #1363	-> 957
/*      */     //   #1366	-> 984
/*      */     //   #1367	-> 1013
/*      */     //   #1370	-> 1041
/*      */     //   #1371	-> 1075
/*      */     //   #1374	-> 1103
/*      */     //   #1375	-> 1142
/*      */     //   #1340	-> 1170
/*      */     //   #1380	-> 1176
/*      */     //   #1381	-> 1187
/*      */     //   #1382	-> 1205
/*      */     //   #1383	-> 1220
/*      */     //   #1384	-> 1235
/*      */     //   #1386	-> 1288
/*      */     //   #1389	-> 1319
/*      */     //   #1392	-> 1350
/*      */     //   #1395	-> 1381
/*      */     //   #1396	-> 1412
/*      */     //   #1399	-> 1415
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   433	57	4	x	I
/*      */     //   0	1416	0	this	Lcrosswordexpress/SlitherlinkBuild;
/*      */     //   8	1408	1	r	Ljava/util/Random;
/*      */     //   540	24	2	i	I
/*      */     //   744	672	2	i	I
/*      */     //   566	850	3	j	I
/*      */     //   502	914	4	x	I
/*      */     //   420	996	5	y	I
/*      */     //   422	994	6	count	I
/*      */     //   416	1000	7	control	[[I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Boolean UpdateSlitherLinkCell(int x, int y, int side) {
/* 1402 */     int[] mask = { 3, 12, 48, 192, 252, 243, 207, 63 };
/* 1403 */     int[] inc = { 1, 4, 16, 64 };
/*      */     
/* 1405 */     if (x < 0 || y < 0 || x >= Grid.xSz || y >= Grid.ySz) return Boolean.valueOf(false); 
/* 1406 */     if ((Grid.iSol[x][y] & mask[side] & 0xAA) != 0) {
/* 1407 */       Grid.iSol[x][y] = Grid.iSol[x][y] & mask[side + 4];
/*      */     } else {
/* 1409 */       Grid.iSol[x][y] = Grid.iSol[x][y] + inc[side];
/* 1410 */     }  if (Def.building == 0)
/* 1411 */       Grid.status[x][y] = Grid.iSol[x][y]; 
/* 1412 */     return Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void UpdateSlitherLink(int x, int y, int side) {
/* 1416 */     UpdateSlitherLinkCell(x, y, side);
/*      */     
/* 1418 */     switch (side) { case 0:
/* 1419 */         UpdateSlitherLinkCell(x, --y, 2); break;
/* 1420 */       case 1: UpdateSlitherLinkCell(++x, y, 3); break;
/* 1421 */       case 2: UpdateSlitherLinkCell(x, ++y, 0); break;
/* 1422 */       case 3: UpdateSlitherLinkCell(--x, y, 1);
/*      */         break; }
/*      */   
/*      */   }
/*      */   private void multiBuild() {
/* 1427 */     String title = Methods.puzzleTitle;
/* 1428 */     int[] sizeDef = { 5, 6, 7, 8, 9, 10, 10 };
/* 1429 */     int saveSlitherlinkSize = Op.getInt(Op.SL.SlAcross.ordinal(), Op.sl);
/*      */     
/* 1431 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1432 */     Calendar c = Calendar.getInstance();
/*      */     
/* 1434 */     for (this.hmCount = 1; this.hmCount <= this.howMany; this.hmCount++) {
/* 1435 */       if (this.startPuz > 9999999) { try {
/* 1436 */           c.setTime(sdf.parse("" + this.startPuz));
/* 1437 */         } catch (ParseException ex) {}
/* 1438 */         this.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 1441 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/* 1442 */         Grid.xSz = Grid.ySz = sizeDef[(this.startPuz - 1) % 7];
/* 1443 */         Op.setInt(Op.SL.SlAcross.ordinal(), Grid.xSz, Op.sl);
/* 1444 */         Op.setInt(Op.SL.SlDown.ordinal(), Grid.xSz, Op.sl);
/*      */       } 
/* 1446 */       Methods.puzzleTitle = "SLITHERLINK Puzzle : " + this.startPuz;
/*      */       
/* 1448 */       Methods.buildProgress(jfSlitherlink, Op.sl[Op.SL.SlPuz
/* 1449 */             .ordinal()] = "" + this.startPuz + ".slitherlink");
/* 1450 */       buildSlitherLink();
/* 1451 */       restoreFrame();
/* 1452 */       Wait.shortWait(100);
/* 1453 */       if (Def.building == 2)
/*      */         return; 
/* 1455 */       this.startPuz++;
/*      */     } 
/* 1457 */     this.howMany = 1;
/* 1458 */     Methods.puzzleTitle = title;
/* 1459 */     Op.setInt(Op.SL.SlAcross.ordinal(), saveSlitherlinkSize, Op.sl);
/* 1460 */     Op.setInt(Op.SL.SlDown.ordinal(), saveSlitherlinkSize, Op.sl);
/*      */   }
/*      */   
/*      */   private void buildSlitherLink() {
/* 1464 */     Random r = new Random();
/* 1465 */     int x2 = 0, y2 = 0;
/*      */     
/* 1467 */     char save2 = ' ';
/*      */     
/* 1469 */     makeGrid(); createPath();
/*      */     int y;
/* 1471 */     for (y = 0; y < Grid.ySz; y++) {
/* 1472 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1473 */         if (Grid.status[x][y] != 255)
/* 1474 */           Grid.status[x][y] = Grid.iSol[x][y] & 0x55; 
/*      */       } 
/* 1476 */     }  for (y = 0; y < Grid.ySz; y++) {
/* 1477 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1478 */         if (Grid.status[x][y] != 255) {
/* 1479 */           int full = getCellStats(x, y) / 256;
/* 1480 */           Grid.letter[x][y] = Character.forDigit(full, 10);
/*      */         } 
/*      */       } 
/* 1483 */     }  for (y = 0; y < Grid.ySz; y++) {
/* 1484 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1485 */         Grid.copy[x][y] = 0;
/* 1486 */         if (Grid.mode[x][y] != 0)
/* 1487 */           Grid.letter[x][y] = 32; 
/*      */       } 
/*      */     }  int k;
/* 1490 */     for (k = Grid.xSz * Grid.ySz; k > 0; k--) {
/* 1491 */       int a, i, m; for (a = r.nextInt(k), i = m = 0; m < Grid.ySz; m++) {
/* 1492 */         for (i = 0; i < Grid.xSz; i++) {
/* 1493 */           if (Grid.copy[i][m] == 0 && 
/* 1494 */             a-- == 0) {
/* 1495 */             Grid.copy[i][m] = 1;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1499 */         if (i < Grid.xSz)
/*      */           break; 
/*      */       } 
/* 1502 */       int x = i; y = m;
/* 1503 */       if (Grid.letter[x][y] >= 48) {
/*      */         
/* 1505 */         char save = (char)Grid.letter[x][y];
/* 1506 */         Grid.letter[x][y] = 32;
/* 1507 */         if (Op.getBool(Op.SL.SlSym.ordinal(), Op.sl).booleanValue()) {
/* 1508 */           x2 = Grid.xSz - 1 - x; y2 = Grid.ySz - 1 - y;
/* 1509 */           save2 = (char)Grid.letter[x2][y2];
/* 1510 */           Grid.letter[x2][y2] = 32;
/*      */         } 
/*      */         
/* 1513 */         for (m = 0; m < 50; m++) {
/* 1514 */           for (i = 0; i < 50; i++)
/* 1515 */             Grid.iSol[i][m] = 0; 
/*      */         }  do {
/* 1517 */           byte mode; for (mode = 1; solveSlitherlink(mode); mode = 0);
/* 1518 */         } while (solveSlitherlink(2));
/*      */         
/*      */         int b;
/*      */         
/* 1522 */         for (b = 0; b < Grid.ySz; b++) {
/* 1523 */           for (a = 0; a < Grid.xSz && (
/* 1524 */             Grid.status[a][b] == 255 || (Grid.iSol[a][b] & 0x55) == Grid.status[a][b]); a++);
/*      */           
/* 1526 */           if (a < Grid.xSz)
/*      */             break; 
/*      */         } 
/* 1529 */         if (b < Grid.ySz) {
/* 1530 */           if (Op.getBool(Op.SL.SlSym.ordinal(), Op.sl).booleanValue())
/* 1531 */             Grid.letter[x2][y2] = save2; 
/* 1532 */           Grid.letter[x][y] = save;
/*      */         } 
/* 1534 */         if (Def.building == 2)
/*      */           return; 
/*      */       } 
/*      */     }  int j;
/* 1538 */     for (k = j = 0; j < Grid.ySz; j++) {
/* 1539 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1540 */         if (Character.isDigit((char)Grid.letter[i][j]))
/* 1541 */           k++; 
/*      */       } 
/* 1543 */     }  for (j = 0; j < 50; j++) {
/* 1544 */       for (int i = 0; i < 50; i++)
/* 1545 */         Grid.iSol[i][j] = 0; 
/*      */     } 
/* 1547 */     saveSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void updateGrid(MouseEvent e) {
/* 1551 */     int mouseX = e.getX(), mouseY = e.getY();
/*      */     
/* 1553 */     if (Def.building == 1)
/*      */       return; 
/* 1555 */     if (mouseX < Grid.xOrg) mouseX = Grid.xOrg + 1; 
/* 1556 */     if (mouseY < Grid.yOrg) mouseY = Grid.yOrg + 1; 
/* 1557 */     int x = Grid.xOrg + Grid.xSz * Grid.xCell; if (mouseX >= x) mouseX = x - 1; 
/* 1558 */     int y = Grid.yOrg + Grid.ySz * Grid.yCell; if (mouseY >= y) mouseY = y - 1; 
/* 1559 */     x = (mouseX - Grid.xOrg) / Grid.xCell;
/* 1560 */     y = (mouseY - Grid.yOrg) / Grid.yCell;
/* 1561 */     if (Grid.mode[x][y] != 0)
/* 1562 */       return;  Grid.xCur = x;
/* 1563 */     Grid.yCur = y;
/* 1564 */     restoreFrame();
/*      */   }
/*      */   void handleKeyPressed(KeyEvent e) {
/*      */     char ch;
/* 1568 */     if (Def.building == 1)
/* 1569 */       return;  if (e.isAltDown())
/* 1570 */       return;  switch (e.getKeyCode()) { case 38:
/* 1571 */         if (Grid.yCur > 0 && Grid.mode[Grid.xCur][Grid.yCur - 1] == 0) Grid.yCur--;  break;
/* 1572 */       case 40: if (Grid.yCur < Grid.ySz - 1 && Grid.mode[Grid.xCur][Grid.yCur + 1] == 0) Grid.yCur++;  break;
/* 1573 */       case 37: if (Grid.xCur > 0 && Grid.mode[Grid.xCur - 1][Grid.yCur] == 0) Grid.xCur--;  break;
/* 1574 */       case 39: if (Grid.xCur < Grid.xSz - 1 && Grid.mode[Grid.xCur + 1][Grid.yCur] == 0) Grid.xCur++;  break;
/* 1575 */       case 36: for (Grid.xCur = 0; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.xCur++); break;
/* 1576 */       case 35: for (Grid.xCur = Grid.xSz - 1; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.xCur--); break;
/* 1577 */       case 33: for (Grid.yCur = 0; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.yCur++); break;
/* 1578 */       case 34: for (Grid.yCur = Grid.ySz - 1; Grid.mode[Grid.xCur][Grid.yCur] != 0; Grid.yCur--); break;
/*      */       case 8: case 32:
/*      */       case 127:
/* 1581 */         Grid.letter[Grid.xCur][Grid.yCur] = 32; break;
/*      */       default:
/* 1583 */         ch = e.getKeyChar();
/* 1584 */         if (ch >= '0' && ch <= '3')
/* 1585 */           Grid.letter[Grid.xCur][Grid.yCur] = ch; 
/*      */         break; }
/*      */     
/* 1588 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SlitherlinkBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */