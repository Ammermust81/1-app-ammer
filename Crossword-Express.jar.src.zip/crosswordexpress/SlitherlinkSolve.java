/*     */ package crosswordexpress;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class SlitherlinkSolve extends JPanel {
/*  25 */   String slitherlinkSolve = "<div>Crossword Express <b>SLITHERLINK</b> puzzles are normally built on a rectangular grid (although other shapes are possible). The grid is defined by an array of dots which represent the corners of the cells within the grid. Some of the cells in this grid contain a single digit number between 0 and 3 inclusive. The remaining cells are blank.<p/>To solve such a puzzle, the solver must join selected dots with horizontal and vertical lines so that a single loop is formed which does not cross over itself. If a cell contains a number, then that number of sides of the cell must be included within the loop.<p/>The puzzles have unique solutions, and no guessing is required to complete the solution.<p/>Interactive SLITHERLINK puzzles normally have faint grey guide-lines joining the dots. These guide-lines can be converted to full lines by pointing to an area near the middle of the line and clicking the mouse. A second click will remove the line altogether, and a third click will restore the faint grey line.<p/>Use logical reasoning to determine which of the guide-lines should be converted to full lines, and which ones should be removed. Each time you add or remove a line, it will open up new possibilities for you to exploit.</div><p/><span class='parhead'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose the puzzle you want to solve from the pool of SLITHERLINK puzzles currently available on your computer.<p/><li/><span>Quit Solving</span><br/>Returns you to the SLITHERLINK Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Slitherlink Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */   
/*     */   static JFrame jfSolveSlitherlink;
/*     */ 
/*     */   
/*     */   static JMenuBar menuBar;
/*     */ 
/*     */   
/*     */   JMenu menu;
/*     */ 
/*     */   
/*     */   JMenu submenu;
/*     */ 
/*     */   
/*     */   JMenuItem menuItem;
/*     */ 
/*     */   
/*     */   static JPanel pp;
/*     */ 
/*     */   
/*     */   static int panelW;
/*     */ 
/*     */   
/*     */   static int panelH;
/*     */ 
/*     */   
/*     */   static JLabel jl1;
/*     */ 
/*     */   
/*     */   static JLabel jl2;
/*     */ 
/*     */   
/*     */   Timer myTimer;
/*     */ 
/*     */   
/*     */   Runnable solveThread;
/*     */ 
/*     */   
/*     */   int memMode;
/*     */ 
/*     */ 
/*     */   
/*     */   SlitherlinkSolve(JFrame jf) {
/*  69 */     this.memMode = Def.puzzleMode;
/*  70 */     Def.puzzleMode = 171;
/*  71 */     Def.dispSolArray = Boolean.valueOf(true);
/*     */ 
/*     */     
/*  74 */     Grid.clearGrid();
/*     */     
/*  76 */     jfSolveSlitherlink = new JFrame("Slitherlink");
/*  77 */     jfSolveSlitherlink.setSize(Op.getInt(Op.SL.SlW.ordinal(), Op.sl), Op.getInt(Op.SL.SlH.ordinal(), Op.sl));
/*  78 */     int frameX = (jf.getX() + jfSolveSlitherlink.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveSlitherlink.getWidth() - 10) : jf.getX();
/*  79 */     jfSolveSlitherlink.setLocation(frameX, jf.getY());
/*  80 */     jfSolveSlitherlink.setLayout((LayoutManager)null);
/*  81 */     jfSolveSlitherlink.setDefaultCloseOperation(0);
/*  82 */     jfSolveSlitherlink
/*  83 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/*  85 */             int oldw = Op.getInt(Op.SL.SlW.ordinal(), Op.sl);
/*  86 */             int oldh = Op.getInt(Op.SL.SlH.ordinal(), Op.sl);
/*  87 */             Methods.frameResize(SlitherlinkSolve.jfSolveSlitherlink, oldw, oldh, 500, 580);
/*  88 */             Op.setInt(Op.SL.SlW.ordinal(), SlitherlinkSolve.jfSolveSlitherlink.getWidth(), Op.sl);
/*  89 */             Op.setInt(Op.SL.SlH.ordinal(), SlitherlinkSolve.jfSolveSlitherlink.getHeight(), Op.sl);
/*  90 */             SlitherlinkSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  94 */     jfSolveSlitherlink
/*  95 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  97 */             if (Def.selecting)
/*  98 */               return;  Op.saveOptions("slitherlink.opt", Op.sl);
/*  99 */             SlitherlinkSolve.this.restoreIfDone();
/* 100 */             SlitherlinkSolve.saveSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/* 101 */             CrosswordExpress.transfer(170, SlitherlinkSolve.jfSolveSlitherlink);
/*     */           }
/*     */         });
/*     */     
/* 105 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 108 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if ((Grid.iSol[i][j] & 0x55) != (Grid.status[i][j] & 0x55))
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveSlitherlink);
/*     */       });
/* 116 */     jl1 = new JLabel(); jfSolveSlitherlink.add(jl1);
/* 117 */     jl2 = new JLabel(); jfSolveSlitherlink.add(jl2);
/*     */ 
/*     */     
/* 120 */     menuBar = new JMenuBar();
/* 121 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 122 */     jfSolveSlitherlink.setJMenuBar(menuBar);
/*     */     
/* 124 */     this.menu = new JMenu("File");
/* 125 */     menuBar.add(this.menu);
/* 126 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 127 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 128 */     this.menu.add(this.menuItem);
/* 129 */     this.menuItem
/* 130 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*     */           new Select(jfSolveSlitherlink, "slitherlink", "slitherlink", Op.sl, Op.SL.SlPuz.ordinal(), false);
/*     */         });
/* 138 */     this.menuItem = new JMenuItem("Quit Solving");
/* 139 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 140 */     this.menu.add(this.menuItem);
/* 141 */     this.menuItem
/* 142 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("slitherlink.opt", Op.sl);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(170, jfSolveSlitherlink);
/*     */         });
/* 151 */     this.menu = new JMenu("View");
/* 152 */     menuBar.add(this.menu);
/* 153 */     this.menuItem = new JMenuItem("Display Options");
/* 154 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 155 */     this.menu.add(this.menuItem);
/* 156 */     this.menuItem
/* 157 */       .addActionListener(ae -> {
/*     */           SlitherlinkBuild.printOptions(jfSolveSlitherlink, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 164 */     this.menu = new JMenu("Tasks");
/* 165 */     menuBar.add(this.menu);
/*     */     
/* 167 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 172 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 174 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 175 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 176 */     this.menu.add(this.menuItem);
/* 177 */     this.menuItem
/* 178 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSlitherlink);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 189 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 190 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 191 */     this.menu.add(this.menuItem);
/* 192 */     this.menuItem
/* 193 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++) {
/*     */                 Grid.iSol[i][j] = Grid.status[i][j]; for (int v = 3; v < 768; v *= 4) {
/*     */                   if ((Grid.iSol[i][j] & v) == 0)
/*     */                     Grid.iSol[i][j] = Grid.iSol[i][j] | 0xAA & v; 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSlitherlink);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 208 */     this.menuItem = new JMenuItem("Begin again");
/* 209 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 210 */     this.menu.add(this.menuItem);
/* 211 */     this.menuItem
/* 212 */       .addActionListener(ae -> {
/*     */           Methods.clearGrid(Grid.iSol);
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 219 */     this.menu = new JMenu("Help");
/* 220 */     menuBar.add(this.menu);
/* 221 */     this.menuItem = new JMenuItem("Slitherlink Help");
/* 222 */     this.menu.add(this.menuItem);
/* 223 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 224 */     this.menuItem
/* 225 */       .addActionListener(ae -> Methods.cweHelp(jfSolveSlitherlink, null, "Solving Slitherlink Puzzles", this.slitherlinkSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     loadSlitherlink(Op.sl[Op.SL.SlPuz.ordinal()]);
/* 232 */     pp = new SlitherlinkSolvePP(0, 37);
/* 233 */     jfSolveSlitherlink.add(pp);
/*     */     
/* 235 */     pp
/* 236 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 238 */             SlitherlinkSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 243 */     pp
/* 244 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 246 */             if (Def.isMac) {
/* 247 */               SlitherlinkSolve.jfSolveSlitherlink.setResizable((SlitherlinkSolve.jfSolveSlitherlink.getWidth() - e.getX() < 15 && SlitherlinkSolve.jfSolveSlitherlink
/* 248 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 253 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 257 */     jfSolveSlitherlink.setVisible(true);
/* 258 */     Insets insets = jfSolveSlitherlink.getInsets();
/* 259 */     panelW = jfSolveSlitherlink.getWidth() - insets.left + insets.right;
/* 260 */     panelH = jfSolveSlitherlink.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 261 */     pp.setSize(panelW, panelH);
/* 262 */     jfSolveSlitherlink.requestFocusInWindow();
/* 263 */     pp.repaint();
/* 264 */     Methods.infoPanel(jl1, jl2, "Solve Slitherlink", "Puzzle : " + Op.sl[Op.SL.SlPuz.ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 268 */     int i = (width - inset) / (Grid.xSz + 1);
/* 269 */     int j = (height - inset) / (Grid.ySz + 1);
/* 270 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 271 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : (10 + Grid.xCell / 2));
/* 272 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : (10 + Grid.yCell / 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveSlitherlink(String slitherlinkName) {
/*     */     try {
/* 278 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("slitherlink/" + slitherlinkName));
/* 279 */       dataOut.writeInt(Grid.xSz);
/* 280 */       dataOut.writeInt(Grid.ySz);
/* 281 */       dataOut.writeByte(Methods.noReveal);
/* 282 */       dataOut.writeByte(Methods.noErrors);
/* 283 */       for (int i = 0; i < 54; i++)
/* 284 */         dataOut.writeByte(0); 
/* 285 */       for (int j = 0; j < Grid.ySz; j++) {
/* 286 */         for (int k = 0; k < Grid.xSz; k++) {
/* 287 */           dataOut.writeInt(Grid.status[k][j]);
/* 288 */           dataOut.writeChar(Grid.letter[k][j]);
/* 289 */           dataOut.writeInt(Grid.iSol[k][j]);
/* 290 */           dataOut.writeInt(Grid.mode[k][j]);
/*     */         } 
/* 292 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 293 */       dataOut.writeUTF(Methods.author);
/* 294 */       dataOut.writeUTF(Methods.copyright);
/* 295 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 296 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 297 */       dataOut.close();
/*     */     }
/* 299 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadSlitherlink(String slitherlinkName) {
/*     */     try {
/* 308 */       File fl = new File("slitherlink/" + slitherlinkName);
/* 309 */       if (!fl.exists()) {
/*     */         
/* 311 */         fl = new File("slitherlink/");
/* 312 */         String[] s = fl.list(); int k;
/* 313 */         for (k = 0; k < s.length && (
/* 314 */           s[k].lastIndexOf(".slitherlink") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 316 */         slitherlinkName = s[k];
/* 317 */         Op.sl[Op.SL.SlPuz.ordinal()] = slitherlinkName;
/*     */       } 
/*     */ 
/*     */       
/* 321 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("slitherlink/" + slitherlinkName));
/* 322 */       Grid.xSz = dataIn.readInt();
/* 323 */       Grid.ySz = dataIn.readInt();
/* 324 */       Methods.noReveal = dataIn.readByte();
/* 325 */       Methods.noErrors = dataIn.readByte(); int i;
/* 326 */       for (i = 0; i < 54; i++)
/* 327 */         dataIn.readByte(); 
/* 328 */       for (int j = 0; j < Grid.ySz; j++) {
/* 329 */         for (i = 0; i < Grid.xSz; i++) {
/* 330 */           Grid.status[i][j] = dataIn.readInt();
/* 331 */           Grid.letter[i][j] = dataIn.readChar();
/* 332 */           Grid.iSol[i][j] = dataIn.readInt();
/* 333 */           Grid.mode[i][j] = dataIn.readInt();
/*     */         } 
/* 335 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 336 */       Methods.author = dataIn.readUTF();
/* 337 */       Methods.copyright = dataIn.readUTF();
/* 338 */       Methods.puzzleNumber = dataIn.readUTF();
/* 339 */       Methods.puzzleNotes = dataIn.readUTF();
/* 340 */       dataIn.close();
/*     */     }
/* 342 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawSlitherlink(Graphics2D g2, int[][] puzzleArray) {
/* 348 */     boolean isError = false;
/*     */     
/* 350 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/* 351 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/* 352 */     g2.setStroke(normalStroke);
/*     */     
/* 354 */     RenderingHints rh = g2.getRenderingHints();
/* 355 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 356 */     g2.setRenderingHints(rh);
/*     */     
/* 358 */     g2.setStroke(wideStroke);
/* 359 */     int margin = Grid.xCell / 2;
/* 360 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlBg.ordinal(), Op.sl) : 16777215));
/* 361 */     g2.fillRect(Grid.xOrg - margin, Grid.yOrg - margin, Grid.xCell * Grid.xSz + 2 * margin, Grid.yCell * Grid.ySz + 2 * margin);
/* 362 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlLine.ordinal(), Op.sl) : 0));
/* 363 */     g2.drawRect(Grid.xOrg - margin, Grid.yOrg - margin, Grid.xCell * Grid.xSz + 2 * margin, Grid.yCell * Grid.ySz + 2 * margin);
/*     */     
/* 365 */     if (Def.dispWithColor.booleanValue())
/* 366 */     { for (int pass = 0; pass < 2; pass++) {
/* 367 */         for (int i = 0; i < Grid.ySz; i++) {
/* 368 */           for (int k = 0; k < Grid.xSz; k++) {
/* 369 */             if (Grid.mode[k][i] == 0) {
/* 370 */               int x = Grid.xOrg + k * Grid.xCell;
/* 371 */               int y = Grid.yOrg + i * Grid.yCell; int c;
/* 372 */               for (c = 3; c < 768; c *= 4) {
/* 373 */                 int t = Grid.iSol[k][i] & c;
/* 374 */                 int v = Grid.status[k][i] & c;
/* 375 */                 if (pass == 0) {
/* 376 */                   if (t != 0)
/* 377 */                     continue;  g2.setColor(new Color(Op.getColorInt(Op.SL.SlGrid.ordinal(), Op.sl)));
/*     */                 } else {
/*     */                   
/* 380 */                   if ((t & 0x55) == 0)
/* 381 */                     continue;  if (Def.dispErrors.booleanValue() && (t & 0x55) != (v & 0x55)) {
/* 382 */                     g2.setColor(new Color(Op.getColorInt(Op.SL.SlError.ordinal(), Op.sl)));
/* 383 */                     isError = true;
/*     */                   } else {
/*     */                     
/* 386 */                     g2.setColor(new Color(Op.getColorInt(Op.SL.SlLine.ordinal(), Op.sl)));
/* 387 */                   }  g2.setColor(new Color((Def.dispErrors.booleanValue() && (t & 0x55) != (v & 0x55)) ? Op.getColorInt(Op.SL.SlError.ordinal(), Op.sl) : Op.getColorInt(Op.SL.SlLine.ordinal(), Op.sl)));
/*     */                 } 
/* 389 */                 switch (c) { case 3:
/* 390 */                     g2.drawLine(x, y, x + Grid.xCell, y); break;
/* 391 */                   case 12: g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); break;
/* 392 */                   case 48: g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); break;
/* 393 */                   case 192: g2.drawLine(x, y + Grid.yCell, x, y); break; }  continue;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }  }
/* 399 */     else { g2.setColor(Def.COLOR_BLACK);
/* 400 */       g2.setStroke(normalStroke);
/* 401 */       for (int i = 0; i <= Grid.ySz; i++) {
/* 402 */         for (int k = 0; k <= Grid.xSz; k++) {
/* 403 */           int x = Grid.xOrg + k * Grid.xCell;
/* 404 */           int y = Grid.yOrg + i * Grid.yCell;
/* 405 */           if ((k < Grid.xSz && i < Grid.ySz && Grid.mode[k][i] == 0) || (k < Grid.xSz && i > 0 && Grid.mode[k][i - 1] == 0) || (k > 0 && i < Grid.ySz && Grid.mode[k - 1][i] == 0) || (k > 0 && i > 0 && Grid.mode[k - 1][i - 1] == 0)) {
/*     */ 
/*     */ 
/*     */             
/* 409 */             g2.drawLine(x - 2, y, x + 2, y);
/* 410 */             g2.drawLine(x, y - 2, x, y + 2);
/*     */           } 
/*     */         } 
/*     */       }  }
/* 414 */      if (!isError) Def.dispErrors = Boolean.valueOf(false);
/*     */     
/* 416 */     g2.setColor(new Color(Def.dispWithColor.booleanValue() ? Op.getColorInt(Op.SL.SlNumber.ordinal(), Op.sl) : 0));
/* 417 */     g2.setFont(new Font(Op.sl[Op.SL.SlFont.ordinal()], 0, 8 * Grid.yCell / 10));
/* 418 */     FontMetrics fm = g2.getFontMetrics();
/* 419 */     for (int j = 0; j < Grid.ySz; j++) {
/* 420 */       for (int i = 0; i < Grid.xSz; i++) {
/* 421 */         char ch = (char)puzzleArray[i][j];
/* 422 */         if (ch != '\000') {
/* 423 */           int w = fm.stringWidth("" + ch);
/* 424 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   
/*     */   void restoreIfDone() {
/* 438 */     for (int j = 0; j < Grid.ySz; j++) {
/* 439 */       for (int i = 0; i < Grid.xSz; i++)
/* 440 */       { if ((Grid.iSol[i][j] & 0x55) != (Grid.status[i][j] & 0x55))
/*     */           return;  } 
/* 442 */     }  Methods.clearGrid(Grid.iSol);
/*     */   }
/*     */   
/*     */   static Boolean UpdateSlitherLinkCell(int x, int y, int side) {
/* 446 */     int[] mask = { 3, 12, 48, 192, 252, 243, 207, 63 };
/* 447 */     int[] inc = { 1, 4, 16, 64 };
/*     */     
/* 449 */     if (x < 0 || y < 0 || x >= Grid.xSz || y >= Grid.ySz) return Boolean.valueOf(false); 
/* 450 */     if ((Grid.iSol[x][y] & mask[side] & 0xAA) != 0) {
/* 451 */       Grid.iSol[x][y] = Grid.iSol[x][y] & mask[side + 4];
/*     */     } else {
/* 453 */       Grid.iSol[x][y] = Grid.iSol[x][y] + inc[side];
/* 454 */     }  return Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   static void UpdateSlitherLink(int x, int y, int side) {
/* 458 */     UpdateSlitherLinkCell(x, y, side);
/*     */     
/* 460 */     switch (side) { case 0:
/* 461 */         UpdateSlitherLinkCell(x, --y, 2); break;
/* 462 */       case 1: UpdateSlitherLinkCell(++x, y, 3); break;
/* 463 */       case 2: UpdateSlitherLinkCell(x, ++y, 0); break;
/* 464 */       case 3: UpdateSlitherLinkCell(--x, y, 1);
/*     */         break; }
/*     */   
/*     */   }
/*     */   void updateGrid(MouseEvent e) {
/* 469 */     int loc[] = new int[4], mouseX = e.getX(), mouseY = e.getY();
/*     */ 
/*     */     
/* 472 */     if (mouseX < Grid.xOrg) mouseX = Grid.xOrg + 1; 
/* 473 */     if (mouseY < Grid.yOrg) mouseY = Grid.yOrg + 1; 
/* 474 */     int x = Grid.xOrg + Grid.xSz * Grid.xCell; if (mouseX >= x) mouseX = x - 1; 
/* 475 */     int y = Grid.yOrg + Grid.ySz * Grid.yCell; if (mouseY >= y) mouseY = y - 1; 
/* 476 */     x = (mouseX - Grid.xOrg) / Grid.xCell;
/* 477 */     y = (mouseY - Grid.yOrg) / Grid.yCell;
/*     */     
/* 479 */     loc[0] = (mouseY - Grid.yOrg) % Grid.yCell;
/* 480 */     loc[3] = (mouseX - Grid.xOrg) % Grid.xCell;
/* 481 */     loc[1] = Grid.xCell - loc[3];
/* 482 */     loc[2] = Grid.yCell - loc[0]; int best;
/* 483 */     for (int min = 1000, i = 0; i < 4; i++) {
/* 484 */       if (loc[i] < min) {
/* 485 */         min = loc[i];
/* 486 */         best = i;
/*     */       } 
/* 488 */     }  UpdateSlitherLink(x, y, best);
/* 489 */     (new Thread(this.solveThread)).start();
/* 490 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SlitherlinkSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */