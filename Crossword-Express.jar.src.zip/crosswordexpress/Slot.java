package crosswordexpress;

class Slot {
  int x;
  
  int y;
  
  int direction;
  
  int scoreW;
  
  int scoreC;
  
  int scoreL;
  
  int wNum;
}


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\Slot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */