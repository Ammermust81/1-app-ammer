/*      */ package crosswordexpress;
/*      */ import java.awt.Color;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Point;
/*      */ import java.awt.Stroke;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class SudokuBuild extends JPanel {
/*      */   static JFrame jfSudoku;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*      */   static JPanel pp;
/*   23 */   static int howMany = 1; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; static int theSudokuColor; static int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); static int hmCount; static int hintNum;
/*      */   boolean sixpack;
/*      */   static int undoIndex;
/*   26 */   static int[] undoI = new int[750];
/*   27 */   static int[] undoM = new int[750];
/*   28 */   static int[] undoS = new int[750];
/*   29 */   static int[] undoX = new int[750];
/*   30 */   static int[] undoY = new int[750];
/*   31 */   static int[] bit = new int[] { 2, 4, 8, 16, 32, 64, 128, 256, 512 };
/*   32 */   static int[] invbit = new int[] { 1020, 1018, 1014, 1006, 990, 958, 894, 766, 510 };
/*   33 */   static int scCandidate = 0;
/*   34 */   static int maxDiff = 19;
/*   35 */   static String rules = "Place numbers into the grid so that every row, every column and every 3x3 box contains each of the digits 1 to 9. There is only one solution, and no guessing is needed.";
/*      */ 
/*      */   
/*   38 */   static Link[] linkDat = new Link[600]; static int linkDatIndex; static int linkCandidateNum; static int linkCandidatePos;
/*      */   static int listN;
/*   40 */   static JunctionCell[] junc = new JunctionCell[100];
/*   41 */   static Color STRONG_LINK = new Color(34816);
/*   42 */   static Color WEAK_LINK = new Color(8978312);
/*   43 */   static int solution = 0; static int delete = 1;
/*   44 */   static Color[] candC = new Color[] { new Color(65484), new Color(16711935) };
/*      */ 
/*      */   
/*   47 */   static int testnum = 1;
/*      */   
/*      */   static void def() {
/*   50 */     Op.updateOption(Op.SU.SuW.ordinal(), "600", Op.su);
/*   51 */     Op.updateOption(Op.SU.SuH.ordinal(), "680", Op.su);
/*   52 */     Op.updateOption(Op.SU.SuDifficulty.ordinal(), "5", Op.su);
/*   53 */     Op.updateOption(Op.SU.SuCell.ordinal(), "FFFFEE", Op.su);
/*   54 */     Op.updateOption(Op.SU.SuHilite.ordinal(), "FFFFF8", Op.su);
/*   55 */     Op.updateOption(Op.SU.SuBorder.ordinal(), "000000", Op.su);
/*   56 */     Op.updateOption(Op.SU.SuGrid.ordinal(), "0088FF", Op.su);
/*   57 */     Op.updateOption(Op.SU.SuNumber.ordinal(), "444444", Op.su);
/*   58 */     Op.updateOption(Op.SU.SuGuide.ordinal(), "444444", Op.su);
/*   59 */     Op.updateOption(Op.SU.SuError.ordinal(), "FF0000", Op.su);
/*   60 */     Op.updateOption(Op.SU.SuPuz.ordinal(), "sample.sudoku", Op.su);
/*   61 */     Op.updateOption(Op.SU.SuSet.ordinal(), "123456789", Op.su);
/*   62 */     Op.updateOption(Op.SU.SuFont.ordinal(), "SansSerif", Op.su);
/*   63 */     Op.updateOption(Op.SU.SuGuideFont.ordinal(), "SansSerif", Op.su);
/*   64 */     Op.updateOption(Op.SU.SuPuzColor.ordinal(), "false", Op.su);
/*   65 */     Op.updateOption(Op.SU.SuSolColor.ordinal(), "false", Op.su);
/*   66 */     Op.updateOption(Op.SU.SuGuideBg.ordinal(), "FFFF00", Op.su);
/*      */   }
/*      */   
/*   69 */   static byte[] candidates = new byte[] { 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8, 5, 6, 6, 7, 6, 7, 7, 8, 6, 7, 7, 8, 7, 8, 8, 9 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int hintIndexb;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   static int[] hintXb = new int[20]; static int[] hintYb = new int[20];
/*      */   static int hintIndexg;
/*   84 */   static int[] hintXg = new int[20]; static int[] hintYg = new int[20];
/*      */   static int hintIndexr;
/*   86 */   static int[] hintXr = new int[20]; static int[] hintYr = new int[20];
/*      */   
/*      */   static int hintUnitIndex;
/*   89 */   static String[] hintUnit = new String[20]; static int hintCellIndex;
/*      */   static int hintCandidate;
/*   91 */   static int[] hintCellx = new int[20];
/*   92 */   static int[] hintCelly = new int[20];
/*      */   static int weakLinkIndex;
/*   94 */   static int[] weakLinkx1 = new int[32]; static int[] weakLinky1 = new int[32]; static int[] weakLinkx2 = new int[32]; static int[] weakLinky2 = new int[32];
/*      */   
/*      */   static int candIndex;
/*   97 */   static int[] candx = new int[36]; static int[] candy = new int[36]; static int[] candv = new int[36]; static int[] candc = new int[36];
/*      */   
/*   99 */   String sudokuHelp = "<div>The Crossword Express <b>SUDOKU</b> function allows you to make puzzles having degrees of difficulty ranging from 1 to 19. If you choose to make a puzzle having a high difficulty level, you need to be aware that, just as it takes longer to solve a hard puzzle, so also does it take longer to build such a puzzle. Please be patient...it will be worth it. The symbols in the puzzle are the digits 1 to 9 by default, but you can change this to any set of printable characters you like.<br/><br/></div><span class='m'>Menu Functions</span><br/><br/><ul><li/><span class='s'>File Menu</span><br/><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of SUDOKU puzzles currently available on your computer.<p/><li/><span>Save</span><br/>If you have done some manual editing of the puzzle, this option will save those changes under the existing file name.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>sudoku</b> folder along with all of the Sudoku puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.<p/></ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option.If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b><p/><li/><span>Test Puzzle Validity</span><br/>Manual construction of a SUDOKU puzzle is not recommended. You should only attempt this if you have a valid puzzle (possibly one published in a magazine) which you would like to enter into the program. Simply move the cursor cell around the puzzle, and type the required values into the appropriate cells. Selecting the <b>Test Puzzle Validity</b> option will check the validity of the puzzle. If it has a unique solution, it will be saved, and you will be advised of this. If not, you will receive a message that the puzzle is not valid.<p/></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.<p/></ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Export Sudoku Web-App</span><br/>This function allows you to export a Web Application Program which you can then upload to your own web site to provide a fully interactive Sudoku puzzle for the entertainment of visitors to your site. For a full description of the facilities provided by this Web-App, please refer to the Help available at <b>Help / Sudoku Web Application</b> on the menu bar of the <b>Build sudoku</b> window of this program.<p/><li/><span>Launch a Demo Sudoku Web App</span><br/>Take a first look at the Sudoku Web App. See what it could do to enhance your web site.<p/><li/><span>Print a Sudoku KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span'>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted SUDOKU puzzles from your file system.<p/></ul><li/><span class='s'>Help Menu</span><ul><li/><span>Sudoku Help</span><br/>Displays the Help screen which you are now reading.<p/></ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   String sudokuOptions = "<div>Before you give the command to build the <b>Sudoku</b> puzzle, you can set some options which the program will use during the construction process.</div><br/><ul><li/><b>Symbol Set:</b> Enter the set of symbols which you want to appear in the completed puzzle. Make sure you enter exactly 9 symbols which may include any printable character.<p/><li/><b>Difficulty:</b> Select the difficulty level to be used for your puzzle. There are 19 levels of difficulty available.<p/><br>Please be aware of the fact that creating a Sudoku puzzle of a specified difficulty is a very tricky task. The only method I know to do this is to create a continuous stream of puzzles and to find out their difficulty level by actually solving them. When a puzzle having the required difficulty is encountered, the build process terminates. Naturally this can take quite a long time. If you want a number of puzzles at some high difficulty level, you can use the Multi-Build function and let your computer run while you sleep.<p/><li/>If you want to make a number of puzzles in a single operation, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> check-box will disable it.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  206 */   static String webAppHelp = "<div><span>Step 1: Export</span><br/>To export the Web Application, select the function <b>Export / Export Puzzle as Web App</b> from the menu bar of the <b>Build Sudoku</b> window of this program. The necessary files will be exported into a folder called <b>Web-App</b> located on your computer's Desktop. Please note that you will need a working Internet connection for this function to operate correctly. The exported files are as follows:-<ul><li><span>sudoku.js</span> This is the file which contains all of the Java Script which implements the interactive features of the Web App.<li><span>sudoku.html</span> This file creates the URL address used to access the Web App. Its main purpose is to start the operation of the sudoku.js Java Script file. If you open sudoku.html with a simple text editor, you will find two appearances of the following text fragment ... <b>&lt;!-- Your HTML code here. --></b>. If you are an experienced HTML coder and would like to add some content of your own to the Web App window, simply replace these fragments with your own HTML code.</ul><span>Step 2: Familiarization</span><br/>Having exported the App, you can give it a first run by starting your web browser, and using it to open the <b>sudoku.html</b> file mentioned above, or more simply, just double click the sudoku.html icon. <p/><span>Step 3: Installation</span><br/>Installation is a three step process:-<ul><li>Create a new folder somewhere on your web server.<li>Upload the two files already discussed into this new folder.<li>Create a link from a convenient point within your web site to the sudoku.html file in your newly created folder.</ul>At this point, any visitor will be able to make full use of the Sudoku Web-App. There is no need to upload any Sudoku puzzle files. This App makes new puzzles on demand as described in the Help information available from the Help button on the App.<p/></div></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  236 */   static String[] sudokuHint = new String[] { "<div>Your partial solution has been checked and found to be in error in those cells which are highlighted in blue. Under these circumstances, it is not possible to provide a trustworthy hint as to the next step in the solution.<p/>Please investigate, and correct the errors before proceeding with the solution process.</div></body>", "<div>The single highlighted cell contains a candidate value of ~ and no other. It must therefore be the solution value for this cell.</div></body>", "<div>The single highlighted cell contains a candidate value of ~ which appears nowhere else in this ~ of the puzzle. It must therefore be a solution value for the cell which contains it.</div></body>", "<div>The cells highlighted in blue contain only the candidate values ~, so the solution for these cells will be provided by just these values. Consequently, any other cells in the same ~ which contain any of the candidate values ~ may have them removed. Such candidates are highlighted by a magenta background for your convenience.</div></body>", "<div>The highlighted cells all reside in a single ~ and a single ~. The ~ which appear in these cells do not appear in the rest of the ~ and so they must provide the solution for ~ within the ~. They will also provide the solution for ~ within the ~. Consequently, the magenta highlighted ~ may be removed from the cells in the rest of the ~.</div></body>", "<div>The highlighted cells contain the candidate values ~ which appear nowhere else in the same ~. These values, in some order, must be the solutions for the highlighted cells. Any other values contained in these cells are redundant and may be removed.</div></body>", "<div>In the highlighted cells, there is a candidate number ~ which appears nowhere else in any of the ~ which contain highlighted cells. This number will become the solution number for one of the highlighted cells in each ~, and in the process will also satisfy the ~ requirement for that number. Consequently, any other cells in the same ~ which contain this value may have it removed.</div></body>", "<div>The cell highlighted in green contains the candidate numbers ~, so one of these must be the solution for that cell. If ~ becomes the solution in the green cell, ~ will become the solution in one of the red cells, and if ~ becomes the solution in the green cell, ~ will become the solution for the other red cell. In other words, one of the red cells must have a solution of ~. The blue cell(s) can 'see' both the red cells, and so they cannot have a solution of ~, and ~ may be removed from them.</div></body>", "<div>The red cell and the two green cells all contain a candidate number of ~. If neither of the green cells have a solution of ~, then the red cell certainly must. In other words, one of the three cells must contain a ~. The blue cell can 'see' all three cells, and so cannot have a solution of ~, and the ~ may be removed from it.</div></body>", "<div>A Singles Chain consists of an unbroken series of links, where a link is a line joining two candidates within a unit (row, column or box) when there are exactly two candidates of that value within the unit. In this chain, the candidate value is ~. For each link of the chain, one of the linked candidates will be a solution, while the other will be a non-solution. All of the solution candidates have the same color (either green or red) while all of the non-solution candidates have the other color. The cell highlighted in blue at ~ can <b>see</b> both a green and a red candidate, one of which will be a solution. This means that the ~ in the blue cell cannot be the solution for that cell and may therefore be removed.</div></body>", "<div>A Singles Chain consists of an unbroken series of links, where a link is a line joining two candidates within a unit (row, column or box) when there are exactly two candidates of that value within the unit. In this chain, the candidate value is ~. For each link of the chain, one of the linked candidates will be a solution, while the other will be a non-solution. All of the solution candidates have the same color (either green or red) while all of the non-solution candidates have the other color. The cells highlighted in blue draw your attention to the fact that there are a number of ~ candidate ~s in the same ~. As there can only be a single solution of ~ in the ~, it follows that ALL of the ~ ~s in the puzzle are non-solutions and can be removed. Similarly, all of the ~ ~s are solutions, and may be processed as such by selecting the cells by means of a mouse click, and typing ~.</div></body>", "<div>X-Cycles are similar to Singles Chains in their use of links between similarly numbered candidates within a unit (row, column or box). Links are classed as <b>Strong Links</b> (dark green) if the candidates they connect are the only two of that value in the unit, or <b>Weak Links</b> (light green) if there are additional candidates of the same value within the unit. A group of such links becomes an X-Cycle if they join together to form a complete loop. An X-Cycle is subject to Rule 1 if it meets the following criteria:- <br/><br/><ul><li/>It contains an even number of links.<li/>There are no examples of consecutive weak links.<li/>Consecutive strong links are acceptable provided they occur in groups having an odd number of members.</ul>The present puzzle contains such a loop for candidates of value ~. If you examine the loop you will soon convince yourself that either all of the red candidates are solutions, or all of the green candidates are solutions. Either way the units highlighted in blue will have their requirement for a ~ solution satisfied. Rule 1 states that additional candidates in weak link units may be removed.</div></body>", "<div>X-Cycles are similar to Singles Chains in their use of links between similarly numbered candidates within a unit (row, column or box). Links are classed as <b>Strong Links</b> (dark green) if the candidates they connect are the only two of that value in the unit, or <b>Weak Links</b> (light green) if there are additional candidates of the same value within the unit. A group of such links becomes an X-Cycle if they join together to form a complete loop. An X-Cycle is subject to Rule 2 if it meets the following criteria:- <br/><br/><ul><li/>It contains an odd number of links.<li/>There are no examples of consecutive weak links.<li/>There is one example of an even number of consecutive strong links.<li/>All other strong links occur in groups having an odd number of members.</ul>The present puzzle contains such a loop for candidates of value ~. If you examine the loop you will soon convince yourself of the truth of Rule 2 which states that the candidate at the first junction between two strong links must constitute a solution.</div></body>", "<div>X-Cycles are similar to Singles Chains in their use of links between similarly numbered candidates within a unit (row, column or box). Links are classed as <b>Strong Links</b> (dark green) if the candidates they connect are the only two of that value in the unit, or <b>Weak Links</b> (light green) if there are additional candidates of the same value within the unit. A group of such links becomes an X-Cycle if they join together to form a complete loop. An X-Cycle is subject to Rule 3 if it meets the following criteria:- <br/><br/><ul><li/>It contains an odd number of links. <li/>There is exactly one example of consecutive weak links. <li/>All strong links occur in groups having an odd number of members. </ul>The present puzzle contains such a loop for candidates of value ~. If you examine the loop you will soon convince yourself of the truth of Rule 3 which states that the candidate at the junction between two weak links must constitute a non-solution and may be removed.</div></body>", "<div>Sorry! Crossword Express cannot find a hint at this time.</div></body>", "<div>In the cage which has cell(s) highlighted in green, the candidate value(s) highlighted in magenta cannot combine to form the score of ~ required by this cage. They may be removed.</div></body>", "<div>The cell highlighted in blue contains a solution number of ~. All ~s in the same row, column, box and cage are highlighted in magenta, and may be removed.</div></body>", "<div>The green cells highlight a cage having a score of ~. There is only one unsolved cell in this cage, so its value must be equal to the score of the cage, minus the sum of the solved cells. This leads to a value of ~ as indicated by the highlighted candidate.</div></body>", "<div>The highlighted area covers ~ ~ having a total score of ~. The red section is the area covered by complete cages which have a total score of ~. The difference of ~ between these two scores represents the score of the section highlighted in green. This green area behaves, in all respects as if it were a cage, and is referred to as a virtual cage. It is easy to see that the highlighted candidate number must be the solution for the cell which contains it.</div></body>", "<div>The highlighted area covers ~ ~ having a total score of ~. The red section is the area covered by complete cages which have a total score of ~. The difference of ~ between these two scores represents the score of the section highlighted in green. This green area behaves, in all respects as if it were a cage, and is referred to as a virtual cage. In this cage, the candidate value(s) highlighted in magenta cannot combine to form the score of ~ required by this cage. They may be removed.</div></body>" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SudokuBuild(JFrame jf, boolean auto, int hm, int start) {
/*  356 */     Def.puzzleMode = 180;
/*  357 */     Def.building = 0;
/*  358 */     Def.dispSolArray = Boolean.valueOf(true); Def.dispCursor = Boolean.valueOf(true); Def.dispGuideDigits = Boolean.valueOf(false);
/*  359 */     makeGrid();
/*      */     
/*  361 */     jfSudoku = new JFrame("Sudoku");
/*  362 */     if (Op.getInt(Op.SU.SuH.ordinal(), Op.su) > Methods.scrH - 200) {
/*  363 */       int diff = Op.getInt(Op.SU.SuH.ordinal(), Op.su) - Op.getInt(Op.SU.SuW.ordinal(), Op.su);
/*  364 */       Op.setInt(Op.SU.SuH.ordinal(), Methods.scrH - 200, Op.su);
/*  365 */       Op.setInt(Op.SU.SuW.ordinal(), Methods.scrH - 200 + diff, Op.su);
/*      */     } 
/*  367 */     jfSudoku.setSize(Op.getInt(Op.SU.SuW.ordinal(), Op.su), Op.getInt(Op.SU.SuH.ordinal(), Op.su));
/*  368 */     int frameX = (jf.getX() + jfSudoku.getWidth() > Methods.scrW) ? (Methods.scrW - jfSudoku.getWidth() - 10) : jf.getX();
/*  369 */     jfSudoku.setLocation(frameX, jf.getY());
/*  370 */     jfSudoku.getContentPane().setBackground(Def.COLOR_FRAMEBG);
/*  371 */     jfSudoku.setLayout((LayoutManager)null);
/*  372 */     jfSudoku.setDefaultCloseOperation(0);
/*      */     
/*  374 */     jfSudoku
/*  375 */       .addComponentListener(new ComponentListener() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  377 */             int oldw = Op.getInt(Op.SU.SuW.ordinal(), Op.su);
/*  378 */             int oldh = Op.getInt(Op.SU.SuH.ordinal(), Op.su);
/*  379 */             Methods.frameResize(SudokuBuild.jfSudoku, oldw, oldh, 600, 680);
/*  380 */             Op.setInt(Op.SU.SuW.ordinal(), SudokuBuild.jfSudoku.getWidth(), Op.su);
/*  381 */             Op.setInt(Op.SU.SuH.ordinal(), SudokuBuild.jfSudoku.getHeight(), Op.su);
/*  382 */             SudokuBuild.restoreFrame();
/*      */           }
/*      */           public void componentMoved(ComponentEvent ce) {}
/*      */           
/*      */           public void componentHidden(ComponentEvent ce) {}
/*      */           
/*      */           public void componentShown(ComponentEvent ce) {}
/*      */         });
/*  390 */     jfSudoku
/*  391 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  393 */             if (Def.building == 1 || Def.selecting)
/*  394 */               return;  Op.saveOptions("sudoku.opt", Op.su);
/*  395 */             Grid.findHint = Boolean.valueOf(false);
/*  396 */             CrosswordExpress.transfer(1, SudokuBuild.jfSudoku);
/*      */           }
/*      */         });
/*      */     
/*  400 */     Methods.closeHelp();
/*      */     
/*  402 */     Runnable buildThread = () -> {
/*      */         if (howMany == 1) {
/*      */           buildSudoku();
/*      */         } else {
/*      */           multiBuild();
/*      */           
/*      */           if (this.sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfSudoku.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfSudoku);
/*      */           makeGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfSudoku, "sudoku", Op.su[Op.SU.SuPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  428 */     jl1 = new JLabel(); jfSudoku.add(jl1);
/*  429 */     jl2 = new JLabel(); jfSudoku.add(jl2);
/*      */ 
/*      */     
/*  432 */     menuBar = new JMenuBar();
/*  433 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  434 */     jfSudoku.setJMenuBar(menuBar);
/*      */     
/*  436 */     this.menu = new JMenu("File");
/*  437 */     menuBar.add(this.menu);
/*  438 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  439 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  440 */     this.menu.add(this.menuItem);
/*  441 */     this.menuItem
/*  442 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfSudoku, "sudoku", "sudoku", Op.su, Op.SU.SuPuz.ordinal(), false);
/*      */         });
/*  449 */     this.menuItem = new JMenuItem("Save");
/*  450 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  451 */     this.menu.add(this.menuItem);
/*  452 */     this.menuItem
/*  453 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*      */           Methods.puzzleSaved(jfSudoku, "sudoku", Op.su[Op.SU.SuPuz.ordinal()]);
/*      */         });
/*  460 */     this.menuItem = new JMenuItem("SaveAs");
/*  461 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  462 */     this.menu.add(this.menuItem);
/*  463 */     this.menuItem
/*  464 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSudoku, Op.su[Op.SU.SuPuz.ordinal()].substring(0, Op.su[Op.SU.SuPuz.ordinal()].indexOf(".sudoku")), "sudoku", ".sudoku");
/*      */           if (Methods.clickedOK) {
/*      */             saveSudoku(Op.su[Op.SU.SuPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfSudoku, "sudoku", Op.su[Op.SU.SuPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  475 */     this.menuItem = new JMenuItem("Quit Construction");
/*  476 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  477 */     this.menu.add(this.menuItem);
/*  478 */     this.menuItem
/*  479 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("sudoku.opt", Op.su);
/*      */           CrosswordExpress.transfer(1, jfSudoku);
/*      */         });
/*  487 */     this.menu = new JMenu("Build");
/*  488 */     menuBar.add(this.menu);
/*  489 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  490 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  491 */     this.menu.add(this.menuItem);
/*  492 */     this.menuItem
/*  493 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfSudoku, Op.su[Op.SU.SuPuz.ordinal()].substring(0, Op.su[Op.SU.SuPuz.ordinal()].indexOf(".sudoku")), "sudoku", ".sudoku");
/*      */           if (Methods.clickedOK) {
/*      */             Op.su[Op.SU.SuPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  504 */     this.menuItem = new JMenuItem("Build Options");
/*  505 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  506 */     this.menu.add(this.menuItem);
/*  507 */     this.menuItem
/*  508 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           sudokuOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (howMany > 1)
/*      */               Op.su[Op.SU.SuPuz.ordinal()] = "" + startPuz + ".sudoku"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  519 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  520 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  521 */     this.menu.add(this.buildMenuItem);
/*  522 */     this.buildMenuItem
/*  523 */       .addActionListener(ae -> {
/*      */           if (Op.su[Op.SU.SuPuz.ordinal()].length() == 0 && howMany == 1) {
/*      */             Methods.noName(jfSudoku);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  539 */     this.menuItem = new JMenuItem("Test Puzzle Validity");
/*  540 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(84, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  541 */     this.menu.add(this.menuItem);
/*  542 */     this.menuItem
/*  543 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           for (int y1 = 0; y1 < 9; y1++) {
/*      */             for (int x1 = 0; x1 < 9; x1++) {
/*      */               Grid.puz[x1][y1] = Grid.grid[x1][y1];
/*      */             }
/*      */           } 
/*      */           if (solveSudoku(maxDiff) > 0L) {
/*      */             for (int y2 = 0; y2 < 9; y2++) {
/*      */               for (int x2 = 0; x2 < 9; x2++) {
/*      */                 Grid.sol[x2][y2] = Grid.grid[x2][y2];
/*      */                 Grid.grid[x2][y2] = Grid.puz[x2][y2];
/*      */               } 
/*      */             } 
/*      */             Methods.havePuzzle = true;
/*      */             saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*      */             Methods.puzzleSaved(jfSudoku, "sudoku", Op.su[Op.SU.SuPuz.ordinal()]);
/*      */           } else {
/*      */             JOptionPane.showMessageDialog(jfSudoku, "There is no solution to this puzzle", "Test Result", 1);
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  567 */     this.menu = new JMenu("View");
/*  568 */     menuBar.add(this.menu);
/*  569 */     this.menuItem = new JMenuItem("Display Options");
/*  570 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  571 */     this.menu.add(this.menuItem);
/*  572 */     this.menuItem
/*  573 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfSudoku, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  581 */     this.menu = new JMenu("Export");
/*  582 */     menuBar.add(this.menu);
/*  583 */     this.menuItem = new JMenuItem("Export Sudoku Web-App");
/*  584 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(87, 1));
/*  585 */     this.menu.add(this.menuItem);
/*  586 */     this.menuItem
/*  587 */       .addActionListener(ae -> Methods.exportWebApp(jfSudoku, "sudoku"));
/*      */ 
/*      */     
/*  590 */     this.menuItem = new JMenuItem("Launch a Demo Sudoku Web App");
/*  591 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, 1));
/*  592 */     this.menu.add(this.menuItem);
/*  593 */     this.menuItem
/*  594 */       .addActionListener(ae -> Methods.launchWebApp(jfSudoku, "sudoku"));
/*      */ 
/*      */     
/*  597 */     this.menuItem = new JMenuItem("Print a Sudoku KDP puzzle book.");
/*  598 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  599 */     this.menu.add(this.menuItem);
/*  600 */     this.menuItem
/*  601 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfSudoku, 180, 6);
/*      */         });
/*  608 */     this.menu = new JMenu("Tasks");
/*  609 */     menuBar.add(this.menu);
/*  610 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  611 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  612 */     this.menu.add(this.menuItem);
/*  613 */     this.menuItem
/*  614 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfSudoku, Op.su[Op.SU.SuPuz.ordinal()]);
/*      */         });
/*  620 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  621 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  622 */     this.menu.add(this.menuItem);
/*  623 */     this.menuItem
/*  624 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(181, jfSudoku);
/*      */           } else {
/*      */             Methods.noPuzzle(jfSudoku, "Solve");
/*      */           } 
/*      */         });
/*  633 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  634 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  635 */     this.menu.add(this.menuItem);
/*  636 */     this.menuItem
/*  637 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfSudoku, Op.su[Op.SU.SuPuz.ordinal()], "sudoku", pp)) {
/*      */             makeGrid();
/*      */             loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  648 */     this.menu = new JMenu("Help");
/*  649 */     menuBar.add(this.menu);
/*  650 */     this.menuItem = new JMenuItem("Sudoku Help");
/*  651 */     this.menu.add(this.menuItem);
/*  652 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, 1));
/*  653 */     this.menuItem
/*  654 */       .addActionListener(ae -> Methods.cweHelp(jfSudoku, null, "Building Sudoku Puzzles", this.sudokuHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  659 */     this.menuItem = new JMenuItem("Sudoku Web Application");
/*  660 */     this.menu.add(this.menuItem);
/*  661 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, 1));
/*  662 */     this.menuItem
/*  663 */       .addActionListener(ae -> Methods.cweHelp(jfSudoku, null, "Sudoku Web Application", webAppHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  669 */     pp = new SudokuBuildPP(0, 37);
/*  670 */     jfSudoku.add(pp);
/*      */     
/*  672 */     pp
/*  673 */       .addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent e) {
/*  675 */             SudokuBuild.this.updateGrid(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  680 */     jfSudoku
/*  681 */       .addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent e) {
/*  683 */             SudokuBuild.this.handleKeyPressed(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  688 */     pp
/*  689 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  691 */             if (Def.isMac) {
/*  692 */               SudokuBuild.jfSudoku.setResizable((SudokuBuild.jfSudoku.getWidth() - e.getX() < 15 && SudokuBuild.jfSudoku
/*  693 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  698 */     loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*  699 */     restoreFrame();
/*      */ 
/*      */     
/*  702 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  708 */     this.myTimer = new Timer(1000, timerAL);
/*      */     
/*  710 */     if (auto) {
/*  711 */       this.sixpack = true;
/*  712 */       howMany = hm; startPuz = start;
/*  713 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  718 */     hintIndexb = hintIndexg = hintIndexr = hintUnitIndex = hintCellIndex = hintCandidate = weakLinkIndex = candIndex = 0;
/*  719 */     jfSudoku.setVisible(true);
/*  720 */     Insets insets = jfSudoku.getInsets();
/*  721 */     panelW = jfSudoku.getWidth() - insets.left + insets.right;
/*  722 */     panelH = jfSudoku.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  723 */     pp.setSize(panelW, panelH);
/*  724 */     jfSudoku.requestFocusInWindow();
/*  725 */     pp.repaint();
/*  726 */     if (!Def.isMac) Wait.shortWait(5); 
/*  727 */     Methods.infoPanel(jl1, jl2, "Build Sudoku", "Puzzle : " + Op.su[Op.SU.SuPuz.ordinal()], panelW + 200);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  731 */     int m = (width - inset) / Grid.xSz;
/*  732 */     int n = (height - inset) / Grid.ySz;
/*  733 */     Grid.xCell = Grid.yCell = (n < m) ? n : m;
/*  734 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/*  735 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*      */   }
/*      */   
/*      */   final void sudokuOptions() {
/*  739 */     final JDialog jdlgSudoku = new JDialog(jfSudoku, "Sudoku Options", true);
/*  740 */     jdlgSudoku.setSize(365, 281);
/*  741 */     jdlgSudoku.setResizable(false);
/*  742 */     jdlgSudoku.setLayout((LayoutManager)null);
/*  743 */     jdlgSudoku.setLocation(jfSudoku.getX(), jfSudoku.getY());
/*      */     
/*  745 */     jdlgSudoku
/*  746 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  748 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  752 */     Methods.closeHelp();
/*      */     
/*  754 */     JLabel jlSymbols = new JLabel("Symbol set:");
/*  755 */     jlSymbols.setForeground(Def.COLOR_LABEL);
/*  756 */     jlSymbols.setSize(100, 20);
/*  757 */     jlSymbols.setLocation(0, 12);
/*  758 */     jlSymbols.setHorizontalAlignment(4);
/*  759 */     jdlgSudoku.add(jlSymbols);
/*      */     
/*  761 */     final JTextField jtfSymbols = new JTextField(Op.su[Op.SU.SuSet.ordinal()], 15);
/*  762 */     jtfSymbols.setSize(140, 26);
/*  763 */     jtfSymbols.setLocation(110, 10);
/*  764 */     jtfSymbols.selectAll();
/*  765 */     jtfSymbols.setHorizontalAlignment(2);
/*  766 */     jdlgSudoku.add(jtfSymbols);
/*  767 */     jtfSymbols.setFont(new Font("SansSerif", 1, 13));
/*      */     
/*  769 */     JLabel jlDiff = new JLabel("Difficulty:");
/*  770 */     jlDiff.setForeground(Def.COLOR_LABEL);
/*  771 */     jlDiff.setSize(100, 20);
/*  772 */     jlDiff.setLocation(0, 46);
/*  773 */     jlDiff.setHorizontalAlignment(4);
/*  774 */     jdlgSudoku.add(jlDiff);
/*      */     
/*  776 */     final JComboBox<Integer> jcbbDiff = new JComboBox<>();
/*  777 */     for (int n = 1; n <= maxDiff; n++)
/*  778 */       jcbbDiff.addItem(Integer.valueOf(n)); 
/*  779 */     jcbbDiff.setSize(50, 20);
/*  780 */     jcbbDiff.setLocation(110, 44);
/*  781 */     jdlgSudoku.add(jcbbDiff);
/*  782 */     jcbbDiff.setBackground(Def.COLOR_BUTTONBG);
/*  783 */     jcbbDiff.setSelectedIndex(Op.getInt(Op.SU.SuDifficulty.ordinal(), Op.su) - 1);
/*      */     
/*  785 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgSudoku, 10, 74, howMany, startPuz, Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue());
/*      */     
/*  787 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  789 */           String s = jtfSymbols.getText();
/*  790 */           if (s.length() != 9) {
/*  791 */             JOptionPane.showMessageDialog(jdlgSudoku, "<html>You must have exactly nine symbols<br>in your Symbol set.", "Error", 1);
/*      */           } else {
/*  793 */             Op.su[Op.SU.SuSet.ordinal()] = s;
/*  794 */             SudokuBuild.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  795 */             SudokuBuild.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  796 */             Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(hmp.jcbVaryDiff.isSelected()), Op.sx);
/*  797 */             Methods.clickedOK = true;
/*  798 */             jdlgSudoku.dispose();
/*  799 */             Methods.closeHelp();
/*      */           } 
/*  801 */           Op.setInt(Op.SU.SuDifficulty.ordinal(), jcbbDiff.getSelectedIndex() + 1, Op.su);
/*      */         }
/*      */       };
/*  804 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 188, 80, 26);
/*  805 */     jdlgSudoku.add(jbOK);
/*      */     
/*  807 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  809 */           Methods.clickedOK = false;
/*  810 */           jdlgSudoku.dispose();
/*  811 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  814 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 223, 80, 26);
/*  815 */     jdlgSudoku.add(jbCancel);
/*      */     
/*  817 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  819 */           Methods.cweHelp(null, jdlgSudoku, "Sudoku Options", SudokuBuild.this.sudokuOptions);
/*      */         }
/*      */       };
/*  822 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 188, 150, 61);
/*  823 */     jdlgSudoku.add(jbHelp);
/*      */     
/*  825 */     jdlgSudoku.getRootPane().setDefaultButton(jbOK);
/*  826 */     Methods.setDialogSize(jdlgSudoku, 260, 259);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  830 */     String[] colorLabel = { "Cell Color", "Hilite Color", "Border Color", "Grid Color", "Number Color", "Guide Digit Color", "Guide Digit Bg", "Error Color" };
/*  831 */     int[] colorInt = { Op.SU.SuCell.ordinal(), Op.SU.SuHilite.ordinal(), Op.SU.SuBorder.ordinal(), Op.SU.SuGrid.ordinal(), Op.SU.SuNumber.ordinal(), Op.SU.SuGuide.ordinal(), Op.SU.SuGuideBg.ordinal(), Op.SU.SuError.ordinal() };
/*  832 */     String[] fontLabel = { "Select Solution Font", "Select Guide Digit Font" };
/*  833 */     int[] fontInt = { Op.SU.SuFont.ordinal(), Op.SU.SuGuideFont.ordinal() };
/*  834 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  835 */     int[] checkInt = { Op.SU.SuPuzColor.ordinal(), Op.SU.SuSolColor.ordinal() };
/*  836 */     Methods.stdPrintOptions(jf, "Sudoku " + type, Op.su, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveSudoku(String sudokuName) {
/*      */     try {
/*  846 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("sudoku/" + sudokuName));
/*  847 */       dataOut.writeInt(Grid.xSz);
/*  848 */       dataOut.writeInt(Grid.ySz);
/*  849 */       dataOut.writeByte(Methods.noReveal);
/*  850 */       dataOut.writeByte(Methods.noErrors); int x;
/*  851 */       for (x = 0; x < 54; x++)
/*  852 */         dataOut.writeByte(0); 
/*  853 */       for (int y = 0; y < Grid.ySz; y++) {
/*  854 */         for (x = 0; x < Grid.xSz; x++) {
/*  855 */           dataOut.writeInt(Grid.grid[x][y]);
/*  856 */           dataOut.writeInt(Grid.puz[x][y]);
/*  857 */           dataOut.writeInt(Grid.sol[x][y]);
/*  858 */           dataOut.writeInt(Grid.color[x][y]);
/*      */         } 
/*  860 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  861 */       dataOut.writeUTF(Methods.author);
/*  862 */       dataOut.writeUTF(Methods.copyright);
/*  863 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  864 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  865 */       dataOut.close();
/*      */     }
/*  867 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadSudoku(String sudokuName) {
/*      */     
/*  875 */     try { File fl = new File("sudoku/" + sudokuName);
/*  876 */       if (!fl.exists()) {
/*  877 */         fl = new File("sudoku/");
/*  878 */         String[] s = fl.list(); int k;
/*  879 */         for (k = 0; k < s.length && (
/*  880 */           s[k].lastIndexOf(".sudoku") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  882 */         if (k == s.length) { makeGrid(); return; }
/*  883 */          sudokuName = s[k];
/*  884 */         Op.su[Op.SU.SuPuz.ordinal()] = sudokuName;
/*      */       } 
/*      */       
/*  887 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("sudoku/" + sudokuName));
/*  888 */       Grid.xSz = dataIn.readInt();
/*  889 */       Grid.ySz = dataIn.readInt();
/*  890 */       Methods.noReveal = dataIn.readByte();
/*  891 */       Methods.noErrors = dataIn.readByte(); int i;
/*  892 */       for (i = 0; i < 54; i++)
/*  893 */         dataIn.readByte(); 
/*  894 */       for (int j = 0; j < Grid.ySz; j++) {
/*  895 */         for (i = 0; i < Grid.xSz; i++) {
/*  896 */           Grid.grid[i][j] = dataIn.readInt();
/*  897 */           Grid.puz[i][j] = dataIn.readInt();
/*  898 */           Grid.sol[i][j] = dataIn.readInt();
/*  899 */           Grid.color[i][j] = dataIn.readInt();
/*      */         } 
/*  901 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  902 */       Methods.author = dataIn.readUTF();
/*  903 */       Methods.copyright = dataIn.readUTF();
/*  904 */       Methods.puzzleNumber = dataIn.readUTF();
/*  905 */       Methods.puzzleNotes = dataIn.readUTF();
/*  906 */       dataIn.close(); }
/*      */     
/*  908 */     catch (IOException exc) { return; }
/*  909 */      Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawSudoku(Graphics2D g2, String opt) {
/*  919 */     int cBoxDim = Grid.xCell / 3;
/*      */ 
/*      */     
/*  922 */     boolean hintsDrawn = false, redrawRequired = false;
/*      */     
/*  924 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  925 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 12.0F, 2, 2);
/*  926 */     g2.setStroke(normalStroke);
/*      */     
/*  928 */     RenderingHints rh = g2.getRenderingHints();
/*  929 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  930 */     g2.setRenderingHints(rh);
/*      */     
/*      */     int j;
/*  933 */     for (j = 0; j < Grid.ySz; j++) {
/*  934 */       for (int i = 0; i < Grid.xSz; i++) {
/*  935 */         int theColor; if (Def.dispWithColor.booleanValue()) {
/*  936 */           if (Def.dispErrors.booleanValue() && ((Grid.grid[i][j] != 0 && Grid.grid[i][j] != Grid.sol[i][j]) || (Grid.grid[i][j] == 0 && (
/*      */             
/*  938 */             getStatus(i, j) & bit[Grid.sol[i][j] - 1]) == 0))) {
/*  939 */             theColor = Op.getColorInt(Op.SU.SuError.ordinal(), Op.su);
/*      */           } else {
/*  941 */             theColor = (Grid.color[i][j] == 16777215) ? Op.getColorInt(Op.SU.SuCell.ordinal(), Op.su) : Grid.color[i][j];
/*      */           } 
/*      */         } else {
/*  944 */           theColor = Grid.color[i][j];
/*  945 */         }  g2.setColor(new Color(theColor));
/*  946 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       } 
/*      */     } 
/*  949 */     if (Grid.findHint.booleanValue()) {
/*  950 */       g2.setColor(Def.COLOR_HINT_B);
/*  951 */       for (int k = 0; k < hintUnitIndex; k++) {
/*  952 */         int a, i, x, y; j = hintUnit[k].charAt(1) - 48;
/*  953 */         switch (hintUnit[k].charAt(0)) {
/*      */           case 'R':
/*  955 */             for (i = 0; i < 9; i++)
/*  956 */               g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */             break;
/*      */           case 'C':
/*  959 */             for (i = 0; i < 9; i++)
/*  960 */               g2.fillRect(Grid.xOrg + j * Grid.xCell, Grid.yOrg + i * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */             break;
/*      */           case 'B':
/*  963 */             x = j % 3 * 3; y = j / 3 * 3;
/*  964 */             for (a = 0; a < 3; a++) {
/*  965 */               for (int b = 0; b < 3; b++) {
/*  966 */                 g2.fillRect(Grid.xOrg + (x + a) * Grid.xCell, Grid.yOrg + (y + b) * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */               }
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*  973 */     if (hintIndexb > 0) {
/*  974 */       if (candc[0] == 0) {
/*  975 */         Grid.xCur = hintXb[0];
/*  976 */         Grid.yCur = hintYb[0];
/*      */       } 
/*  978 */       g2.setColor(Def.COLOR_HINT_B);
/*  979 */       for (int i = 0; i < hintIndexb; i++) {
/*  980 */         g2.fillRect(Grid.xOrg + hintXb[i] * Grid.xCell, Grid.yOrg + hintYb[i] * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       }
/*      */     } 
/*  983 */     if (hintIndexg > 0) {
/*  984 */       g2.setColor(Def.COLOR_HINT_G);
/*  985 */       for (int i = 0; i < hintIndexg; i++) {
/*  986 */         g2.fillRect(Grid.xOrg + hintXg[i] * Grid.xCell, Grid.yOrg + hintYg[i] * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       }
/*      */     } 
/*  989 */     if (hintIndexr > 0) {
/*  990 */       g2.setColor(Def.COLOR_HINT_R);
/*  991 */       for (int i = 0; i < hintIndexr; i++) {
/*  992 */         g2.fillRect(Grid.xOrg + hintXr[i] * Grid.xCell, Grid.yOrg + hintYr[i] * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       }
/*      */     } 
/*      */     
/*  996 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SU.SuGrid.ordinal(), Op.su)) : Def.COLOR_BLACK);
/*  997 */     g2.setStroke(normalStroke);
/*  998 */     for (j = 0; j < Grid.ySz; j++) {
/*  999 */       for (int i = 0; i < Grid.xSz; i++)
/* 1000 */         g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/* 1001 */     }  g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)) : Def.COLOR_BLACK);
/*      */ 
/*      */     
/* 1004 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)) : Def.COLOR_BLACK);
/* 1005 */     g2.setStroke(wideStroke);
/* 1006 */     g2.drawLine(Grid.xOrg, Grid.yOrg + 3 * Grid.yCell, Grid.xOrg + 9 * Grid.xCell, Grid.yOrg + 3 * Grid.yCell);
/* 1007 */     g2.drawLine(Grid.xOrg, Grid.yOrg + 6 * Grid.yCell, Grid.xOrg + 9 * Grid.xCell, Grid.yOrg + 6 * Grid.yCell);
/* 1008 */     g2.drawLine(Grid.xOrg + 3 * Grid.xCell, Grid.yOrg, Grid.xOrg + 3 * Grid.xCell, Grid.yOrg + 9 * Grid.yCell);
/* 1009 */     g2.drawLine(Grid.xOrg + 6 * Grid.xCell, Grid.yOrg, Grid.xOrg + 6 * Grid.xCell, Grid.yOrg + 9 * Grid.yCell);
/* 1010 */     g2.drawRect(Grid.xOrg, Grid.yOrg, Grid.xSz * Grid.xCell, Grid.ySz * Grid.yCell);
/*      */     
/* 1012 */     if (Def.dispCursor.booleanValue() && !Grid.findHint.booleanValue()) {
/* 1013 */       g2.setColor(Def.COLOR_RED);
/* 1014 */       g2.setStroke(wideStroke);
/* 1015 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */     } 
/*      */     
/* 1018 */     if (Grid.findHint.booleanValue() && linkDatIndex > 0) {
/* 1019 */       int k = linkCandidateNum - 1;
/* 1020 */       for (int i = 0; i < linkDatIndex; i++) {
/* 1021 */         g2.setStroke(wideStroke);
/* 1022 */         int x1 = (linkDat[i]).start.x, y1 = (linkDat[i]).start.y;
/* 1023 */         int x2 = (linkDat[i]).end.x, y2 = (linkDat[i]).end.y;
/*      */         
/* 1025 */         if ((linkDat[i]).Y > 1) {
/* 1026 */           g2.setColor(STRONG_LINK);
/* 1027 */           g2.drawLine(Grid.xOrg + x1 * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + y1 * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2, Grid.xOrg + x2 * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + y2 * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2);
/*      */ 
/*      */ 
/*      */           
/* 1031 */           g2.setStroke(normalStroke);
/* 1032 */           if ((getStatus(x1, y1) & bit[k]) > 0) {
/* 1033 */             g2.setColor(((linkDat[i]).Y == 2) ? Def.COLOR_GREEN : Def.COLOR_RED);
/* 1034 */             g2.fillRect(Grid.xOrg + x1 * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + y1 * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */             
/* 1036 */             g2.setColor(new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)));
/* 1037 */             g2.drawRect(Grid.xOrg + x1 * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + y1 * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */             
/* 1039 */             if (hintNum == 10) {
/* 1040 */               hintsDrawn = true;
/*      */             }
/*      */           } 
/* 1043 */           if ((getStatus(x2, y2) & bit[k]) > 0) {
/* 1044 */             g2.setColor(((linkDat[i]).N == 2) ? Def.COLOR_GREEN : Def.COLOR_RED);
/* 1045 */             g2.fillRect(Grid.xOrg + x2 * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + y2 * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */             
/* 1047 */             g2.setColor(new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)));
/* 1048 */             g2.drawRect(Grid.xOrg + x2 * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + y2 * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */             
/* 1050 */             if (hintNum == 10)
/* 1051 */               hintsDrawn = true; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1056 */     g2.setStroke(normalStroke);
/*      */     
/* 1058 */     if (Grid.findHint.booleanValue()) {
/* 1059 */       int k = hintCandidate - 1; int i;
/* 1060 */       for (i = 0; i < hintCellIndex; i++) {
/* 1061 */         g2.setStroke(wideStroke);
/* 1062 */         g2.setColor(STRONG_LINK);
/* 1063 */         g2.drawLine(Grid.xOrg + hintCellx[i] * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + hintCelly[i] * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2, Grid.xOrg + hintCellx[(i + 1) % hintCellIndex] * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + hintCelly[(i + 1) % hintCellIndex] * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1069 */       for (i = 0; i < weakLinkIndex; i++) {
/* 1070 */         g2.setStroke(wideStroke);
/* 1071 */         g2.setColor(WEAK_LINK);
/* 1072 */         g2.drawLine(Grid.xOrg + weakLinkx1[i] * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + weakLinky1[i] * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2, Grid.xOrg + weakLinkx2[i] * Grid.xCell + k % 3 * cBoxDim + cBoxDim / 2, Grid.yOrg + weakLinky2[i] * Grid.yCell + k / 3 * cBoxDim + cBoxDim / 2);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1078 */       for (i = 0; i < hintCellIndex; i++) {
/* 1079 */         g2.setColor((i % 2 == 0) ? Def.COLOR_GREEN : Def.COLOR_RED);
/* 1080 */         g2.fillRect(Grid.xOrg + hintCellx[i] * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + hintCelly[i] * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */         
/* 1082 */         g2.setColor(new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)));
/* 1083 */         g2.setStroke(normalStroke);
/* 1084 */         g2.drawRect(Grid.xOrg + hintCellx[i] * Grid.xCell + k % 3 * cBoxDim, Grid.yOrg + hintCelly[i] * Grid.yCell + k / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */       } 
/*      */ 
/*      */       
/* 1088 */       for (i = 0; i < candIndex; i++) {
/* 1089 */         if ((getStatus(candx[i], candy[i]) & bit[candv[i]]) != 0) {
/* 1090 */           g2.setColor(candC[candc[i]]);
/* 1091 */           g2.fillRect(Grid.xOrg + candx[i] * Grid.xCell + candv[i] % 3 * cBoxDim, Grid.yOrg + candy[i] * Grid.yCell + candv[i] / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */           
/* 1093 */           g2.setColor(new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)));
/* 1094 */           g2.setStroke(normalStroke);
/* 1095 */           g2.drawRect(Grid.xOrg + candx[i] * Grid.xCell + candv[i] % 3 * cBoxDim, Grid.yOrg + candy[i] * Grid.yCell + candv[i] / 3 * cBoxDim, cBoxDim, cBoxDim);
/*      */           
/* 1097 */           hintsDrawn = true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1101 */     g2.setStroke(normalStroke);
/*      */ 
/*      */     
/* 1104 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SU.SuNumber.ordinal(), Op.su)) : Def.COLOR_BLACK);
/* 1105 */     g2.setFont(new Font(Op.su[Op.SU.SuFont.ordinal()], 0, 8 * Grid.yCell / 10));
/* 1106 */     FontMetrics fm = g2.getFontMetrics();
/* 1107 */     int[][] thePuzzleArray = (opt.indexOf('G') != -1) ? Grid.grid : ((opt.indexOf('S') != -1) ? Grid.sol : Grid.puz);
/* 1108 */     for (j = 0; j < Grid.ySz; j++) {
/* 1109 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1110 */         if (thePuzzleArray[i][j] > 0) { char ch; 
/* 1111 */           try { ch = Op.su[Op.SU.SuSet.ordinal()].charAt(thePuzzleArray[i][j] - 1); }
/* 1112 */           catch (Exception e) { ch = '1'; }
/* 1113 */            int w = fm.stringWidth("" + ch);
/* 1114 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm
/* 1115 */               .getAscent() - fm.getDescent()) / 2); }
/*      */       
/*      */       } 
/*      */     } 
/*      */     
/* 1120 */     if (opt.indexOf('C') != -1 && SudokuSolve.assist) {
/* 1121 */       g2.setFont(new Font(Op.su[Op.SU.SuGuideFont.ordinal()], 0, 9 * Grid.yCell / 32));
/* 1122 */       fm = g2.getFontMetrics();
/* 1123 */       for (j = 0; j < Grid.ySz; j++) {
/* 1124 */         for (int i = 0; i < Grid.xSz; i++) {
/* 1125 */           if (Grid.grid[i][j] == 0)
/* 1126 */             for (int k = 0; k < 9; k++) {
/* 1127 */               if ((getStatus(i, j) & bit[k]) > 0) {
/* 1128 */                 if (Grid.grid[Grid.xCur][Grid.yCur] == k + 1 && 
/* 1129 */                   !Grid.findHint.booleanValue()) {
/* 1130 */                   g2.setColor(new Color(Op.getColorInt(Op.SU.SuGuideBg.ordinal(), Op.su)));
/* 1131 */                   g2.fillRect(Grid.xOrg + i * Grid.xCell + k % 3 * Grid.xCell / 3, Grid.yOrg + j * Grid.yCell + k / 3 * Grid.yCell / 3, Grid.xCell / 3, Grid.yCell / 3);
/*      */                   
/* 1133 */                   g2.setColor(new Color(Op.getColorInt(Op.SU.SuBorder.ordinal(), Op.su)));
/* 1134 */                   g2.setStroke(normalStroke);
/* 1135 */                   g2.drawRect(Grid.xOrg + i * Grid.xCell + k % 3 * Grid.xCell / 3, Grid.yOrg + j * Grid.yCell + k / 3 * Grid.yCell / 3, Grid.xCell / 3, Grid.yCell / 3);
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/* 1140 */                 char ch = Op.su[Op.SU.SuSet.ordinal()].charAt(k);
/* 1141 */                 g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SU.SuGuide.ordinal(), Op.su)) : Def.COLOR_BLACK);
/* 1142 */                 int w = (Grid.xCell / 3 - fm.stringWidth("" + ch)) / 2;
/* 1143 */                 g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + Grid.xCell * k % 3 / 3 + w, Grid.yOrg + j * Grid.yCell + Grid.yCell * k / 3 / 3 + fm.getAscent() + 1);
/*      */               } 
/*      */             }  
/*      */         } 
/*      */       } 
/*      */     } 
/* 1149 */     if (opt.indexOf('I') != -1) {
/* 1150 */       for (int i = 0; i < Grid.ySz; i++) {
/* 1151 */         g2.setFont(new Font(Op.su[Op.SU.SuGuideFont.ordinal()], 1, 12 * Grid.yCell / 32));
/* 1152 */         fm = g2.getFontMetrics();
/* 1153 */         g2.setColor(new Color(11141120));
/* 1154 */         int w = fm.stringWidth("" + (i + 1));
/* 1155 */         g2.drawString("" + (i + 1), Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg - Grid.yCell / 6);
/* 1156 */         char ch = (char)(65 + i);
/* 1157 */         g2.drawString("" + ch, Grid.xOrg - (6 * Grid.xCell / 10 + fm.charWidth(ch)) / 2, Grid.yOrg + i * Grid.yCell + Grid.yCell / 2 + fm.getAscent() / 2);
/*      */       } 
/*      */     }
/*      */     
/* 1161 */     if (Def.dispCursor.booleanValue()) {
/* 1162 */       g2.setColor(Def.COLOR_RED);
/* 1163 */       g2.setStroke(wideStroke);
/* 1164 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */     } 
/*      */     
/* 1167 */     g2.setStroke(new BasicStroke(1.0F));
/* 1168 */     if (!hintsDrawn)
/* 1169 */       if (Grid.findHint.booleanValue()) {
/* 1170 */         Grid.findHint = Boolean.valueOf(false);
/* 1171 */         linkDatIndex = 0;
/* 1172 */         if (hintIndexb > 0 && !hintsDrawn) redrawRequired = true; 
/* 1173 */         Methods.clearHintData();
/* 1174 */         if (redrawRequired) {
/* 1175 */           SudokuSolve.pp.repaint();
/*      */         }
/*      */       } else {
/* 1178 */         hintIndexb = 0;
/*      */       }  
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/* 1183 */     loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/* 1184 */     setSizesAndOffsets(left, top, width, height, 0);
/* 1185 */     SudokuSolve.clearSolution();
/* 1186 */     Def.dispWithColor = Op.getBool(Op.SU.SuPuzColor.ordinal(), Op.su);
/* 1187 */     boolean mem = Def.dispGuideDigits.booleanValue(); Def.dispGuideDigits = Boolean.valueOf(false);
/* 1188 */     drawSudoku(g2, "G");
/* 1189 */     Def.dispGuideDigits = Boolean.valueOf(mem);
/* 1190 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 1194 */     loadSudoku(solutionPuzzle);
/* 1195 */     setSizesAndOffsets(left, top, width, height, 0);
/* 1196 */     Def.dispWithColor = Op.getBool(Op.SU.SuSolColor.ordinal(), Op.su);
/* 1197 */     drawSudoku(g2, "S");
/* 1198 */     Def.dispWithColor = Boolean.valueOf(true);
/* 1199 */     loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 1203 */     loadSudoku(solutionPuzzle);
/* 1204 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/* 1205 */     loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/* 1211 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/* 1213 */     String st = Op.sx[Op.SX.SxSu.ordinal()];
/* 1214 */     if (st.length() < 3) st = "SUDOKU"; 
/* 1215 */     int w = fm.stringWidth(st);
/* 1216 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/* 1217 */     SudokuSolve.loadSudoku(puzName + ".sudoku");
/* 1218 */     setSizesAndOffsets(left, top, dim, dim, 0);
/* 1219 */     SudokuSolve.clearSolution();
/* 1220 */     drawSudoku(g2, "P");
/* 1221 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/* 1222 */       st = rules;
/*      */     } else {
/* 1224 */       st = Op.su[Op.SU.SuRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/* 1225 */     }  if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/* 1226 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/* 1232 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/* 1234 */     String st = Op.sx[Op.SX.SxSu.ordinal()];
/* 1235 */     if (st.length() < 3) st = "SUDOKU"; 
/* 1236 */     int w = fm.stringWidth(st);
/* 1237 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/* 1238 */     loadSudoku(solName + ".sudoku");
/* 1239 */     setSizesAndOffsets(left, top, dim, dim, 0);
/* 1240 */     drawSudoku(g2, "S");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/* 1246 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/* 1248 */     String st = puzName;
/* 1249 */     int w = fm.stringWidth(st);
/* 1250 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/* 1251 */     SudokuSolve.loadSudoku(puzName + ".sudoku");
/* 1252 */     setSizesAndOffsets(left, top, dim, dim, 0);
/* 1253 */     SudokuSolve.clearSolution();
/* 1254 */     drawSudoku(g2, "P");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/* 1260 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/* 1262 */     String st = solName;
/* 1263 */     int w = fm.stringWidth(st);
/* 1264 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/* 1265 */     loadSudoku(solName + ".sudoku");
/* 1266 */     setSizesAndOffsets(left, top, dim, dim, 0);
/* 1267 */     drawSudoku(g2, "S");
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/* 1271 */     Methods.havePuzzle = false;
/* 1272 */     Grid.clearGrid();
/* 1273 */     Grid.xSz = 9; Grid.ySz = 9; int i;
/* 1274 */     for (i = 0; i < 9; i++) {
/* 1275 */       Grid.mode[i][5] = 4; Grid.mode[i][2] = 4;
/* 1276 */     }  for (i = 0; i < 9; i++) {
/* 1277 */       Grid.mode[5][i] = (i == 2 || i == 5) ? 5 : 3; Grid.mode[2][i] = (i == 2 || i == 5) ? 5 : 3;
/*      */     } 
/*      */   }
/*      */   void updateGrid(MouseEvent e) {
/* 1281 */     int x = e.getX(), y = e.getY();
/* 1282 */     if (Def.building == 1)
/* 1283 */       return;  if (x < Grid.xOrg || y < Grid.yOrg)
/*      */       return; 
/* 1285 */     x = (x - Grid.xOrg) / Grid.xCell;
/* 1286 */     y = (y - Grid.yOrg) / Grid.yCell;
/* 1287 */     if (x >= Grid.xSz || y >= Grid.ySz)
/*      */       return; 
/* 1289 */     Grid.xCur = x;
/* 1290 */     Grid.yCur = y;
/* 1291 */     restoreFrame();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void updateStatus(int x, int y, int z) {
/* 1297 */     if (z == -1)
/* 1298 */       return;  int a = x / 3 * 3, b = y / 3 * 3;
/* 1299 */     for (int j = 0; j < 9; j++) {
/* 1300 */       Grid.status[x][y] = Grid.status[x][y] & invbit[j];
/* 1301 */       Grid.status[j][y] = Grid.status[j][y] & invbit[z];
/* 1302 */       Grid.status[x][j] = Grid.status[x][j] & invbit[z];
/* 1303 */       Grid.status[a + j % 3][b + j / 3] = Grid.status[a + j % 3][b + j / 3] & invbit[z];
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static void recalculateStatus() {
/*      */     int y;
/* 1310 */     for (y = 0; y < 9; y++) {
/* 1311 */       for (int x = 0; x < 9; x++)
/* 1312 */         Grid.status[x][y] = 1022; 
/*      */     } 
/* 1314 */     for (y = 0; y < 9; y++) {
/* 1315 */       for (int x = 0; x < 9; x++)
/* 1316 */         updateStatus(x, y, Grid.grid[x][y] - 1); 
/*      */     } 
/*      */   }
/*      */   static void setCand(int x, int y, int v, int c) {
/* 1320 */     candx[candIndex] = x;
/* 1321 */     candy[candIndex] = y;
/* 1322 */     candv[candIndex] = v;
/* 1323 */     candc[candIndex++] = c;
/*      */   }
/*      */   
/*      */   static int getStatus(int x, int y) {
/* 1327 */     if (Grid.grid[x][y] != 0) return 0; 
/* 1328 */     return Grid.status[x][y];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int singleCandidate() {
/* 1336 */     Boolean found = Boolean.valueOf(false), done = Boolean.valueOf(true);
/*      */     
/* 1338 */     for (int y = 0; y < 9; y++) {
/* 1339 */       for (int x = 0; x < 9; x++) {
/* 1340 */         if (Grid.grid[x][y] == 0) {
/* 1341 */           done = Boolean.valueOf(false);
/* 1342 */           if (candidates[Grid.status[x][y] / 2] == 1) {
/* 1343 */             found = Boolean.valueOf(true);
/* 1344 */             for (int i = 0; i < 9; i++) {
/* 1345 */               if ((getStatus(x, y) & bit[i]) != 0)
/* 1346 */               { Grid.hintWord[0] = "" + (i + 1);
/* 1347 */                 Grid.hintWrdCnt = 1;
/* 1348 */                 Grid.hintTitle = "Single Candidate";
/* 1349 */                 if (Grid.findHint.booleanValue()) {
/* 1350 */                   hintXb[0] = x;
/* 1351 */                   hintYb[0] = y;
/* 1352 */                   hintIndexb = 1;
/* 1353 */                   setCand(x, y, i, 0);
/* 1354 */                   hintNum = 1;
/* 1355 */                   return 1;
/*      */                 } 
/* 1357 */                 Grid.grid[x][y] = i + 1;
/* 1358 */                 updateStatus(x, y, i); break; } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1363 */     }  return done.booleanValue() ? 2 : (found.booleanValue() ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Boolean singlePosition() {
/* 1369 */     int[] count = new int[9];
/* 1370 */     Boolean ret = Boolean.valueOf(false);
/*      */     
/*      */     int y;
/* 1373 */     for (y = 0; y < 9; y++) {
/* 1374 */       for (int j = 0; j < 9; count[j++] = 0); int m;
/* 1375 */       for (m = 0; m < 9; m++) {
/* 1376 */         if (Grid.grid[m][y] == 0)
/* 1377 */           for (int n = 0; n < 9; n++)
/* 1378 */           { if ((getStatus(m, y) & bit[n]) != 0)
/* 1379 */               count[n] = count[n] + 1;  }  
/* 1380 */       }  for (int i = 0; i < 9; i++) {
/* 1381 */         if (count[i] == 1)
/* 1382 */           for (m = 0; m < 9; m++) {
/* 1383 */             if ((getStatus(m, y) & bit[i]) != 0 && Grid.grid[m][y] == 0) {
/* 1384 */               if (Grid.findHint.booleanValue()) {
/* 1385 */                 hintXb[0] = m; hintYb[0] = y; hintIndexb = 1;
/* 1386 */                 setCand(m, y, i, 0);
/* 1387 */                 hintNum = 2;
/* 1388 */                 Grid.hintWord[0] = "" + (i + 1);
/* 1389 */                 Grid.hintWord[1] = "row";
/* 1390 */                 Grid.hintWrdCnt = 2;
/* 1391 */                 Grid.hintTitle = "Single position";
/* 1392 */                 return Boolean.valueOf(true);
/*      */               } 
/* 1394 */               Grid.grid[m][y] = i + 1;
/* 1395 */               updateStatus(m, y, i);
/* 1396 */               ret = Boolean.valueOf(true);
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     }  int x;
/* 1401 */     for (x = 0; x < 9; x++) {
/* 1402 */       for (int j = 0; j < 9; count[j++] = 0);
/* 1403 */       for (y = 0; y < 9; y++) {
/* 1404 */         if (Grid.grid[x][y] == 0)
/* 1405 */           for (int m = 0; m < 9; m++)
/* 1406 */           { if ((getStatus(x, y) & bit[m]) != 0)
/* 1407 */               count[m] = count[m] + 1;  }  
/* 1408 */       }  for (int i = 0; i < 9; i++) {
/* 1409 */         if (count[i] == 1)
/* 1410 */           for (y = 0; y < 9; y++) {
/* 1411 */             if ((getStatus(x, y) & bit[i]) != 0 && Grid.grid[x][y] == 0) {
/* 1412 */               if (Grid.findHint.booleanValue()) {
/* 1413 */                 hintXb[0] = x;
/* 1414 */                 hintYb[0] = y;
/* 1415 */                 hintIndexb = 1;
/* 1416 */                 setCand(x, y, i, 0);
/* 1417 */                 hintNum = 2;
/* 1418 */                 Grid.hintWord[0] = "" + (i + 1);
/* 1419 */                 Grid.hintWord[1] = "column";
/* 1420 */                 Grid.hintWrdCnt = 2;
/* 1421 */                 Grid.hintTitle = "Single position";
/* 1422 */                 return Boolean.valueOf(true);
/*      */               } 
/* 1424 */               Grid.grid[x][y] = i + 1;
/* 1425 */               updateStatus(x, y, i);
/* 1426 */               ret = Boolean.valueOf(true);
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     } 
/* 1431 */     for (int k = 0; k < 9; k++) {
/* 1432 */       int a = k % 3 * 3, b = k / 3 * 3; int j;
/* 1433 */       for (j = 0; j < 9; count[j++] = 0); int i;
/* 1434 */       for (i = 0; i < 3; i++) {
/* 1435 */         for (j = 0; j < 3; j++) {
/* 1436 */           x = a + i; y = b + j;
/* 1437 */           if (Grid.grid[x][y] == 0)
/* 1438 */             for (int m = 0; m < 9; m++)
/* 1439 */             { if ((getStatus(x, y) & bit[m]) != 0)
/* 1440 */                 count[m] = count[m] + 1;  }  
/*      */         } 
/* 1442 */       }  for (int c = 0; c < 9; c++) {
/* 1443 */         if (count[c] == 1)
/* 1444 */           for (i = 0; i < 3; i++) {
/* 1445 */             for (j = 0; j < 3; j++) {
/* 1446 */               x = a + i; y = b + j;
/* 1447 */               if ((getStatus(x, y) & bit[c]) != 0 && Grid.grid[x][y] == 0) {
/* 1448 */                 if (Grid.findHint.booleanValue()) {
/* 1449 */                   hintXb[0] = x;
/* 1450 */                   hintYb[0] = y;
/* 1451 */                   hintIndexb = 1;
/* 1452 */                   setCand(x, y, c, 0);
/* 1453 */                   hintNum = 2;
/* 1454 */                   Grid.hintWord[0] = "" + (c + 1);
/* 1455 */                   Grid.hintWord[1] = "box";
/* 1456 */                   Grid.hintWrdCnt = 2;
/* 1457 */                   Grid.hintTitle = "Single position";
/* 1458 */                   return Boolean.valueOf(true);
/*      */                 } 
/* 1460 */                 Grid.grid[x][y] = c + 1;
/* 1461 */                 updateStatus(x, y, c);
/* 1462 */                 ret = Boolean.valueOf(true);
/*      */               } 
/*      */             } 
/*      */           }  
/*      */       } 
/* 1467 */     }  return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean nakedSets(int from, int to) {
/* 1473 */     int[] guideMask = new int[126], guideMaskHits = new int[126];
/* 1474 */     Boolean ret = Boolean.valueOf(false);
/* 1475 */     String str = "";
/* 1476 */     String[] title = { "Naked Pair", "Naked Triple", "Naked Quad" };
/*      */     
/* 1478 */     for (int mode = from; mode < to + 1; mode++) {
/* 1479 */       int span; if (mode == 2)
/* 1480 */       { span = 36; int i;
/* 1481 */         for (int m = 0; i < 512; i *= 2) {
/* 1482 */           int j; for (j = i * 2; j < 1024; j *= 2)
/* 1483 */             guideMask[m++] = i | j; 
/*      */         }  }
/* 1485 */       else if (mode == 3)
/* 1486 */       { span = 84; int i;
/* 1487 */         for (int m = 0; i < 256; i *= 2) {
/* 1488 */           int j; for (j = i * 2; j < 512; j *= 2) {
/* 1489 */             int k; for (k = j * 2; k < 1024; k *= 2)
/* 1490 */               guideMask[m++] = i | j | k; 
/*      */           } 
/*      */         }  }
/* 1493 */       else { span = 126; int i;
/* 1494 */         for (int m = 0; i < 128; i *= 2) {
/* 1495 */           int j; for (j = i * 2; j < 256; j *= 2) {
/* 1496 */             int k; for (k = j * 2; k < 512; k *= 2) {
/* 1497 */               int l; for (l = k * 2; l < 1024; l *= 2)
/* 1498 */                 guideMask[m++] = i | j | k | l; 
/*      */             } 
/*      */           } 
/*      */         }  }
/* 1502 */        int y; for (y = 0; y < 9; y++) {
/* 1503 */         for (int j = 0; j < 126; guideMaskHits[j++] = 0); int i;
/* 1504 */         for (i = 0; i < 9; i++) {
/* 1505 */           for (byte b1 = 0; b1 < span; b1++)
/* 1506 */           { if (getStatus(i, y) != 0 && (
/* 1507 */               getStatus(i, y) | guideMask[b1]) == guideMask[b1])
/* 1508 */               guideMaskHits[b1] = guideMaskHits[b1] + 1;  } 
/* 1509 */         }  for (byte b = 0; b < span; b++) {
/* 1510 */           if (guideMaskHits[b] == mode) {
/* 1511 */             for (i = 0; i < 9; i++) {
/* 1512 */               if ((getStatus(i, y) & guideMask[b]) != 0 && (
/* 1513 */                 getStatus(i, y) | guideMask[b]) != guideMask[b]) {
/* 1514 */                 if (!Grid.findHint.booleanValue())
/* 1515 */                   Grid.status[i][y] = Grid.status[i][y] & (guideMask[b] ^ 0x3FE); 
/* 1516 */                 ret = Boolean.valueOf(true);
/*      */               } 
/* 1518 */             }  if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */               
/* 1520 */               for (i = 0; i < 9; i++) {
/* 1521 */                 if (getStatus(i, y) != 0 && (getStatus(i, y) | guideMask[b]) == guideMask[b])
/* 1522 */                 { hintXb[hintIndexb] = i;
/* 1523 */                   hintYb[hintIndexb++] = y;
/* 1524 */                   hintNum = 3; }
/*      */                 else
/*      */                 { byte b1; int l;
/* 1527 */                   for (l = 1, b1 = 0; b1 < 10; b1++, l *= 2)
/* 1528 */                   { if ((guideMask[b] & l) == l && (getStatus(i, y) & l) == l)
/* 1529 */                       setCand(i, y, b1 - 1, 1);  }  } 
/* 1530 */               }  int k; int c; for (k = 1, c = 2; c < 1024; c *= 2, k++) {
/* 1531 */                 if ((guideMask[b] & c) != 0)
/* 1532 */                   str = str + k + ", "; 
/* 1533 */               }  str = str.substring(0, str.length() - 2);
/* 1534 */               k = str.lastIndexOf(',');
/* 1535 */               str = str.substring(0, k) + " and " + str.charAt(k + 2);
/* 1536 */               Grid.hintWord[2] = str; Grid.hintWord[0] = str;
/* 1537 */               Grid.hintWord[1] = "row";
/* 1538 */               Grid.hintWrdCnt = 3;
/* 1539 */               Grid.hintTitle = title[mode - 2];
/* 1540 */               return true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*      */       int x;
/* 1547 */       for (x = 0; x < 9; x++) {
/* 1548 */         for (int j = 0; j < 126; guideMaskHits[j++] = 0);
/* 1549 */         for (y = 0; y < 9; y++) {
/* 1550 */           for (byte b1 = 0; b1 < span; b1++)
/* 1551 */           { if (getStatus(x, y) != 0 && (
/* 1552 */               getStatus(x, y) | guideMask[b1]) == guideMask[b1])
/* 1553 */               guideMaskHits[b1] = guideMaskHits[b1] + 1;  } 
/* 1554 */         }  for (byte b = 0; b < span; b++) {
/* 1555 */           if (guideMaskHits[b] == mode) {
/* 1556 */             for (y = 0; y < 9; y++) {
/* 1557 */               if ((getStatus(x, y) & guideMask[b]) != 0 && (
/* 1558 */                 getStatus(x, y) | guideMask[b]) != guideMask[b]) {
/* 1559 */                 if (!Grid.findHint.booleanValue())
/* 1560 */                   Grid.status[x][y] = Grid.status[x][y] & (guideMask[b] ^ 0x3FE); 
/* 1561 */                 ret = Boolean.valueOf(true);
/*      */               } 
/* 1563 */             }  if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */               
/* 1565 */               for (y = 0; y < 9; y++) {
/* 1566 */                 if (getStatus(x, y) != 0 && (getStatus(x, y) | guideMask[b]) == guideMask[b])
/* 1567 */                 { hintXb[hintIndexb] = x;
/* 1568 */                   hintYb[hintIndexb++] = y;
/* 1569 */                   hintNum = 3; }
/*      */                 else
/*      */                 { byte b1; int l;
/* 1572 */                   for (l = 1, b1 = 0; b1 < 10; b1++, l *= 2)
/* 1573 */                   { if ((guideMask[b] & l) == l && (getStatus(x, y) & l) == l)
/* 1574 */                       setCand(x, y, b1 - 1, 1);  }  } 
/* 1575 */               }  int i; int c; for (i = 1, c = 2; c < 1024; c *= 2, i++) {
/* 1576 */                 if ((guideMask[b] & c) != 0)
/* 1577 */                   str = str + i + ", "; 
/* 1578 */               }  str = str.substring(0, str.length() - 2);
/* 1579 */               i = str.lastIndexOf(',');
/* 1580 */               str = str.substring(0, i) + " and " + str.charAt(i + 2);
/* 1581 */               Grid.hintWord[2] = str; Grid.hintWord[0] = str;
/* 1582 */               Grid.hintWord[1] = "column";
/* 1583 */               Grid.hintWrdCnt = 3;
/* 1584 */               Grid.hintTitle = title[mode - 2];
/* 1585 */               return true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1592 */       for (int a = 0; a < 9; a++) {
/* 1593 */         x = a % 3 * 3; y = a / 3 * 3;
/* 1594 */         for (int j = 0; j < 126; guideMaskHits[j++] = 0); int b;
/* 1595 */         for (b = 0; b < 9; b++) {
/* 1596 */           int c = x + b % 3, d = y + b / 3;
/* 1597 */           for (byte b2 = 0; b2 < span; b2++) {
/* 1598 */             if (getStatus(c, d) != 0 && (
/* 1599 */               getStatus(c, d) | guideMask[b2]) == guideMask[b2])
/* 1600 */               guideMaskHits[b2] = guideMaskHits[b2] + 1; 
/*      */           } 
/* 1602 */         }  for (byte b1 = 0; b1 < span; b1++) {
/* 1603 */           if (guideMaskHits[b1] == mode)
/* 1604 */             for (b = 0; b < 9; b++) {
/* 1605 */               int c = x + b % 3, d = y + b / 3;
/* 1606 */               if ((getStatus(c, d) & guideMask[b1]) != 0 && (
/* 1607 */                 getStatus(c, d) | guideMask[b1]) != guideMask[b1]) {
/* 1608 */                 if (!Grid.findHint.booleanValue())
/* 1609 */                   Grid.status[c][d] = Grid.status[c][d] & (guideMask[b1] ^ 0x3FE); 
/* 1610 */                 ret = Boolean.valueOf(true);
/*      */               } 
/*      */             }  
/* 1613 */           if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */             
/* 1615 */             for (b = 0; b < 9; b++) {
/* 1616 */               int i = x + b % 3, d = y + b / 3;
/* 1617 */               if (getStatus(i, d) != 0 && (getStatus(i, d) | guideMask[b1]) == guideMask[b1]) {
/* 1618 */                 hintXb[hintIndexb] = i;
/* 1619 */                 hintYb[hintIndexb++] = d;
/* 1620 */                 hintNum = 3;
/*      */               } else {
/*      */                 byte b2; int l;
/* 1623 */                 for (l = 1, b2 = 0; b2 < 10; b2++, l *= 2)
/* 1624 */                 { if ((guideMask[b1] & l) == l && (getStatus(i, d) & l) == l)
/* 1625 */                     setCand(i, d, b2 - 1, 1);  } 
/*      */               } 
/* 1627 */             }  int c; for (a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 1628 */               if ((guideMask[b1] & c) != 0)
/* 1629 */                 str = str + a + ", "; 
/* 1630 */             }  str = str.substring(0, str.length() - 2);
/* 1631 */             a = str.lastIndexOf(',');
/* 1632 */             str = str.substring(0, a) + " and " + str.charAt(a + 2);
/* 1633 */             Grid.hintWord[2] = str; Grid.hintWord[0] = str;
/* 1634 */             Grid.hintWord[1] = "box";
/* 1635 */             Grid.hintWrdCnt = 3;
/* 1636 */             Grid.hintTitle = title[mode - 2];
/* 1637 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1642 */     return ret.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Boolean unitIntersection() {
/* 1649 */     int accum2 = 0;
/* 1650 */     Boolean ret = Boolean.valueOf(false);
/* 1651 */     String str = "";
/*      */     
/*      */     int y;
/* 1654 */     for (y = 0; y < 9; y++) {
/* 1655 */       for (int x = 0; x < 9; x += 3) {
/* 1656 */         int accum = getStatus(x, y) | getStatus(x + 1, y) | getStatus(x + 2, y); int c;
/* 1657 */         for (c = 0; c < 9; c++) {
/* 1658 */           if (c / 3 != x / 3)
/* 1659 */             accum &= getStatus(c, y) ^ 0x3FE; 
/* 1660 */         }  if (accum != 0) {
/* 1661 */           int xStart = x, yStart = y - y % 3;
/* 1662 */           for (int j = 0; j < 3; j++) {
/* 1663 */             for (int i = 0; i < 3; i++) {
/* 1664 */               int a = xStart + i, b = yStart + j;
/* 1665 */               if (b != y && 
/* 1666 */                 Grid.grid[a][b] == 0 && (getStatus(a, b) & accum) != 0) {
/* 1667 */                 if (!Grid.findHint.booleanValue()) {
/* 1668 */                   Grid.status[a][b] = Grid.status[a][b] & (accum ^ 0x3FE);
/*      */                 } else {
/* 1670 */                   int k; int l; for (l = 1, k = 0; k < 10; k++, l *= 2)
/* 1671 */                   { if ((accum & l) == l && (getStatus(a, b) & l) == l)
/* 1672 */                       setCand(a, b, k - 1, 1);  } 
/* 1673 */                 }  ret = Boolean.valueOf(true);
/*      */               } 
/*      */             } 
/*      */           } 
/* 1677 */         }  if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */           
/* 1679 */           for (int j = 0; j < 3; j++) {
/* 1680 */             if ((getStatus(x + j, y) & accum) != 0) {
/* 1681 */               hintXb[hintIndexb] = x + j;
/* 1682 */               hintYb[hintIndexb] = y;
/* 1683 */               hintIndexb++;
/* 1684 */               hintNum = 4;
/* 1685 */               for (int i = 1; c < 1024; c *= 2, i++)
/* 1686 */               { if ((accum & c) != 0)
/* 1687 */                   accum2 |= c;  } 
/*      */             } 
/* 1689 */           }  Grid.hintWord[5] = "row"; Grid.hintWord[3] = "row"; Grid.hintWord[0] = "row";
/* 1690 */           Grid.hintWord[9] = "box"; Grid.hintWord[7] = "box"; Grid.hintWord[1] = "box";
/* 1691 */           Grid.hintWrdCnt = 10;
/* 1692 */           for (int a = 1; c < 1024; c *= 2, a++) {
/* 1693 */             if ((accum2 & c) != 0)
/* 1694 */               str = str + a + "s and "; 
/* 1695 */           }  str = str.substring(0, str.length() - 5);
/* 1696 */           Grid.hintWord[8] = str; Grid.hintWord[6] = str; Grid.hintWord[4] = str; Grid.hintWord[2] = str;
/* 1697 */           Grid.hintTitle = "Unit Intersection";
/* 1698 */           return Boolean.valueOf(true);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1703 */     for (y = 0; y < 9; y += 3) {
/* 1704 */       for (int x = 0; x < 9; x++) {
/* 1705 */         int accum = getStatus(x, y) | getStatus(x, y + 1) | getStatus(x, y + 2); int c;
/* 1706 */         for (c = 0; c < 9; c++) {
/* 1707 */           if (c / 3 != y / 3)
/* 1708 */             accum &= getStatus(x, c) ^ 0x3FE; 
/* 1709 */         }  if (accum != 0) {
/* 1710 */           int xStart = x - x % 3, yStart = y;
/* 1711 */           for (int j = 0; j < 3; j++) {
/* 1712 */             for (int i = 0; i < 3; i++) {
/* 1713 */               int a = xStart + i, b = yStart + j;
/* 1714 */               if (a != x && 
/* 1715 */                 Grid.grid[a][b] == 0 && (getStatus(a, b) & accum) != 0) {
/* 1716 */                 if (!Grid.findHint.booleanValue()) {
/* 1717 */                   Grid.status[a][b] = Grid.status[a][b] & (accum ^ 0x3FE);
/*      */                 } else {
/* 1719 */                   int k; int l; for (l = 1, k = 0; k < 10; k++, l *= 2)
/* 1720 */                   { if ((accum & l) == l && (getStatus(a, b) & l) == l)
/* 1721 */                       setCand(a, b, k - 1, 1);  } 
/* 1722 */                 }  ret = Boolean.valueOf(true);
/*      */               } 
/*      */             } 
/*      */           } 
/* 1726 */         }  if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */           
/* 1728 */           for (int j = 0; j < 3; j++) {
/* 1729 */             if ((getStatus(x, y + j) & accum) != 0) {
/* 1730 */               hintXb[hintIndexb] = x;
/* 1731 */               hintYb[hintIndexb] = y + j;
/* 1732 */               hintIndexb++;
/* 1733 */               hintNum = 4;
/* 1734 */               for (int i = 1; c < 1024; c *= 2, i++)
/* 1735 */               { if ((accum & c) != 0)
/* 1736 */                   accum2 |= c;  } 
/*      */             } 
/* 1738 */           }  Grid.hintWord[5] = "column"; Grid.hintWord[3] = "column"; Grid.hintWord[0] = "column";
/* 1739 */           Grid.hintWord[9] = "box"; Grid.hintWord[7] = "box"; Grid.hintWord[1] = "box";
/* 1740 */           Grid.hintWrdCnt = 10;
/* 1741 */           for (int a = 1; c < 1024; c *= 2, a++) {
/* 1742 */             if ((accum2 & c) != 0)
/* 1743 */               str = str + a + "s and "; 
/* 1744 */           }  str = str.substring(0, str.length() - 5);
/* 1745 */           Grid.hintWord[8] = str; Grid.hintWord[6] = str; Grid.hintWord[4] = str; Grid.hintWord[2] = str;
/* 1746 */           Grid.hintTitle = "Unit Intersection";
/* 1747 */           return Boolean.valueOf(true);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1753 */     for (y = 0; y < 9; y++) {
/* 1754 */       for (int x = 0; x < 9; x += 3) {
/* 1755 */         int i, accum; for (accum = 0, i = x; i < x + 3; i++) {
/* 1756 */           if (Grid.grid[i][y] == 0)
/* 1757 */             accum |= getStatus(i, y); 
/* 1758 */         }  accum = getStatus(x, y) | getStatus(x + 1, y) | getStatus(x + 2, y);
/* 1759 */         int xStart = x, yStart = y - y % 3; int j;
/* 1760 */         for (j = 0; j < 3; j++) {
/* 1761 */           for (i = 0; i < 3; i++) {
/* 1762 */             int a = xStart + i, b = yStart + j;
/* 1763 */             if (b != y)
/* 1764 */               accum &= getStatus(a, b) ^ 0x3FE; 
/*      */           } 
/* 1766 */         }  if (accum != 0)
/* 1767 */           for (int c = 0; c < 9; c++) {
/* 1768 */             if (c / 3 != x / 3 && 
/* 1769 */               Grid.grid[c][y] == 0 && (getStatus(c, y) & accum) != 0) {
/* 1770 */               if (!Grid.findHint.booleanValue()) {
/* 1771 */                 Grid.status[c][y] = Grid.status[c][y] & (accum ^ 0x3FE);
/*      */               } else {
/* 1773 */                 int k; int l; for (l = 1, k = 0; k < 10; k++, l *= 2)
/* 1774 */                 { if ((accum & l) == l && (getStatus(c, y) & l) == l)
/* 1775 */                     setCand(c, y, k - 1, 1);  } 
/* 1776 */               }  ret = Boolean.valueOf(true);
/*      */             } 
/*      */           }  
/* 1779 */         if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */           
/* 1781 */           for (j = 0; j < 3; j++) {
/* 1782 */             if ((getStatus(x + j, y) & accum) != 0) {
/* 1783 */               hintXb[hintIndexb] = x + j;
/* 1784 */               hintYb[hintIndexb] = y;
/* 1785 */               hintIndexb++;
/* 1786 */               hintNum = 4;
/* 1787 */               for (int k = 1, m = 2; m < 1024; m *= 2, k++)
/* 1788 */               { if ((accum & m) != 0)
/* 1789 */                   accum2 |= m;  } 
/*      */             } 
/* 1791 */           }  Grid.hintWord[5] = "box"; Grid.hintWord[3] = "box"; Grid.hintWord[0] = "box";
/* 1792 */           Grid.hintWord[9] = "row"; Grid.hintWord[7] = "row"; Grid.hintWord[1] = "row";
/* 1793 */           Grid.hintWrdCnt = 10;
/* 1794 */           for (int a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 1795 */             if ((accum2 & c) != 0)
/* 1796 */               str = str + a + "s and "; 
/* 1797 */           }  str = str.substring(0, str.length() - 5);
/* 1798 */           Grid.hintWord[8] = str; Grid.hintWord[6] = str; Grid.hintWord[4] = str; Grid.hintWord[2] = str;
/* 1799 */           Grid.hintTitle = "Unit Intersection";
/* 1800 */           return Boolean.valueOf(true);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1805 */     for (y = 0; y < 9; y += 3) {
/* 1806 */       for (int x = 0; x < 9; x++) {
/* 1807 */         int accum = getStatus(x, y) | getStatus(x, y + 1) | getStatus(x, y + 2);
/* 1808 */         int xStart = x - x % 3, yStart = y; int j;
/* 1809 */         for (j = 0; j < 3; j++) {
/* 1810 */           for (int i = 0; i < 3; i++) {
/* 1811 */             int a = xStart + i, b = yStart + j;
/* 1812 */             if (a != x)
/* 1813 */               accum &= getStatus(a, b) ^ 0x3FE; 
/*      */           } 
/* 1815 */         }  if (accum != 0)
/* 1816 */           for (int c = 0; c < 9; c++) {
/* 1817 */             if (c / 3 != y / 3 && 
/* 1818 */               Grid.grid[x][c] == 0 && (getStatus(x, c) & accum) != 0) {
/* 1819 */               if (!Grid.findHint.booleanValue()) {
/* 1820 */                 Grid.status[x][c] = Grid.status[x][c] & (accum ^ 0x3FE);
/*      */               } else {
/* 1822 */                 int k; int l; for (l = 1, k = 0; k < 10; k++, l *= 2)
/* 1823 */                 { if ((accum & l) == l && (getStatus(x, c) & l) == l)
/* 1824 */                     setCand(x, c, k - 1, 1);  } 
/* 1825 */               }  ret = Boolean.valueOf(true);
/*      */             } 
/*      */           }  
/* 1828 */         if (Grid.findHint.booleanValue() && ret.booleanValue()) {
/*      */           
/* 1830 */           for (j = 0; j < 3; j++) {
/* 1831 */             if ((getStatus(x, y + j) & accum) != 0) {
/* 1832 */               hintXb[hintIndexb] = x;
/* 1833 */               hintYb[hintIndexb] = y + j;
/* 1834 */               hintIndexb++;
/* 1835 */               hintNum = 4;
/* 1836 */               for (int i = 1, k = 2; k < 1024; k *= 2, i++)
/* 1837 */               { if ((accum & k) != 0)
/* 1838 */                   accum2 |= k;  } 
/*      */             } 
/* 1840 */           }  Grid.hintWord[5] = "box"; Grid.hintWord[3] = "box"; Grid.hintWord[0] = "box";
/* 1841 */           Grid.hintWord[9] = "column"; Grid.hintWord[7] = "column"; Grid.hintWord[1] = "column";
/* 1842 */           Grid.hintWrdCnt = 10;
/* 1843 */           for (int a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 1844 */             if ((accum2 & c) != 0)
/* 1845 */               str = str + a + "s and "; 
/* 1846 */           }  str = str.substring(0, str.length() - 5);
/* 1847 */           Grid.hintWord[8] = str; Grid.hintWord[6] = str; Grid.hintWord[4] = str; Grid.hintWord[2] = str;
/* 1848 */           Grid.hintTitle = "Unit Intersection";
/* 1849 */           return Boolean.valueOf(true);
/*      */         } 
/*      */       } 
/* 1852 */     }  return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Boolean hiddenSets(int from, int to) {
/* 1859 */     int[] guideMask = new int[126];
/* 1860 */     Boolean found = Boolean.valueOf(false), ret = Boolean.valueOf(false);
/* 1861 */     String str = "";
/* 1862 */     String[] title = { "Hidden Pair", "Hidden Triple", "Hidden Quad" };
/*      */     
/* 1864 */     for (int mode = from; mode < to + 1; mode++) {
/* 1865 */       int span; if (mode == 2)
/* 1866 */       { span = 36; int i;
/* 1867 */         for (int m = 0; i < 512; i *= 2) {
/* 1868 */           int j; for (j = i * 2; j < 1024; j *= 2)
/* 1869 */             guideMask[m++] = i | j; 
/*      */         }  }
/* 1871 */       else if (mode == 3)
/* 1872 */       { span = 84; int i;
/* 1873 */         for (int m = 0; i < 256; i *= 2) {
/* 1874 */           int j; for (j = i * 2; j < 512; j *= 2) {
/* 1875 */             int k; for (k = j * 2; k < 1024; k *= 2)
/* 1876 */               guideMask[m++] = i | j | k; 
/*      */           } 
/*      */         }  }
/* 1879 */       else { span = 126; int i;
/* 1880 */         for (int m = 0; i < 128; i *= 2) {
/* 1881 */           int j; for (j = i * 2; j < 256; j *= 2) {
/* 1882 */             int k; for (k = j * 2; k < 512; k *= 2) {
/* 1883 */               int l; for (l = k * 2; l < 1024; l *= 2)
/* 1884 */                 guideMask[m++] = i | j | k | l; 
/*      */             } 
/*      */           } 
/*      */         }  }
/* 1888 */        int y; for (y = 0; y < 9; y++) {
/* 1889 */         int i; int theMask; for (theMask = i = 0; i < 9; i++)
/* 1890 */           theMask |= getStatus(i, y); 
/* 1891 */         for (byte b = 0; b < span; b++) {
/* 1892 */           if ((theMask & guideMask[b]) == guideMask[b]) {
/* 1893 */             int hits; int validHits; for (validHits = hits = i = 0; i < 9; i++) {
/* 1894 */               if ((getStatus(i, y) & guideMask[b]) != 0) {
/* 1895 */                 hits++;
/* 1896 */                 if ((getStatus(i, y) & guideMask[b] ^ getStatus(i, y)) > 0)
/* 1897 */                   validHits++; 
/*      */               } 
/* 1899 */             }  if (hits == mode && validHits > 0)
/* 1900 */               for (i = 0; i < 9; i++) {
/* 1901 */                 if ((getStatus(i, y) & guideMask[b]) != 0)
/* 1902 */                   if (!Grid.findHint.booleanValue()) {
/* 1903 */                     Grid.status[i][y] = Grid.status[i][y] & guideMask[b];
/* 1904 */                     ret = Boolean.valueOf(true);
/*      */                   } else {
/*      */                     
/* 1907 */                     hintXb[hintIndexb] = i;
/* 1908 */                     hintYb[hintIndexb] = y;
/* 1909 */                     hintIndexb++; int k, l;
/* 1910 */                     for (l = 1, k = 0; k < 10; k++, l *= 2) {
/* 1911 */                       if ((guideMask[b] & l) != l && (getStatus(i, y) & l) == l)
/* 1912 */                         setCand(i, y, k - 1, 1); 
/* 1913 */                     }  found = Boolean.valueOf(true);
/* 1914 */                     hintNum = 5;
/*      */                   }  
/*      */               }  
/* 1917 */             if (found.booleanValue()) {
/* 1918 */               int a; int j; for (a = 1, j = 2; j < 1024; j *= 2, a++) {
/* 1919 */                 if ((guideMask[b] & j) != 0)
/* 1920 */                   str = str + a + ", "; 
/* 1921 */               }  str = str.substring(0, str.length() - 2);
/* 1922 */               a = str.lastIndexOf(',');
/* 1923 */               str = str.substring(0, a) + " and " + str.charAt(a + 2);
/* 1924 */               Grid.hintWord[0] = str;
/* 1925 */               Grid.hintWord[1] = "row";
/* 1926 */               Grid.hintWrdCnt = 2;
/* 1927 */               Grid.hintTitle = title[mode - 2];
/* 1928 */               return Boolean.valueOf(true);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       int x;
/* 1934 */       for (x = 0; x < 9; x++) {
/* 1935 */         int theMask; for (theMask = y = 0; y < 9; y++)
/* 1936 */           theMask |= getStatus(x, y); 
/* 1937 */         for (byte b = 0; b < span; b++) {
/* 1938 */           if ((theMask & guideMask[b]) == guideMask[b]) {
/* 1939 */             int hits; int validHits; for (validHits = hits = y = 0; y < 9; y++) {
/* 1940 */               if ((getStatus(x, y) & guideMask[b]) != 0) {
/* 1941 */                 hits++;
/* 1942 */                 if ((getStatus(x, y) & guideMask[b] ^ getStatus(x, y)) > 0)
/* 1943 */                   validHits++; 
/*      */               } 
/* 1945 */             }  if (hits == mode && validHits > 0)
/* 1946 */               for (y = 0; y < 9; y++) {
/* 1947 */                 if ((getStatus(x, y) & guideMask[b]) != 0)
/* 1948 */                   if (!Grid.findHint.booleanValue()) {
/* 1949 */                     Grid.status[x][y] = Grid.status[x][y] & guideMask[b];
/* 1950 */                     ret = Boolean.valueOf(true);
/*      */                   } else {
/*      */                     
/* 1953 */                     hintXb[hintIndexb] = x;
/* 1954 */                     hintYb[hintIndexb] = y;
/* 1955 */                     hintIndexb++; int k, l;
/* 1956 */                     for (l = 1, k = 0; k < 10; k++, l *= 2) {
/* 1957 */                       if ((guideMask[b] & l) != l && (getStatus(x, y) & l) == l)
/* 1958 */                         setCand(x, y, k - 1, 1); 
/* 1959 */                     }  found = Boolean.valueOf(true);
/* 1960 */                     hintNum = 5;
/*      */                   }  
/*      */               }  
/* 1963 */             if (found.booleanValue()) {
/* 1964 */               int a; int i; for (a = 1, i = 2; i < 1024; i *= 2, a++) {
/* 1965 */                 if ((guideMask[b] & i) != 0)
/* 1966 */                   str = str + a + ", "; 
/* 1967 */               }  str = str.substring(0, str.length() - 2);
/* 1968 */               a = str.lastIndexOf(',');
/* 1969 */               str = str.substring(0, a) + " and " + str.charAt(a + 2);
/* 1970 */               Grid.hintWord[0] = str;
/* 1971 */               Grid.hintWord[1] = "column";
/* 1972 */               Grid.hintWrdCnt = 2;
/* 1973 */               Grid.hintTitle = title[mode - 2];
/* 1974 */               return Boolean.valueOf(true);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1980 */       for (int c = 0; c < 9; c++) {
/* 1981 */         int a = c % 3 * 3, b = c / 3 * 3; int theMask;
/* 1982 */         for (theMask = y = 0; y < 3; y++) {
/* 1983 */           for (x = 0; x < 3; x++)
/* 1984 */             theMask |= getStatus(a + x, b + y); 
/* 1985 */         }  for (byte b1 = 0; b1 < span; b1++) {
/* 1986 */           if ((theMask & guideMask[b1]) == guideMask[b1]) {
/* 1987 */             int hits; int validHits; for (validHits = hits = y = 0; y < 3; y++) {
/* 1988 */               for (x = 0; x < 3; x++) {
/* 1989 */                 if ((getStatus(a + x, b + y) & guideMask[b1]) != 0)
/* 1990 */                 { hits++;
/* 1991 */                   if ((getStatus(a + x, b + y) & guideMask[b1] ^ getStatus(a + x, b + y)) > 0)
/* 1992 */                     validHits++;  } 
/*      */               } 
/* 1994 */             }  if (hits == mode && validHits > 0)
/* 1995 */               for (y = 0; y < 3; y++) {
/* 1996 */                 for (x = 0; x < 3; x++) {
/* 1997 */                   if ((getStatus(a + x, b + y) & guideMask[b1]) != 0)
/* 1998 */                     if (!Grid.findHint.booleanValue()) {
/* 1999 */                       Grid.status[a + x][b + y] = Grid.status[a + x][b + y] & guideMask[b1];
/* 2000 */                       ret = Boolean.valueOf(true);
/*      */                     } else {
/*      */                       
/* 2003 */                       hintXb[hintIndexb] = a + x;
/* 2004 */                       hintYb[hintIndexb] = b + y;
/* 2005 */                       hintIndexb++; int k, l;
/* 2006 */                       for (l = 1, k = 0; k < 10; k++, l *= 2) {
/* 2007 */                         if ((guideMask[b1] & l) != l && (getStatus(a + x, b + y) & l) == l)
/* 2008 */                           setCand(a + x, b + y, k - 1, 1); 
/* 2009 */                       }  found = Boolean.valueOf(true);
/* 2010 */                       hintNum = 5;
/*      */                     }  
/*      */                 } 
/* 2013 */               }   if (found.booleanValue()) {
/* 2014 */               for (a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 2015 */                 if ((guideMask[b1] & c) != 0)
/* 2016 */                   str = str + a + ", "; 
/* 2017 */               }  str = str.substring(0, str.length() - 2);
/* 2018 */               a = str.lastIndexOf(',');
/* 2019 */               str = str.substring(0, a) + " and " + str.charAt(a + 2);
/* 2020 */               Grid.hintWord[0] = str;
/* 2021 */               Grid.hintWord[1] = "box";
/* 2022 */               Grid.hintWrdCnt = 2;
/* 2023 */               Grid.hintTitle = title[mode - 2];
/* 2024 */               return Boolean.valueOf(true);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2029 */     }  return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   static Boolean xWing(int order) {
/* 2034 */     int[] theBit = { 1, 2, 4, 8, 16, 32, 64, 128, 256 };
/* 2035 */     Boolean found = Boolean.valueOf(false);
/*      */     
/*      */     int y;
/* 2038 */     for (y = 0; y < 9; y++) {
/* 2039 */       for (int x = 0; x < 9; x++)
/* 2040 */         Grid.sig[x][y] = 0; 
/*      */     } 
/* 2042 */     for (y = 0; y < 9; y++) {
/* 2043 */       for (int x = 0; x < 9; x++) {
/* 2044 */         for (int i = 0; i < 9; i++)
/* 2045 */         { if ((getStatus(x, y) & bit[i]) != 0)
/* 2046 */             Grid.sig[i][y] = Grid.sig[i][y] | theBit[x];  } 
/*      */       } 
/* 2048 */     }  int n; for (hintIndexb = n = 0; n < 9; n++) {
/* 2049 */       for (int a = 0; a < 9; a++) {
/* 2050 */         if (Grid.sig[n][a] != 0) {
/* 2051 */           int accumA = Grid.sig[n][a];
/* 2052 */           for (int b = a + 1; b < 9; b++) {
/* 2053 */             if (Grid.sig[n][b] != 0) {
/* 2054 */               int accumB = accumA | Grid.sig[n][b];
/* 2055 */               if (order == 2) {
/* 2056 */                 if (candidates[accumB] == 2) {
/*      */                   
/* 2058 */                   for (int x = 0; x < 9; x++) {
/* 2059 */                     if ((accumB & theBit[x]) > 0) {
/* 2060 */                       hintXb[hintIndexb] = x; hintYb[hintIndexb++] = a;
/* 2061 */                       hintXb[hintIndexb] = x; hintYb[hintIndexb++] = b;
/*      */                     } 
/*      */                   } 
/* 2064 */                   for (y = 0; y < 9; y++) {
/* 2065 */                     if (y != a && y != b && ((
/* 2066 */                       getStatus(hintXb[0], y) & bit[n]) > 0 || (
/* 2067 */                       getStatus(hintXb[2], y) & bit[n]) > 0)) {
/*      */                       
/* 2069 */                       found = Boolean.valueOf(true);
/* 2070 */                       if (Grid.findHint.booleanValue()) {
/* 2071 */                         hintNum = 6;
/* 2072 */                         if ((getStatus(hintXb[0], y) & bit[n]) > 0) setCand(hintXb[0], y, n, 1); 
/* 2073 */                         if ((getStatus(hintXb[2], y) & bit[n]) > 0) setCand(hintXb[2], y, n, 1);
/*      */                       
/*      */                       } else {
/* 2076 */                         Grid.status[hintXb[0]][y] = Grid.status[hintXb[0]][y] & invbit[n];
/* 2077 */                         Grid.status[hintXb[2]][y] = Grid.status[hintXb[2]][y] & invbit[n];
/*      */                       } 
/*      */                     } 
/*      */                   } 
/* 2081 */                   if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2082 */                     Grid.hintWord[0] = "" + (n + 1);
/* 2083 */                     Grid.hintWord[1] = "rows"; Grid.hintWord[2] = "row";
/* 2084 */                     Grid.hintWord[3] = "column"; Grid.hintWord[4] = "column";
/* 2085 */                     Grid.hintWrdCnt = 5;
/* 2086 */                     Grid.hintTitle = "X-wing";
/* 2087 */                     return Boolean.valueOf(true);
/*      */                   } 
/* 2089 */                   hintIndexb = 0;
/* 2090 */                   if (found.booleanValue()) return Boolean.valueOf(true);
/*      */                 
/*      */                 } 
/*      */               } else {
/* 2094 */                 for (int c = b + 1; c < 9; c++) {
/* 2095 */                   if (Grid.sig[n][c] != 0) {
/* 2096 */                     int accumC = accumB | Grid.sig[n][c];
/* 2097 */                     if (order == 3)
/* 2098 */                     { if (countBits(accumC) == 3) {
/*      */                         
/* 2100 */                         for (int x = 0; x < 9; x++) {
/* 2101 */                           if ((accumC & theBit[x]) > 0) {
/* 2102 */                             hintXb[hintIndexb] = x; hintYb[hintIndexb++] = a;
/* 2103 */                             hintXb[hintIndexb] = x; hintYb[hintIndexb++] = b;
/* 2104 */                             hintXb[hintIndexb] = x; hintYb[hintIndexb++] = c;
/*      */                           } 
/*      */                         } 
/* 2107 */                         for (y = 0; y < 9; y++) {
/* 2108 */                           if (y != a && y != b && y != c && ((
/* 2109 */                             getStatus(hintXb[0], y) & bit[n]) > 0 || (
/* 2110 */                             getStatus(hintXb[3], y) & bit[n]) > 0 || (
/* 2111 */                             getStatus(hintXb[6], y) & bit[n]) > 0)) {
/*      */                             
/* 2113 */                             found = Boolean.valueOf(true);
/* 2114 */                             if (Grid.findHint.booleanValue()) {
/* 2115 */                               hintNum = 6;
/* 2116 */                               if ((getStatus(hintXb[0], y) & bit[n]) > 0) setCand(hintXb[0], y, n, 1); 
/* 2117 */                               if ((getStatus(hintXb[3], y) & bit[n]) > 0) setCand(hintXb[3], y, n, 1); 
/* 2118 */                               if ((getStatus(hintXb[6], y) & bit[n]) > 0) setCand(hintXb[6], y, n, 1);
/*      */                             
/*      */                             } else {
/* 2121 */                               Grid.status[hintXb[0]][y] = Grid.status[hintXb[0]][y] & invbit[n];
/* 2122 */                               Grid.status[hintXb[3]][y] = Grid.status[hintXb[3]][y] & invbit[n];
/* 2123 */                               Grid.status[hintXb[6]][y] = Grid.status[hintXb[6]][y] & invbit[n];
/*      */                             } 
/*      */                           } 
/*      */                         } 
/* 2127 */                         if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2128 */                           Grid.hintWord[0] = "" + (n + 1);
/* 2129 */                           Grid.hintWord[1] = "rows"; Grid.hintWord[2] = "row";
/* 2130 */                           Grid.hintWord[3] = "column"; Grid.hintWord[4] = "column";
/* 2131 */                           Grid.hintWrdCnt = 5;
/* 2132 */                           Grid.hintTitle = "Swordfish";
/* 2133 */                           return Boolean.valueOf(true);
/*      */                         } 
/* 2135 */                         hintIndexb = 0;
/* 2136 */                         if (found.booleanValue()) return Boolean.valueOf(true);
/*      */                       
/*      */                       }  }
/*      */                     else
/* 2140 */                     { for (int d = c + 1; d < 9; d++)
/* 2141 */                       { if (Grid.sig[n][d] != 0)
/* 2142 */                         { int accumD = accumC | Grid.sig[n][d];
/* 2143 */                           if (countBits(accumD) == 4)
/*      */                           
/* 2145 */                           { for (int x = 0; x < 9; x++) {
/* 2146 */                               if ((accumD & theBit[x]) > 0) {
/* 2147 */                                 hintXb[hintIndexb] = x; hintYb[hintIndexb++] = a;
/* 2148 */                                 hintXb[hintIndexb] = x; hintYb[hintIndexb++] = b;
/* 2149 */                                 hintXb[hintIndexb] = x; hintYb[hintIndexb++] = c;
/* 2150 */                                 hintXb[hintIndexb] = x; hintYb[hintIndexb++] = d;
/*      */                               } 
/*      */                             } 
/* 2153 */                             for (y = 0; y < 9; y++) {
/* 2154 */                               if (y != a && y != b && y != c && y != d && ((
/* 2155 */                                 getStatus(hintXb[0], y) & bit[n]) > 0 || (
/* 2156 */                                 getStatus(hintXb[4], y) & bit[n]) > 0 || (
/* 2157 */                                 getStatus(hintXb[8], y) & bit[n]) > 0 || (
/* 2158 */                                 getStatus(hintXb[12], y) & bit[n]) > 0)) {
/*      */                                 
/* 2160 */                                 found = Boolean.valueOf(true);
/* 2161 */                                 if (Grid.findHint.booleanValue()) {
/* 2162 */                                   hintNum = 6;
/* 2163 */                                   if ((getStatus(hintXb[0], y) & bit[n]) > 0) setCand(hintXb[0], y, n, 1); 
/* 2164 */                                   if ((getStatus(hintXb[4], y) & bit[n]) > 0) setCand(hintXb[4], y, n, 1); 
/* 2165 */                                   if ((getStatus(hintXb[8], y) & bit[n]) > 0) setCand(hintXb[8], y, n, 1); 
/* 2166 */                                   if ((getStatus(hintXb[12], y) & bit[n]) > 0) setCand(hintXb[12], y, n, 1);
/*      */                                 
/*      */                                 } else {
/* 2169 */                                   Grid.status[hintXb[0]][y] = Grid.status[hintXb[0]][y] & invbit[n];
/* 2170 */                                   Grid.status[hintXb[4]][y] = Grid.status[hintXb[4]][y] & invbit[n];
/* 2171 */                                   Grid.status[hintXb[8]][y] = Grid.status[hintXb[8]][y] & invbit[n];
/* 2172 */                                   Grid.status[hintXb[12]][y] = Grid.status[hintXb[12]][y] & invbit[n];
/*      */                                 } 
/*      */                               } 
/*      */                             } 
/* 2176 */                             if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2177 */                               Grid.hintWord[0] = "" + (n + 1);
/* 2178 */                               Grid.hintWord[1] = "rows"; Grid.hintWord[2] = "row";
/* 2179 */                               Grid.hintWord[3] = "column"; Grid.hintWord[4] = "column";
/* 2180 */                               Grid.hintWrdCnt = 5;
/* 2181 */                               Grid.hintTitle = "Jellyfish";
/* 2182 */                               return Boolean.valueOf(true);
/*      */                             } 
/* 2184 */                             hintIndexb = 0;
/* 2185 */                             if (found.booleanValue()) return Boolean.valueOf(true);  }  }  }  } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2193 */     }  for (y = 0; y < 9; y++) {
/* 2194 */       for (int x = 0; x < 9; x++)
/* 2195 */         Grid.sig[x][y] = 0; 
/*      */     } 
/* 2197 */     for (y = 0; y < 9; y++) {
/* 2198 */       for (int x = 0; x < 9; x++) {
/* 2199 */         for (n = 0; n < 9; n++)
/* 2200 */         { if ((getStatus(x, y) & bit[n]) != 0)
/* 2201 */             Grid.sig[x][n] = Grid.sig[x][n] | theBit[y];  } 
/*      */       } 
/* 2203 */     }  for (hintIndexb = n = 0; n < 9; n++) {
/* 2204 */       for (int a = 0; a < 9; a++) {
/* 2205 */         if (Grid.sig[a][n] != 0) {
/* 2206 */           int accumA = Grid.sig[a][n];
/* 2207 */           for (int b = a + 1; b < 9; b++) {
/* 2208 */             if (Grid.sig[b][n] != 0) {
/* 2209 */               int accumB = accumA | Grid.sig[b][n];
/* 2210 */               if (order == 2) {
/* 2211 */                 if (candidates[accumB] == 2) {
/*      */                   
/* 2213 */                   for (y = 0; y < 9; y++) {
/* 2214 */                     if ((accumB & theBit[y]) > 0) {
/* 2215 */                       hintXb[hintIndexb] = a; hintYb[hintIndexb++] = y;
/* 2216 */                       hintXb[hintIndexb] = b; hintYb[hintIndexb++] = y;
/*      */                     } 
/*      */                   } 
/*      */                   
/* 2220 */                   for (int x = 0; x < 9; x++) {
/* 2221 */                     if (x != a && x != b && ((
/* 2222 */                       getStatus(x, hintYb[0]) & bit[n]) > 0 || (
/* 2223 */                       getStatus(x, hintYb[2]) & bit[n]) > 0)) {
/*      */                       
/* 2225 */                       found = Boolean.valueOf(true);
/* 2226 */                       if (Grid.findHint.booleanValue()) {
/* 2227 */                         hintNum = 6;
/* 2228 */                         if ((getStatus(x, hintYb[0]) & bit[n]) > 0) setCand(x, hintYb[0], n, 1); 
/* 2229 */                         if ((getStatus(x, hintYb[2]) & bit[n]) > 0) setCand(x, hintYb[2], n, 1);
/*      */                       
/*      */                       } else {
/* 2232 */                         Grid.status[x][hintYb[0]] = Grid.status[x][hintYb[0]] & invbit[n];
/* 2233 */                         Grid.status[x][hintYb[2]] = Grid.status[x][hintYb[2]] & invbit[n];
/*      */                       } 
/*      */                     } 
/*      */                   } 
/* 2237 */                   if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2238 */                     Grid.hintWord[0] = "" + (n + 1);
/* 2239 */                     Grid.hintWord[1] = "columns"; Grid.hintWord[2] = "column";
/* 2240 */                     Grid.hintWord[3] = "row"; Grid.hintWord[4] = "row";
/* 2241 */                     Grid.hintWrdCnt = 5;
/* 2242 */                     Grid.hintTitle = "X-wing";
/* 2243 */                     return Boolean.valueOf(true);
/*      */                   } 
/* 2245 */                   hintIndexb = 0;
/* 2246 */                   if (found.booleanValue()) return Boolean.valueOf(true);
/*      */                 
/*      */                 } 
/*      */               } else {
/* 2250 */                 for (int c = b + 1; c < 9; c++)
/* 2251 */                 { if (Grid.sig[c][n] != 0)
/* 2252 */                   { int accumC = accumB | Grid.sig[c][n];
/* 2253 */                     if (order == 3)
/* 2254 */                     { if (countBits(accumC) == 3) {
/*      */                         
/* 2256 */                         for (y = 0; y < 9; y++) {
/* 2257 */                           if ((accumC & theBit[y]) > 0) {
/* 2258 */                             hintXb[hintIndexb] = a; hintYb[hintIndexb++] = y;
/* 2259 */                             hintXb[hintIndexb] = b; hintYb[hintIndexb++] = y;
/* 2260 */                             hintXb[hintIndexb] = c; hintYb[hintIndexb++] = y;
/*      */                           } 
/*      */                         } 
/* 2263 */                         for (int x = 0; x < 9; x++) {
/* 2264 */                           if (x != a && x != b && x != c && ((
/* 2265 */                             getStatus(x, hintYb[0]) & bit[n]) > 0 || (
/* 2266 */                             getStatus(x, hintYb[3]) & bit[n]) > 0 || (
/* 2267 */                             getStatus(x, hintYb[6]) & bit[n]) > 0)) {
/*      */                             
/* 2269 */                             found = Boolean.valueOf(true);
/* 2270 */                             if (Grid.findHint.booleanValue()) {
/* 2271 */                               hintNum = 6;
/* 2272 */                               if ((getStatus(x, hintYb[0]) & bit[n]) > 0) setCand(x, hintYb[0], n, 1); 
/* 2273 */                               if ((getStatus(x, hintYb[3]) & bit[n]) > 0) setCand(x, hintYb[3], n, 1); 
/* 2274 */                               if ((getStatus(x, hintYb[6]) & bit[n]) > 0) setCand(x, hintYb[6], n, 1);
/*      */                             
/*      */                             } else {
/* 2277 */                               Grid.status[x][hintYb[0]] = Grid.status[x][hintYb[0]] & invbit[n];
/* 2278 */                               Grid.status[x][hintYb[3]] = Grid.status[x][hintYb[3]] & invbit[n];
/* 2279 */                               Grid.status[x][hintYb[6]] = Grid.status[x][hintYb[6]] & invbit[n];
/*      */                             } 
/*      */                           } 
/*      */                         } 
/* 2283 */                         if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2284 */                           Grid.hintWord[0] = "" + (n + 1);
/* 2285 */                           Grid.hintWord[1] = "columns"; Grid.hintWord[2] = "column";
/* 2286 */                           Grid.hintWord[3] = "row"; Grid.hintWord[4] = "row";
/* 2287 */                           Grid.hintWrdCnt = 5;
/* 2288 */                           Grid.hintTitle = "Swordfish";
/* 2289 */                           return Boolean.valueOf(true);
/*      */                         } 
/* 2291 */                         hintIndexb = 0;
/* 2292 */                         if (found.booleanValue()) return Boolean.valueOf(true);
/*      */                       
/*      */                       }  }
/*      */                     else
/* 2296 */                     { for (int d = c + 1; d < 9; d++)
/* 2297 */                       { if (Grid.sig[d][n] != 0)
/* 2298 */                         { int accumD = accumC | Grid.sig[d][n];
/* 2299 */                           if (countBits(accumD) == 4)
/*      */                           
/* 2301 */                           { for (y = 0; y < 9; y++) {
/* 2302 */                               if ((accumD & theBit[y]) > 0) {
/* 2303 */                                 hintXb[hintIndexb] = a; hintYb[hintIndexb++] = y;
/* 2304 */                                 hintXb[hintIndexb] = b; hintYb[hintIndexb++] = y;
/* 2305 */                                 hintXb[hintIndexb] = c; hintYb[hintIndexb++] = y;
/* 2306 */                                 hintXb[hintIndexb] = d; hintYb[hintIndexb++] = y;
/*      */                               } 
/*      */                             } 
/* 2309 */                             for (int x = 0; x < 9; x++) {
/* 2310 */                               if (x != a && x != b && x != c && x != d && ((
/* 2311 */                                 getStatus(x, hintYb[0]) & bit[n]) > 0 || (
/* 2312 */                                 getStatus(x, hintYb[4]) & bit[n]) > 0 || (
/* 2313 */                                 getStatus(x, hintYb[8]) & bit[n]) > 0 || (
/* 2314 */                                 getStatus(x, hintYb[12]) & bit[n]) > 0)) {
/*      */                                 
/* 2316 */                                 found = Boolean.valueOf(true);
/* 2317 */                                 if (Grid.findHint.booleanValue()) {
/* 2318 */                                   hintNum = 6;
/* 2319 */                                   if ((getStatus(x, hintYb[0]) & bit[n]) > 0) setCand(x, hintYb[0], n, 1); 
/* 2320 */                                   if ((getStatus(x, hintYb[4]) & bit[n]) > 0) setCand(x, hintYb[4], n, 1); 
/* 2321 */                                   if ((getStatus(x, hintYb[8]) & bit[n]) > 0) setCand(x, hintYb[8], n, 1); 
/* 2322 */                                   if ((getStatus(x, hintYb[12]) & bit[n]) > 0) setCand(x, hintYb[12], n, 1);
/*      */                                 
/*      */                                 } else {
/* 2325 */                                   Grid.status[x][hintYb[0]] = Grid.status[x][hintYb[0]] & invbit[n];
/* 2326 */                                   Grid.status[x][hintYb[4]] = Grid.status[x][hintYb[4]] & invbit[n];
/* 2327 */                                   Grid.status[x][hintYb[8]] = Grid.status[x][hintYb[8]] & invbit[n];
/* 2328 */                                   Grid.status[x][hintYb[12]] = Grid.status[x][hintYb[12]] & invbit[n];
/*      */                                 } 
/*      */                               } 
/*      */                             } 
/* 2332 */                             if ((found.booleanValue() & Grid.findHint.booleanValue()) != 0) {
/* 2333 */                               Grid.hintWord[0] = "" + (n + 1);
/* 2334 */                               Grid.hintWord[1] = "columns"; Grid.hintWord[2] = "column";
/* 2335 */                               Grid.hintWord[3] = "row "; Grid.hintWord[4] = "row";
/* 2336 */                               Grid.hintWrdCnt = 5;
/* 2337 */                               Grid.hintTitle = "Jellyfish";
/* 2338 */                               return Boolean.valueOf(true);
/*      */                             } 
/* 2340 */                             hintIndexb = 0;
/* 2341 */                             if (found.booleanValue()) return Boolean.valueOf(true);  }  }  }  }  }  } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2347 */     }  return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   
/*      */   static Boolean singlesChain(int scMode) {
/* 2352 */     Point start = null, end = null;
/*      */     
/* 2354 */     String ltr = "ABCDEFGHI";
/*      */     
/* 2356 */     linkCandidatePos = 2; linkCandidateNum = 1;
/* 2357 */     for (; linkCandidateNum < 10; 
/* 2358 */       linkCandidatePos *= 2, linkCandidateNum++) {
/* 2359 */       linkDatIndex = 0; listN = 0; int j;
/* 2360 */       for (j = 0; j < 9; j++) {
/* 2361 */         for (int m = 0; m < 9; m++) {
/* 2362 */           Grid.scratch[m][j] = ((getStatus(m, j) & linkCandidatePos) == linkCandidatePos) ? 1 : 0;
/*      */         }
/*      */       } 
/*      */       
/* 2366 */       for (j = 0; j < 9; j++) {
/* 2367 */         int m; int count; for (count = m = 0; m < 9; m++) {
/* 2368 */           if (Grid.scratch[m][j] > 0)
/* 2369 */             count++; 
/* 2370 */         }  if (count == 2) {
/* 2371 */           for (boolean first = true; m < 9; m++) {
/* 2372 */             if (Grid.scratch[m][j] > 0) {
/* 2373 */               if (first) { start = new Point(m, j); }
/* 2374 */               else { end = new Point(m, j); }
/* 2375 */                first = false;
/*      */             } 
/* 2377 */           }  linkDat[linkDatIndex++] = new Link(start, end, 0, 0, "S", -1, -1);
/*      */         } 
/*      */       } 
/*      */       
/*      */       int i;
/* 2382 */       for (i = 0; i < 9; i++) {
/* 2383 */         int count; for (count = j = 0; j < 9; j++) {
/* 2384 */           if (Grid.scratch[i][j] > 0)
/* 2385 */             count++; 
/* 2386 */         }  if (count == 2) {
/* 2387 */           for (boolean first = true; j < 9; j++) {
/* 2388 */             if (Grid.scratch[i][j] > 0) {
/* 2389 */               if (first) { start = new Point(i, j); }
/* 2390 */               else { end = new Point(i, j); }
/* 2391 */                first = false;
/*      */             } 
/* 2393 */           }  linkDat[linkDatIndex++] = new Link(start, end, 0, 0, "S", -1, -1);
/*      */         } 
/*      */       } 
/*      */       
/*      */       int k;
/* 2398 */       for (k = 0; k < 9; k++) {
/* 2399 */         int a = k % 3 * 3, b = k / 3 * 3; int count;
/* 2400 */         for (count = i = 0; i < 3; i++) {
/* 2401 */           for (j = 0; j < 3; j++) {
/* 2402 */             int x = a + i, y = b + j;
/* 2403 */             if (Grid.scratch[x][y] > 0)
/* 2404 */               count++; 
/*      */           } 
/* 2406 */         }  if (count == 2) {
/* 2407 */           a = k % 3 * 3; b = k / 3 * 3;
/* 2408 */           for (boolean first = true; i < 3; i++) {
/* 2409 */             for (j = 0; j < 3; j++) {
/* 2410 */               int x = a + i, y = b + j;
/* 2411 */               if (Grid.scratch[x][y] > 0) {
/* 2412 */                 if (first) { start = new Point(x, y); }
/* 2413 */                 else { end = new Point(x, y); }
/* 2414 */                  first = false;
/*      */               } 
/*      */             } 
/* 2417 */           }  if (start.x != end.x && start.y != end.y) {
/* 2418 */             linkDat[linkDatIndex++] = new Link(start, end, 0, 0, "S", -1, -1);
/*      */           }
/*      */         } 
/*      */       } 
/* 2422 */       if (scMode < 2) {
/* 2423 */         if (linkDatIndex > 0)
/*      */           while (true) {
/* 2425 */             (linkDat[0]).Y = 2; (linkDat[0]).N = 4;
/* 2426 */             for (boolean linkPathFound = true; linkPathFound; ) {
/* 2427 */               linkPathFound = false;
/* 2428 */               for (i = 0; i < linkDatIndex; i++) {
/* 2429 */                 if ((linkDat[i]).Y != 0) {
/* 2430 */                   for (j = 0; j < linkDatIndex; j++) {
/* 2431 */                     if (i != j && 
/* 2432 */                       (linkDat[j]).Y == 0) {
/* 2433 */                       if ((linkDat[i]).start.equals((linkDat[j]).start)) {
/* 2434 */                         (linkDat[j]).Y = (linkDat[i]).Y;
/* 2435 */                         (linkDat[j]).N = (linkDat[i]).N;
/* 2436 */                         linkPathFound = true;
/*      */                       } 
/* 2438 */                       if ((linkDat[i]).start.equals((linkDat[j]).end)) {
/* 2439 */                         (linkDat[j]).Y = (linkDat[i]).N;
/* 2440 */                         (linkDat[j]).N = (linkDat[i]).Y;
/* 2441 */                         linkPathFound = true;
/*      */                       } 
/* 2443 */                       if ((linkDat[i]).end.equals((linkDat[j]).start)) {
/* 2444 */                         (linkDat[j]).Y = (linkDat[i]).N;
/* 2445 */                         (linkDat[j]).N = (linkDat[i]).Y;
/* 2446 */                         linkPathFound = true;
/*      */                       } 
/* 2448 */                       if ((linkDat[i]).end.equals((linkDat[j]).end)) {
/* 2449 */                         (linkDat[j]).Y = (linkDat[i]).Y;
/* 2450 */                         (linkDat[j]).N = (linkDat[i]).N;
/* 2451 */                         linkPathFound = true;
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 }
/*      */               } 
/*      */             } 
/* 2458 */             for (i = 0; i < linkDatIndex; i++) {
/* 2459 */               if ((linkDat[i]).Y > 0) {
/* 2460 */                 Grid.scratch[(linkDat[i]).start.x][(linkDat[i]).start.y] = (linkDat[i]).Y;
/* 2461 */                 Grid.scratch[(linkDat[i]).end.x][(linkDat[i]).end.y] = (linkDat[i]).N;
/*      */               } 
/*      */             } 
/* 2464 */             if (scMode == 0)
/* 2465 */               for (j = 0; j < 9; j++) {
/* 2466 */                 for (i = 0; i < 9; i++) {
/* 2467 */                   if (Grid.scratch[i][j] == 1) {
/* 2468 */                     int a = i / 3 * 3, b = j / 3 * 3; int res;
/* 2469 */                     for (int x = 0; x < 9; x++) {
/* 2470 */                       res |= Grid.scratch[x][j];
/* 2471 */                       res |= Grid.scratch[i][x];
/* 2472 */                       res |= Grid.scratch[a + x % 3][b + x / 3];
/*      */                     } 
/* 2474 */                     if (res == 7) {
/* 2475 */                       if (!Grid.findHint.booleanValue()) {
/* 2476 */                         Grid.status[i][j] = Grid.status[i][j] ^ linkCandidatePos;
/*      */                       } else {
/* 2478 */                         Grid.hintTitle = "Singles Chain <br> Complimentary candidates visible";
/* 2479 */                         hintNum = 9;
/* 2480 */                         hintXb[0] = i; hintYb[0] = j; hintIndexb = 1;
/* 2481 */                         setCand(i, j, linkCandidateNum - 1, 1);
/* 2482 */                         Grid.hintWord[0] = "" + linkCandidateNum; Grid.hintWord[1] = "" + ltr.charAt(j) + (i + 1);
/* 2483 */                         Grid.hintWord[2] = "" + linkCandidateNum;
/* 2484 */                         Grid.hintWrdCnt = 3;
/*      */                       } 
/* 2486 */                       return Boolean.valueOf(true);
/*      */                     } 
/*      */                   } 
/*      */                 } 
/* 2490 */               }   if (scMode == 1) {
/* 2491 */               for (j = 0; j < 9; j++) {
/* 2492 */                 int count2; int count4; for (count2 = count4 = i = 0; i < 9; i++) {
/* 2493 */                   if (Grid.scratch[i][j] == 2) count2++; 
/* 2494 */                   if (Grid.scratch[i][j] == 4) count4++; 
/*      */                 } 
/* 2496 */                 if (count2 > 1) {
/* 2497 */                   for (k = i = 0; i < 9; i++) {
/* 2498 */                     if (Grid.scratch[i][j] == 2)
/* 2499 */                       if (!Grid.findHint.booleanValue()) {
/* 2500 */                         Grid.status[i][j] = Grid.status[i][j] ^ linkCandidatePos;
/*      */                       } else {
/* 2502 */                         hintXb[k] = i; hintYb[k] = j; hintIndexb = ++k;
/* 2503 */                         setHintData("" + linkCandidateNum, "row", "green", "red");
/*      */                       }  
/* 2505 */                   }  return Boolean.valueOf(true);
/*      */                 } 
/* 2507 */                 if (count4 > 1) {
/* 2508 */                   for (k = i = 0; i < 9; i++) {
/* 2509 */                     if (Grid.scratch[i][j] == 4)
/* 2510 */                       if (!Grid.findHint.booleanValue()) {
/* 2511 */                         Grid.status[i][j] = Grid.status[i][j] ^ linkCandidatePos;
/*      */                       } else {
/* 2513 */                         hintXb[k] = i; hintYb[k] = j; hintIndexb = ++k;
/* 2514 */                         setHintData("" + linkCandidateNum, "row", "red", "green");
/*      */                       }  
/* 2516 */                   }  return Boolean.valueOf(true);
/*      */                 } 
/*      */               } 
/*      */               
/* 2520 */               for (i = 0; i < 9; i++) {
/* 2521 */                 int count2; int count4; for (count2 = count4 = j = 0; j < 9; j++) {
/* 2522 */                   if (Grid.scratch[i][j] == 2) count2++; 
/* 2523 */                   if (Grid.scratch[i][j] == 4) count4++; 
/*      */                 } 
/* 2525 */                 if (count2 > 1) {
/* 2526 */                   for (k = j = 0; j < 9; j++) {
/* 2527 */                     if (Grid.scratch[i][j] == 2)
/* 2528 */                       if (!Grid.findHint.booleanValue()) {
/* 2529 */                         Grid.status[i][j] = Grid.status[i][j] ^ linkCandidatePos;
/*      */                       } else {
/* 2531 */                         hintXb[k] = i; hintYb[k] = j; hintIndexb = ++k;
/* 2532 */                         setHintData("" + linkCandidateNum, "column", "green", "red");
/*      */                       }  
/* 2534 */                   }  return Boolean.valueOf(true);
/*      */                 } 
/* 2536 */                 if (count4 > 1) {
/* 2537 */                   for (k = j = 0; j < 9; j++) {
/* 2538 */                     if (Grid.scratch[i][j] == 4)
/* 2539 */                       if (!Grid.findHint.booleanValue()) {
/* 2540 */                         Grid.status[i][j] = Grid.status[i][j] ^ linkCandidatePos;
/*      */                       } else {
/* 2542 */                         hintXb[k] = i; hintYb[k] = j; hintIndexb = ++k;
/* 2543 */                         setHintData("" + linkCandidateNum, "column", "red", "green");
/*      */                       }  
/* 2545 */                   }  return Boolean.valueOf(true);
/*      */                 } 
/*      */               } 
/*      */               
/* 2549 */               for (j = 0; j < 9; j += 3) {
/* 2550 */                 for (i = 0; i < 9; i += 3) {
/* 2551 */                   int b; int count2; int count4; for (count2 = count4 = b = 0; b < 3; b++) {
/* 2552 */                     for (int a = 0; a < 3; a++) {
/* 2553 */                       if (Grid.scratch[i + a][j + b] == 2) count2++; 
/* 2554 */                       if (Grid.scratch[i + a][j + b] == 4) count4++; 
/*      */                     } 
/* 2556 */                   }  if (count2 > 1) {
/* 2557 */                     for (k = b = 0; b < 3; b++) {
/* 2558 */                       for (int a = 0; a < 3; a++) {
/* 2559 */                         if (Grid.scratch[i + a][j + b] == 2)
/* 2560 */                           if (!Grid.findHint.booleanValue())
/* 2561 */                           { Grid.status[i + a][j + b] = Grid.status[i + a][j + b] ^ linkCandidatePos; }
/*      */                           else
/* 2563 */                           { hintXb[k] = i + a; hintYb[k] = j + b; hintIndexb = ++k;
/* 2564 */                             setHintData("" + linkCandidateNum, "box", "green", "red"); }  
/*      */                       } 
/* 2566 */                     }  return Boolean.valueOf(true);
/*      */                   } 
/* 2568 */                   if (count4 > 1) {
/* 2569 */                     for (k = b = 0; b < 3; b++) {
/* 2570 */                       for (int a = 0; a < 3; a++) {
/* 2571 */                         if (Grid.scratch[i + a][j + b] == 4)
/* 2572 */                           if (!Grid.findHint.booleanValue())
/* 2573 */                           { Grid.status[i + a][j + b] = Grid.status[i + a][j + b] ^ linkCandidatePos; }
/*      */                           else
/* 2575 */                           { hintXb[k] = i + a; hintYb[k] = j + b; hintIndexb = ++k;
/* 2576 */                             setHintData("" + linkCandidateNum, "box", "red", "green"); }  
/*      */                       } 
/* 2578 */                     }  return Boolean.valueOf(true);
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/* 2583 */             for (j = k = 0; k < linkDatIndex; k++) {
/* 2584 */               if ((linkDat[k]).Y == 0)
/* 2585 */                 linkDat[j++] = linkDat[k]; 
/* 2586 */             }  linkDatIndex = j;
/* 2587 */             if (j == 0)
/*      */               break; 
/* 2589 */             for (j = 0; j < 9; j++) {
/* 2590 */               for (i = 0; i < 9; i++) {
/* 2591 */                 if (Grid.scratch[i][j] > 1)
/* 2592 */                   Grid.scratch[i][j] = 1; 
/*      */               } 
/*      */             } 
/*      */           }  
/*      */       } else {
/* 2597 */         for (listN = k = 0; k < linkDatIndex; k++) {
/* 2598 */           for (i = 0; i < listN && 
/* 2599 */             listN != 0 && 
/* 2600 */             !(junc[i]).p.equals((linkDat[k]).start); i++);
/*      */           
/* 2602 */           if (i == listN)
/* 2603 */             junc[listN++] = new JunctionCell((linkDat[k]).start); 
/* 2604 */           for (i = 0; i < listN && 
/* 2605 */             !(junc[i]).p.equals((linkDat[k]).end); i++);
/*      */           
/* 2607 */           if (i == listN) {
/* 2608 */             junc[listN++] = new JunctionCell((linkDat[k]).end);
/*      */           }
/*      */         } 
/* 2611 */         if (listN > 1) {
/* 2612 */           int a = linkDatIndex;
/* 2613 */           int wlCount = 0;
/* 2614 */           for (k = 0; k < listN - 1; k++) {
/* 2615 */             for (i = k + 1; i < listN; i++) {
/* 2616 */               if ((junc[k]).p.x == (junc[i]).p.x || (junc[k]).p.y == (junc[i]).p.y || ((junc[k]).p.x / 3 == (junc[i]).p.x / 3 && (junc[k]).p.y / 3 == (junc[i]).p.y / 3)) {
/*      */ 
/*      */                 
/* 2619 */                 boolean create = true;
/* 2620 */                 for (j = 0; j < a; j++) {
/* 2621 */                   if (((linkDat[j]).start.equals((junc[k]).p) && (linkDat[j]).end.equals((junc[i]).p)) || ((linkDat[j]).start
/* 2622 */                     .equals((junc[i]).p) && (linkDat[j]).end.equals((junc[k]).p))) {
/* 2623 */                     create = false; break;
/*      */                   } 
/*      */                 } 
/* 2626 */                 if (create)
/* 2627 */                 { linkDat[linkDatIndex++] = new Link((junc[k]).p, (junc[i]).p, 0, 0, "W", -1, -1);
/* 2628 */                   wlCount++; } 
/*      */               } 
/*      */             } 
/* 2631 */           }  if (wlCount == 0) {
/* 2632 */             return Boolean.valueOf(false);
/*      */           }
/*      */         } 
/*      */         
/* 2636 */         for (j = 0; j < listN; j++) {
/* 2637 */           for (i = 0; i < linkDatIndex; i++) {
/* 2638 */             if ((junc[j]).p.equals((linkDat[i]).start))
/* 2639 */               for (int x = 0; x < listN; x++) {
/* 2640 */                 if ((junc[x]).p.equals((linkDat[i]).end))
/* 2641 */                   for (k = 0; k < 8; k++) {
/* 2642 */                     if ((junc[j]).next[k] == -1) {
/* 2643 */                       (junc[j]).next[k] = x;
/* 2644 */                       (junc[j]).type[k] = "" + (linkDat[i]).type + (junc[j]).p.x + (junc[j]).p.y; break;
/*      */                     } 
/*      */                   }  
/* 2647 */               }   if ((junc[j]).p.equals((linkDat[i]).end))
/* 2648 */               for (int x = 0; x < listN; x++) {
/* 2649 */                 if ((junc[x]).p.equals((linkDat[i]).start))
/* 2650 */                   for (k = 0; k < 8; k++) {
/* 2651 */                     if ((junc[j]).next[k] == -1) {
/* 2652 */                       (junc[j]).next[k] = x;
/* 2653 */                       (junc[j]).type[k] = "" + (linkDat[i]).type + (junc[j]).p.x + (junc[j]).p.y; break;
/*      */                     } 
/*      */                   }  
/*      */               }  
/*      */           } 
/* 2658 */         }  if (listN > 0 && junc[0] != null && 
/* 2659 */           scanForSolution(0, -1, "", "", scMode))
/* 2660 */           return Boolean.valueOf(true); 
/*      */       } 
/*      */     } 
/* 2663 */     linkDatIndex = 0;
/* 2664 */     listN = 0;
/* 2665 */     return Boolean.valueOf(false);
/*      */   }
/*      */   
/*      */   static void setHintData(String cand, String unit, String color, String otherColor) {
/* 2669 */     Grid.hintTitle = "Singles Chain <br> Two candidates in a unit";
/* 2670 */     hintNum = 10;
/* 2671 */     Grid.hintWord[10] = cand; Grid.hintWord[9] = cand; Grid.hintWord[7] = cand; Grid.hintWord[4] = cand; Grid.hintWord[2] = cand; Grid.hintWord[0] = cand;
/* 2672 */     Grid.hintWord[6] = color; Grid.hintWord[1] = color;
/* 2673 */     Grid.hintWord[5] = unit; Grid.hintWord[3] = unit;
/* 2674 */     Grid.hintWord[8] = otherColor;
/* 2675 */     Grid.hintWrdCnt = 11;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean scanForSolution(int juncIndex, int caller, String strength, String res, int mode) {
/* 2683 */     if ((junc[juncIndex]).visited) {
/* 2684 */       String theString = res.substring((junc[juncIndex]).chain.length());
/* 2685 */       if (!theString.contains("W"))
/* 2686 */         return false;  int j;
/* 2687 */       theString = theString.substring(j = theString.indexOf('W')) + theString.substring(0, j);
/* 2688 */       if (theString.length() % 6 == 0) {
/* 2689 */         if (mode != 2) return false;  int k;
/* 2690 */         for (k = j = 3; j < theString.length(); j += 3) {
/* 2691 */           if (theString.charAt(j) == 'W') {
/* 2692 */             if ((j - k) % 6 == 0)
/*      */               break; 
/* 2694 */             k = j + 3;
/*      */           } 
/* 2696 */         }  if (j == theString.length()) {
/* 2697 */           int y; for (y = 0; y < 9; y++) {
/* 2698 */             for (int x = 0; x < 9; x++)
/* 2699 */               Grid.sig[x][y] = Grid.scratch[x][y]; 
/* 2700 */           }  for (k = 0; k < listN; k++)
/* 2701 */             Grid.sig[(junc[k]).p.x][(junc[k]).p.y] = 0; 
/* 2702 */           hintUnitIndex = hintCellIndex = weakLinkIndex = 0;
/* 2703 */           for (k = 0; k < theString.length(); k += 3) {
/* 2704 */             int x1 = theString.charAt(k + 1) - 48, x2 = theString.charAt((k + 4 < theString.length()) ? (k + 4) : 1) - 48;
/* 2705 */             int y1 = theString.charAt(k + 2) - 48, y2 = theString.charAt((k + 5 < theString.length()) ? (k + 5) : 2) - 48;
/* 2706 */             if (!theString.substring(k, k + 1).equals("S")) {
/* 2707 */               int a, m, x; String unitType; weakLinkx1[weakLinkIndex] = x1;
/* 2708 */               weakLinky1[weakLinkIndex] = y1;
/* 2709 */               weakLinkx2[weakLinkIndex] = x2;
/* 2710 */               weakLinky2[weakLinkIndex++] = y2;
/*      */               
/* 2712 */               if (y1 == y2) { unitType = "R"; m = y1; }
/* 2713 */               else if (x1 == x2) { unitType = "C"; m = x1; }
/* 2714 */               else { unitType = "B"; m = 3 * y1 / 3 + x1 / 3; }
/*      */               
/* 2716 */               switch (unitType.charAt(0)) {
/*      */                 case 'R':
/* 2718 */                   for (j = 0; j < 9; j++) {
/* 2719 */                     if (Grid.sig[j][m] == 1)
/* 2720 */                       if (Grid.findHint.booleanValue())
/* 2721 */                       { setCand(j, m, linkCandidateNum - 1, 1); }
/* 2722 */                       else { Grid.status[j][m] = Grid.status[j][m] ^ linkCandidatePos; }  
/*      */                   }  break;
/*      */                 case 'C':
/* 2725 */                   for (j = 0; j < 9; j++) {
/* 2726 */                     if (Grid.sig[m][j] == 1)
/* 2727 */                       if (Grid.findHint.booleanValue())
/* 2728 */                       { setCand(m, j, linkCandidateNum - 1, 1); }
/* 2729 */                       else { Grid.status[m][j] = Grid.status[m][j] ^ linkCandidatePos; }  
/*      */                   }  break;
/*      */                 case 'B':
/* 2732 */                   x = m % 3 * 3; y = m / 3 * 3;
/* 2733 */                   for (a = 0; a < 3; a++) {
/* 2734 */                     for (int b = 0; b < 3; b++) {
/* 2735 */                       if (Grid.sig[x + a][y + b] == 1)
/* 2736 */                         if (Grid.findHint.booleanValue())
/* 2737 */                         { setCand(x + a, y + b, linkCandidateNum - 1, 1); }
/* 2738 */                         else { Grid.status[x + a][y + b] = Grid.status[x + a][y + b] ^ linkCandidatePos; }
/*      */                          
/*      */                     } 
/*      */                   }  break;
/* 2742 */               }  if (Grid.findHint.booleanValue())
/* 2743 */                 hintUnit[hintUnitIndex++] = unitType + m; 
/*      */             } 
/* 2745 */             if (Grid.findHint.booleanValue()) {
/* 2746 */               hintCellx[hintCellIndex] = x1;
/* 2747 */               hintCelly[hintCellIndex++] = y1;
/* 2748 */               hintCandidate = linkCandidateNum;
/* 2749 */               hintNum = 11;
/* 2750 */               Grid.hintTitle = "X-Cycle : Rule 1";
/* 2751 */               Grid.hintWord[2] = "" + linkCandidateNum; Grid.hintWord[1] = "" + linkCandidateNum; Grid.hintWord[0] = "" + linkCandidateNum;
/* 2752 */               Grid.hintWrdCnt = 3;
/*      */             } 
/*      */           } 
/* 2755 */           return true;
/*      */         } 
/*      */       } else {
/*      */         
/* 2759 */         if (mode == 3) {
/* 2760 */           for (j = 3; j < theString.length() - 3 && (
/* 2761 */             theString.charAt(j) != 'S' || theString.charAt(j + 3) != 'S'); j += 3);
/*      */           
/* 2763 */           if (j < theString.length() - 3) {
/* 2764 */             theString = theString.substring(j + 3) + theString.substring(0, j + 3); int k;
/* 2765 */             for (k = j = 0; j < theString.length() - 3; j += 3) {
/* 2766 */               if (theString.charAt(j) == 'W') {
/* 2767 */                 if ((j - k) % 6 == 0)
/*      */                   break; 
/* 2769 */                 k = j + 3;
/*      */               } 
/* 2771 */             }  if (j == theString.length() - 3) {
/* 2772 */               for (hintUnitIndex = hintCellIndex = weakLinkIndex = 0, k = 0; k < theString.length(); k += 3) {
/* 2773 */                 int x1 = theString.charAt(k + 1) - 48, x2 = theString.charAt((k + 4 < theString.length()) ? (k + 4) : 1) - 48;
/* 2774 */                 int y1 = theString.charAt(k + 2) - 48, y2 = theString.charAt((k + 5 < theString.length()) ? (k + 5) : 2) - 48;
/* 2775 */                 if (!theString.substring(k, k + 1).equals("S")) {
/* 2776 */                   weakLinkx1[weakLinkIndex] = x1;
/* 2777 */                   weakLinky1[weakLinkIndex] = y1;
/* 2778 */                   weakLinkx2[weakLinkIndex] = x2;
/* 2779 */                   weakLinky2[weakLinkIndex++] = y2;
/*      */                 } 
/* 2781 */                 if (Grid.findHint.booleanValue()) {
/* 2782 */                   hintCellx[hintCellIndex] = x1;
/* 2783 */                   hintCelly[hintCellIndex++] = y1;
/* 2784 */                   hintCandidate = linkCandidateNum;
/*      */                 } 
/* 2786 */                 if (k == 0) {
/* 2787 */                   if (Grid.findHint.booleanValue()) {
/* 2788 */                     setCand(x1, y1, linkCandidateNum - 1, 0);
/* 2789 */                     hintNum = 12;
/* 2790 */                     Grid.hintTitle = "X-Cycle : Rule 2";
/* 2791 */                     Grid.hintWord[0] = "" + linkCandidateNum;
/* 2792 */                     Grid.hintWrdCnt = 1;
/*      */                   } else {
/*      */                     
/* 2795 */                     Grid.status[x1][y1] = 0;
/* 2796 */                     Grid.grid[x1][y1] = linkCandidateNum;
/* 2797 */                     updateStatus(x1, y1, linkCandidateNum - 1);
/*      */                   } 
/*      */                 }
/*      */               } 
/* 2801 */               return true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 2806 */         if (mode == 4) {
/* 2807 */           int k; int wCount; for (wCount = k = 0, j = theString.length() - 3; k < theString.length(); j = k, k += 3) {
/* 2808 */             if (theString.charAt(j) == 'W' && theString.charAt(k) == 'W')
/* 2809 */               wCount++; 
/*      */           } 
/* 2811 */           if (wCount == 1) {
/* 2812 */             int sCount; boolean valid; for (valid = true, sCount = 0, k = 3; k < theString.length(); k += 3) {
/* 2813 */               if (theString.charAt(k) == 'S')
/* 2814 */                 sCount++; 
/* 2815 */               if (theString.charAt(k) == 'W' || k == theString.length() - 3) {
/* 2816 */                 if (sCount % 2 != 1)
/* 2817 */                   valid = false; 
/* 2818 */                 sCount = 0;
/*      */               } 
/*      */             } 
/*      */             
/* 2822 */             if (valid) {
/* 2823 */               for (hintUnitIndex = hintCellIndex = weakLinkIndex = 0, k = 0; k < theString.length(); k += 3) {
/* 2824 */                 int x1 = theString.charAt(k + 1) - 48, x2 = theString.charAt((k + 4 < theString.length()) ? (k + 4) : 1) - 48;
/* 2825 */                 int y1 = theString.charAt(k + 2) - 48, y2 = theString.charAt((k + 5 < theString.length()) ? (k + 5) : 2) - 48;
/* 2826 */                 if (!theString.substring(k, k + 1).equals("S")) {
/* 2827 */                   weakLinkx1[weakLinkIndex] = x1;
/* 2828 */                   weakLinky1[weakLinkIndex] = y1;
/* 2829 */                   weakLinkx2[weakLinkIndex] = x2;
/* 2830 */                   weakLinky2[weakLinkIndex++] = y2;
/*      */                 } 
/* 2832 */                 if (Grid.findHint.booleanValue()) {
/* 2833 */                   hintCellx[hintCellIndex] = x1;
/* 2834 */                   hintCelly[hintCellIndex++] = y1;
/* 2835 */                   hintCandidate = linkCandidateNum;
/*      */                 } 
/* 2837 */                 if (k == 0)
/* 2838 */                   if (Grid.findHint.booleanValue()) {
/* 2839 */                     setCand(x1, y1, linkCandidateNum - 1, 1);
/* 2840 */                     hintNum = 13;
/* 2841 */                     Grid.hintTitle = "X-Cycle : Rule 3";
/* 2842 */                     Grid.hintWord[0] = "" + linkCandidateNum;
/* 2843 */                     Grid.hintWrdCnt = 2;
/*      */                   } else {
/*      */                     
/* 2846 */                     Grid.status[x1][y1] = Grid.status[x1][y1] ^ linkCandidatePos;
/*      */                   }  
/*      */               } 
/* 2849 */               return true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2854 */       return false;
/*      */     } 
/* 2856 */     (junc[juncIndex]).chain = res;
/* 2857 */     (junc[juncIndex]).visited = true;
/* 2858 */     for (int i = 0; i < 8; i++) {
/* 2859 */       if ((junc[juncIndex]).next[i] != caller && (junc[juncIndex]).next[i] != -1 && 
/* 2860 */         scanForSolution((junc[juncIndex]).next[i], juncIndex, (junc[juncIndex]).type[i], (junc[juncIndex]).chain + (junc[juncIndex]).type[i], mode))
/* 2861 */         return true; 
/* 2862 */     }  (junc[juncIndex]).visited = false;
/* 2863 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2938 */   static wingDat[] datW = new wingDat[81];
/*      */   static int keyCandidate;
/*      */   static int candNum;
/*      */   
/*      */   static boolean common(int x1, int y1, int x2, int y2, int loop, int incX, int incY, int i, int j, int k) {
/* 2943 */     String str = "";
/*      */     int a, c;
/* 2945 */     for (a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 2946 */       if ((keyCandidate & c) != 0)
/* 2947 */         candNum = a; 
/*      */     }  int z;
/* 2949 */     for (hintIndexb = z = 0; z < loop; z++, x1 += incX, y1 += incY) {
/* 2950 */       if (Grid.grid[x1][y1] == 0 && (getStatus(x1, y1) & keyCandidate) > 0) {
/* 2951 */         if (Grid.findHint.booleanValue()) {
/* 2952 */           hintXb[hintIndexb] = x1;
/* 2953 */           hintYb[hintIndexb] = y1;
/* 2954 */           setCand(x1, y1, candNum - 1, 1);
/*      */         } else {
/*      */           
/* 2957 */           Grid.status[x1][y1] = Grid.status[x1][y1] ^ keyCandidate;
/* 2958 */         }  hintIndexb++;
/*      */       } 
/*      */     } 
/* 2961 */     if (loop == 3) {
/* 2962 */       for (z = 0; z < loop; z++, x2 += incX, y2 += incY) {
/* 2963 */         if (Grid.grid[x2][y2] == 0 && (getStatus(x2, y2) & keyCandidate) > 0) {
/* 2964 */           if (Grid.findHint.booleanValue()) {
/* 2965 */             hintXb[hintIndexb] = x2;
/* 2966 */             hintYb[hintIndexb] = y2;
/* 2967 */             setCand(x2, y2, candNum - 1, 1);
/*      */           } else {
/*      */             
/* 2970 */             Grid.status[x2][y2] = Grid.status[x2][y2] ^ keyCandidate;
/* 2971 */           }  hintIndexb++;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 2976 */     if ((Grid.findHint.booleanValue() & ((hintIndexb > 0) ? 1 : 0)) != 0) {
/* 2977 */       for (a = 1, c = 2; c < 1024; c *= 2, a++) {
/* 2978 */         if (((datW[i]).dat & c) != 0)
/* 2979 */           str = str + a + " and "; 
/* 2980 */       }  str = str.substring(0, str.length() - 5);
/* 2981 */       Grid.hintWord[0] = str;
/* 2982 */       Grid.hintWord[1] = str.substring(0, 1);
/* 2983 */       Grid.hintWord[3] = str.substring(6);
/* 2984 */       Grid.hintWord[7] = "" + candNum; Grid.hintWord[6] = "" + candNum; Grid.hintWord[5] = "" + candNum; Grid.hintWord[4] = "" + candNum; Grid.hintWord[2] = "" + candNum;
/* 2985 */       Grid.hintWrdCnt = 8;
/* 2986 */       hintNum = 7;
/* 2987 */       Grid.hintTitle = "Y-wing";
/* 2988 */       hintXr[0] = (datW[j]).col;
/* 2989 */       hintYr[0] = (datW[j]).row;
/* 2990 */       hintXr[1] = (datW[k]).col;
/* 2991 */       hintYr[1] = (datW[k]).row;
/* 2992 */       hintXg[0] = (datW[i]).col;
/* 2993 */       hintYg[0] = (datW[i]).row;
/* 2994 */       hintIndexg = 1;
/* 2995 */       hintIndexr = 2;
/*      */     } 
/* 2997 */     return (hintIndexb > 0);
/*      */   }
/*      */   
/*      */   static boolean yWing() {
/*      */     int j;
/*      */     int item;
/* 3003 */     for (item = j = 0; j < 9; j++) {
/* 3004 */       for (int k = 0; k < 9; k++) {
/* 3005 */         if (Grid.grid[k][j] == 0 && candidates[getStatus(k, j) / 2] == 2) {
/* 3006 */           datW[item] = new wingDat();
/* 3007 */           (datW[item]).row = j;
/* 3008 */           (datW[item]).col = k;
/* 3009 */           (datW[item]).box = k / 3 + 3 * j / 3;
/* 3010 */           (datW[item++]).dat = getStatus(k, j);
/*      */         } 
/*      */       } 
/*      */     } 
/* 3014 */     for (int i = 0; i < item; i++) {
/* 3015 */       for (j = 0; j < item; j++) {
/* 3016 */         if (i != j && (
/* 3017 */           (datW[i]).row == (datW[j]).row || (datW[i]).col == (datW[j]).col || (datW[i]).box == (datW[j]).box))
/* 3018 */           for (int k = j + 1; k < item; k++) {
/* 3019 */             if (k != i && k != j && (
/* 3020 */               (datW[i]).row == (datW[k]).row || (datW[i]).col == (datW[k]).col || (datW[i]).box == (datW[k]).box) && 
/* 3021 */               (datW[j]).row != (datW[k]).row && (datW[j]).col != (datW[k]).col && (datW[j]).box != (datW[k]).box && 
/* 3022 */               (datW[i]).dat == ((datW[i]).dat ^ (datW[j]).dat ^ (datW[i]).dat ^ (datW[k]).dat)) {
/* 3023 */               keyCandidate = ((datW[j]).dat | (datW[k]).dat) ^ (datW[i]).dat;
/* 3024 */               if ((datW[i]).box == (datW[j]).box) {
/* 3025 */                 if ((datW[i]).row == (datW[k]).row) {
/* 3026 */                   int x1 = 3 * (datW[k]).box % 3, y1 = (datW[j]).row;
/* 3027 */                   int x2 = 3 * (datW[i]).box % 3, y2 = (datW[i]).row;
/* 3028 */                   if (common(x1, y1, x2, y2, 3, 1, 0, i, j, k)) return true;
/*      */                 
/*      */                 } else {
/* 3031 */                   int x1 = (datW[j]).col, y1 = 3 * (datW[k]).box / 3;
/* 3032 */                   int x2 = (datW[i]).col, y2 = 3 * (datW[i]).box / 3;
/* 3033 */                   if (common(x1, y1, x2, y2, 3, 0, 1, i, j, k)) return true;
/*      */                 
/*      */                 } 
/* 3036 */               } else if ((datW[i]).box == (datW[k]).box) {
/* 3037 */                 if ((datW[i]).row == (datW[j]).row) {
/* 3038 */                   int x1 = 3 * (datW[j]).box % 3, y1 = (datW[k]).row;
/* 3039 */                   int x2 = 3 * (datW[i]).box % 3, y2 = (datW[i]).row;
/* 3040 */                   if (common(x1, y1, x2, y2, 3, 1, 0, i, j, k)) return true;
/*      */                 
/*      */                 } else {
/* 3043 */                   int x1 = (datW[k]).col, y1 = 3 * (datW[j]).box / 3;
/* 3044 */                   int x2 = (datW[i]).col, y2 = 3 * (datW[i]).box / 3;
/* 3045 */                   if (common(x1, y1, x2, y2, 3, 0, 1, i, j, k)) return true;
/*      */                 
/*      */                 }
/*      */               
/* 3049 */               } else if ((datW[i]).row == (datW[j]).row) {
/* 3050 */                 int x1 = (datW[j]).col, y1 = (datW[k]).row;
/* 3051 */                 if (common(x1, y1, 0, 0, 1, 0, 0, i, j, k)) return true;
/*      */               
/*      */               } else {
/* 3054 */                 int x1 = (datW[k]).col, y1 = (datW[j]).row;
/* 3055 */                 if (common(x1, y1, 0, 0, 1, 0, 0, i, j, k)) return true; 
/*      */               } 
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     } 
/* 3061 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean xyzWing() {
/* 3067 */     hintIndexb = 0;
/* 3068 */     for (int y1 = 0; y1 < 9; y1++) {
/* 3069 */       for (int x1 = 0; x1 < 9; x1++) {
/* 3070 */         if (Grid.grid[x1][y1] == 0 && candidates[getStatus(x1, y1) / 2] == 3) {
/* 3071 */           int c = 3 * x1 / 3, d = 3 * y1 / 3;
/* 3072 */           for (int y2 = 0; y2 < 3; y2++) {
/* 3073 */             for (int x2 = 0; x2 < 3; x2++) {
/* 3074 */               if (Grid.grid[c + x2][d + y2] == 0 && candidates[getStatus(c + x2, d + y2) / 2] == 2 && 
/* 3075 */                 candidates[(getStatus(x1, y1) | getStatus(c + x2, d + y2)) / 2] == 3) {
/* 3076 */                 if (y1 != d + y2)
/* 3077 */                   for (int x3 = 0; x3 < 9; x3++) {
/* 3078 */                     if (Grid.grid[x3][y1] == 0 && candidates[getStatus(x3, y1) / 2] == 2 && 
/* 3079 */                       candidates[(getStatus(x1, y1) | getStatus(x3, y1)) / 2] == 3 && 
/* 3080 */                       candidates[(getStatus(x3, y1) | getStatus(c + x2, d + y2)) / 2] == 3 && (
/* 3081 */                       x3 / 3 != (c + x2) / 3 || y1 / 3 != (d + y2) / 3)) {
/* 3082 */                       int z = getStatus(x3, y1) & getStatus(c + x2, d + y2);
/* 3083 */                       for (int b = 3 * x1 / 3, a = 0; a < 3; a++) {
/* 3084 */                         if (b + a != x1 && (getStatus(b + a, y1) & z) != 0) {
/* 3085 */                           if (Grid.findHint.booleanValue()) {
/* 3086 */                             hintXb[hintIndexb] = b + a;
/* 3087 */                             hintYb[hintIndexb++] = y1;
/* 3088 */                             setCand(b + a, y1, candidateNum(z) - 1, 1);
/*      */                           } else {
/*      */                             
/* 3091 */                             Grid.status[b + a][y1] = Grid.status[b + a][y1] ^ z;
/* 3092 */                           }  if (Grid.findHint.booleanValue() && hintIndexb > 0) {
/* 3093 */                             hintXr[0] = x1;
/* 3094 */                             hintYr[0] = y1;
/* 3095 */                             hintXg[0] = c + x2;
/* 3096 */                             hintYg[0] = d + y2;
/* 3097 */                             hintXg[1] = x3;
/* 3098 */                             hintYg[1] = y1;
/* 3099 */                             hintIndexr = 1;
/* 3100 */                             hintIndexg = 2;
/* 3101 */                             hintNum = 8;
/* 3102 */                             Grid.hintTitle = "XYZ-wing";
/* 3103 */                             Grid.hintWord[4] = "" + candidateNum(z); Grid.hintWord[3] = "" + candidateNum(z); Grid.hintWord[2] = "" + candidateNum(z); Grid.hintWord[1] = "" + candidateNum(z); Grid.hintWord[0] = "" + candidateNum(z);
/* 3104 */                             Grid.hintWrdCnt = 5;
/*      */                           } 
/* 3106 */                           return true;
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   }  
/* 3111 */                 if (x1 != c + x2)
/* 3112 */                   for (int y3 = 0; y3 < 9; y3++) {
/* 3113 */                     if (Grid.grid[x1][y3] == 0 && candidates[getStatus(x1, y3) / 2] == 2 && 
/* 3114 */                       candidates[(getStatus(x1, y1) | getStatus(x1, y3)) / 2] == 3 && 
/* 3115 */                       candidates[(getStatus(x1, y3) | getStatus(c + x2, d + y2)) / 2] == 3 && (
/* 3116 */                       x1 / 3 != (c + x2) / 3 || y3 / 3 != (d + y2) / 3)) {
/* 3117 */                       int z = getStatus(x1, y3) & getStatus(c + x2, d + y2);
/* 3118 */                       for (int b = 3 * y1 / 3, a = 0; a < 3; a++)
/* 3119 */                       { if (b + a != y1 && (getStatus(x1, b + a) & z) != 0)
/* 3120 */                         { if (Grid.findHint.booleanValue()) {
/* 3121 */                             hintXb[hintIndexb] = x1;
/* 3122 */                             hintYb[hintIndexb++] = b + a;
/* 3123 */                             setCand(x1, b + a, candidateNum(z) - 1, 1);
/*      */                           } else {
/*      */                             
/* 3126 */                             Grid.status[x1][b + a] = Grid.status[x1][b + a] ^ z;
/* 3127 */                           }  if (Grid.findHint.booleanValue() && hintIndexb > 0) {
/* 3128 */                             hintXr[0] = x1;
/* 3129 */                             hintYr[0] = y1;
/* 3130 */                             hintXg[0] = c + x2;
/* 3131 */                             hintYg[0] = d + y2;
/* 3132 */                             hintXg[1] = x1;
/* 3133 */                             hintYg[1] = y3;
/* 3134 */                             hintIndexr = 1;
/* 3135 */                             hintIndexg = 2;
/* 3136 */                             hintNum = 8;
/* 3137 */                             Grid.hintTitle = "XYZ-wing";
/* 3138 */                             Grid.hintWord[4] = "" + candidateNum(z); Grid.hintWord[3] = "" + candidateNum(z); Grid.hintWord[2] = "" + candidateNum(z); Grid.hintWord[1] = "" + candidateNum(z); Grid.hintWord[0] = "" + candidateNum(z);
/* 3139 */                             Grid.hintWrdCnt = 5;
/*      */                           } 
/* 3141 */                           return true; }  } 
/*      */                     } 
/*      */                   }  
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 3149 */     }  return false;
/*      */   }
/*      */   
/*      */   static int countBits(int bitArray) {
/* 3153 */     return candidates[bitArray];
/*      */   }
/*      */   
/*      */   static int candidateNum(int t) {
/*      */     int a;
/*      */     int c;
/* 3159 */     for (a = 1, c = 2; c < 1024 && (
/* 3160 */       t & c) != c; ) {
/*      */       c *= 2; a++;
/* 3162 */     }  return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int nextHint() {
/* 3273 */     for (int j = 0; j < 9; j++) {
/* 3274 */       for (int i = 0; i < 9; i++) {
/* 3275 */         if ((Grid.grid[i][j] != 0 && Grid.sol[i][j] != 0 && Grid.grid[i][j] != Grid.sol[i][j]) || (Grid.grid[i][j] == 0 && (
/*      */ 
/*      */ 
/*      */           
/* 3279 */           getStatus(i, j) & bit[Grid.sol[i][j] - 1]) == 0))
/* 3280 */         { hintXb[hintIndexb] = i;
/* 3281 */           hintYb[hintIndexb] = j;
/* 3282 */           hintIndexb++; } 
/*      */       } 
/* 3284 */     }  if (hintIndexb > 0) {
/* 3285 */       Grid.hintTitle = "Error in Solution";
/* 3286 */       hintNum = 0;
/* 3287 */       Grid.errorExists = Boolean.valueOf(true);
/* 3288 */       Grid.findHint = Boolean.valueOf(false);
/* 3289 */       return 0;
/*      */     } 
/*      */     
/* 3292 */     if (singleCandidate() == 1) return hintNum; 
/* 3293 */     if (singlePosition().booleanValue()) return hintNum; 
/* 3294 */     if (nakedSets(2, 2)) return hintNum; 
/* 3295 */     if (nakedSets(3, 3)) return hintNum; 
/* 3296 */     if (nakedSets(4, 4)) return hintNum; 
/* 3297 */     if (unitIntersection().booleanValue()) return hintNum; 
/* 3298 */     if (hiddenSets(2, 2).booleanValue()) return hintNum; 
/* 3299 */     if (hiddenSets(3, 3).booleanValue()) return hintNum; 
/* 3300 */     if (hiddenSets(4, 4).booleanValue()) return hintNum; 
/* 3301 */     if (xWing(2).booleanValue()) return hintNum; 
/* 3302 */     if (singlesChain(0).booleanValue()) return hintNum; 
/* 3303 */     if (singlesChain(1).booleanValue()) return hintNum; 
/* 3304 */     if (yWing()) return hintNum; 
/* 3305 */     if (xWing(3).booleanValue()) return hintNum; 
/* 3306 */     if (xyzWing()) return hintNum; 
/* 3307 */     if (singlesChain(2).booleanValue()) return hintNum; 
/* 3308 */     if (singlesChain(3).booleanValue()) return hintNum; 
/* 3309 */     if (singlesChain(4).booleanValue()) return hintNum; 
/* 3310 */     if (xWing(4).booleanValue()) return hintNum; 
/* 3311 */     Grid.hintTitle = "No Hint Available";
/* 3312 */     return 14;
/*      */   }
/*      */   
/*      */   public static boolean lastChance() {
/* 3316 */     if (Def.puzzleMode == 112)
/* 3317 */       return KsudokuBuild.cageSumEliminations(false); 
/* 3318 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long solveSudoku(int requestedLevel) {
/* 3328 */     if (Def.puzzleMode == 112) {
/* 3329 */       KsudokuSolve.setCageValues();
/*      */     } else {
/* 3331 */       recalculateStatus();
/*      */     } 
/*      */     
/* 3334 */     int difficultyAchieved = 0; while (true) {
/* 3335 */       int y; Boolean done; for (done = Boolean.valueOf(true), y = 0; y < 9; y++) {
/* 3336 */         for (int x = 0; x < 9; x++)
/* 3337 */         { if (Grid.grid[x][y] == 0)
/* 3338 */             done = Boolean.valueOf(false);  } 
/* 3339 */       }  if (done.booleanValue()) return difficultyAchieved;
/*      */       
/* 3341 */       int thisLevel = 1; long thisScore = 1L;
/* 3342 */       int result = singleCandidate();
/* 3343 */       if (result == 1) {
/* 3344 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         continue;
/*      */       } 
/* 3347 */       if (result == 2) {
/* 3348 */         return difficultyAchieved;
/*      */       }
/* 3350 */       thisLevel++; thisScore *= 2L;
/* 3351 */       if (requestedLevel < thisLevel) { if (lastChance()) continue;  return 0L; }
/* 3352 */        if (singlePosition().booleanValue()) {
/* 3353 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3357 */       thisLevel++; thisScore *= 2L;
/* 3358 */       if (requestedLevel < thisLevel) { if (lastChance()) continue;  return 0L; }
/* 3359 */        if (nakedSets(2, 2)) {
/* 3360 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3364 */       thisLevel++; thisScore *= 2L;
/* 3365 */       if (requestedLevel < thisLevel) { if (lastChance()) continue;  return 0L; }
/* 3366 */        if (nakedSets(3, 3)) {
/* 3367 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3371 */       thisLevel++; thisScore *= 2L;
/* 3372 */       if (requestedLevel < thisLevel) { if (lastChance()) continue;  return 0L; }
/* 3373 */        if (nakedSets(4, 4)) {
/* 3374 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3378 */       thisLevel++; thisScore *= 2L;
/* 3379 */       if (requestedLevel < thisLevel) { if (lastChance()) continue;  return 0L; }
/* 3380 */        if (unitIntersection().booleanValue()) {
/* 3381 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3385 */       if (Def.puzzleMode == 112 && 
/* 3386 */         KsudokuBuild.cageSumEliminations(false)) {
/*      */         continue;
/*      */       }
/* 3389 */       thisLevel++; thisScore *= 2L;
/* 3390 */       if (requestedLevel < thisLevel) return 0L; 
/* 3391 */       if (hiddenSets(2, 2).booleanValue()) {
/* 3392 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3396 */       thisLevel++; thisScore *= 2L;
/* 3397 */       if (requestedLevel < thisLevel) return 0L; 
/* 3398 */       if (hiddenSets(3, 3).booleanValue()) {
/* 3399 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3403 */       thisLevel++; thisScore *= 2L;
/* 3404 */       if (requestedLevel < thisLevel) return 0L; 
/* 3405 */       if (hiddenSets(4, 4).booleanValue()) {
/* 3406 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3410 */       thisLevel++; thisScore *= 2L;
/* 3411 */       if (requestedLevel < thisLevel) return 0L; 
/* 3412 */       if (xWing(2).booleanValue()) {
/* 3413 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3417 */       thisLevel++; thisScore *= 2L;
/* 3418 */       if (requestedLevel < thisLevel) return 0L; 
/* 3419 */       if (singlesChain(0).booleanValue()) {
/* 3420 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3424 */       thisLevel++; thisScore *= 2L;
/* 3425 */       if (requestedLevel < thisLevel) return 0L; 
/* 3426 */       if (singlesChain(1).booleanValue()) {
/* 3427 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3431 */       thisLevel++; thisScore *= 2L;
/* 3432 */       if (requestedLevel < thisLevel) return 0L; 
/* 3433 */       if (yWing()) {
/* 3434 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3438 */       thisLevel++; thisScore *= 2L;
/* 3439 */       if (requestedLevel < thisLevel) return 0L; 
/* 3440 */       if (xWing(3).booleanValue()) {
/* 3441 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3445 */       thisLevel++; thisScore *= 2L;
/* 3446 */       if (requestedLevel < thisLevel) return 0L; 
/* 3447 */       if (xyzWing()) {
/* 3448 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3452 */       thisLevel++; thisScore *= 2L;
/* 3453 */       if (requestedLevel < thisLevel) return 0L; 
/* 3454 */       if (singlesChain(2).booleanValue()) {
/* 3455 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3459 */       thisLevel++; thisScore *= 2L;
/* 3460 */       if (requestedLevel < thisLevel) return 0L; 
/* 3461 */       if (singlesChain(3).booleanValue()) {
/* 3462 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3466 */       thisLevel++; thisScore *= 2L;
/* 3467 */       if (requestedLevel < thisLevel) return 0L; 
/* 3468 */       if (singlesChain(4).booleanValue()) {
/* 3469 */         difficultyAchieved = (int)(difficultyAchieved | thisScore);
/*      */         
/*      */         continue;
/*      */       } 
/* 3473 */       thisLevel++; thisScore *= 2L;
/* 3474 */       if (requestedLevel < thisLevel) return 0L; 
/* 3475 */       if (xWing(4).booleanValue()) {
/* 3476 */         difficultyAchieved = (int)(difficultyAchieved | thisScore); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 3480 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Boolean depopulateSudoku() {
/* 3674 */     int[] v = new int[41];
/*      */     
/* 3676 */     Random r = new Random();
/*      */     
/*      */     int k;
/* 3679 */     for (k = 0; k < 41; v[k] = k++);
/* 3680 */     for (k = 0; k < 41; k++) {
/* 3681 */       int m = r.nextInt(41);
/* 3682 */       int n = v[m]; v[m] = v[k]; v[k] = n;
/*      */     } 
/*      */ 
/*      */     
/* 3686 */     for (k = 0; k < 41; k++) {
/*      */       int m;
/* 3688 */       for (m = 0; m < 9; m++) {
/* 3689 */         for (int n = 0; n < 9; n++)
/* 3690 */           Grid.grid[n][m] = Grid.puz[n][m]; 
/*      */       } 
/* 3692 */       int x = v[k] % 9; m = v[k] / 9;
/* 3693 */       int X = 8 - x, Y = 8 - m;
/* 3694 */       Grid.grid[X][Y] = 0; Grid.grid[x][m] = 0;
/*      */       
/* 3696 */       if (solveSudoku(Op.getInt(Op.SU.SuDifficulty.ordinal(), Op.su)) > 0L) {
/* 3697 */         Grid.puz[X][Y] = 0; Grid.puz[x][m] = 0;
/*      */       } 
/*      */     } 
/*      */     int y;
/* 3701 */     for (y = 0; y < 9; y++) {
/* 3702 */       for (int x = 0; x < 9; x++)
/* 3703 */         Grid.grid[x][y] = Grid.puz[x][y]; 
/* 3704 */     }  int i; long requiredScore; for (requiredScore = 1L, i = 1; i < Op.getInt(Op.SU.SuDifficulty.ordinal(), Op.su); ) { requiredScore *= 2L; i++; }
/* 3705 */      if (solveSudoku(Op.getInt(Op.SU.SuDifficulty.ordinal(), Op.su)) < requiredScore) {
/* 3706 */       return Boolean.valueOf(false);
/*      */     }
/*      */     int j;
/* 3709 */     for (k = 0, j = 0; j < 9; j++) {
/* 3710 */       for (i = 0; i < 9; i++) {
/* 3711 */         Grid.sol[i][j] = Grid.grid[i][j];
/* 3712 */         if (Grid.puz[i][j] != 0)
/* 3713 */           k++; 
/*      */       } 
/* 3715 */     }  if (k > 26) return Boolean.valueOf(false);
/*      */     
/* 3717 */     for (y = 0; y < 9; y++) {
/* 3718 */       for (int x = 0; x < 9; x++)
/* 3719 */         Grid.grid[x][y] = Grid.puz[x][y]; 
/*      */     } 
/* 3721 */     recalculateStatus();
/* 3722 */     return Boolean.valueOf(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int fillSudokuAt(int v) {
/* 3727 */     int[] r = new int[9];
/* 3728 */     Random rand = new Random();
/*      */     
/* 3730 */     if (v == 81) return 1;  int x;
/* 3731 */     for (x = 0; x < 9; r[x] = x++);
/* 3732 */     for (x = 0; x < 9; x++) {
/* 3733 */       int i = rand.nextInt(9);
/* 3734 */       int j = r[x]; r[x] = r[i]; r[i] = j;
/*      */     } 
/* 3736 */     x = v % 9; int y = v / 9;
/* 3737 */     for (int z = 0; z < 9; z++) {
/* 3738 */       int m = r[z];
/* 3739 */       if ((getStatus(x, y) & bit[m]) > 0) {
/* 3740 */         Grid.grid[x][y] = m + 1;
/* 3741 */         updateStatus(x, y, m);
/* 3742 */         if (fillSudokuAt(v + 1) == 1)
/* 3743 */           return 1; 
/* 3744 */         Grid.grid[x][y] = 0;
/* 3745 */         recalculateStatus();
/*      */       } 
/*      */     } 
/* 3748 */     return 0;
/*      */   }
/*      */   
/*      */   private void multiBuild() {
/* 3752 */     String title = Methods.puzzleTitle;
/* 3753 */     int[] diffDef = { 2, 3, 4, 5, 6, 12, 13 };
/* 3754 */     int saveDiff = Op.getInt(Op.SU.SuDifficulty.ordinal(), Op.su);
/*      */     
/* 3756 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 3757 */     Calendar c = Calendar.getInstance();
/*      */     
/* 3759 */     for (hmCount = 1; hmCount <= howMany; hmCount++) {
/* 3760 */       if (startPuz > 9999999) { try {
/* 3761 */           c.setTime(sdf.parse("" + startPuz));
/* 3762 */         } catch (ParseException ex) {}
/* 3763 */         startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 3766 */       Methods.puzzleTitle = "SUDOKU Puzzle : " + startPuz;
/* 3767 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/* 3768 */         Op.setInt(Op.SU.SuDifficulty.ordinal(), diffDef[(startPuz - 1) % 7], Op.su);
/*      */       }
/* 3770 */       Methods.buildProgress(jfSudoku, Op.su[Op.SU.SuPuz
/* 3771 */             .ordinal()] = "" + startPuz + ".sudoku");
/* 3772 */       buildSudoku();
/* 3773 */       restoreFrame();
/* 3774 */       Wait.shortWait(100);
/* 3775 */       if (Def.building == 2)
/*      */         return; 
/* 3777 */       startPuz++;
/*      */     } 
/* 3779 */     howMany = 1;
/* 3780 */     Methods.puzzleTitle = title;
/* 3781 */     Op.setInt(Op.SU.SuDifficulty.ordinal(), saveDiff, Op.su);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void buildSudoku() {
/* 3787 */     for (int loop = 0;; loop++) {
/* 3788 */       int y; for (y = 0; y < 9; y++) {
/* 3789 */         for (int x = 0; x < 9; x++)
/* 3790 */           Grid.grid[x][y] = 0; 
/* 3791 */       }  recalculateStatus();
/* 3792 */       fillSudokuAt(0);
/*      */       
/* 3794 */       for (y = 0; y < 9; y++) {
/* 3795 */         for (int x = 0; x < 9; x++)
/* 3796 */         { Grid.sol[x][y] = Grid.grid[x][y]; Grid.puz[x][y] = Grid.grid[x][y]; } 
/* 3797 */       }  if (depopulateSudoku().booleanValue())
/*      */         break; 
/* 3799 */       if (Def.building == 2) {
/*      */         return;
/*      */       }
/* 3802 */       if (loop % 500 == 0) {
/* 3803 */         restoreFrame();
/* 3804 */         Methods.buildProgress(jfSudoku, Op.su[Op.SU.SuPuz.ordinal()]);
/*      */       } 
/*      */     } 
/* 3807 */     saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/* 3808 */     undoIndex = 0;
/*      */   }
/*      */   void handleKeyPressed(KeyEvent e) {
/*      */     byte b;
/* 3812 */     if (Def.building == 1)
/* 3813 */       return;  if (e.isAltDown())
/* 3814 */       return;  switch (e.getKeyCode()) { case 38:
/* 3815 */         if (Grid.yCur > 0) Grid.yCur--;  break;
/* 3816 */       case 40: if (Grid.yCur < Grid.ySz - 1) Grid.yCur++;  break;
/* 3817 */       case 37: if (Grid.xCur > 0) Grid.xCur--;  break;
/* 3818 */       case 39: if (Grid.xCur < Grid.xSz - 1) Grid.xCur++;  break;
/* 3819 */       case 36: Grid.xCur = 0; break;
/* 3820 */       case 35: Grid.xCur = Grid.xSz - 1; break;
/* 3821 */       case 33: Grid.yCur = 0; break;
/* 3822 */       case 34: Grid.yCur = Grid.ySz - 1; break;
/*      */       case 8:
/*      */       case 127:
/* 3825 */         Grid.sol[Grid.xCur][Grid.yCur] = 0;
/* 3826 */         Grid.color[Grid.xCur][Grid.yCur] = 16777215;
/*      */         break;
/*      */       case 10:
/*      */       case 32:
/* 3830 */         Grid.grid[Grid.xCur][Grid.yCur] = 0;
/* 3831 */         recalculateStatus();
/*      */         break;
/*      */       default:
/* 3834 */         Grid.grid[Grid.xCur][Grid.yCur] = 0;
/* 3835 */         recalculateStatus();
/* 3836 */         b = (byte)(e.getKeyChar() - 48);
/* 3837 */         if (b > 0 && b <= 9 && (
/* 3838 */           getStatus(Grid.xCur, Grid.yCur) & bit[b - 1]) > 0) {
/* 3839 */           Grid.grid[Grid.xCur][Grid.yCur] = b;
/* 3840 */           Grid.color[Grid.xCur][Grid.yCur] = Op.getColorInt(Op.SU.SuHilite.ordinal(), Op.su);
/*      */         } 
/*      */         break; }
/*      */     
/* 3844 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SudokuBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */