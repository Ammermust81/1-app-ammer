/*     */ package crosswordexpress;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class SudokuSolve extends JPanel {
/*     */   static JFrame jfSolveSudoku;
/*     */   static JMenuBar menuBar;
/*     */   JMenu menu;
/*     */   JMenu submenu;
/*     */   JMenuItem menuItem;
/*     */   static JPanel pp;
/*     */   static int panelW;
/*  27 */   int[] undoX = new int[750]; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Runnable solveThread; int memMode; static boolean assist = true; static int undoIndex;
/*  28 */   int[] undoY = new int[750];
/*  29 */   int[] undoI = new int[750];
/*  30 */   int[] undoM = new int[750];
/*  31 */   int[] undoS = new int[750];
/*  32 */   static int[] bit = new int[] { 2, 4, 8, 16, 32, 64, 128, 256, 512 };
/*  33 */   static int[] invbit = new int[] { 1020, 1018, 1014, 1006, 990, 958, 894, 766, 510 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   String sudokuSolveHelp = "<div>The solving of a SUDOKU puzzle is guided by a red focus cell which can be moved about the puzzle by pointing and clicking with the mouse or by means of the cursor keys.<p/>Any character which is typed at the keyboard will be placed into the focus cell.<p/>Under default conditions, the program displays in each unsolved cell, the set of candidate symbols which might legally be placed into that cell. Whenever a solution symbol is placed into one of the cells, the list of candidate symbols in other cells is automatically updated.<p/> If you are familiar with some of the more advanced SUDOKU solving techniques (X wing, Swordfish etc), you may see that certain of the listed candidate symbols cannot possibly be a solution for the cell in which they are shown. Such candidates may be removed by pointing and clicking with the mouse. When the last candidate symbol is removed from a cell, it becomes the solution symbol for that cell.<br/><br/></div><span class='m'>Menu Functions</span><br/><br/><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose the puzzle you want to solve from the pool of SUDOKU puzzles currently available on your computer.<p/><li/><span class='menusub'>Quit Solving</span><br/>Returns you to the SUDOKU Construction screen.<p/></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.<p/><li/><span class='menusub'>Toggle Assist Mode</span><br/>If you prefer to solve these puzzles without the assistance of the candidate symbols, they can be turned on and off using this option.<p/></ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Undo</span><br/>This option will undo in reverse order, each of the operations you have done on the puzzle.<p/><li/><span>Reveal One Symbol</span><br/>If you need a little help to get started, this option will place the correct symbol into the current focus cell.<p/><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Request a Hint</span><br/>This option will highlight one or more puzzle cells in blue to indicate the location within the puzzle where further progress can be made. In addition an automatic Help screen will appear giving you a detailed description of the strategy you will need to apply.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.<p/></ul><li/><span class='s'>Help Menu</span><ul><li/><span>Sudoku Help</span><br/>Displays the Help screen which you are now reading.<p/></ul></ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SudokuSolve(JFrame jf) {
/* 104 */     this.memMode = Def.puzzleMode;
/* 105 */     Def.puzzleMode = 181;
/* 106 */     Def.dispCursor = Boolean.valueOf(true); Def.dispGuideDigits = Boolean.valueOf(true);
/* 107 */     SudokuBuild.linkDatIndex = 0;
/*     */     
/* 109 */     jfSolveSudoku = new JFrame("Sudoku");
/* 110 */     jfSolveSudoku.setSize(Op.getInt(Op.SU.SuW.ordinal(), Op.su), Op.getInt(Op.SU.SuH.ordinal(), Op.su));
/* 111 */     int frameX = (jf.getX() + jfSolveSudoku.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveSudoku.getWidth() - 10) : jf.getX();
/* 112 */     jfSolveSudoku.setLocation(frameX, jf.getY());
/* 113 */     jfSolveSudoku.setLayout((LayoutManager)null);
/* 114 */     jfSolveSudoku.setDefaultCloseOperation(0);
/* 115 */     jfSolveSudoku
/* 116 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/* 118 */             int oldw = Op.getInt(Op.SU.SuW.ordinal(), Op.su);
/* 119 */             int oldh = Op.getInt(Op.SU.SuH.ordinal(), Op.su);
/* 120 */             Methods.frameResize(SudokuSolve.jfSolveSudoku, oldw, oldh, 600, 680);
/* 121 */             Op.setInt(Op.SU.SuW.ordinal(), SudokuSolve.jfSolveSudoku.getWidth(), Op.su);
/* 122 */             Op.setInt(Op.SU.SuH.ordinal(), SudokuSolve.jfSolveSudoku.getHeight(), Op.su);
/* 123 */             SudokuSolve.restoreFrame("");
/*     */           }
/*     */         });
/*     */     
/* 127 */     jfSolveSudoku
/* 128 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 130 */             if (Def.selecting)
/* 131 */               return;  Op.saveOptions("sudoku.opt", Op.su);
/* 132 */             SudokuSolve.this.restoreIfDone();
/* 133 */             SudokuSolve.saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/* 134 */             for (int j = 0; j < Grid.ySz; j++) {
/* 135 */               for (int i = 0; i < Grid.xSz; i++)
/* 136 */                 Grid.grid[i][j] = Grid.puz[i][j]; 
/* 137 */             }  Grid.findHint = Boolean.valueOf(false);
/* 138 */             CrosswordExpress.transfer(180, SudokuSolve.jfSolveSudoku);
/*     */           }
/*     */         });
/*     */     
/* 142 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 145 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < 9; j++) {
/*     */           for (int i = 0; i < 9; i++) {
/*     */             if (Grid.grid[i][j] != Grid.sol[i][j])
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveSudoku);
/*     */       });
/* 153 */     jl1 = new JLabel(); jfSolveSudoku.add(jl1);
/* 154 */     jl2 = new JLabel(); jfSolveSudoku.add(jl2);
/*     */ 
/*     */     
/* 157 */     menuBar = new JMenuBar();
/* 158 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 159 */     jfSolveSudoku.setJMenuBar(menuBar);
/*     */     
/* 161 */     this.menu = new JMenu("File");
/* 162 */     menuBar.add(this.menu);
/* 163 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 164 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 165 */     this.menu.add(this.menuItem);
/* 166 */     this.menuItem
/* 167 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           Methods.clearHintData();
/*     */           restoreIfDone();
/*     */           saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*     */           new Select(jfSolveSudoku, "sudoku", "sudoku", Op.su, Op.SU.SuPuz.ordinal(), false);
/*     */           clearStatus();
/*     */           recalculateStatus();
/*     */         });
/* 178 */     this.menuItem = new JMenuItem("Quit Solving");
/* 179 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 180 */     this.menu.add(this.menuItem);
/* 181 */     this.menuItem
/* 182 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("sudoku.opt", Op.su);
/*     */           
/*     */           restoreIfDone();
/*     */           saveSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/*     */           for (int j = 0; j < Grid.ySz; j++) {
/*     */             for (int i = 0; i < Grid.xSz; i++) {
/*     */               Grid.grid[i][j] = Grid.puz[i][j];
/*     */             }
/*     */           } 
/*     */           Grid.findHint = Boolean.valueOf(false);
/*     */           CrosswordExpress.transfer(180, jfSolveSudoku);
/*     */         });
/* 195 */     this.menu = new JMenu("View");
/* 196 */     menuBar.add(this.menu);
/* 197 */     this.menuItem = new JMenuItem("Display Options");
/* 198 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 199 */     this.menu.add(this.menuItem);
/* 200 */     this.menuItem
/* 201 */       .addActionListener(ae -> {
/*     */           SudokuBuild.printOptions(jfSolveSudoku, "Display Options");
/*     */           
/*     */           restoreFrame("");
/*     */         });
/*     */     
/* 207 */     this.menuItem = new JMenuItem("Toggle Assist Mode");
/* 208 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(77, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 209 */     this.menu.add(this.menuItem);
/* 210 */     this.menuItem
/* 211 */       .addActionListener(ae -> {
/*     */           assist = !assist;
/*     */ 
/*     */           
/*     */           Def.dispGuideDigits = Boolean.valueOf(assist);
/*     */           
/*     */           restoreFrame("");
/*     */         });
/*     */     
/* 220 */     this.menu = new JMenu("Tasks");
/* 221 */     menuBar.add(this.menu);
/* 222 */     this.menuItem = new JMenuItem("Undo");
/* 223 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(85, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 224 */     this.menu.add(this.menuItem);
/* 225 */     this.menuItem
/* 226 */       .addActionListener(ae -> {
/*     */           Methods.clearHintData();
/*     */           
/*     */           if (undoIndex > 0) {
/*     */             do {
/*     */               undoIndex--;
/*     */               
/*     */               Grid.xCur = this.undoX[undoIndex];
/*     */               Grid.yCur = this.undoY[undoIndex];
/*     */               Grid.status[Grid.xCur][Grid.yCur] = Grid.status[Grid.xCur][Grid.yCur] | bit[this.undoI[undoIndex]];
/*     */               Grid.grid[Grid.xCur][Grid.yCur] = 0;
/*     */             } while (this.undoS[undoIndex] == 0);
/*     */           }
/*     */           restoreFrame("");
/*     */         });
/* 241 */     this.menuItem = new JMenuItem("Reveal One Symbol");
/* 242 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 243 */     this.menu.add(this.menuItem);
/* 244 */     this.menuItem
/* 245 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             char ch = (char)Grid.grid[Grid.xCur][Grid.yCur];
/*     */             
/*     */             if (ch == '\000') {
/*     */               int i = Grid.sol[Grid.xCur][Grid.yCur] - 1;
/*     */               
/*     */               Grid.grid[Grid.xCur][Grid.yCur] = Grid.sol[Grid.xCur][Grid.yCur];
/*     */               
/*     */               updateUndo(Grid.xCur, Grid.yCur, i);
/*     */               this.undoS[undoIndex - 1] = 1;
/*     */               updateSolveStatus(Grid.xCur, Grid.yCur, i);
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSudoku);
/*     */           } 
/*     */           restoreFrame("");
/*     */         });
/* 263 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 268 */     this.myTimer = new Timer(1500, errorTimer);
/* 269 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 270 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 271 */     this.menu.add(this.menuItem);
/* 272 */     this.menuItem
/* 273 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSudoku);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 284 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 285 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 286 */     this.menu.add(this.menuItem);
/* 287 */     this.menuItem
/* 288 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < 9; j++) {
/*     */               for (int i = 0; i < 9; i++) {
/*     */                 Grid.grid[i][j] = Grid.sol[i][j];
/*     */               }
/*     */             } 
/*     */             clearStatus();
/*     */             recalculateStatus();
/*     */             undoIndex = 0;
/*     */           } else {
/*     */             Methods.noReveal(jfSolveSudoku);
/*     */           } 
/*     */           restoreFrame("");
/*     */         });
/* 303 */     this.menuItem = new JMenuItem("Request a Hint");
/* 304 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(82, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 305 */     this.menu.add(this.menuItem);
/* 306 */     this.menuItem
/* 307 */       .addActionListener(ae -> {
/*     */           Grid.findHint = Boolean.valueOf(true);
/*     */           
/*     */           SudokuBuild.hintIndexb = 0;
/*     */           
/*     */           int hintNum = SudokuBuild.nextHint();
/*     */           
/*     */           Methods.closeHelp();
/*     */           String str = Methods.hintReplacements(SudokuBuild.sudokuHint[hintNum], Grid.hintWrdCnt);
/*     */           Methods.cweHelp(jfSolveSudoku, null, Grid.hintTitle, str);
/*     */           restoreFrame("");
/*     */         });
/* 319 */     this.menuItem = new JMenuItem("Begin again");
/* 320 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 321 */     this.menu.add(this.menuItem);
/* 322 */     this.menuItem
/* 323 */       .addActionListener(ae -> {
/*     */           Methods.clearHintData();
/*     */           
/*     */           clearSolution();
/*     */           
/*     */           clearStatus();
/*     */           
/*     */           recalculateStatus();
/*     */           undoIndex = 0;
/*     */           restoreFrame("");
/*     */         });
/* 334 */     this.menu = new JMenu("Help");
/* 335 */     menuBar.add(this.menu);
/* 336 */     this.menuItem = new JMenuItem("Sudoku Help");
/* 337 */     this.menu.add(this.menuItem);
/* 338 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 339 */     this.menuItem
/* 340 */       .addActionListener(ae -> Methods.cweHelp(jfSolveSudoku, null, "Solving Sudoku Puzzles", this.sudokuSolveHelp));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     loadSudoku(Op.su[Op.SU.SuPuz.ordinal()]);
/* 347 */     recalculateStatus();
/* 348 */     undoIndex = 0;
/* 349 */     pp = new SudokuSolvePP(0, 37);
/* 350 */     jfSolveSudoku.add(pp);
/*     */     
/* 352 */     pp
/* 353 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 355 */             SudokuSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 360 */     jfSolveSudoku
/* 361 */       .addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent e) {
/* 363 */             SudokuSolve.this.handleKeyPressed(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 368 */     pp
/* 369 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 371 */             if (Def.isMac) {
/* 372 */               SudokuSolve.jfSolveSudoku.setResizable((SudokuSolve.jfSolveSudoku.getWidth() - e.getX() < 15 && SudokuSolve.jfSolveSudoku
/* 373 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 378 */     restoreFrame("");
/*     */   }
/*     */   
/*     */   static void restoreFrame(String hint) {
/* 382 */     jfSolveSudoku.setVisible(true);
/* 383 */     Insets insets = jfSolveSudoku.getInsets();
/* 384 */     panelW = jfSolveSudoku.getWidth() - insets.left + insets.right;
/* 385 */     panelH = jfSolveSudoku.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 386 */     pp.setSize(panelW, panelH);
/* 387 */     setSizesAndOffsets(0, 0, panelW, panelH, 20);
/* 388 */     jfSolveSudoku.requestFocusInWindow();
/* 389 */     pp.repaint();
/* 390 */     Methods.infoPanel(jl1, jl2, "Solve Sudoku", (hint.length() > 0) ? ("  Hint : " + hint) : ("Puzzle : " + Op.su[Op.SU.SuPuz.ordinal()]), panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 394 */     int i = 2 * (width - inset) / (2 * Grid.xSz + 1);
/* 395 */     int j = 2 * (height - inset) / (2 * Grid.ySz + 1);
/* 396 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 397 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : (10 + Grid.xCell / 2));
/* 398 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : (10 + Grid.yCell / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveSudoku(String sudokuName) {
/*     */     try {
/* 405 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("sudoku/" + sudokuName));
/* 406 */       dataOut.writeInt(Grid.xSz);
/* 407 */       dataOut.writeInt(Grid.ySz);
/* 408 */       dataOut.writeByte(Methods.noReveal);
/* 409 */       dataOut.writeByte(Methods.noErrors);
/* 410 */       for (int i = 0; i < 54; i++)
/* 411 */         dataOut.writeByte(0); 
/* 412 */       for (int j = 0; j < Grid.ySz; j++) {
/* 413 */         for (int k = 0; k < Grid.xSz; k++) {
/* 414 */           dataOut.writeInt(Grid.grid[k][j]);
/* 415 */           dataOut.writeInt(Grid.puz[k][j]);
/* 416 */           dataOut.writeInt(Grid.sol[k][j]);
/* 417 */           dataOut.writeInt(Grid.color[k][j]);
/*     */         } 
/* 419 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 420 */       dataOut.writeUTF(Methods.author);
/* 421 */       dataOut.writeUTF(Methods.copyright);
/* 422 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 423 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 424 */       dataOut.close();
/*     */     }
/* 426 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadSudoku(String sudokuName) {
/*     */     try {
/* 434 */       File fl = new File("sudoku/" + sudokuName);
/* 435 */       if (!fl.exists()) {
/* 436 */         fl = new File("sudoku/");
/* 437 */         String[] s = fl.list(); int k;
/* 438 */         for (k = 0; k < s.length && (
/* 439 */           s[k].lastIndexOf(".sudoku") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 441 */         sudokuName = s[k];
/* 442 */         Op.su[Op.SU.SuPuz.ordinal()] = sudokuName;
/*     */       } 
/*     */       
/* 445 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("sudoku/" + sudokuName));
/* 446 */       Grid.xSz = dataIn.readInt();
/* 447 */       Grid.ySz = dataIn.readInt();
/* 448 */       Methods.noReveal = dataIn.readByte();
/* 449 */       Methods.noErrors = dataIn.readByte(); int i;
/* 450 */       for (i = 0; i < 54; i++)
/* 451 */         dataIn.readByte(); 
/* 452 */       for (int j = 0; j < Grid.ySz; j++) {
/* 453 */         for (i = 0; i < Grid.xSz; i++) {
/* 454 */           Grid.grid[i][j] = dataIn.readInt();
/* 455 */           Grid.puz[i][j] = dataIn.readInt();
/* 456 */           Grid.sol[i][j] = dataIn.readInt();
/* 457 */           Grid.color[i][j] = dataIn.readInt();
/*     */         } 
/* 459 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 460 */       Methods.author = dataIn.readUTF();
/* 461 */       Methods.copyright = dataIn.readUTF();
/* 462 */       Methods.puzzleNumber = dataIn.readUTF();
/* 463 */       Methods.puzzleNotes = dataIn.readUTF();
/* 464 */       dataIn.close();
/*     */     }
/* 466 */     catch (IOException exc) {}
/*     */   }
/*     */   
/*     */   void updateUndo(int x, int y, int i) {
/* 470 */     if ((Grid.status[x][y] & bit[i]) > 0) {
/* 471 */       Grid.status[x][y] = Grid.status[x][y] & invbit[i];
/* 472 */       this.undoX[undoIndex] = x;
/* 473 */       this.undoY[undoIndex] = y;
/* 474 */       this.undoI[undoIndex] = i;
/* 475 */       this.undoS[undoIndex++] = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void clearSolution() {
/* 480 */     for (int j = 0; j < 9; j++) {
/* 481 */       for (int i = 0; i < 9; i++)
/* 482 */         Grid.grid[i][j] = Grid.puz[i][j]; 
/*     */     } 
/*     */   }
/*     */   void restoreIfDone() {
/* 486 */     for (int j = 0; j < 9; j++) {
/* 487 */       for (int i = 0; i < 9; i++)
/* 488 */       { if (Grid.grid[i][j] == 0)
/*     */           return;  } 
/* 490 */     }  clearSolution();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   char updateSolveStatus(int x, int y, int i) {
/*     */     int j;
/* 497 */     for (j = 0; j < 9; j++) {
/* 498 */       updateUndo(x, y, j);
/* 499 */       updateUndo(j, y, i);
/* 500 */       updateUndo(x, j, i);
/*     */     } 
/* 502 */     int a = x / 3 * 3, b = y / 3 * 3;
/* 503 */     for (j = 0; j < 3; j++) {
/* 504 */       for (int k = 0; k < 3; k++)
/* 505 */         updateUndo(a + j, b + k, i); 
/* 506 */     }  return '\001';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void updateStatus(int x, int y, int z) {
/* 512 */     if (z == -1)
/* 513 */       return;  int a = x / 3 * 3, b = y / 3 * 3;
/* 514 */     for (int j = 0; j < 9; j++) {
/* 515 */       Grid.status[x][y] = Grid.status[x][y] & invbit[j];
/* 516 */       Grid.status[j][y] = Grid.status[j][y] & invbit[z];
/* 517 */       Grid.status[x][j] = Grid.status[x][j] & invbit[z];
/* 518 */       Grid.status[a + j % 3][b + j / 3] = Grid.status[a + j % 3][b + j / 3] & invbit[z];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void recalculateStatus() {
/*     */     int y;
/* 525 */     for (y = 0; y < 9; y++) {
/* 526 */       for (int x = 0; x < 9; x++)
/* 527 */         Grid.status[x][y] = 1022; 
/*     */     } 
/* 529 */     for (y = 0; y < 9; y++) {
/* 530 */       for (int x = 0; x < 9; x++)
/* 531 */         updateStatus(x, y, Grid.grid[x][y] - 1); 
/*     */     } 
/*     */   }
/*     */   public void clearStatus() {
/* 535 */     for (int y = 0; y < 9; y++) {
/* 536 */       for (int x = 0; x < 9; x++)
/* 537 */         Grid.status[x][y] = 0; 
/*     */     } 
/*     */   }
/*     */   void updateGrid(MouseEvent e) {
/* 541 */     int x = e.getX(), y = e.getY();
/*     */     
/* 543 */     if (x < Grid.xOrg || y < Grid.yOrg)
/* 544 */       return;  int i = (x - Grid.xOrg) / Grid.xCell;
/* 545 */     int j = (y - Grid.yOrg) / Grid.yCell;
/* 546 */     if (i >= Grid.xSz || j >= Grid.ySz)
/* 547 */       return;  Grid.xCur = i; Grid.yCur = j;
/* 548 */     if (assist) {
/* 549 */       i = (x - Grid.xOrg - i * Grid.xCell) / Grid.xCell / 3;
/* 550 */       j = (y - Grid.yOrg - j * Grid.yCell) / Grid.yCell / 3;
/* 551 */       int val = j * 3 + i;
/*     */       
/* 553 */       for (x = 0; x < SudokuBuild.candIndex; x++) {
/* 554 */         if (SudokuBuild.candx[x] == Grid.xCur && SudokuBuild.candy[x] == Grid.yCur && SudokuBuild.candv[x] == val && SudokuBuild.candc[x] == 0) {
/*     */ 
/*     */ 
/*     */           
/* 558 */           updateUndo(Grid.xCur, Grid.yCur, val);
/* 559 */           this.undoS[undoIndex - 1] = 1;
/* 560 */           Grid.grid[Grid.xCur][Grid.yCur] = val + 1;
/* 561 */           updateSolveStatus(Grid.xCur, Grid.yCur, val);
/* 562 */           (new Thread(this.solveThread)).start();
/* 563 */           restoreFrame("");
/*     */           return;
/*     */         } 
/*     */       } 
/* 567 */       if ((Grid.status[Grid.xCur][Grid.yCur] & bit[val]) > 0) {
/* 568 */         updateUndo(Grid.xCur, Grid.yCur, val);
/* 569 */         this.undoS[undoIndex - 1] = 1;
/* 570 */         if (Grid.status[Grid.xCur][Grid.yCur] == 0) {
/* 571 */           Grid.grid[Grid.xCur][Grid.yCur] = val + 1;
/* 572 */           updateSolveStatus(Grid.xCur, Grid.yCur, val);
/* 573 */           (new Thread(this.solveThread)).start();
/* 574 */           restoreFrame("");
/*     */           return;
/*     */         } 
/* 577 */         restoreFrame("");
/*     */         return;
/*     */       } 
/* 580 */       Methods.clearHintData();
/*     */     } 
/* 582 */     restoreFrame("");
/*     */   }
/*     */   void handleKeyPressed(KeyEvent e) {
/*     */     int i;
/* 586 */     if (e.isAltDown())
/* 587 */       return;  switch (e.getKeyCode()) { case 38:
/* 588 */         if (Grid.yCur > 0) Grid.yCur--;  break;
/* 589 */       case 40: if (Grid.yCur < Grid.ySz - 1) Grid.yCur++;  break;
/* 590 */       case 37: if (Grid.xCur > 0) Grid.xCur--;  break;
/* 591 */       case 39: if (Grid.xCur < Grid.xSz - 1) Grid.xCur++;  break;
/* 592 */       case 36: Grid.xCur = 0; break;
/* 593 */       case 35: Grid.xCur = Grid.xSz - 1; break;
/* 594 */       case 33: Grid.yCur = 0; break;
/* 595 */       case 34: Grid.yCur = Grid.ySz - 1; break;
/*     */       default:
/* 597 */         i = e.getKeyChar() - 49;
/* 598 */         if (i >= 0 && i < 9) {
/* 599 */           if ((Grid.status[Grid.xCur][Grid.yCur] & bit[i]) > 0) {
/* 600 */             updateUndo(Grid.xCur, Grid.yCur, i);
/* 601 */             this.undoS[undoIndex - 1] = 1;
/* 602 */             Grid.grid[Grid.xCur][Grid.yCur] = i + 1;
/* 603 */             updateSolveStatus(Grid.xCur, Grid.yCur, i);
/* 604 */             (new Thread(this.solveThread)).start();
/*     */             break;
/*     */           } 
/* 607 */           Methods.noCandidate(jfSolveSudoku);
/*     */         }  break; }
/*     */     
/* 610 */     restoreFrame("");
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\SudokuSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */