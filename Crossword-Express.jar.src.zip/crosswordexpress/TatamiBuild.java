/*      */ package crosswordexpress;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.util.Random;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class TatamiBuild extends JPanel {
/*      */   static JFrame jfTatami;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   24 */   int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date()));
/*      */   int hmCount;
/*      */   boolean sixpack;
/*   27 */   static byte[][] status = new byte[12][12];
/*   28 */   static byte[] selbit = new byte[] { 1, 2, 4, 8, 16 };
/*   29 */   static byte[] delbit = new byte[] { 30, 29, 27, 23, 15 };
/*   30 */   static byte[] mask = new byte[] { 0, 0, 0, 7, 15, 31 };
/*   31 */   static int[] theTileSize = new int[] { 0, 0, 0, 0, 0, 0, 3, 0, 4, 3, 5, 0, 4 }; static int tileSize;
/*      */   static int target;
/*   33 */   static String rules = "Fill the empty cells with the numbers 1 to <n1>. Each tile must contain exactly one of each of these digits, and each row and column of the puzzle must contain exactly <n2> of each digit.";
/*      */ 
/*      */   
/*      */   static void def() {
/*   37 */     Op.updateOption(Op.TT.TtW.ordinal(), "500", Op.tt);
/*   38 */     Op.updateOption(Op.TT.TtH.ordinal(), "580", Op.tt);
/*   39 */     Op.updateOption(Op.TT.TtAcross.ordinal(), "9", Op.tt);
/*   40 */     Op.updateOption(Op.TT.TtDown.ordinal(), "9", Op.tt);
/*   41 */     Op.updateOption(Op.TT.TtCell.ordinal(), "FFFFCC", Op.tt);
/*   42 */     Op.updateOption(Op.TT.TtGrid.ordinal(), "CCCCCC", Op.tt);
/*   43 */     Op.updateOption(Op.TT.TtTile.ordinal(), "007777", Op.tt);
/*   44 */     Op.updateOption(Op.TT.TtNumbers.ordinal(), "CC0033", Op.tt);
/*   45 */     Op.updateOption(Op.TT.TtError.ordinal(), "FF0000", Op.tt);
/*   46 */     Op.updateOption(Op.TT.TtPuz.ordinal(), "sample.tatami", Op.tt);
/*   47 */     Op.updateOption(Op.TT.TtFont.ordinal(), "SansSerif", Op.tt);
/*   48 */     Op.updateOption(Op.TT.TtPuzColor.ordinal(), "false", Op.tt);
/*   49 */     Op.updateOption(Op.TT.TtSolColor.ordinal(), "false", Op.tt);
/*      */   }
/*      */   
/*   52 */   String tatamiHelp = "<span class='m'>About TATAMI puzzles.</span><br/><div>A TATAMI puzzle consists of a square grid which has been covered with rectangular tiles which are either 3, 4 or 5 cells in area. Any given puzzle will be fully covered using tiles of only one of these sizes. To solve such a puzzle, the solver must place numbers from 1 up to the numerical size of the tile into the puzzle cells so that the following three rules are met:-<ul>  <li/>The numbers within a tile must all be different.  <li/>Horizontally or Vertically adjacent puzzle cells must not contain the same number.  <li/>Each row and column of the puzzle must contain the same number of appearances of each number.</ul>Some of the puzzle cells will have a number already inserted to get you started.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of TATAMI puzzles currently available on your computer.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>tatami</b> folder along with all of the Tatami puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</span> and <b>Copyright</span> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Print a Tatami KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted TATAMI puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Tatami Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   String tatamiOptions = "<div>The following options are available for adjustment before you start to build your Tatami puzzle:-</div><br/><ul><li/>Tatami puzzles can be made in sizes 6x6, 8x8, 9x9, 10x10 and 12x12. The required size can be selected using the <b>Puzzle Size</b> combo-box.<p/><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> check-box will disable it.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TatamiBuild(JFrame jf, boolean auto, int hm, int start) {
/*  145 */     Def.puzzleMode = 182;
/*  146 */     Def.building = 0;
/*  147 */     Def.dispCursor = Boolean.valueOf(true);
/*  148 */     makeGrid();
/*      */     
/*  150 */     jfTatami = new JFrame("Tatami");
/*  151 */     if (Op.getInt(Op.TT.TtH.ordinal(), Op.tt) > Methods.scrH - 200) {
/*  152 */       int diff = Op.getInt(Op.TT.TtH.ordinal(), Op.tt) - Op.getInt(Op.TT.TtW.ordinal(), Op.tt);
/*  153 */       Op.setInt(Op.TT.TtH.ordinal(), Methods.scrH - 200, Op.tt);
/*  154 */       Op.setInt(Op.TT.TtW.ordinal(), Methods.scrH - 200 + diff, Op.tt);
/*      */     } 
/*  156 */     jfTatami.setSize(Op.getInt(Op.TT.TtW.ordinal(), Op.tt), Op.getInt(Op.TT.TtH.ordinal(), Op.tt));
/*  157 */     int frameX = (jf.getX() + jfTatami.getWidth() > Methods.scrW) ? (Methods.scrW - jfTatami.getWidth() - 10) : jf.getX();
/*  158 */     jfTatami.setLocation(frameX, jf.getY());
/*  159 */     jfTatami.setLayout((LayoutManager)null);
/*  160 */     jfTatami.setDefaultCloseOperation(0);
/*  161 */     jfTatami
/*  162 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  164 */             int oldw = Op.getInt(Op.TT.TtW.ordinal(), Op.tt);
/*  165 */             int oldh = Op.getInt(Op.TT.TtH.ordinal(), Op.tt);
/*  166 */             Methods.frameResize(TatamiBuild.jfTatami, oldw, oldh, 500, 580);
/*  167 */             Op.setInt(Op.TT.TtW.ordinal(), TatamiBuild.jfTatami.getWidth(), Op.tt);
/*  168 */             Op.setInt(Op.TT.TtH.ordinal(), TatamiBuild.jfTatami.getHeight(), Op.tt);
/*  169 */             TatamiBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  173 */     jfTatami
/*  174 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  176 */             if (Def.building == 1 || Def.selecting)
/*  177 */               return;  Op.saveOptions("tatami.opt", Op.tt);
/*  178 */             CrosswordExpress.transfer(1, TatamiBuild.jfTatami);
/*      */           }
/*      */         });
/*      */     
/*  182 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  185 */     Runnable buildThread = () -> {
/*      */         if (this.howMany == 1) {
/*      */           makeGrid();
/*      */           
/*      */           restoreFrame();
/*      */           
/*      */           buildTatami();
/*      */         } else {
/*      */           multiBuild();
/*      */           if (this.sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfTatami.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfTatami);
/*      */           makeGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfTatami, "tatami", Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  214 */     jl1 = new JLabel(); jfTatami.add(jl1);
/*  215 */     jl2 = new JLabel(); jfTatami.add(jl2);
/*      */ 
/*      */     
/*  218 */     menuBar = new JMenuBar();
/*  219 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  220 */     jfTatami.setJMenuBar(menuBar);
/*      */     
/*  222 */     this.menu = new JMenu("File");
/*  223 */     menuBar.add(this.menu);
/*  224 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  225 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  226 */     this.menu.add(this.menuItem);
/*  227 */     this.menuItem
/*  228 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfTatami, "tatami", "tatami", Op.tt, Op.TT.TtPuz.ordinal(), false);
/*      */         });
/*  235 */     this.menuItem = new JMenuItem("SaveAs");
/*  236 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  237 */     this.menu.add(this.menuItem);
/*  238 */     this.menuItem
/*  239 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfTatami, Op.tt[Op.TT.TtPuz.ordinal()].substring(0, Op.tt[Op.TT.TtPuz.ordinal()].indexOf(".tatami")), "tatami", ".tatami");
/*      */           if (Methods.clickedOK) {
/*      */             saveTatami(Op.tt[Op.TT.TtPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfTatami, "tatami", Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  250 */     this.menuItem = new JMenuItem("Quit Construction");
/*  251 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  252 */     this.menu.add(this.menuItem);
/*  253 */     this.menuItem
/*  254 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("tatami.opt", Op.tt);
/*      */           CrosswordExpress.transfer(1, jfTatami);
/*      */         });
/*  262 */     this.menu = new JMenu("Build");
/*  263 */     menuBar.add(this.menu);
/*  264 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  265 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  266 */     this.menu.add(this.menuItem);
/*  267 */     this.menuItem
/*  268 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfTatami, Op.tt[Op.TT.TtPuz.ordinal()].substring(0, Op.tt[Op.TT.TtPuz.ordinal()].indexOf(".tatami")), "tatami", ".tatami");
/*      */           if (Methods.clickedOK) {
/*      */             Op.tt[Op.TT.TtPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  279 */     this.menuItem = new JMenuItem("Build Options");
/*  280 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  281 */     this.menu.add(this.menuItem);
/*  282 */     this.menuItem
/*  283 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           tatamiOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (this.howMany > 1)
/*      */               Op.tt[Op.TT.TtPuz.ordinal()] = "" + this.startPuz + ".tatami"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  294 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  295 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  296 */     this.menu.add(this.buildMenuItem);
/*  297 */     this.buildMenuItem
/*  298 */       .addActionListener(ae -> {
/*      */           if (Op.tt[Op.TT.TtPuz.ordinal()].length() == 0 && this.howMany == 1) {
/*      */             Methods.noName(jfTatami);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  315 */     this.menu = new JMenu("View");
/*  316 */     menuBar.add(this.menu);
/*  317 */     this.menuItem = new JMenuItem("Display Options");
/*  318 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  319 */     this.menu.add(this.menuItem);
/*  320 */     this.menuItem
/*  321 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfTatami, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  329 */     this.menu = new JMenu("Export");
/*  330 */     menuBar.add(this.menu);
/*  331 */     this.menuItem = new JMenuItem("Print a Tatami KDP puzzle book.");
/*  332 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  333 */     this.menu.add(this.menuItem);
/*  334 */     this.menuItem
/*  335 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfTatami, 182, 6);
/*      */         });
/*  342 */     this.menu = new JMenu("Tasks");
/*  343 */     menuBar.add(this.menu);
/*  344 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  345 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  346 */     this.menu.add(this.menuItem);
/*  347 */     this.menuItem
/*  348 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfTatami, Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */         });
/*  354 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  355 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  356 */     this.menu.add(this.menuItem);
/*  357 */     this.menuItem
/*  358 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(183, jfTatami);
/*      */           } else {
/*      */             Methods.noPuzzle(jfTatami, "Solve");
/*      */           } 
/*      */         });
/*  367 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  368 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  369 */     this.menu.add(this.menuItem);
/*  370 */     this.menuItem
/*  371 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfTatami, Op.tt[Op.TT.TtPuz.ordinal()], "tatami", pp)) {
/*      */             makeGrid();
/*      */             loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  382 */     this.menu = new JMenu("Help");
/*  383 */     menuBar.add(this.menu);
/*  384 */     this.menuItem = new JMenuItem("Tatami Help");
/*  385 */     this.menu.add(this.menuItem);
/*  386 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  387 */     this.menuItem
/*  388 */       .addActionListener(ae -> Methods.cweHelp(jfTatami, null, "Building Tatami Puzzles", this.tatamiHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     pp = new TatamiBuildPP(0, 37);
/*  395 */     jfTatami.add(pp);
/*      */     
/*  397 */     pp
/*  398 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  400 */             if (Def.isMac) {
/*  401 */               TatamiBuild.jfTatami.setResizable((TatamiBuild.jfTatami.getWidth() - e.getX() < 15 && TatamiBuild.jfTatami
/*  402 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  407 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*  408 */     restoreFrame();
/*      */ 
/*      */     
/*  411 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  417 */     this.myTimer = new Timer(1000, timerAL);
/*  418 */     tileSize = theTileSize[Grid.xSz];
/*      */     
/*  420 */     if (auto) {
/*  421 */       this.sixpack = true;
/*  422 */       this.howMany = hm; this.startPuz = start;
/*  423 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  428 */     jfTatami.setVisible(true);
/*  429 */     Insets insets = jfTatami.getInsets();
/*  430 */     panelW = jfTatami.getWidth() - insets.left + insets.right;
/*  431 */     panelH = jfTatami.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  432 */     pp.setSize(panelW, panelH);
/*  433 */     jfTatami.requestFocusInWindow();
/*  434 */     pp.repaint();
/*  435 */     Methods.infoPanel(jl1, jl2, "Build Tatami", "Puzzle : " + Op.tt[Op.TT.TtPuz.ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  439 */     int i = (width - inset) / Grid.xSz;
/*  440 */     int j = (height - inset) / Grid.ySz;
/*  441 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  442 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/*  443 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*      */   }
/*      */   
/*      */   private void tatamiOptions() {
/*  447 */     String[] size = { "6x6", "8x8", "9x9", "10x10", "12x12" };
/*      */     
/*  449 */     final int[] puzSize = { 6, 8, 9, 10, 12 };
/*      */ 
/*      */     
/*  452 */     final JDialog jdlgTatami = new JDialog(jfTatami, "Tatami Options", true);
/*  453 */     jdlgTatami.setSize(270, 250);
/*  454 */     jdlgTatami.setResizable(false);
/*  455 */     jdlgTatami.setLayout((LayoutManager)null);
/*  456 */     jdlgTatami.setLocation(jfTatami.getX(), jfTatami.getY());
/*      */     
/*  458 */     jdlgTatami
/*  459 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  461 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  465 */     Methods.closeHelp();
/*      */     
/*  467 */     JLabel jlSize = new JLabel("Puzzle Size:");
/*  468 */     jlSize.setForeground(Def.COLOR_LABEL);
/*  469 */     jlSize.setSize(80, 20);
/*  470 */     jlSize.setLocation(20, 8);
/*  471 */     jlSize.setHorizontalAlignment(4);
/*  472 */     jdlgTatami.add(jlSize);
/*      */     
/*  474 */     final JComboBox<String> jcbbSize = new JComboBox<>(size);
/*  475 */     jcbbSize.setSize(60, 20);
/*  476 */     jcbbSize.setLocation(120, 8);
/*  477 */     jdlgTatami.add(jcbbSize);
/*  478 */     jcbbSize.setBackground(Def.COLOR_BUTTONBG); int i;
/*  479 */     for (i = 0; puzSize[i] != Op.getInt(Op.TT.TtAcross.ordinal(), Op.tt); i++);
/*  480 */     jcbbSize.setSelectedIndex(i);
/*      */     
/*  482 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgTatami, 10, 35, this.howMany, this.startPuz, Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue());
/*      */     
/*  484 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  486 */           Grid.xSz = Grid.ySz = puzSize[jcbbSize.getSelectedIndex()];
/*  487 */           Op.setInt(Op.TT.TtAcross.ordinal(), Grid.xSz, Op.tt);
/*  488 */           Op.setInt(Op.TT.TtDown.ordinal(), Grid.ySz, Op.tt);
/*  489 */           TatamiBuild.tileSize = TatamiBuild.theTileSize[Grid.xSz];
/*  490 */           TatamiBuild.this.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  491 */           TatamiBuild.this.howMany = (TatamiBuild.this.howMany < 1) ? 1 : TatamiBuild.this.howMany;
/*  492 */           TatamiBuild.this.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  493 */           Methods.clickedOK = true;
/*  494 */           jdlgTatami.dispose();
/*  495 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  498 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 149, 80, 26);
/*  499 */     jdlgTatami.add(jbOK);
/*      */     
/*  501 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  503 */           Methods.clickedOK = false;
/*  504 */           jdlgTatami.dispose();
/*  505 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  508 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 184, 80, 26);
/*  509 */     jdlgTatami.add(jbCancel);
/*      */     
/*  511 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  513 */           Methods.cweHelp(null, jdlgTatami, "Tatami Options", TatamiBuild.this.tatamiOptions);
/*      */         }
/*      */       };
/*  516 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 100, 149, 150, 61);
/*  517 */     jdlgTatami.add(jbHelp);
/*      */     
/*  519 */     jdlgTatami.getRootPane().setDefaultButton(jbOK);
/*  520 */     Methods.setDialogSize(jdlgTatami, 260, 220);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  524 */     String[] colorLabel = { "Cell Color", "Grid Color", "Tile Color", "Number Color", "Solve Error Color" };
/*  525 */     int[] colorInt = { Op.TT.TtCell.ordinal(), Op.TT.TtGrid.ordinal(), Op.TT.TtTile.ordinal(), Op.TT.TtNumbers.ordinal(), Op.TT.TtError.ordinal() };
/*  526 */     String[] fontLabel = { "Puzzle Font" };
/*  527 */     int[] fontInt = { Op.TT.TtFont.ordinal() };
/*  528 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  529 */     int[] checkInt = { Op.TT.TtPuzColor.ordinal(), Op.TT.TtSolColor.ordinal() };
/*  530 */     Methods.stdPrintOptions(jf, "Tatami " + type, Op.tt, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void saveTatami(String tatamiName) {
/*      */     try {
/*  539 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("tatami/" + tatamiName));
/*  540 */       dataOut.writeInt(Grid.xSz);
/*  541 */       dataOut.writeInt(Grid.ySz);
/*  542 */       dataOut.writeByte(Methods.noReveal);
/*  543 */       dataOut.writeByte(Methods.noErrors);
/*  544 */       for (int i = 0; i < 54; i++)
/*  545 */         dataOut.writeByte(0); 
/*  546 */       for (int j = 0; j < Grid.ySz; j++) {
/*  547 */         for (int k = 0; k < Grid.xSz; k++) {
/*  548 */           dataOut.writeInt(Grid.mode[k][j]);
/*  549 */           dataOut.writeInt(Grid.sol[k][j]);
/*  550 */           dataOut.writeInt(Grid.copy[k][j]);
/*  551 */           dataOut.writeInt(Grid.letter[k][j]);
/*      */         } 
/*  553 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  554 */       dataOut.writeUTF(Methods.author);
/*  555 */       dataOut.writeUTF(Methods.copyright);
/*  556 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  557 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  558 */       dataOut.close();
/*      */     }
/*  560 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadTatami(String tatamiName) {
/*      */     try {
/*  568 */       File fl = new File("tatami/" + tatamiName);
/*  569 */       if (!fl.exists()) {
/*  570 */         fl = new File("tatami/");
/*  571 */         String[] s = fl.list(); int k;
/*  572 */         for (k = 0; k < s.length && (
/*  573 */           s[k].lastIndexOf(".tatami") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  575 */         if (k == s.length) { makeGrid(); return; }
/*  576 */          tatamiName = s[k];
/*  577 */         Op.tt[Op.TT.TtPuz.ordinal()] = tatamiName;
/*      */       } 
/*      */ 
/*      */       
/*  581 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("tatami/" + tatamiName));
/*  582 */       Grid.xSz = dataIn.readInt();
/*  583 */       Grid.ySz = dataIn.readInt();
/*  584 */       Methods.noReveal = dataIn.readByte();
/*  585 */       Methods.noErrors = dataIn.readByte(); int i;
/*  586 */       for (i = 0; i < 54; i++)
/*  587 */         dataIn.readByte(); 
/*  588 */       for (int j = 0; j < Grid.ySz; j++) {
/*  589 */         for (i = 0; i < Grid.xSz; i++) {
/*  590 */           Grid.mode[i][j] = dataIn.readInt();
/*  591 */           Grid.sol[i][j] = dataIn.readInt();
/*  592 */           Grid.copy[i][j] = dataIn.readInt();
/*  593 */           Grid.letter[i][j] = dataIn.readInt();
/*      */         } 
/*  595 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  596 */       Methods.author = dataIn.readUTF();
/*  597 */       Methods.copyright = dataIn.readUTF();
/*  598 */       Methods.puzzleNumber = dataIn.readUTF();
/*  599 */       Methods.puzzleNotes = dataIn.readUTF();
/*  600 */       dataIn.close();
/*      */     }
/*  602 */     catch (IOException exc) {
/*      */       return;
/*  604 */     }  tileSize = theTileSize[Grid.xSz];
/*  605 */     Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawTatami(Graphics2D g2, int[][] puzzleArray) {
/*  612 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  613 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/*  614 */     g2.setStroke(normalStroke);
/*      */     
/*  616 */     RenderingHints rh = g2.getRenderingHints();
/*  617 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  618 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  619 */     g2.setRenderingHints(rh);
/*      */     
/*      */     int j;
/*  622 */     for (j = 0; j < Grid.ySz; j++) {
/*  623 */       for (int i = 0; i < Grid.xSz; i++) {
/*  624 */         int theColor; if (Def.dispWithColor.booleanValue()) {
/*  625 */           theColor = Op.getColorInt(Op.TT.TtCell.ordinal(), Op.tt);
/*      */         } else {
/*  627 */           theColor = 16777215;
/*  628 */         }  g2.setColor(new Color(theColor));
/*  629 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*  630 */         g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtGrid.ordinal(), Op.tt)) : Def.COLOR_GRAY);
/*  631 */         g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */       } 
/*      */     } 
/*      */     
/*  635 */     g2.setStroke(wideStroke);
/*  636 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtTile.ordinal(), Op.tt)) : Def.COLOR_BLACK);
/*  637 */     for (j = 0; j < Grid.ySz; j++) {
/*  638 */       for (int i = 0; i < Grid.xSz; i++) {
/*  639 */         int x = Grid.xOrg + Grid.xCell * i;
/*  640 */         int y = Grid.yOrg + Grid.yCell * j;
/*  641 */         if (Grid.mode[i][j] == 65) {
/*  642 */           g2.drawRect(x, y, Grid.xCell * tileSize, Grid.yCell);
/*  643 */         } else if (Grid.mode[i][j] == 68) {
/*  644 */           g2.drawRect(x, y, Grid.xCell, Grid.yCell * tileSize);
/*      */         } 
/*      */       } 
/*      */     } 
/*  648 */     g2.setFont(new Font(Op.tt[Op.TT.TtFont.ordinal()], 0, 5 * Grid.yCell / 10));
/*  649 */     FontMetrics fm = g2.getFontMetrics();
/*  650 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtNumbers.ordinal(), Op.tt)) : Def.COLOR_BLACK);
/*  651 */     for (j = 0; j < Grid.ySz; j++) {
/*  652 */       for (int i = 0; i < Grid.xSz; i++) {
/*  653 */         char ch = (char)puzzleArray[i][j];
/*  654 */         if (Character.isDigit(ch)) {
/*  655 */           int w = fm.stringWidth("" + ch);
/*  656 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  662 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*  663 */     setSizesAndOffsets(left, top, width, height, 0);
/*  664 */     TatamiSolve.clearSolution();
/*  665 */     Def.dispWithColor = Op.getBool(Op.TT.TtPuzColor.ordinal(), Op.tt);
/*  666 */     boolean mem = Def.dispGuideDigits.booleanValue(); Def.dispGuideDigits = Boolean.valueOf(false);
/*  667 */     TatamiSolve.drawTatami(g2, Grid.sol);
/*  668 */     Def.dispGuideDigits = Boolean.valueOf(true);
/*  669 */     Def.dispWithColor = Boolean.valueOf(true);
/*  670 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  674 */     loadTatami(solutionPuzzle);
/*  675 */     setSizesAndOffsets(left, top, width, height, 0);
/*  676 */     Def.dispWithColor = Op.getBool(Op.TT.TtSolColor.ordinal(), Op.tt);
/*  677 */     for (int j = 0; j < Grid.ySz; j++) {
/*  678 */       for (int i = 0; i < Grid.xSz; i++)
/*  679 */         Grid.letter[i][j] = Grid.copy[i][j]; 
/*  680 */     }  drawTatami(g2, Grid.letter);
/*  681 */     Def.dispWithColor = Boolean.valueOf(true);
/*  682 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  686 */     loadTatami(solutionPuzzle);
/*  687 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  688 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  694 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  696 */     String st = Op.sx[Op.SX.SxTt.ordinal()];
/*  697 */     if (st.length() < 3) st = "TATAMI"; 
/*  698 */     int w = fm.stringWidth(st);
/*  699 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  700 */     TatamiSolve.loadTatami(puzName + ".tatami");
/*  701 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  702 */     TatamiSolve.clearSolution();
/*  703 */     TatamiSolve.drawTatami(g2, Grid.sol);
/*  704 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/*  705 */       st = rules;
/*      */     } else {
/*  707 */       st = Op.tt[Op.TT.TtRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/*  708 */     }  int n1 = theTileSize[Grid.xSz];
/*  709 */     int n2 = Grid.xSz / n1;
/*  710 */     st = st.replace("<n1>", "" + n1); st = st.replace("<n2>", "" + n2);
/*  711 */     if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/*  712 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  718 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  720 */     String st = Op.sx[Op.SX.SxTt.ordinal()];
/*  721 */     if (st.length() < 3) st = "TATAMI"; 
/*  722 */     int w = fm.stringWidth(st);
/*  723 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  724 */     loadTatami(solName + ".tatami");
/*  725 */     for (int j = 0; j < Grid.ySz; j++) {
/*  726 */       for (int i = 0; i < Grid.xSz; i++)
/*  727 */         Grid.letter[i][j] = Grid.copy[i][j]; 
/*  728 */     }  setSizesAndOffsets(left, top, dim, dim, 0);
/*  729 */     drawTatami(g2, Grid.letter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  735 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  737 */     String st = puzName;
/*  738 */     int w = fm.stringWidth(st);
/*  739 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  740 */     TatamiSolve.loadTatami(puzName + ".tatami");
/*  741 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  742 */     TatamiSolve.clearSolution();
/*  743 */     TatamiSolve.drawTatami(g2, Grid.sol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  749 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  751 */     String st = solName;
/*  752 */     int w = fm.stringWidth(st);
/*  753 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  754 */     TatamiSolve.loadTatami(solName + ".tatami");
/*  755 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  756 */     for (int j = 0; j < Grid.ySz; j++) {
/*  757 */       for (int i = 0; i < Grid.xSz; i++)
/*  758 */         Grid.letter[i][j] = Grid.copy[i][j]; 
/*  759 */     }  TatamiSolve.clearSolution();
/*  760 */     TatamiSolve.drawTatami(g2, Grid.sol);
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/*  764 */     Methods.havePuzzle = false;
/*  765 */     Grid.xSz = Op.getInt(Op.TT.TtAcross.ordinal(), Op.tt);
/*  766 */     Grid.ySz = Op.getInt(Op.TT.TtDown.ordinal(), Op.tt);
/*  767 */     Grid.clearGrid();
/*      */   }
/*      */ 
/*      */   
/*      */   static void regenStatus() {
/*      */     int j;
/*  773 */     for (j = 0; j < Grid.ySz; j++) {
/*  774 */       for (int k = 0; k < Grid.xSz; k++) {
/*  775 */         status[k][j] = mask[tileSize];
/*      */       }
/*      */     } 
/*  778 */     for (j = 0; j < Grid.ySz; j++) {
/*  779 */       for (int k = 0; k < Grid.xSz; k++) {
/*  780 */         if (Grid.mode[k][j] == 65) {
/*  781 */           for (int m = 0; m < tileSize; m++) {
/*  782 */             if (Grid.sol[k + m][j] != 0) {
/*  783 */               status[k + m][j] = 0;
/*  784 */               int v = Grid.sol[k + m][j] - 49;
/*  785 */               for (int w = 0; w < tileSize; w++) {
/*  786 */                 status[k + w][j] = (byte)(status[k + w][j] & delbit[v]);
/*      */               }
/*      */             } 
/*      */           } 
/*  790 */         } else if (Grid.mode[k][j] == 68) {
/*  791 */           for (int m = 0; m < tileSize; m++) {
/*  792 */             if (Grid.sol[k][j + m] != 0) {
/*  793 */               status[k][j + m] = 0;
/*  794 */               int v = Grid.sol[k][j + m] - 49;
/*  795 */               for (int w = 0; w < tileSize; w++)
/*  796 */                 status[k][j + w] = (byte)(status[k][j + w] & delbit[v]); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  801 */     }  for (j = 0; j < Grid.ySz; j++) {
/*  802 */       for (int k = 0; k < Grid.xSz; k++) {
/*  803 */         if (Grid.sol[k][j] != 0) {
/*  804 */           int v = Grid.sol[k][j] - 49;
/*  805 */           if (k > 0) status[k - 1][j] = (byte)(status[k - 1][j] & delbit[v]); 
/*  806 */           if (j > 0) status[k][j - 1] = (byte)(status[k][j - 1] & delbit[v]); 
/*  807 */           if (k < Grid.xSz - 1) status[k + 1][j] = (byte)(status[k + 1][j] & delbit[v]); 
/*  808 */           if (j < Grid.ySz - 1) status[k][j + 1] = (byte)(status[k][j + 1] & delbit[v]); 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     int i;
/*  813 */     for (i = 0; i < Grid.xSz; i++) {
/*  814 */       for (int k = 0; k < tileSize; k++) {
/*  815 */         int count; for (count = j = 0; j < Grid.ySz; j++) {
/*  816 */           if (Grid.sol[i][j] - 49 == k)
/*  817 */             count++; 
/*  818 */         }  if (count == target)
/*  819 */           for (j = 0; j < Grid.ySz; j++) {
/*  820 */             status[i][j] = (byte)(status[i][j] & delbit[k]);
/*      */           } 
/*      */       } 
/*      */     } 
/*  824 */     for (j = 0; j < Grid.ySz; j++) {
/*  825 */       for (int k = 0; k < tileSize; k++) {
/*  826 */         int count; for (count = i = 0; i < Grid.xSz; i++) {
/*  827 */           if (Grid.sol[i][j] - 49 == k)
/*  828 */             count++; 
/*  829 */         }  if (count == target) {
/*  830 */           for (i = 0; i < Grid.xSz; i++) {
/*  831 */             status[i][j] = (byte)(status[i][j] & delbit[k]);
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static int tatamiSolve() {
/*      */     boolean found;
/*      */     do {
/*  841 */       regenStatus(); int y;
/*  842 */       for (found = false, y = 0; y < Grid.ySz; y++) {
/*  843 */         for (int x = 0; x < Grid.xSz; x++) {
/*  844 */           if (Grid.sol[x][y] == 0)
/*  845 */             for (int z = 0; z < tileSize; z++)
/*  846 */             { if (selbit[z] == status[x][y])
/*  847 */               { Grid.sol[x][y] = z + 49;
/*  848 */                 found = true; }  }  
/*      */         } 
/*      */       } 
/*  851 */     } while (found);
/*      */ 
/*      */ 
/*      */     
/*  855 */     for (byte b = 0; b < Grid.ySz; b++) {
/*  856 */       for (int x = 0; x < Grid.xSz; x++) {
/*  857 */         if (Grid.sol[x][b] == 0)
/*  858 */           return 0; 
/*      */       } 
/*  860 */     }  return 1;
/*      */   }
/*      */   
/*      */   void depopulate() {
/*  864 */     Random r = new Random();
/*  865 */     int sz = Grid.xSz * Grid.ySz, vec[] = new int[sz];
/*      */     int i;
/*  867 */     for (i = 0; i < sz; ) { vec[i] = i; i++; }
/*  868 */      for (i = 0; i < sz; i++) {
/*  869 */       int j = r.nextInt(sz);
/*  870 */       int k = vec[i]; vec[i] = vec[j]; vec[j] = k;
/*      */     } 
/*      */     
/*  873 */     for (int v = 0; v < sz; v++) {
/*  874 */       int x = vec[v] % Grid.xSz, y = vec[v] / Grid.xSz;
/*  875 */       int mem = Grid.letter[x][y];
/*  876 */       Grid.letter[x][y] = 0;
/*      */       
/*  878 */       for (int j = 0; j < Grid.ySz; j++) {
/*  879 */         for (i = 0; i < Grid.xSz; i++)
/*  880 */           Grid.sol[i][j] = Grid.letter[i][j]; 
/*  881 */       }  if (tatamiSolve() == 0) {
/*  882 */         Grid.letter[x][y] = mem;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean insertTile() {
/*  888 */     Random r = new Random();
/*      */     
/*  890 */     for (int y = 0; y < Grid.ySz; y++) {
/*  891 */       for (int x = 0; x < Grid.xSz; x++) {
/*  892 */         if (Grid.mode[x][y] == 0)
/*  893 */         { int i; int dir; for (dir = r.nextInt(2), i = 0; i < 2; i++, dir = 1 - dir) {
/*  894 */             if ((dir != 0 || x + tileSize - 1 < Grid.xSz) && (dir != 1 || y + tileSize - 1 < Grid.ySz)) {
/*  895 */               int j; for (j = 0; j < tileSize; j++) {
/*  896 */                 if (Grid.mode[x + ((dir == 0) ? j : 0)][y + ((dir == 1) ? j : 0)] != 0)
/*      */                   break; 
/*  898 */               }  if (j >= tileSize)
/*  899 */               { for (j = 0; j < tileSize; j++)
/*  900 */                   Grid.mode[x + ((dir == 0) ? j : 0)][y + ((dir == 1) ? j : 0)] = (dir == 0) ? ((j == 0) ? 65 : 97) : ((j == 0) ? 68 : 100); 
/*  901 */                 if (insertTile())
/*  902 */                   return true; 
/*  903 */                 for (j = 0; j < tileSize; j++)
/*  904 */                   Grid.mode[x + ((dir == 0) ? j : 0)][y + ((dir == 1) ? j : 0)] = 0;  } 
/*      */             } 
/*  906 */           }  return false; } 
/*      */       } 
/*  908 */     }  return true;
/*      */   }
/*      */ 
/*      */   
/*      */   void tilePuzzle() {
/*      */     int diff;
/*      */     do {
/*  915 */       makeGrid();
/*  916 */       insertTile(); int countA, countD;
/*  917 */       for (int j = 0; j < Grid.ySz; j++) {
/*  918 */         for (int i = 0; i < Grid.xSz; i++)
/*  919 */         { if (Grid.mode[i][j] == 65)
/*  920 */           { countA++; }
/*  921 */           else if (Grid.mode[i][j] == 68)
/*  922 */           { countD++; }  } 
/*  923 */       }  diff = (countA < countD) ? (countD - countA) : (countA - countD);
/*  924 */     } while (diff >= 5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean numberTiles() {
/*  930 */     Random r = new Random();
/*  931 */     int sz = Grid.xSz * Grid.ySz;
/*      */     
/*  933 */     int count = 0; while (true) {
/*  934 */       count++;
/*  935 */       for (int x = 0; x < sz && count % 1000 != 0; count++) {
/*  936 */         int start, i = x % Grid.xSz, k = x / Grid.xSz;
/*      */         
/*  938 */         if (Grid.sol[i][k] == 0) {
/*  939 */           start = r.nextInt(tileSize);
/*  940 */           Grid.control[i][k] = 0;
/*      */         } else {
/*      */           
/*  943 */           start = (Grid.sol[i][k] - 48) % tileSize;
/*  944 */           Grid.sol[i][k] = 0;
/*      */         } 
/*  946 */         regenStatus();
/*      */         int y;
/*  948 */         for (y = 0; y < sz; y++) {
/*  949 */           int a = y % Grid.xSz, b = y / Grid.xSz;
/*  950 */           if (Grid.sol[a][b] == 0 && status[a][b] == 0)
/*      */             break; 
/*      */         } 
/*  953 */         if (y < sz) { x--; }
/*      */         else
/*  955 */         { for (; Grid.control[i][k] < tileSize; Grid.control[i][k] = (byte)(Grid.control[i][k] + 1), start = (start + 1) % tileSize) {
/*  956 */             if ((status[i][k] & selbit[start]) != 0) {
/*  957 */               Grid.sol[i][k] = start + 49; break;
/*      */             } 
/*      */           } 
/*  960 */           x += (Grid.control[i][k] == tileSize) ? -1 : 1; }
/*      */       
/*  962 */       }  if (count == 5000) return false; 
/*  963 */       if (count % 1000 == 0) {
/*  964 */         for (int b = 0; b < Grid.xSz; b++) {
/*  965 */           for (int a = 0; a < Grid.ySz; a++)
/*  966 */             Grid.sol[a][b] = 0; 
/*      */         }  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  971 */     for (int j = 0; j < Grid.xSz; j++) {
/*  972 */       for (int i = 0; i < Grid.ySz; i++)
/*  973 */         Grid.letter[i][j] = Grid.sol[i][j]; 
/*  974 */     }  return true;
/*      */   }
/*      */   
/*      */   private void multiBuild() {
/*  978 */     String title = Methods.puzzleTitle;
/*  979 */     int[] sizeDef = { 6, 9, 8, 10, 10, 12, 12 };
/*      */ 
/*      */     
/*  982 */     int acrossMem = Op.getInt(Op.TT.TtAcross.ordinal(), Op.tt);
/*  983 */     int downMem = Op.getInt(Op.TT.TtDown.ordinal(), Op.tt);
/*      */ 
/*      */     
/*  986 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/*  987 */     Calendar c = Calendar.getInstance();
/*      */     
/*  989 */     for (this.hmCount = 0; this.hmCount < this.howMany; this.hmCount++) {
/*  990 */       if (this.startPuz > 9999999) { try {
/*  991 */           c.setTime(sdf.parse("" + this.startPuz));
/*  992 */         } catch (ParseException ex) {}
/*  993 */         this.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/*  996 */       Methods.puzzleTitle = "TATAMI Puzzle : " + this.startPuz;
/*  997 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/*  998 */         Grid.xSz = Grid.ySz = sizeDef[(this.startPuz - 1) % 7];
/*  999 */         Op.setInt(Op.TT.TtAcross.ordinal(), Grid.xSz, Op.tt);
/* 1000 */         Op.setInt(Op.TT.TtDown.ordinal(), Grid.ySz, Op.tt);
/*      */       } 
/* 1002 */       Methods.buildProgress(jfTatami, Op.tt[Op.TT.TtPuz
/* 1003 */             .ordinal()] = "" + this.startPuz + ".tatami");
/* 1004 */       buildTatami();
/* 1005 */       restoreFrame();
/* 1006 */       Wait.shortWait(100);
/* 1007 */       if (Def.building == 2)
/*      */         return; 
/* 1009 */       this.startPuz++;
/*      */     } 
/* 1011 */     this.howMany = 1;
/* 1012 */     Methods.puzzleTitle = title;
/*      */     
/* 1014 */     Op.setInt(Op.TT.TtAcross.ordinal(), acrossMem, Op.tt);
/* 1015 */     Op.setInt(Op.TT.TtDown.ordinal(), downMem, Op.tt);
/*      */   }
/*      */   
/*      */   private boolean buildTatami() {
/* 1019 */     int best = 1000;
/* 1020 */     target = Grid.xSz / (tileSize = theTileSize[Grid.xSz]);
/* 1021 */     makeGrid();
/* 1022 */     for (int l = 0; l < 50; l++) {
/* 1023 */       tilePuzzle();
/* 1024 */       if (numberTiles()) {
/*      */         int j;
/* 1026 */         for (j = 0; j < Grid.ySz; j++) {
/* 1027 */           for (int i = 0; i < Grid.xSz; i++)
/* 1028 */             Grid.copy[i][j] = Grid.letter[i][j]; 
/* 1029 */         }  depopulate(); int count;
/* 1030 */         for (count = j = 0; j < Grid.ySz; j++) {
/* 1031 */           for (int i = 0; i < Grid.xSz; i++)
/* 1032 */           { if (Grid.letter[i][j] != 0)
/* 1033 */               count++;  } 
/* 1034 */         }  if (Def.building == 2)
/* 1035 */           return true; 
/* 1036 */         if (count < best) {
/* 1037 */           best = count;
/* 1038 */           for (j = 0; j < Grid.ySz; j++) {
/* 1039 */             for (int i = 0; i < Grid.xSz; i++)
/* 1040 */               Grid.sol[i][j] = Grid.letter[i][j]; 
/* 1041 */           }  saveTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/* 1042 */           restoreFrame();
/* 1043 */           Methods.buildProgress(jfTatami, Op.tt[Op.TT.TtPuz.ordinal()]);
/*      */         } 
/*      */       } 
/* 1046 */     }  loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/* 1047 */     return true;
/*      */   }
/*      */   
/*      */   void updateGrid(MouseEvent e) {
/* 1051 */     int x = e.getX(), y = e.getY();
/*      */     
/* 1053 */     if (Def.building == 1)
/* 1054 */       return;  if (x < Grid.xOrg || y < Grid.yOrg)
/* 1055 */       return;  x = (x - Grid.xOrg) / Grid.xCell;
/* 1056 */     y = (y - Grid.yOrg) / Grid.yCell;
/* 1057 */     if (x >= Grid.xSz || y >= Grid.ySz)
/*      */       return; 
/* 1059 */     Grid.xCur = x; Grid.yCur = y;
/* 1060 */     restoreFrame();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void handleKeyPressed(KeyEvent e) {
/*      */     char ch;
/* 1067 */     if (Def.building == 1)
/* 1068 */       return;  if (e.isAltDown())
/* 1069 */       return;  switch (e.getKeyCode()) { case 38:
/* 1070 */         if (Grid.yCur > 0) Grid.yCur--;  break;
/* 1071 */       case 40: if (Grid.yCur < Grid.ySz - 1) Grid.yCur++;  break;
/* 1072 */       case 37: if (Grid.xCur > 0) Grid.xCur--;  break;
/* 1073 */       case 39: if (Grid.xCur < Grid.xSz - 1) Grid.xCur++;  break;
/* 1074 */       case 36: Grid.xCur = 0; break;
/* 1075 */       case 35: Grid.xCur = Grid.xSz - 1; break;
/* 1076 */       case 33: Grid.yCur = 0; break;
/* 1077 */       case 34: Grid.yCur = Grid.ySz - 1; break;
/*      */       case 8:
/*      */       case 32:
/*      */       case 127:
/* 1081 */         if (Grid.letter[Grid.xCur][Grid.yCur] != 0) {
/* 1082 */           Grid.letter[Grid.xCur][Grid.yCur] = 0; break;
/* 1083 */         }  if (Grid.mode[Grid.xCur][Grid.yCur] == 65) {
/* 1084 */           for (int i = 0; i < tileSize; i++)
/* 1085 */             Grid.mode[Grid.xCur + i][Grid.yCur] = 0;  break;
/* 1086 */         }  if (Grid.mode[Grid.xCur][Grid.yCur] == 68)
/* 1087 */           for (int i = 0; i < tileSize; i++)
/* 1088 */             Grid.mode[Grid.xCur][Grid.yCur + i] = 0;  
/*      */         break;
/*      */       default:
/* 1091 */         ch = e.getKeyChar();
/* 1092 */         if (ch == 'A' || ch == 'a') {
/* 1093 */           if (Grid.xCur + tileSize <= Grid.xSz) {
/* 1094 */             int i; for (i = 0; i < tileSize && 
/* 1095 */               Grid.mode[Grid.xCur + i][Grid.yCur] == 0; i++);
/*      */             
/* 1097 */             if (i == tileSize)
/* 1098 */               for (i = 0; i < tileSize; i++)
/* 1099 */                 Grid.mode[Grid.xCur + i][Grid.yCur] = (i == 0) ? 65 : 97;  
/*      */           }  break;
/*      */         } 
/* 1102 */         if (ch == 'D' || ch == 'd') {
/* 1103 */           if (Grid.yCur + tileSize <= Grid.ySz) {
/* 1104 */             int i; for (i = 0; i < tileSize && 
/* 1105 */               Grid.mode[Grid.xCur][Grid.yCur + i] == 0; i++);
/*      */             
/* 1107 */             if (i == tileSize)
/* 1108 */               for (i = 0; i < tileSize; i++)
/* 1109 */                 Grid.mode[Grid.xCur][Grid.yCur + i] = (i == 0) ? 68 : 100;  
/*      */           }  break;
/*      */         } 
/* 1112 */         if (ch > '0' && ch < tileSize + 49)
/* 1113 */           Grid.letter[Grid.xCur][Grid.yCur] = ch; 
/*      */         break; }
/*      */     
/* 1116 */     restoreFrame();
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\TatamiBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */