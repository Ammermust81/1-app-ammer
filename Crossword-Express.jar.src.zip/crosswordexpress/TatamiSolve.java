/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class TatamiSolve extends JPanel {
/*  27 */   String tatamiSolve = "<div>A TATAMI puzzle consists of a square grid which has been covered with rectangular tiles which are either 3, 4 or 5 cells in area. Any given puzzle will be fully covered using tiles of only one of these sizes. To solve such a puzzle, the solver must place numbers from 1 up to the numerical size of the tile into the puzzle cells so that the following three rules are met:-<ul>  <li/>The numbers within a tile must all be different.  <li/>Horizontally or Vertically adjacent puzzle cells must not contain the same number.  <li/>Each row and column of the puzzle must contain the same number of appearances of each number.</ul>Some of the puzzle cells will have a number already inserted to get you started.<p/>Solving a TATAMI puzzle is controlled by means of a cursor cell which can be moved around the puzzle using the arrow buttons, or by clicking with the mouse. Any legal digit typed on the keyboard will be placed into the cursor cell. You can also complete the solution by removing candidate numbers from the cells by pointing and clicking with the mouse. When the last one is removed from a cell, it becomes the solution for that cell.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose the puzzle you want to solve from the pool of TATAMI puzzles currently available on your computer.<p/><li/><span>Quit Solving</span><br/>Returns you to the TATAMI Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.<p/><li/><span>Toggle Assist Mode</span><br/>If you prefer to solve these puzzles without the assistance of the candidate symbols, they can be turned on and off using this option.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Tatami Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */   
/*     */   static JFrame jfSolveTatami;
/*     */ 
/*     */   
/*     */   static JMenuBar menuBar;
/*     */ 
/*     */   
/*     */   JMenu menu;
/*     */ 
/*     */   
/*     */   JMenu submenu;
/*     */ 
/*     */   
/*     */   JMenuItem menuItem;
/*     */ 
/*     */   
/*     */   static JPanel pp;
/*     */ 
/*     */   
/*     */   static int panelW;
/*     */ 
/*     */   
/*     */   static int panelH;
/*     */ 
/*     */   
/*     */   static JLabel jl1;
/*     */ 
/*     */   
/*     */   static JLabel jl2;
/*     */ 
/*     */   
/*     */   Timer myTimer;
/*     */ 
/*     */   
/*     */   Runnable solveThread;
/*     */ 
/*     */   
/*     */   static int memMode;
/*     */ 
/*     */   
/*     */   boolean assist = true;
/*     */ 
/*     */ 
/*     */   
/*     */   TatamiSolve(JFrame jf) {
/*  74 */     memMode = Def.puzzleMode;
/*  75 */     Def.puzzleMode = 183;
/*  76 */     Def.dispCursor = Def.dispGuideDigits = Boolean.valueOf(true);
/*     */     
/*  78 */     jfSolveTatami = new JFrame("Tatami");
/*  79 */     jfSolveTatami.setSize(Op.getInt(Op.TT.TtW.ordinal(), Op.tt), Op.getInt(Op.TT.TtH.ordinal(), Op.tt));
/*  80 */     int frameX = (jf.getX() + jfSolveTatami.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveTatami.getWidth() - 10) : jf.getX();
/*  81 */     jfSolveTatami.setLocation(frameX, jf.getY());
/*  82 */     jfSolveTatami.setLayout((LayoutManager)null);
/*  83 */     jfSolveTatami.setDefaultCloseOperation(0);
/*  84 */     jfSolveTatami
/*  85 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/*  87 */             int oldw = Op.getInt(Op.TT.TtW.ordinal(), Op.tt);
/*  88 */             int oldh = Op.getInt(Op.TT.TtH.ordinal(), Op.tt);
/*  89 */             Methods.frameResize(TatamiSolve.jfSolveTatami, oldw, oldh, 500, 580);
/*  90 */             Op.setInt(Op.TT.TtW.ordinal(), TatamiSolve.jfSolveTatami.getWidth(), Op.tt);
/*  91 */             Op.setInt(Op.TT.TtH.ordinal(), TatamiSolve.jfSolveTatami.getHeight(), Op.tt);
/*  92 */             TatamiSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  96 */     jfSolveTatami
/*  97 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  99 */             if (Def.selecting)
/* 100 */               return;  Op.saveOptions("tatami.opt", Op.tt);
/* 101 */             TatamiSolve.this.restoreIfDone();
/* 102 */             TatamiSolve.saveTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/* 103 */             CrosswordExpress.transfer(182, TatamiSolve.jfSolveTatami);
/*     */           }
/*     */         });
/*     */     
/* 107 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 110 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if (Grid.sol[i][j] != Grid.copy[i][j])
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveTatami);
/*     */       });
/* 118 */     jl1 = new JLabel(); jfSolveTatami.add(jl1);
/* 119 */     jl2 = new JLabel(); jfSolveTatami.add(jl2);
/*     */ 
/*     */     
/* 122 */     menuBar = new JMenuBar();
/* 123 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 124 */     jfSolveTatami.setJMenuBar(menuBar);
/*     */     
/* 126 */     this.menu = new JMenu("File");
/* 127 */     menuBar.add(this.menu);
/* 128 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 129 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 130 */     this.menu.add(this.menuItem);
/* 131 */     this.menuItem
/* 132 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*     */           new Select(jfSolveTatami, "tatami", "tatami", Op.tt, Op.TT.TtPuz.ordinal(), false);
/*     */         });
/* 140 */     this.menuItem = new JMenuItem("Quit Solving");
/* 141 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 142 */     this.menu.add(this.menuItem);
/* 143 */     this.menuItem
/* 144 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("tatami.opt", Op.tt);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(182, jfSolveTatami);
/*     */         });
/* 153 */     this.menu = new JMenu("View");
/* 154 */     menuBar.add(this.menu);
/* 155 */     this.menuItem = new JMenuItem("Display Options");
/* 156 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 157 */     this.menu.add(this.menuItem);
/* 158 */     this.menuItem
/* 159 */       .addActionListener(ae -> {
/*     */           TatamiBuild.printOptions(jfSolveTatami, "Display Options");
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 165 */     this.menuItem = new JMenuItem("Toggle Assist Mode");
/* 166 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(77, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 167 */     this.menu.add(this.menuItem);
/* 168 */     this.menuItem
/* 169 */       .addActionListener(ae -> {
/*     */           this.assist = !this.assist;
/*     */           
/*     */           Def.dispGuideDigits = Boolean.valueOf(this.assist);
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 177 */     this.menu = new JMenu("Tasks");
/* 178 */     menuBar.add(this.menu);
/*     */     
/* 180 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 185 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 187 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 188 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 189 */     this.menu.add(this.menuItem);
/* 190 */     this.menuItem
/* 191 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveTatami);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 202 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 203 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 204 */     this.menu.add(this.menuItem);
/* 205 */     this.menuItem
/* 206 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++) {
/*     */                 Grid.sol[i][j] = Grid.copy[i][j];
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveTatami);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 218 */     this.menuItem = new JMenuItem("Begin again");
/* 219 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 220 */     this.menu.add(this.menuItem);
/* 221 */     this.menuItem
/* 222 */       .addActionListener(ae -> {
/*     */           for (int j = 0; j < Grid.ySz; j++) {
/*     */             for (int i = 0; i < Grid.ySz; i++) {
/*     */               Grid.sol[i][j] = Grid.letter[i][j];
/*     */             }
/*     */           } 
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 231 */     this.menu = new JMenu("Help");
/* 232 */     menuBar.add(this.menu);
/* 233 */     this.menuItem = new JMenuItem("Tatami Help");
/* 234 */     this.menu.add(this.menuItem);
/* 235 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 236 */     this.menuItem
/* 237 */       .addActionListener(ae -> Methods.cweHelp(jfSolveTatami, null, "Solving Tatami Puzzles", this.tatamiSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     loadTatami(Op.tt[Op.TT.TtPuz.ordinal()]);
/* 244 */     pp = new TatamiSolvePP(0, 37);
/* 245 */     jfSolveTatami.add(pp);
/*     */     
/* 247 */     pp
/* 248 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 250 */             TatamiSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 255 */     pp
/* 256 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 258 */             if (Def.isMac) {
/* 259 */               TatamiSolve.jfSolveTatami.setResizable((TatamiSolve.jfSolveTatami.getWidth() - e.getX() < 15 && TatamiSolve.jfSolveTatami
/* 260 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 266 */     jfSolveTatami
/* 267 */       .addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent e) {
/* 269 */             TatamiSolve.this.handleKeyPressed(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 274 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 278 */     jfSolveTatami.setVisible(true);
/* 279 */     Insets insets = jfSolveTatami.getInsets();
/* 280 */     panelW = jfSolveTatami.getWidth() - insets.left + insets.right;
/* 281 */     panelH = jfSolveTatami.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 282 */     pp.setSize(panelW, panelH);
/* 283 */     jfSolveTatami.requestFocusInWindow();
/* 284 */     pp.repaint();
/* 285 */     Methods.infoPanel(jl1, jl2, "Solve Tatami", "Puzzle : " + Op.tt[Op.TT.TtPuz.ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 289 */     int i = (width - inset) / Grid.xSz;
/* 290 */     int j = (height - inset) / Grid.ySz;
/* 291 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 292 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/* 293 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveTatami(String tatamiName) {
/*     */     try {
/* 299 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("tatami/" + tatamiName));
/* 300 */       dataOut.writeInt(Grid.xSz);
/* 301 */       dataOut.writeInt(Grid.ySz);
/* 302 */       dataOut.writeByte(Methods.noReveal);
/* 303 */       dataOut.writeByte(Methods.noErrors);
/* 304 */       for (int i = 0; i < 54; i++)
/* 305 */         dataOut.writeByte(0); 
/* 306 */       for (int j = 0; j < Grid.ySz; j++) {
/* 307 */         for (int k = 0; k < Grid.xSz; k++) {
/* 308 */           dataOut.writeInt(Grid.mode[k][j]);
/* 309 */           dataOut.writeInt(Grid.sol[k][j]);
/* 310 */           dataOut.writeInt(Grid.copy[k][j]);
/* 311 */           dataOut.writeInt(Grid.letter[k][j]);
/*     */         } 
/* 313 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 314 */       dataOut.writeUTF(Methods.author);
/* 315 */       dataOut.writeUTF(Methods.copyright);
/* 316 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 317 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 318 */       dataOut.close();
/*     */     }
/* 320 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadTatami(String tatamiName) {
/*     */     try {
/* 328 */       File fl = new File("tatami/" + tatamiName);
/* 329 */       if (!fl.exists()) {
/* 330 */         fl = new File("tatami/");
/* 331 */         String[] s = fl.list(); int m;
/* 332 */         for (m = 0; m < s.length && (
/* 333 */           s[m].lastIndexOf(".tatami") == -1 || s[m].charAt(0) == '.'); m++);
/*     */         
/* 335 */         tatamiName = s[m];
/* 336 */         Op.tt[Op.TT.TtPuz.ordinal()] = tatamiName;
/*     */       } 
/*     */ 
/*     */       
/* 340 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("tatami/" + tatamiName));
/* 341 */       Grid.xSz = dataIn.readInt();
/* 342 */       Grid.ySz = dataIn.readInt();
/* 343 */       Methods.noReveal = dataIn.readByte();
/* 344 */       Methods.noErrors = dataIn.readByte(); int i;
/* 345 */       for (i = 0; i < 54; i++)
/* 346 */         dataIn.readByte(); 
/* 347 */       for (int k = 0; k < Grid.ySz; k++) {
/* 348 */         for (i = 0; i < Grid.xSz; i++) {
/* 349 */           Grid.mode[i][k] = dataIn.readInt();
/* 350 */           Grid.sol[i][k] = dataIn.readInt();
/* 351 */           Grid.copy[i][k] = dataIn.readInt();
/* 352 */           Grid.letter[i][k] = dataIn.readInt();
/*     */         } 
/* 354 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 355 */       Methods.author = dataIn.readUTF();
/* 356 */       Methods.copyright = dataIn.readUTF();
/* 357 */       Methods.puzzleNumber = dataIn.readUTF();
/* 358 */       Methods.puzzleNotes = dataIn.readUTF();
/* 359 */       dataIn.close();
/*     */     }
/* 361 */     catch (IOException exc) {
/*     */       return;
/* 363 */     }  TatamiBuild.target = Grid.xSz / (TatamiBuild.tileSize = TatamiBuild.theTileSize[Grid.xSz]);
/* 364 */     for (int j = 0; j < Grid.ySz; j++) {
/* 365 */       for (int i = 0; i < Grid.xSz; i++) {
/* 366 */         TatamiBuild.status[i][j] = TatamiBuild.mask[TatamiBuild.tileSize];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void drawTatami(Graphics2D g2, int[][] puzzleArray) {
/* 373 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/* 374 */     Stroke wideStroke = new BasicStroke(Grid.xCell / 10.0F, 2, 2);
/* 375 */     g2.setStroke(normalStroke);
/*     */     
/* 377 */     RenderingHints rh = g2.getRenderingHints();
/* 378 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 379 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 380 */     g2.setRenderingHints(rh);
/*     */     
/*     */     int j;
/* 383 */     for (j = 0; j < Grid.ySz; j++) {
/* 384 */       for (int i = 0; i < Grid.xSz; i++) {
/* 385 */         int theColor; if (Def.dispWithColor.booleanValue()) {
/* 386 */           if (Def.dispErrors.booleanValue() && Grid.sol[i][j] != 0 && Grid.sol[i][j] != Grid.copy[i][j]) {
/* 387 */             theColor = Op.getColorInt(Op.TT.TtError.ordinal(), Op.tt);
/*     */           } else {
/*     */             
/* 390 */             theColor = Op.getColorInt(Op.TT.TtCell.ordinal(), Op.tt);
/*     */           } 
/*     */         } else {
/* 393 */           theColor = 16777215;
/* 394 */         }  g2.setColor(new Color(theColor));
/* 395 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/* 396 */         g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtGrid.ordinal(), Op.tt)) : Def.COLOR_GRAY);
/* 397 */         g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */       } 
/*     */     } 
/*     */     
/* 401 */     g2.setStroke(wideStroke);
/* 402 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtTile.ordinal(), Op.tt)) : Def.COLOR_BLACK);
/* 403 */     for (j = 0; j < Grid.ySz; j++) {
/* 404 */       for (int i = 0; i < Grid.xSz; i++) {
/* 405 */         int x = Grid.xOrg + Grid.xCell * i;
/* 406 */         int y = Grid.yOrg + Grid.yCell * j;
/* 407 */         if (Grid.mode[i][j] == 65) {
/* 408 */           g2.drawRect(x, y, Grid.xCell * TatamiBuild.tileSize, Grid.yCell);
/* 409 */         } else if (Grid.mode[i][j] == 68) {
/* 410 */           g2.drawRect(x, y, Grid.xCell, Grid.yCell * TatamiBuild.tileSize);
/*     */         } 
/*     */       } 
/*     */     } 
/* 414 */     g2.setFont(new Font(Op.tt[Op.TT.TtFont.ordinal()], 0, 5 * Grid.yCell / 10));
/* 415 */     FontMetrics fm = g2.getFontMetrics();
/* 416 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TT.TtNumbers.ordinal(), Op.tt)) : Def.COLOR_BLACK);
/* 417 */     for (j = 0; j < Grid.ySz; j++) {
/* 418 */       for (int i = 0; i < Grid.xSz; i++) {
/* 419 */         char ch = (char)puzzleArray[i][j];
/* 420 */         if (Character.isDigit(ch)) {
/* 421 */           int w = fm.stringWidth("" + ch);
/* 422 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 427 */     if (Def.dispCursor.booleanValue()) {
/* 428 */       g2.setStroke(wideStroke);
/* 429 */       g2.setColor(Def.COLOR_RED);
/* 430 */       g2.drawRect(Grid.xOrg + Grid.xCur * Grid.xCell, Grid.yOrg + Grid.yCur * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */     } 
/*     */     
/* 433 */     if (!Def.dispGuideDigits.booleanValue())
/* 434 */       return;  g2.setFont(new Font("Sans-Serif", 0, Grid.yCell / 5));
/* 435 */     g2.setColor(Color.BLACK);
/* 436 */     fm = g2.getFontMetrics();
/* 437 */     for (j = 0; j < Grid.ySz; j++) {
/* 438 */       for (int i = 0; i < Grid.xSz; i++) {
/* 439 */         if (Grid.sol[i][j] == 0)
/* 440 */           for (int k = 0; k < TatamiBuild.tileSize; k++) {
/* 441 */             if ((TatamiBuild.status[i][j] & TatamiBuild.selbit[k]) != 0) {
/* 442 */               int w = (Grid.xCell / 3 - fm.stringWidth("" + (k + 1))) / 2;
/* 443 */               g2.drawString("" + (k + 1), Grid.xOrg + i * Grid.xCell + Grid.xCell * k % 3 / 3 + w, Grid.yOrg + j * Grid.yCell + Grid.yCell * (1 + k / 3) / 4 + fm.getAscent());
/*     */             } 
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   } static void clearSolution() {
/* 449 */     for (int j = 0; j < Grid.ySz; j++) {
/* 450 */       for (int i = 0; i < Grid.xSz; i++)
/* 451 */         Grid.sol[i][j] = Grid.letter[i][j]; 
/*     */     } 
/*     */   }
/*     */   void restoreIfDone() {
/* 455 */     for (int j = 0; j < Grid.ySz; j++) {
/* 456 */       for (int i = 0; i < Grid.xSz; i++)
/* 457 */       { if (Grid.sol[i][j] != Grid.copy[i][j])
/*     */           return;  } 
/* 459 */     }  clearSolution();
/*     */   }
/*     */   
/*     */   void updateGrid(MouseEvent e) {
/* 463 */     int x = e.getX(), y = e.getY();
/*     */     
/* 465 */     if (x < Grid.xOrg || y < Grid.yOrg)
/* 466 */       return;  int i = (x - Grid.xOrg) / Grid.xCell;
/* 467 */     int j = (y - Grid.yOrg) / Grid.yCell;
/* 468 */     if (i >= Grid.xSz || j >= Grid.ySz)
/*     */       return; 
/* 470 */     Grid.xCur = i; Grid.yCur = j;
/*     */     
/* 472 */     if (Grid.sol[Grid.xCur][Grid.yCur] == 0) {
/* 473 */       i = (x - Grid.xOrg - i * Grid.xCell) / Grid.xCell / 3;
/* 474 */       j = (y - Grid.yOrg - j * Grid.yCell) / Grid.yCell / 4 - 1;
/* 475 */       int val = i + 3 * j;
/* 476 */       if (val >= 0 && val < TatamiBuild.tileSize)
/* 477 */         TatamiBuild.status[Grid.xCur][Grid.yCur] = (byte)(TatamiBuild.status[Grid.xCur][Grid.yCur] & TatamiBuild.delbit[val]); 
/* 478 */       if (TatamiBuild.status[Grid.xCur][Grid.yCur] == 0)
/* 479 */         Grid.sol[Grid.xCur][Grid.yCur] = (byte)(val + 49); 
/*     */     } 
/* 481 */     (new Thread(this.solveThread)).start();
/* 482 */     pp.repaint();
/*     */   }
/*     */   void handleKeyPressed(KeyEvent e) {
/*     */     char ch;
/* 486 */     if (e.isAltDown())
/* 487 */       return;  switch (e.getKeyCode()) { case 38:
/* 488 */         if (Grid.yCur > 0) Grid.yCur--;  break;
/* 489 */       case 40: if (Grid.yCur < Grid.ySz - 1) Grid.yCur++;  break;
/* 490 */       case 37: if (Grid.xCur > 0) Grid.xCur--;  break;
/* 491 */       case 39: if (Grid.xCur < Grid.xSz - 1) Grid.xCur++;  break;
/* 492 */       case 36: Grid.xCur = 0; break;
/* 493 */       case 35: Grid.xCur = Grid.xSz - 1; break;
/* 494 */       case 33: Grid.yCur = 0; break;
/* 495 */       case 34: Grid.yCur = Grid.ySz - 1; break;
/*     */       case 8:
/*     */       case 10:
/*     */       case 32:
/*     */       case 127:
/* 500 */         Grid.sol[Grid.xCur][Grid.yCur] = 0;
/*     */         break;
/*     */       default:
/* 503 */         ch = e.getKeyChar();
/* 504 */         if (ch > '0' && ch < TatamiBuild.tileSize + 49)
/* 505 */           Grid.sol[Grid.xCur][Grid.yCur] = ch; 
/*     */         break; }
/*     */     
/* 508 */     (new Thread(this.solveThread)).start();
/* 509 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\TatamiSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */