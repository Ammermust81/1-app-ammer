/*      */ package crosswordexpress;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public class TentsBuild {
/*      */   static JFrame jfTents;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   23 */   static int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Thread thread; static int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date())); static int hmCount; static int mazeID;
/*      */   static boolean sixpack;
/*   25 */   static int GRASS = 0; static int TREE = 1; static int NOTENT = 2; static int TENT = 3; static int NONTREE = 4;
/*   26 */   static String rules = "Place tents into vacant squares so that each tent is next to a tree, either horizontally or vertically, and every tree has a tent either horizontally or vertically. Tents must not be placed in squares which contact each other on either the sides or the corners. The number at the side and bottom tell you the number of tents in each row and column.";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   31 */   String tentsHelp = "<div>A Crossword Express <b>TENTS</b> puzzle consists of a square or rectangular array of squares in which some of the squares contain a tree, with the remainder containing only grass. The puzzle is solved by placing tents into selected grassy squares so that each tree has its own tent (either horizontally or vertically), and each tent has its own tree (either horizontally or vertically). The squares in which tents are placed must not touch on either the sides or the corners. Numbers located to the side and to the bottom of the puzzle tell you how many tents are in each row and column. The Crossword Express <b>TENTS</b> construction function allows you to build puzzles in sizes from 5x5 up to 16x16.<br/><br/></div><span class='parhead'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose your puzzle from the pool of TENTS puzzles currently available on your computer.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the <b>tents</b> folder along with all of the Tents puzzles you have made. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Export Menu</span><br/><ul><li/><span>Print a Tents KDP puzzle book.</span><br/>The letters KDP stand for <b>Kindle Direct Publishing</b>. This is a free publishing service operared by Amazon, in which they handle all matters related to printing, advertising and sales of books created by members of the public. A portion of the proceeds are retained by Amazon while the remainder is paid to the author. Fifteen of the Puzzles created by Crossword Express can be printed into PDF format files ready for publication by Amazon. When you select this option, you will be presented with a dialog which allows you to control the process. Please study the Help offered by this dialog before attempting to make use of it.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print this Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted TENTS puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Tents Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   String tentsOptions = "<div>Before you give the command to build the <b>Tents</b> puzzle, you can set some options which the program will use during the construction process.</div><br/><ul><li/><b>Difficulty:</b> Select the difficulty level to be used for your puzzle. The difficulty can be varied by means of a slider control, and can be set to any of seven different difficulty settings.<p/><li/>Tents puzzles can be made in sizes ranging from 5x5 up to 16x16. This can be controlled using the <b>Cells Across</b> and <b>Cells Down</b> combo-boxes.<p/><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>If you do choose to make multiple puzzles, then by default, Crossword Express will change the difficulty of the resulting puzzles over a cycle of seven puzzles. This would be useful for a daily newspaper so that the week could start with a very easy puzzle, with quite difficult puzzles reserved for the weekend. If you don't want this feature, clearing the <b>Vary Difficulty on 7 day cycle</b> checkbox will disable it.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void def() {
/*  122 */     Op.updateOption(Op.TE.TeW.ordinal(), "500", Op.te);
/*  123 */     Op.updateOption(Op.TE.TeH.ordinal(), "580", Op.te);
/*  124 */     Op.updateOption(Op.TE.TeAcross.ordinal(), "9", Op.te);
/*  125 */     Op.updateOption(Op.TE.TeDown.ordinal(), "9", Op.te);
/*  126 */     Op.updateOption(Op.TE.TeDifficulty.ordinal(), "2", Op.te);
/*  127 */     Op.updateOption(Op.TE.TeCell.ordinal(), "779977", Op.te);
/*  128 */     Op.updateOption(Op.TE.TeLine.ordinal(), "000000", Op.te);
/*  129 */     Op.updateOption(Op.TE.TeTree.ordinal(), "005500", Op.te);
/*  130 */     Op.updateOption(Op.TE.TeTrunk.ordinal(), "444400", Op.te);
/*  131 */     Op.updateOption(Op.TE.TeTent.ordinal(), "AAAA77", Op.te);
/*  132 */     Op.updateOption(Op.TE.TeCount.ordinal(), "000088", Op.te);
/*  133 */     Op.updateOption(Op.TE.TeError.ordinal(), "FF0000", Op.te);
/*  134 */     Op.updateOption(Op.TE.TePuz.ordinal(), "sample.tents", Op.te);
/*  135 */     Op.updateOption(Op.TE.TeCountFont.ordinal(), "SansSerif", Op.te);
/*  136 */     Op.updateOption(Op.TE.TePuzColor.ordinal(), "false", Op.te);
/*  137 */     Op.updateOption(Op.TE.TeSolColor.ordinal(), "false", Op.te);
/*      */   }
/*      */   
/*      */   TentsBuild(JFrame jf, boolean auto, int hm, int start) {
/*  141 */     Def.puzzleMode = 190;
/*  142 */     Def.building = 0;
/*  143 */     Def.dispCursor = Boolean.valueOf(true);
/*      */     
/*  145 */     makeGrid();
/*      */     
/*  147 */     jfTents = new JFrame("Tents");
/*  148 */     if (Op.getInt(Op.TE.TeH.ordinal(), Op.te) > Methods.scrH - 200) {
/*  149 */       int diff = Op.getInt(Op.TE.TeH.ordinal(), Op.te) - Op.getInt(Op.TE.TeW.ordinal(), Op.te);
/*  150 */       Op.setInt(Op.TE.TeH.ordinal(), Methods.scrH - 200, Op.te);
/*  151 */       Op.setInt(Op.TE.TeW.ordinal(), Methods.scrH - 200 + diff, Op.te);
/*      */     } 
/*  153 */     jfTents.setSize(Op.getInt(Op.TE.TeW.ordinal(), Op.te), Op.getInt(Op.TE.TeH.ordinal(), Op.te));
/*  154 */     int frameX = (jf.getX() + jfTents.getWidth() > Methods.scrW) ? (Methods.scrW - jfTents.getWidth() - 10) : jf.getX();
/*  155 */     jfTents.setLocation(frameX, jf.getY());
/*  156 */     jfTents.setLayout((LayoutManager)null);
/*  157 */     jfTents.setDefaultCloseOperation(0);
/*  158 */     jfTents
/*  159 */       .addComponentListener(new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent ce) {
/*  161 */             int oldw = Op.getInt(Op.TE.TeW.ordinal(), Op.te);
/*  162 */             int oldh = Op.getInt(Op.TE.TeH.ordinal(), Op.te);
/*  163 */             Methods.frameResize(TentsBuild.jfTents, oldw, oldh, 500, 580);
/*  164 */             Op.setInt(Op.TE.TeW.ordinal(), TentsBuild.jfTents.getWidth(), Op.te);
/*  165 */             Op.setInt(Op.TE.TeH.ordinal(), TentsBuild.jfTents.getHeight(), Op.te);
/*  166 */             TentsBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */     
/*  170 */     jfTents
/*  171 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  173 */             if (Def.building == 1 || Def.selecting)
/*  174 */               return;  Op.saveOptions("tents.opt", Op.te);
/*  175 */             CrosswordExpress.transfer(1, TentsBuild.jfTents);
/*      */           }
/*      */         });
/*      */     
/*  179 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  182 */     Runnable buildThread = () -> {
/*      */         if (howMany == 1) {
/*      */           buildTents();
/*      */           
/*      */           if (Def.building != 2) {
/*      */             saveTents(Op.te[Op.TE.TePuz.ordinal()]);
/*      */           }
/*      */         } else {
/*      */           multiBuild();
/*      */           if (sixpack) {
/*      */             Sixpack.trigger();
/*      */             jfTents.dispose();
/*      */             Def.building = 0;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         if (Def.building == 2) {
/*      */           Def.building = 0;
/*      */           Methods.interrupted(jfTents);
/*      */           makeGrid();
/*      */           restoreFrame();
/*      */           return;
/*      */         } 
/*      */         Methods.havePuzzle = true;
/*      */         restoreFrame();
/*      */         Methods.puzzleSaved(jfTents, "tents", Op.te[Op.TE.TePuz.ordinal()]);
/*      */         Def.building = 0;
/*      */       };
/*  211 */     jl1 = new JLabel(); jfTents.add(jl1);
/*  212 */     jl2 = new JLabel(); jfTents.add(jl2);
/*      */ 
/*      */     
/*  215 */     menuBar = new JMenuBar();
/*  216 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  217 */     jfTents.setJMenuBar(menuBar);
/*      */     
/*  219 */     this.menu = new JMenu("File");
/*  220 */     menuBar.add(this.menu);
/*  221 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  222 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  223 */     this.menu.add(this.menuItem);
/*  224 */     this.menuItem
/*  225 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfTents, "tents", "tents", Op.te, Op.TE.TePuz.ordinal(), false);
/*      */         });
/*  232 */     this.menuItem = new JMenuItem("SaveAs");
/*  233 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  234 */     this.menu.add(this.menuItem);
/*  235 */     this.menuItem
/*  236 */       .addActionListener(ae -> {
/*      */           Methods.puzzleDescriptionDialog(jfTents, Op.te[Op.TE.TePuz.ordinal()].substring(0, Op.te[Op.TE.TePuz.ordinal()].indexOf(".tents")), "tents", ".tents");
/*      */           
/*      */           if (Methods.clickedOK) {
/*      */             saveTents(Op.te[Op.TE.TePuz.ordinal()] = Methods.theFileName);
/*      */             
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfTents, "tents", Op.te[Op.TE.TePuz.ordinal()]);
/*      */           } 
/*      */         });
/*  246 */     this.menuItem = new JMenuItem("Quit Construction");
/*  247 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  248 */     this.menu.add(this.menuItem);
/*  249 */     this.menuItem
/*  250 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("tents.opt", Op.te);
/*      */           CrosswordExpress.transfer(1, jfTents);
/*      */         });
/*  258 */     this.menu = new JMenu("Build");
/*  259 */     menuBar.add(this.menu);
/*  260 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  261 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  262 */     this.menu.add(this.menuItem);
/*  263 */     this.menuItem
/*  264 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Methods.puzzleDescriptionDialog(jfTents, Op.te[Op.TE.TePuz.ordinal()].substring(0, Op.te[Op.TE.TePuz.ordinal()].indexOf(".tents")), "tents", ".tents");
/*      */           if (Methods.clickedOK) {
/*      */             Op.te[Op.TE.TePuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  275 */     this.menuItem = new JMenuItem("Build Options");
/*  276 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  277 */     this.menu.add(this.menuItem);
/*  278 */     this.menuItem
/*  279 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           tentsOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             if (howMany > 1)
/*      */               Op.te[Op.TE.TePuz.ordinal()] = "" + startPuz + ".tents"; 
/*      */           } 
/*      */           restoreFrame();
/*      */         });
/*  290 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  291 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  292 */     this.menu.add(this.buildMenuItem);
/*  293 */     this.buildMenuItem
/*  294 */       .addActionListener(ae -> {
/*      */           if (Op.te[Op.TE.TePuz.ordinal()].length() == 0 && howMany == 1) {
/*      */             Methods.noName(jfTents);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  311 */     this.menu = new JMenu("View");
/*  312 */     menuBar.add(this.menu);
/*  313 */     this.menuItem = new JMenuItem("Display Options");
/*  314 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  315 */     this.menu.add(this.menuItem);
/*  316 */     this.menuItem
/*  317 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfTents, "Display Options");
/*      */           restoreFrame();
/*      */         });
/*  325 */     this.menu = new JMenu("Export");
/*  326 */     menuBar.add(this.menu);
/*  327 */     this.menuItem = new JMenuItem("Print a Tents KDP puzzle book.");
/*  328 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  329 */     this.menu.add(this.menuItem);
/*  330 */     this.menuItem
/*  331 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.printKdpDialog(jfTents, 190, 6);
/*      */         });
/*  338 */     this.menu = new JMenu("Tasks");
/*  339 */     menuBar.add(this.menu);
/*  340 */     this.menuItem = new JMenuItem("Print this Puzzle");
/*  341 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  342 */     this.menu.add(this.menuItem);
/*  343 */     this.menuItem
/*  344 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           CrosswordExpress.toPrint(jfTents, Op.te[Op.TE.TePuz.ordinal()]);
/*      */         });
/*  350 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  351 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  352 */     this.menu.add(this.menuItem);
/*  353 */     this.menuItem
/*  354 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1)
/*      */             return; 
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(191, jfTents);
/*      */           } else {
/*      */             Methods.noPuzzle(jfTents, "Solve");
/*      */           } 
/*      */         });
/*  363 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  364 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  365 */     this.menu.add(this.menuItem);
/*  366 */     this.menuItem
/*  367 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfTents, Op.te[Op.TE.TePuz.ordinal()], "tents", pp)) {
/*      */             makeGrid();
/*      */             loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  378 */     this.menu = new JMenu("Help");
/*  379 */     menuBar.add(this.menu);
/*  380 */     this.menuItem = new JMenuItem("Tents Help");
/*  381 */     this.menu.add(this.menuItem);
/*  382 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  383 */     this.menuItem
/*  384 */       .addActionListener(ae -> Methods.cweHelp(jfTents, null, "Building Tents Puzzles", this.tentsHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  390 */     pp = new TentsBuildPP(0, 37);
/*  391 */     jfTents.add(pp);
/*      */     
/*  393 */     pp
/*  394 */       .addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent e) {
/*  396 */             TentsBuild.this.updateGrid(e);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  401 */     pp
/*  402 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  404 */             if (Def.isMac) {
/*  405 */               TentsBuild.jfTents.setResizable((TentsBuild.jfTents.getWidth() - e.getX() < 15 && TentsBuild.jfTents
/*  406 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  411 */     loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/*  412 */     restoreFrame();
/*      */ 
/*      */     
/*  415 */     ActionListener timerAL = ae -> {
/*      */         this.myTimer.stop();
/*      */         this.thread = new Thread(paramRunnable);
/*      */         this.thread.start();
/*      */         Def.building = 1;
/*      */       };
/*  421 */     this.myTimer = new Timer(1000, timerAL);
/*      */     
/*  423 */     if (auto) {
/*  424 */       sixpack = true;
/*  425 */       howMany = hm; startPuz = start;
/*  426 */       this.myTimer.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  431 */     jfTents.setVisible(true);
/*  432 */     Insets insets = jfTents.getInsets();
/*  433 */     panelW = jfTents.getWidth() - insets.left + insets.right;
/*  434 */     panelH = jfTents.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  435 */     pp.setSize(panelW, panelH);
/*  436 */     jfTents.requestFocusInWindow();
/*  437 */     pp.repaint();
/*  438 */     Methods.infoPanel(jl1, jl2, "Build Tents", "Puzzle : " + Op.te[Op.TE.TePuz.ordinal()], panelW);
/*      */   }
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  442 */     int i = (int)((width - inset) / (Grid.xSz + 0.5D));
/*  443 */     int j = (int)((height - inset) / (Grid.ySz + 0.5D));
/*  444 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  445 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - (int)((Grid.xSz + 0.5D) * Grid.xCell)) / 2) : 10);
/*  446 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - (int)((Grid.ySz + 0.5D) * Grid.yCell)) / 2) : 10);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void tentsOptions() {
/*  452 */     final JDialog jdlgTents = new JDialog(jfTents, "Tents Options", true);
/*  453 */     jdlgTents.setSize(390, 270);
/*  454 */     jdlgTents.setResizable(false);
/*  455 */     jdlgTents.setLayout((LayoutManager)null);
/*  456 */     jdlgTents.setLocation(jfTents.getX(), jfTents.getY());
/*      */     
/*  458 */     jdlgTents
/*  459 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  461 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  465 */     Methods.closeHelp();
/*      */     
/*  467 */     JPanel diffPanel = new JPanel();
/*  468 */     diffPanel.setLayout((LayoutManager)null);
/*  469 */     diffPanel.setSize(110, 220);
/*  470 */     diffPanel.setLocation(10, 10);
/*  471 */     diffPanel.setOpaque(true);
/*  472 */     diffPanel.setBorder(BorderFactory.createEtchedBorder());
/*  473 */     jdlgTents.add(diffPanel);
/*      */     
/*  475 */     JLabel jlDiff = new JLabel("Difficulty");
/*  476 */     jlDiff.setForeground(Def.COLOR_LABEL);
/*  477 */     jlDiff.setSize(100, 20);
/*  478 */     jlDiff.setLocation(5, 5);
/*  479 */     jlDiff.setHorizontalAlignment(0);
/*  480 */     diffPanel.add(jlDiff);
/*      */     
/*  482 */     JLabel jl = new JLabel("Too Hard");
/*  483 */     jl.setForeground(Def.COLOR_LABEL);
/*  484 */     jl.setSize(80, 20);
/*  485 */     jl.setLocation(35, 25);
/*  486 */     jl.setHorizontalAlignment(2);
/*  487 */     diffPanel.add(jl);
/*      */     
/*  489 */     jl = new JLabel("Very Hard");
/*  490 */     jl.setForeground(Def.COLOR_LABEL);
/*  491 */     jl.setSize(80, 20);
/*  492 */     jl.setLocation(35, 51);
/*  493 */     jl.setHorizontalAlignment(2);
/*  494 */     diffPanel.add(jl);
/*      */     
/*  496 */     jl = new JLabel("Hard");
/*  497 */     jl.setForeground(Def.COLOR_LABEL);
/*  498 */     jl.setSize(80, 20);
/*  499 */     jl.setLocation(35, 77);
/*  500 */     jl.setHorizontalAlignment(2);
/*  501 */     diffPanel.add(jl);
/*      */     
/*  503 */     jl = new JLabel("Moderate");
/*  504 */     jl.setForeground(Def.COLOR_LABEL);
/*  505 */     jl.setSize(80, 20);
/*  506 */     jl.setLocation(35, 103);
/*  507 */     jl.setHorizontalAlignment(2);
/*  508 */     diffPanel.add(jl);
/*      */     
/*  510 */     jl = new JLabel("Easy");
/*  511 */     jl.setForeground(Def.COLOR_LABEL);
/*  512 */     jl.setSize(80, 20);
/*  513 */     jl.setLocation(35, 130);
/*  514 */     jl.setHorizontalAlignment(2);
/*  515 */     diffPanel.add(jl);
/*      */     
/*  517 */     jl = new JLabel("Very Easy");
/*  518 */     jl.setForeground(Def.COLOR_LABEL);
/*  519 */     jl.setSize(80, 20);
/*  520 */     jl.setLocation(35, 155);
/*  521 */     jl.setHorizontalAlignment(2);
/*  522 */     diffPanel.add(jl);
/*      */     
/*  524 */     jl = new JLabel("Trivial");
/*  525 */     jl.setForeground(Def.COLOR_LABEL);
/*  526 */     jl.setSize(80, 20);
/*  527 */     jl.setLocation(35, 181);
/*  528 */     jl.setHorizontalAlignment(2);
/*  529 */     diffPanel.add(jl);
/*      */     
/*  531 */     final JSlider jsldrDiff = new JSlider(1, 0, 49, Op.getInt(Op.TE.TeDifficulty.ordinal(), Op.te));
/*  532 */     jsldrDiff.setBackground(Def.COLOR_DIALOGBG);
/*  533 */     jsldrDiff.setSize(20, 180);
/*  534 */     jsldrDiff.setLocation(10, 25);
/*  535 */     diffPanel.add(jsldrDiff);
/*      */     
/*  537 */     JLabel jlAcross = new JLabel("Cells Across:");
/*  538 */     jlAcross.setForeground(Def.COLOR_LABEL);
/*  539 */     jlAcross.setSize(120, 20);
/*  540 */     jlAcross.setLocation(120, 8);
/*  541 */     jlAcross.setHorizontalAlignment(4);
/*  542 */     jdlgTents.add(jlAcross);
/*      */     
/*  544 */     final JComboBox<Integer> jcbbAcross = new JComboBox<>();
/*  545 */     for (int i = 5; i <= 16; i++)
/*  546 */       jcbbAcross.addItem(Integer.valueOf(i)); 
/*  547 */     jcbbAcross.setSize(60, 20);
/*  548 */     jcbbAcross.setLocation(250, 8);
/*  549 */     jdlgTents.add(jcbbAcross);
/*  550 */     jcbbAcross.setBackground(Def.COLOR_BUTTONBG);
/*  551 */     jcbbAcross.setSelectedIndex(Op.getInt(Op.TE.TeAcross.ordinal(), Op.te) - 5);
/*      */     
/*  553 */     JLabel jlDown = new JLabel("Cells Down:");
/*  554 */     jlDown.setForeground(Def.COLOR_LABEL);
/*  555 */     jlDown.setSize(120, 20);
/*  556 */     jlDown.setLocation(120, 30);
/*  557 */     jlDown.setHorizontalAlignment(4);
/*  558 */     jdlgTents.add(jlDown);
/*      */     
/*  560 */     final JComboBox<Integer> jcbbDown = new JComboBox<>();
/*  561 */     for (int j = 5; j <= 16; j++)
/*  562 */       jcbbDown.addItem(Integer.valueOf(j)); 
/*  563 */     jcbbDown.setSize(60, 20);
/*  564 */     jcbbDown.setLocation(250, 30);
/*  565 */     jdlgTents.add(jcbbDown);
/*  566 */     jcbbDown.setBackground(Def.COLOR_BUTTONBG);
/*  567 */     jcbbDown.setSelectedIndex(Op.getInt(Op.TE.TeDown.ordinal(), Op.te) - 5);
/*      */     
/*  569 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgTents, 130, 55, howMany, startPuz, Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue());
/*      */     
/*  571 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  573 */           Grid.xSz = jcbbAcross.getSelectedIndex() + 5;
/*  574 */           Op.setInt(Op.TE.TeAcross.ordinal(), Grid.xSz, Op.te);
/*  575 */           Grid.ySz = jcbbDown.getSelectedIndex() + 5;
/*  576 */           Op.setInt(Op.TE.TeDown.ordinal(), Grid.ySz, Op.te);
/*  577 */           TentsBuild.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  578 */           TentsBuild.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*  579 */           Op.setBool(Op.SX.VaryDiff.ordinal(), Boolean.valueOf(hmp.jcbVaryDiff.isSelected()), Op.sx);
/*  580 */           Methods.clickedOK = true;
/*  581 */           jdlgTents.dispose();
/*  582 */           Methods.closeHelp();
/*  583 */           Op.setInt(Op.TE.TeDifficulty.ordinal(), jsldrDiff.getValue(), Op.te);
/*      */         }
/*      */       };
/*  586 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 130, 169, 80, 26);
/*  587 */     jdlgTents.add(jbOK);
/*      */     
/*  589 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  591 */           Methods.clickedOK = false;
/*  592 */           jdlgTents.dispose();
/*  593 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  596 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 130, 204, 80, 26);
/*  597 */     jdlgTents.add(jbCancel);
/*      */     
/*  599 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  601 */           Methods.cweHelp(null, jdlgTents, "Tents Options", TentsBuild.this.tentsOptions);
/*      */         }
/*      */       };
/*  604 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 220, 169, 150, 61);
/*  605 */     jdlgTents.add(jbHelp);
/*      */     
/*  607 */     jdlgTents.getRootPane().setDefaultButton(jbOK);
/*  608 */     Methods.setDialogSize(jdlgTents, 380, 240);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/*  612 */     String[] colorLabel = { "Cell Color", "Grid Color", "Tree Color", "Trunk Color", "Tent Color", "Count Color", "Error Color" };
/*  613 */     int[] colorInt = { Op.TE.TeCell.ordinal(), Op.TE.TeLine.ordinal(), Op.TE.TeTree.ordinal(), Op.TE.TeTrunk.ordinal(), Op.TE.TeTent.ordinal(), Op.TE.TeCount.ordinal(), Op.TE.TeError.ordinal() };
/*  614 */     String[] fontLabel = { "Select Tent Count Font" };
/*  615 */     int[] fontInt = { Op.TE.TeCountFont.ordinal() };
/*  616 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/*  617 */     int[] checkInt = { Op.TE.TePuzColor.ordinal(), Op.TE.TeSolColor.ordinal() };
/*  618 */     Methods.stdPrintOptions(jf, "Tents " + type, Op.te, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveTents(String tentsName) {
/*      */     try {
/*  627 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("tents/" + tentsName));
/*  628 */       dataOut.writeInt(Grid.xSz);
/*  629 */       dataOut.writeInt(Grid.ySz);
/*  630 */       dataOut.writeByte(Methods.noReveal);
/*  631 */       dataOut.writeByte(Methods.noErrors);
/*  632 */       for (int i = 0; i < 54; i++)
/*  633 */         dataOut.writeByte(0); 
/*  634 */       for (int j = 0; j <= Grid.ySz; j++) {
/*  635 */         for (int k = 0; k <= Grid.xSz; k++) {
/*  636 */           if (Grid.copy[k][j] != 3 || k == Grid.xSz || j == Grid.ySz) {
/*  637 */             Grid.sol[k][j] = Grid.copy[k][j];
/*      */           } else {
/*  639 */             Grid.sol[k][j] = 0;
/*  640 */           }  dataOut.writeInt(Grid.sol[k][j]);
/*  641 */           dataOut.writeInt(Grid.copy[k][j]);
/*      */         } 
/*  643 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/*  644 */       dataOut.writeUTF(Methods.author);
/*  645 */       dataOut.writeUTF(Methods.copyright);
/*  646 */       dataOut.writeUTF(Methods.puzzleNumber);
/*  647 */       dataOut.writeUTF(Methods.puzzleNotes);
/*  648 */       dataOut.close();
/*      */     }
/*  650 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadTents(String tentsName) {
/*      */     try {
/*  658 */       File fl = new File("tents/" + tentsName);
/*  659 */       if (!fl.exists()) {
/*  660 */         fl = new File("tents/");
/*  661 */         String[] s = fl.list(); int k;
/*  662 */         for (k = 0; k < s.length && (
/*  663 */           s[k].lastIndexOf(".tents") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/*  665 */         if (k == s.length) { makeGrid(); return; }
/*  666 */          tentsName = s[k];
/*  667 */         Op.te[Op.TE.TePuz.ordinal()] = tentsName;
/*      */       } 
/*      */ 
/*      */       
/*  671 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("tents/" + tentsName));
/*  672 */       Grid.xSz = dataIn.readInt();
/*  673 */       Grid.ySz = dataIn.readInt();
/*  674 */       Methods.noReveal = dataIn.readByte();
/*  675 */       Methods.noErrors = dataIn.readByte(); int i;
/*  676 */       for (i = 0; i < 54; i++)
/*  677 */         dataIn.readByte(); 
/*  678 */       for (int j = 0; j <= Grid.ySz; j++) {
/*  679 */         for (i = 0; i <= Grid.xSz; i++) {
/*  680 */           Grid.sol[i][j] = dataIn.readInt();
/*  681 */           Grid.copy[i][j] = dataIn.readInt();
/*      */         } 
/*  683 */       }  Methods.puzzleTitle = dataIn.readUTF();
/*  684 */       Methods.author = dataIn.readUTF();
/*  685 */       Methods.copyright = dataIn.readUTF();
/*  686 */       Methods.puzzleNumber = dataIn.readUTF();
/*  687 */       Methods.puzzleNotes = dataIn.readUTF();
/*  688 */       dataIn.close();
/*      */     }
/*  690 */     catch (IOException exc) {
/*      */       return;
/*  692 */     }  Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawOneTent(Graphics2D g2, int x, int y, int xCell, int yCell) {
/*  698 */     int[] xPoints = new int[5], yPoints = new int[5];
/*  699 */     int[] xStart = new int[6], yStart = new int[6];
/*  700 */     int[] xEnd = new int[6], yEnd = new int[6];
/*      */     
/*  702 */     int cntr = xPoints[0] = x + xCell / 2;
/*  703 */     int width = xCell / 4;
/*  704 */     xPoints[2] = cntr - width; xPoints[1] = cntr - width;
/*  705 */     xPoints[4] = cntr + width; xPoints[3] = cntr + width;
/*  706 */     int top = yPoints[0] = y + yCell / 5;
/*  707 */     yPoints[4] = top + width; yPoints[1] = top + width;
/*  708 */     int base = y + 3 * yCell / 4;
/*  709 */     yPoints[3] = base; yPoints[2] = base;
/*  710 */     int flapX = cntr - xCell / 10;
/*  711 */     int flapY = y + 9 * yCell / 20;
/*  712 */     int eaves = xCell / 12;
/*  713 */     xStart[0] = cntr + width; yStart[0] = top + width; xEnd[0] = cntr + width + eaves; yEnd[0] = top + width + eaves;
/*  714 */     xStart[1] = cntr - width; yStart[1] = top + width; xEnd[1] = cntr - width - eaves; yEnd[1] = top + width + eaves;
/*  715 */     xStart[2] = flapX; yStart[2] = flapY; xEnd[2] = flapX; yEnd[2] = base;
/*  716 */     xStart[3] = flapX; yStart[3] = flapY; xEnd[3] = cntr + xCell / 8; yEnd[3] = base;
/*  717 */     xStart[4] = flapX; yStart[4] = flapY; xEnd[4] = cntr + xCell / 8; yEnd[4] = base - yCell / 5;
/*  718 */     xStart[5] = cntr + xCell / 8; yStart[5] = base - yCell / 5; xEnd[5] = cntr + xCell / 8; yEnd[5] = base;
/*      */     
/*  720 */     g2.setStroke(new BasicStroke(xCell / 25.0F, 1, 2));
/*      */     
/*  722 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTent.ordinal(), Op.te)) : Def.COLOR_WHITE);
/*  723 */     g2.fillPolygon(xPoints, yPoints, 5);
/*      */     
/*  725 */     g2.setColor(Def.COLOR_BLACK);
/*  726 */     g2.drawPolygon(xPoints, yPoints, 5);
/*      */     
/*  728 */     for (int i = 0; i < 6; i++)
/*  729 */       g2.drawLine(xStart[i], yStart[i], xEnd[i], yEnd[i]); 
/*      */   }
/*      */   
/*      */   static void drawTree(Graphics2D g2, int x, int y, int xCell, int yCell) {
/*  733 */     int[] xPoints = new int[3], yPoints = new int[3];
/*  734 */     int[] xOffset = { -4, 0, 4, -6, 0, 6, -8, 0, 8 };
/*  735 */     int[] yOffset = { 5, 2, 5, 9, 4, 9, 14, 7, 14 };
/*      */     
/*  737 */     g2.setStroke(new BasicStroke(xCell / 25.0F, 0, 2));
/*  738 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTrunk.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*  739 */     int center = xCell / 2;
/*  740 */     g2.drawLine(x + center, y + 13 * yCell / 20, x + center, y + 18 * yCell / 20);
/*      */     
/*  742 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTree.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*  743 */     for (int j = 0; j < 3; j++) {
/*  744 */       for (int i = 0; i < 3; i++) {
/*  745 */         xPoints[i] = x + center + xOffset[i + 3 * j] * xCell / 20;
/*  746 */         yPoints[i] = y + yOffset[i + 3 * j] * yCell / 20;
/*      */       } 
/*  748 */       g2.fillPolygon(xPoints, yPoints, 3);
/*      */     } 
/*      */   }
/*      */   
/*      */   static void drawDot(Graphics2D g2, int x, int y, int xCell, int yCell) {
/*  753 */     int[] xPoints = new int[4], yPoints = new int[4];
/*  754 */     int[] xOffset = { 9, 11, 11, 9 };
/*  755 */     int[] yOffset = { 9, 9, 11, 11 };
/*      */     
/*  757 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeLine.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*  758 */     for (int i = 0; i < 4; i++) {
/*  759 */       xPoints[i] = x + xOffset[i] * xCell / 20;
/*  760 */       yPoints[i] = y + yOffset[i] * yCell / 20;
/*      */     } 
/*      */     
/*  763 */     g2.fillPolygon(xPoints, yPoints, 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawTents(Graphics2D g2, int[][] puzzleArray) {
/*  770 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/*  771 */     g2.setStroke(normalStroke);
/*      */     
/*  773 */     RenderingHints rh = g2.getRenderingHints();
/*  774 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  775 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  776 */     g2.setRenderingHints(rh);
/*      */     
/*      */     int j;
/*  779 */     for (j = 0; j < Grid.ySz + 1; j++) {
/*  780 */       for (int i = 0; i < Grid.xSz + 1; i++) {
/*  781 */         g2.setColor(Def.dispWithColor.booleanValue() ? ((i == Grid.xSz || j == Grid.ySz) ? Def.COLOR_WHITE : new Color(Op.getColorInt(Op.TE.TeCell.ordinal(), Op.te))) : Def.COLOR_WHITE);
/*  782 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, (i == Grid.xSz) ? (Grid.xCell / 2) : Grid.xCell, (j == Grid.ySz) ? (Grid.yCell / 2) : Grid.yCell);
/*  783 */         g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeLine.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*      */       } 
/*      */     } 
/*      */     
/*  787 */     int len = Grid.xSz * Grid.xCell + Grid.xCell / 2;
/*  788 */     for (j = 0; j < Grid.ySz + 1; j++)
/*  789 */       g2.drawLine(Grid.xOrg, Grid.yOrg + j * Grid.yCell, Grid.xOrg + len, Grid.yOrg + j * Grid.yCell); 
/*  790 */     for (j = 0; j < Grid.xSz + 1; j++)
/*  791 */       g2.drawLine(Grid.xOrg + j * Grid.xCell, Grid.yOrg, Grid.xOrg + j * Grid.xCell, Grid.yOrg + len); 
/*  792 */     g2.drawLine(Grid.xOrg, Grid.yOrg + len, Grid.xOrg + len, Grid.yOrg + len);
/*  793 */     g2.drawLine(Grid.xOrg + len, Grid.yOrg, Grid.xOrg + len, Grid.yOrg + len);
/*      */ 
/*      */     
/*  796 */     for (j = 0; j < Grid.ySz; j++) {
/*  797 */       for (int i = 0; i < Grid.xSz; i++) {
/*  798 */         if (Grid.copy[i][j] == 1 || Grid.copy[i][j] == 4) {
/*  799 */           g2.setColor(Def.dispToPrinter.booleanValue() ? Def.COLOR_BLACK : Def.COLOR_TREE_GREEN);
/*  800 */           drawTree(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */         } 
/*  802 */         if (Grid.copy[i][j] == 2)
/*  803 */           drawDot(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*  804 */         if (Grid.copy[i][j] == 3) {
/*  805 */           drawOneTent(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*      */         }
/*      */       } 
/*      */     } 
/*  809 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeCount.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*  810 */     g2.setFont(new Font("SansSerif", 0, 4 * Grid.yCell / 10));
/*  811 */     FontMetrics fm = g2.getFontMetrics();
/*  812 */     for (j = 0; j <= Grid.ySz; j++) {
/*  813 */       for (int i = 0; i <= Grid.xSz; i++) {
/*  814 */         if ((i == Grid.xSz && j < Grid.ySz) || (j == Grid.ySz && i < Grid.xSz)) {
/*  815 */           char ch = (char)(48 + Grid.copy[i][j]);
/*  816 */           int w = fm.stringWidth("" + ch);
/*  817 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell / ((i == Grid.xSz) ? 2 : 1) - w) / 2, Grid.yOrg + j * Grid.yCell + ((j == Grid.ySz) ? fm
/*  818 */               .getAscent() : ((Grid.yCell + fm.getAscent()) / 2)));
/*      */         } 
/*      */       } 
/*  821 */     }  g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */   
/*      */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/*  825 */     loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/*  826 */     setSizesAndOffsets(left, top, width, height, 0);
/*  827 */     TentsSolve.clearSolution();
/*  828 */     Def.dispWithColor = Op.getBool(Op.TE.TePuzColor.ordinal(), Op.te);
/*  829 */     TentsSolve.drawTents(g2, Grid.copy);
/*  830 */     Def.dispWithColor = Boolean.valueOf(true);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  834 */     loadTents(solutionPuzzle);
/*  835 */     setSizesAndOffsets(left, top, width, height, 0);
/*  836 */     Def.dispWithColor = Op.getBool(Op.TE.TeSolColor.ordinal(), Op.te);
/*  837 */     drawTents(g2, Grid.copy);
/*  838 */     Def.dispWithColor = Boolean.valueOf(true);
/*  839 */     loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/*  843 */     loadTents(solutionPuzzle);
/*  844 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/*  845 */     loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printSixpackPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  851 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  853 */     String st = Op.sx[Op.SX.SxTe.ordinal()];
/*  854 */     if (st.length() < 3) st = "TENTS"; 
/*  855 */     int w = fm.stringWidth(st);
/*  856 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  857 */     TentsSolve.loadTents(puzName + ".tents");
/*  858 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  859 */     TentsSolve.clearSolution();
/*  860 */     TentsSolve.drawTents(g2, Grid.copy);
/*  861 */     if (Op.sx[Op.SX.SxRuleLang.ordinal()].equals("English")) {
/*  862 */       st = rules;
/*      */     } else {
/*  864 */       st = Op.te[Op.TE.TeRule1.ordinal() + Op.getInt(Op.SX.SxRuleLangIndex.ordinal(), Op.sx) - 1];
/*  865 */     }  if (Op.getBool(Op.SX.SxInstructions.ordinal(), Op.sx).booleanValue()) {
/*  866 */       Methods.renderText(g2, left, top + dim + dim / 50, dim, dim / 4, "SansSerif", 1, st, 3, 4, true, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void printSixpackSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  872 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  874 */     String st = Op.sx[Op.SX.SxTe.ordinal()];
/*  875 */     if (st.length() < 3) st = "TENTS"; 
/*  876 */     int w = fm.stringWidth(st);
/*  877 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  878 */     loadTents(solName + ".tents");
/*  879 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  880 */     drawTents(g2, Grid.copy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPPuz(Graphics2D g2, int left, int top, int dim, int gap, String puzName) {
/*  886 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  888 */     String st = puzName;
/*  889 */     int w = fm.stringWidth(st);
/*  890 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  891 */     TentsSolve.loadTents(puzName + ".tents");
/*  892 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  893 */     TentsSolve.clearSolution();
/*  894 */     TentsSolve.drawTents(g2, Grid.copy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void printKDPSol(Graphics2D g2, int left, int top, int dim, int gap, String solName) {
/*  900 */     FontMetrics fm = g2.getFontMetrics();
/*      */     
/*  902 */     String st = solName;
/*  903 */     int w = fm.stringWidth(st);
/*  904 */     g2.drawString(st, left + (dim - w) / 2, top - gap / 3);
/*  905 */     loadTents(solName + ".tents");
/*  906 */     setSizesAndOffsets(left, top, dim, dim, 0);
/*  907 */     drawTents(g2, Grid.copy);
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/*  911 */     Methods.havePuzzle = false;
/*  912 */     Grid.clearGrid();
/*  913 */     Grid.xSz = Op.getInt(Op.TE.TeAcross.ordinal(), Op.te);
/*  914 */     Grid.ySz = Op.getInt(Op.TE.TeDown.ordinal(), Op.te);
/*      */   }
/*      */   
/*      */   void updateGrid(MouseEvent e) {
/*  918 */     int x = e.getX(), y = e.getY();
/*      */     
/*  920 */     if (Def.building == 1)
/*  921 */       return;  if (x < Grid.xOrg || y < Grid.yOrg)
/*  922 */       return;  x = (x - Grid.xOrg) / Grid.xCell;
/*  923 */     y = (y - Grid.yOrg) / Grid.yCell;
/*  924 */     if (x > Grid.xSz || y > Grid.ySz)
/*      */       return; 
/*  926 */     Grid.copy[x][y] = (Grid.copy[x][y] + 1) % 4;
/*  927 */     if (Grid.copy[x][y] == 2)
/*  928 */       Grid.copy[x][y] = Grid.copy[x][y] + 1; 
/*  929 */     if (Grid.copy[x][y] == 3) {
/*  930 */       Grid.copy[Grid.xSz][y] = Grid.copy[Grid.xSz][y] + 1;
/*  931 */       Grid.copy[x][Grid.ySz] = Grid.copy[x][Grid.ySz] + 1;
/*      */     } 
/*  933 */     if (Grid.copy[x][y] == 0) {
/*  934 */       Grid.copy[Grid.xSz][y] = Grid.copy[Grid.xSz][y] - 1;
/*  935 */       Grid.copy[x][Grid.ySz] = Grid.copy[x][Grid.ySz] - 1;
/*      */     } 
/*  937 */     Grid.xCur = x; Grid.yCur = y;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean rowAndColumnCounts() {
/*  942 */     boolean found = false;
/*      */     int j;
/*  944 */     for (j = 0; j < Grid.ySz; j++) {
/*      */       int k; int tents; int grass;
/*  946 */       for (grass = tents = k = 0; k < Grid.xSz; k++) {
/*  947 */         if (Grid.copy[k][j] == TENT) {
/*  948 */           tents++;
/*  949 */         } else if (Grid.copy[k][j] == GRASS) {
/*  950 */           grass++;
/*      */         } 
/*  952 */       }  if (Grid.copy[Grid.xSz][j] == tents)
/*  953 */         for (k = 0; k < Grid.xSz; k++) {
/*  954 */           if (Grid.copy[k][j] == GRASS) {
/*  955 */             Grid.copy[k][j] = NOTENT;
/*  956 */             found = true;
/*      */           } 
/*      */         }  
/*  959 */       if (Grid.copy[Grid.xSz][j] == grass + tents)
/*  960 */         for (k = 0; k < Grid.xSz; k++) {
/*  961 */           if (Grid.copy[k][j] == GRASS) {
/*  962 */             insertTent(k, j);
/*  963 */             found = true;
/*      */           } 
/*      */         }  
/*      */     } 
/*  967 */     for (int i = 0; i < Grid.xSz; i++) {
/*      */       int tents; int grass;
/*  969 */       for (grass = tents = j = 0; j < Grid.ySz; j++) {
/*  970 */         if (Grid.copy[i][j] == TENT) {
/*  971 */           tents++;
/*  972 */         } else if (Grid.copy[i][j] == GRASS) {
/*  973 */           grass++;
/*      */         } 
/*  975 */       }  if (Grid.copy[i][Grid.ySz] == tents)
/*  976 */         for (j = 0; j < Grid.ySz; j++) {
/*  977 */           if (Grid.copy[i][j] == GRASS) {
/*  978 */             Grid.copy[i][j] = NOTENT;
/*  979 */             found = true;
/*      */           } 
/*      */         }  
/*  982 */       if (Grid.copy[i][Grid.ySz] == grass + tents)
/*  983 */         for (j = 0; j < Grid.ySz; j++) {
/*  984 */           if (Grid.copy[i][j] == GRASS) {
/*  985 */             insertTent(i, j);
/*  986 */             found = true;
/*      */           } 
/*      */         }  
/*  989 */     }  return found;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean rowAndColumnGaps() {
/*  994 */     boolean found = false;
/*      */     
/*      */     int j;
/*  997 */     for (j = 0; j < Grid.ySz; j++) {
/*  998 */       int k; int tents; int gap1; int gap2; int gap3; int gap4; for (int thisGap = k = 0; k < Grid.xSz; k++) {
/*  999 */         if (Grid.copy[k][j] == TENT)
/* 1000 */           tents++; 
/* 1001 */         if (Grid.copy[k][j] == GRASS)
/* 1002 */           thisGap++; 
/* 1003 */         if (Grid.copy[k][j] != GRASS || k == Grid.xSz - 1) {
/* 1004 */           switch (thisGap) { case 0: break;
/*      */             case 1:
/* 1006 */               gap1++; break;
/* 1007 */             case 2: gap2++; break;
/* 1008 */             case 3: gap3++; break;
/* 1009 */             default: gap4++; break; }
/*      */           
/* 1011 */           thisGap = 0;
/*      */         } 
/*      */       } 
/*      */       
/* 1015 */       if (gap3 + gap4 == 0 && gap1 + gap2 > 0 && Grid.copy[Grid.xSz][j] == gap1 + gap2 + tents)
/* 1016 */         for (k = 0; k < Grid.xSz; k++) {
/* 1017 */           if (Grid.copy[k][j] == GRASS)
/* 1018 */             if (k + 1 == Grid.xSz || (k + 1 < Grid.xSz && Grid.copy[k + 1][j] != GRASS)) {
/* 1019 */               insertTent(k, j);
/* 1020 */               found = true;
/*      */             }
/* 1022 */             else if (k + 1 < Grid.xSz && Grid.copy[k + 1][j] == GRASS) {
/* 1023 */               if (j > 0) {
/* 1024 */                 if (Grid.copy[k][j - 1] == GRASS) { Grid.copy[k][j - 1] = NOTENT; found = true; }
/* 1025 */                  if (Grid.copy[k + 1][j - 1] == GRASS) { Grid.copy[k + 1][j - 1] = NOTENT; found = true; }
/*      */               
/* 1027 */               }  if (j < Grid.ySz - 1) {
/* 1028 */                 if (Grid.copy[k][j + 1] == GRASS) { Grid.copy[k][j + 1] = NOTENT; found = true; }
/* 1029 */                  if (Grid.copy[k + 1][j + 1] == GRASS) { Grid.copy[k + 1][j + 1] = NOTENT; found = true; }
/*      */               
/* 1031 */               }  k++;
/*      */             }  
/*      */         }  
/* 1034 */       if (gap3 == 1 && gap1 + gap2 + gap4 == 0) {
/* 1035 */         if (Grid.copy[Grid.xSz][j] == tents + 2)
/* 1036 */           for (k = 0; k < Grid.xSz; k++) {
/* 1037 */             if (Grid.copy[k][j] == GRASS) {
/* 1038 */               insertTent(k, j);
/* 1039 */               insertTent(k + 2, j);
/* 1040 */               found = true;
/*      */             } 
/*      */           }  
/* 1043 */         if (Grid.copy[Grid.xSz][j] == tents + 1) {
/* 1044 */           for (k = 0; k < Grid.xSz; k++) {
/* 1045 */             if (Grid.copy[k][j] == GRASS) {
/* 1046 */               if (j > 0 && Grid.copy[k + 1][j - 1] == GRASS) {
/* 1047 */                 Grid.copy[k + 1][j - 1] = NOTENT;
/* 1048 */                 found = true;
/*      */               } 
/* 1050 */               if (j < Grid.ySz - 1 && Grid.copy[k + 1][j + 1] == GRASS) {
/* 1051 */                 Grid.copy[k + 1][j + 1] = NOTENT;
/* 1052 */                 found = true;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1059 */     for (int i = 0; i < Grid.xSz; i++) {
/* 1060 */       int tents; int gap1; int gap2; int gap3; int gap4; for (int thisGap = j = 0; j < Grid.ySz; j++) {
/* 1061 */         if (Grid.copy[i][j] == TENT)
/* 1062 */           tents++; 
/* 1063 */         if (Grid.copy[i][j] == GRASS)
/* 1064 */           thisGap++; 
/* 1065 */         if (Grid.copy[i][j] != GRASS || j == Grid.ySz - 1) {
/* 1066 */           switch (thisGap) { case 0: break;
/*      */             case 1:
/* 1068 */               gap1++; break;
/* 1069 */             case 2: gap2++; break;
/* 1070 */             case 3: gap3++; break;
/* 1071 */             default: gap4++; break; }
/*      */           
/* 1073 */           thisGap = 0;
/*      */         } 
/*      */       } 
/*      */       
/* 1077 */       if (gap3 + gap4 == 0 && gap1 + gap2 > 0 && Grid.copy[i][Grid.ySz] == gap1 + gap2 + tents)
/* 1078 */         for (j = 0; j < Grid.ySz; j++) {
/* 1079 */           if (Grid.copy[i][j] == GRASS) {
/* 1080 */             if (j + 1 == Grid.ySz || (j + 1 < Grid.ySz && Grid.copy[i][j + 1] != GRASS)) {
/* 1081 */               insertTent(i, j);
/* 1082 */               found = true;
/*      */             }
/* 1084 */             else if (j + 1 < Grid.ySz && Grid.copy[i][j + 1] == GRASS) {
/* 1085 */               if (i > 0) {
/* 1086 */                 if (Grid.copy[i - 1][j] == GRASS) { Grid.copy[i - 1][j] = NOTENT; found = true; }
/* 1087 */                  if (Grid.copy[i - 1][j + 1] == GRASS) { Grid.copy[i - 1][j + 1] = NOTENT; found = true; }
/*      */               
/* 1089 */               }  if (i < Grid.xSz - 1) {
/* 1090 */                 if (Grid.copy[i + 1][j] == GRASS) { Grid.copy[i + 1][j] = NOTENT; found = true; }
/* 1091 */                  if (Grid.copy[i + 1][j + 1] == GRASS) { Grid.copy[i + 1][j + 1] = NOTENT; found = true; }
/*      */               
/*      */               } 
/* 1094 */             }  j++;
/*      */           } 
/* 1096 */         }   if (gap3 == 1 && gap1 + gap2 + gap4 == 0) {
/* 1097 */         if (Grid.copy[i][Grid.ySz] == tents + 2)
/* 1098 */           for (j = 0; j < Grid.ySz; j++) {
/* 1099 */             if (Grid.copy[i][j] == GRASS) {
/* 1100 */               insertTent(i, j);
/* 1101 */               insertTent(i, j + 2);
/* 1102 */               found = true;
/*      */             } 
/*      */           }  
/* 1105 */         if (Grid.copy[i][Grid.ySz] == tents + 1)
/* 1106 */           for (j = 0; j < Grid.ySz; j++) {
/* 1107 */             if (Grid.copy[i][j] == GRASS) {
/* 1108 */               if (i > 0 && Grid.copy[i - 1][j + 1] == GRASS) {
/* 1109 */                 Grid.copy[i - 1][j + 1] = NOTENT;
/* 1110 */                 found = true;
/*      */               } 
/* 1112 */               if (i < Grid.ySz - 1 && Grid.copy[i + 1][j + 1] == GRASS) {
/* 1113 */                 Grid.copy[i + 1][j + 1] = NOTENT;
/* 1114 */                 found = true;
/*      */               } 
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     } 
/* 1120 */     return found;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean noAdjacentTrees() {
/* 1125 */     boolean found = false;
/*      */     
/* 1127 */     for (int j = 0; j < Grid.ySz; j++) {
/* 1128 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1129 */         if (Grid.copy[i][j] == GRASS && (
/* 1130 */           i <= 0 || Grid.copy[i - 1][j] != TREE) && (
/* 1131 */           j <= 0 || Grid.copy[i][j - 1] != TREE) && (
/* 1132 */           i >= Grid.xSz - 1 || Grid.copy[i + 1][j] != TREE) && (
/* 1133 */           j >= Grid.ySz - 1 || Grid.copy[i][j + 1] != TREE)) {
/* 1134 */           Grid.copy[i][j] = NOTENT;
/* 1135 */           found = true;
/*      */         } 
/*      */       } 
/* 1138 */     }  return found;
/*      */   }
/*      */   
/*      */   static void insertTent(int x, int y) {
/* 1142 */     int a = 0, b = 0;
/*      */     
/* 1144 */     Grid.copy[x][y] = TENT; int j, count;
/* 1145 */     for (count = 0, j = y - 1; j < y + 2; j++) {
/* 1146 */       for (int i = x - 1; i < x + 2; i++) {
/* 1147 */         if (i >= 0 && j >= 0 && i < Grid.xSz && j <= -Grid.ySz)
/* 1148 */         { if (Grid.copy[i][j] == GRASS)
/* 1149 */             Grid.copy[i][j] = NOTENT; 
/* 1150 */           if (Grid.copy[i][j] == TREE && (i == x || j == y)) { count++; a = i; b = j; }  } 
/*      */       } 
/* 1152 */     }  if (count == 1) Grid.copy[a][b] = NONTREE; 
/*      */   }
/*      */   
/*      */   static boolean oneOptionTrees() {
/* 1156 */     int x = 0, y = 0;
/* 1157 */     boolean found = false;
/*      */     
/* 1159 */     for (int j = 0; j < Grid.ySz; j++) {
/* 1160 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1161 */         if (Grid.copy[i][j] == TREE) {
/* 1162 */           int count = 0;
/* 1163 */           if (i > 0 && Grid.copy[i - 1][j] == GRASS) { count++; x = i - 1; y = j; }
/* 1164 */            if (j > 0 && Grid.copy[i][j - 1] == GRASS) { count++; x = i; y = j - 1; }
/* 1165 */            if (i < Grid.xSz - 1 && Grid.copy[i + 1][j] == GRASS) { count++; x = i + 1; y = j; }
/* 1166 */            if (j < Grid.ySz - 1 && Grid.copy[i][j + 1] == GRASS) { count++; x = i; y = j + 1; }
/* 1167 */            if (count == 1) {
/* 1168 */             insertTent(x, y);
/* 1169 */             found = true;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1173 */     }  return found;
/*      */   }
/*      */   
/*      */   static boolean allocateTreesToTents() {
/* 1177 */     int x = 0, y = 0;
/* 1178 */     boolean found = false;
/*      */     
/* 1180 */     for (int j = 0; j < Grid.ySz; j++) {
/* 1181 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1182 */         if (Grid.copy[i][j] == TENT) {
/* 1183 */           int count = 0;
/* 1184 */           if (i > 0 && Grid.copy[i - 1][j] == TREE) { count++; x = i - 1; y = j; }
/* 1185 */            if (j > 0 && Grid.copy[i][j - 1] == TREE) { count++; x = i; y = j - 1; }
/* 1186 */            if (i < Grid.xSz - 1 && Grid.copy[i + 1][j] == TREE) { count++; x = i + 1; y = j; }
/* 1187 */            if (j < Grid.ySz - 1 && Grid.copy[i][j + 1] == TREE) { count++; x = i; y = j + 1; }
/* 1188 */            if (count == 1)
/* 1189 */           { Grid.copy[x][y] = NONTREE;
/* 1190 */             found = true; } 
/*      */         } 
/*      */       } 
/* 1193 */     }  return found;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean solveTents() {
/*      */     int j;
/* 1201 */     for (j = 0; j < Grid.ySz; j++) {
/* 1202 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1203 */         if (Grid.copy[i][j] == TENT)
/* 1204 */           Grid.copy[i][j] = 0; 
/*      */       } 
/* 1206 */     }  for (boolean found = true; found; ) {
/* 1207 */       found = rowAndColumnCounts();
/* 1208 */       while (allocateTreesToTents());
/* 1209 */       found |= noAdjacentTrees();
/* 1210 */       found |= oneOptionTrees();
/* 1211 */       if (Op.getInt(Op.TE.TeDifficulty.ordinal(), Op.te) > 24) {
/* 1212 */         found |= rowAndColumnGaps();
/*      */       }
/*      */     } 
/*      */     
/* 1216 */     for (j = 0; j < Grid.ySz; j++) {
/* 1217 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1218 */         if (Grid.scratch[i][j] == TENT && Grid.copy[i][j] != TENT)
/* 1219 */           return false; 
/*      */       } 
/* 1221 */     }  for (j = 0; j <= Grid.ySz; j++) {
/* 1222 */       for (int i = 0; i <= Grid.xSz; i++)
/* 1223 */         Grid.copy[i][j] = Grid.scratch[i][j]; 
/*      */     } 
/* 1225 */     return true;
/*      */   }
/*      */   
/*      */   static boolean insertTentAndTree() {
/* 1229 */     Random r = new Random();
/* 1230 */     int loop = Grid.xSz * Grid.ySz * 10;
/*      */ 
/*      */ 
/*      */     
/* 1234 */     for (int l = 0;; l++) {
/* 1235 */       if (l == loop) return false; 
/* 1236 */       int i = r.nextInt(Grid.xSz), j = r.nextInt(Grid.ySz);
/* 1237 */       if (Grid.scratch[i][j] == 0) {
/* 1238 */         int y; boolean found; for (found = false, y = j - 1; y < j + 2; y++) {
/* 1239 */           if (y >= 0 && y != Grid.ySz)
/* 1240 */             for (int x = i - 1; x < i + 2; x++) {
/* 1241 */               if (x >= 0 && x != Grid.xSz && 
/* 1242 */                 Grid.scratch[x][y] == TENT) found = true; 
/*      */             }  
/*      */         } 
/* 1245 */         if (!found) {
/*      */           int x;
/*      */           do {
/* 1248 */             x = r.nextInt(3) - 1;
/* 1249 */             y = r.nextInt(3) - 1;
/* 1250 */           } while ((x != 0 || y == 0) && (x == 0 || y != 0));
/*      */ 
/*      */           
/* 1253 */           x += i; y += j;
/* 1254 */           if (y >= 0 && y != Grid.ySz && x >= 0 && x != Grid.xSz && 
/* 1255 */             Grid.scratch[x][y] == GRASS) {
/* 1256 */             Grid.scratch[x][y] = TREE;
/* 1257 */             Grid.scratch[i][j] = TENT;
/* 1258 */             Grid.scratch[i][Grid.ySz] = Grid.scratch[i][Grid.ySz] + 1;
/* 1259 */             Grid.scratch[Grid.xSz][j] = Grid.scratch[Grid.xSz][j] + 1; break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1264 */     return true;
/*      */   }
/*      */   
/*      */   private void multiBuild() {
/* 1268 */     String title = Methods.puzzleTitle;
/* 1269 */     int[] diffDef = { 1, 1, 1, 1, 49, 49, 49 };
/* 1270 */     int[] sizeDef = { 6, 7, 8, 9, 10, 11, 12 };
/*      */     
/* 1272 */     int saveDiff = Op.getInt(Op.TE.TeDifficulty.ordinal(), Op.te);
/* 1273 */     int saveAcross = Op.getInt(Op.TE.TeAcross.ordinal(), Op.te);
/* 1274 */     int saveDown = Op.getInt(Op.TE.TeDown.ordinal(), Op.te);
/*      */     
/* 1276 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1277 */     Calendar c = Calendar.getInstance();
/*      */     
/* 1279 */     for (hmCount = 1; hmCount <= howMany; hmCount++) {
/* 1280 */       if (startPuz > 9999999) { try {
/* 1281 */           c.setTime(sdf.parse("" + startPuz));
/* 1282 */         } catch (ParseException ex) {}
/* 1283 */         startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 1286 */       Methods.puzzleTitle = "TENTS Puzzle : " + startPuz;
/* 1287 */       if (Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue()) {
/* 1288 */         Op.setInt(Op.TE.TeDifficulty.ordinal(), diffDef[(startPuz - 1) % 7], Op.te);
/* 1289 */         Op.setInt(Op.TE.TeAcross.ordinal(), sizeDef[(startPuz - 1) % 7], Op.te);
/* 1290 */         Op.setInt(Op.TE.TeDown.ordinal(), sizeDef[(startPuz - 1) % 7], Op.te);
/*      */       } 
/*      */       
/* 1293 */       Methods.buildProgress(jfTents, Op.te[Op.TE.TePuz
/* 1294 */             .ordinal()] = "" + startPuz + ".tents");
/* 1295 */       buildTents();
/* 1296 */       restoreFrame();
/* 1297 */       Wait.shortWait(100);
/* 1298 */       if (Def.building == 2)
/*      */         return; 
/* 1300 */       startPuz++;
/*      */     } 
/* 1302 */     howMany = 1;
/* 1303 */     Methods.puzzleTitle = title;
/* 1304 */     Op.setInt(Op.TE.TeDifficulty.ordinal(), saveDiff, Op.te);
/* 1305 */     Op.setInt(Op.TE.TeAcross.ordinal(), saveAcross, Op.te);
/* 1306 */     Op.setInt(Op.TE.TeDown.ordinal(), saveDown, Op.te);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void buildTents() {
/* 1312 */     int k = 0; while (true) {
/* 1313 */       makeGrid(); int i;
/* 1314 */       for (i = 0; i < 51 && 
/* 1315 */         insertTentAndTree(); i++);
/*      */       
/* 1317 */       for (int j = 0; j <= Grid.ySz; j++) {
/* 1318 */         for (i = 0; i <= Grid.xSz; i++)
/* 1319 */           Grid.copy[i][j] = Grid.scratch[i][j]; 
/*      */       } 
/* 1321 */       if (solveTents())
/*      */         break; 
/* 1323 */       if (Def.building == 2) {
/*      */         return;
/*      */       }
/* 1326 */       if (howMany == 1 && k++ % 500 == 0) {
/* 1327 */         restoreFrame();
/* 1328 */         Methods.buildProgress(jfTents, Op.su[Op.SU.SuPuz.ordinal()]);
/*      */       } 
/*      */     } 
/* 1331 */     saveTents(Op.te[Op.TE.TePuz.ordinal()]);
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\TentsBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */