/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class TentsSolve extends JPanel {
/*     */   static JFrame jfSolveTents;
/*     */   static JMenuBar menuBar;
/*     */   JMenu menu;
/*     */   JMenu submenu;
/*     */   JMenuItem menuItem;
/*     */   static JPanel pp;
/*  24 */   static int GRASS = 0; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; Runnable solveThread; int memMode; static int TREE = 1; static int NOTENT = 2; static int TENT = 3; static int NONTREE = 4;
/*     */   
/*  26 */   String tentsSolve = "<div>A Crossword Express <b>TENTS</b> puzzle consists of a square or rectangular array of squares in which some of the squares contain a tree, with the remainder containing only grass. The puzzle is solved by placing tents into selected grassy squares so that each tree has its own tent (either horizontally or vertically), and each tent has its own tree (either horizontally or vertically). The squares in which tents are placed must not touch on either the sides or the corners. Numbers located to the side and to the bottom of the puzzle tell you how many tents are in each row and column.<p/>Solving the puzzle is a point and click mouse operation. A single click inside a square will insert a black dot in the center of the square. Insert these black dots into all squares which you know cannot contain a tent. A second click will replace the black dot with a tent, and a third click will return the square to a grass only condition for those cases where you believe you have made a mistake.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Load a Puzzle</span><br/>Use this option to choose the puzzle you want to solve from the pool of TENTS puzzles currently available on your computer.<p/><li/><span>Quit Solving</span><br/>Returns you to the TENTS Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Reveal Errors</span><br/>If you think you may have made errors, this option will show you where they are by highlighting them for a period of 1.5 seconds.<p/><li/><span>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Tents Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TentsSolve(JFrame jf) {
/*  67 */     this.memMode = Def.puzzleMode;
/*  68 */     Def.puzzleMode = 191;
/*     */     
/*  70 */     jfSolveTents = new JFrame("Tents");
/*  71 */     jfSolveTents.setSize(Op.getInt(Op.TE.TeW.ordinal(), Op.te), Op.getInt(Op.TE.TeH.ordinal(), Op.te));
/*  72 */     int frameX = (jf.getX() + jfSolveTents.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveTents.getWidth() - 10) : jf.getX();
/*  73 */     jfSolveTents.setLocation(frameX, jf.getY());
/*  74 */     jfSolveTents.setLayout((LayoutManager)null);
/*  75 */     jfSolveTents.setDefaultCloseOperation(0);
/*  76 */     jfSolveTents
/*  77 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/*  79 */             int oldw = Op.getInt(Op.TE.TeW.ordinal(), Op.te);
/*  80 */             int oldh = Op.getInt(Op.TE.TeH.ordinal(), Op.te);
/*  81 */             Methods.frameResize(TentsSolve.jfSolveTents, oldw, oldh, 500, 580);
/*  82 */             Op.setInt(Op.TE.TeW.ordinal(), TentsSolve.jfSolveTents.getWidth(), Op.te);
/*  83 */             Op.setInt(Op.TE.TeH.ordinal(), TentsSolve.jfSolveTents.getHeight(), Op.te);
/*  84 */             TentsSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/*  88 */     jfSolveTents
/*  89 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/*  91 */             if (Def.selecting)
/*  92 */               return;  Op.saveOptions("tents.opt", Op.te);
/*  93 */             TentsSolve.this.restoreIfDone();
/*  94 */             TentsSolve.saveTents(Op.te[Op.TE.TePuz.ordinal()]);
/*  95 */             CrosswordExpress.transfer(190, TentsSolve.jfSolveTents);
/*     */           }
/*     */         });
/*     */     
/*  99 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 102 */     this.solveThread = (() -> {
/*     */         for (int j = 0; j < Grid.ySz; j++) {
/*     */           for (int i = 0; i < Grid.xSz; i++) {
/*     */             if ((Grid.sol[i][j] == 3 || Grid.copy[i][j] == 3) && Grid.sol[i][j] != Grid.copy[i][j])
/*     */               return; 
/*     */           } 
/*     */         }  Methods.congratulations(jfSolveTents);
/*     */       });
/* 110 */     jl1 = new JLabel(); jfSolveTents.add(jl1);
/* 111 */     jl2 = new JLabel(); jfSolveTents.add(jl2);
/*     */ 
/*     */     
/* 114 */     menuBar = new JMenuBar();
/* 115 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 116 */     jfSolveTents.setJMenuBar(menuBar);
/*     */     
/* 118 */     this.menu = new JMenu("File");
/* 119 */     menuBar.add(this.menu);
/* 120 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 121 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 122 */     this.menu.add(this.menuItem);
/* 123 */     this.menuItem
/* 124 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveTents(Op.te[Op.TE.TePuz.ordinal()]);
/*     */           new Select(jfSolveTents, "tents", "tents", Op.te, Op.TE.TePuz.ordinal(), false);
/*     */         });
/* 132 */     this.menuItem = new JMenuItem("Quit Solving");
/* 133 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 134 */     this.menu.add(this.menuItem);
/* 135 */     this.menuItem
/* 136 */       .addActionListener(ae -> {
/*     */           Op.saveOptions("tents.opt", Op.te);
/*     */           
/*     */           restoreIfDone();
/*     */           
/*     */           saveTents(Op.te[Op.TE.TePuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(190, jfSolveTents);
/*     */         });
/* 145 */     this.menu = new JMenu("View");
/* 146 */     menuBar.add(this.menu);
/* 147 */     this.menuItem = new JMenuItem("Display Options");
/* 148 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 149 */     this.menu.add(this.menuItem);
/* 150 */     this.menuItem
/* 151 */       .addActionListener(ae -> {
/*     */           TentsBuild.printOptions(jfSolveTents, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 158 */     this.menu = new JMenu("Tasks");
/* 159 */     menuBar.add(this.menu);
/*     */     
/* 161 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 166 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 168 */     this.menuItem = new JMenuItem("Reveal Errors");
/* 169 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 170 */     this.menu.add(this.menuItem);
/* 171 */     this.menuItem
/* 172 */       .addActionListener(ae -> {
/*     */           if (Methods.noErrors == 0) {
/*     */             this.myTimer.start();
/*     */             
/*     */             Def.dispErrors = Boolean.valueOf(true);
/*     */           } else {
/*     */             Methods.noReveal(jfSolveTents);
/*     */           } 
/*     */           
/*     */           pp.repaint();
/*     */         });
/* 183 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 184 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 185 */     this.menu.add(this.menuItem);
/* 186 */     this.menuItem
/* 187 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             for (int j = 0; j < Grid.ySz; j++) {
/*     */               for (int i = 0; i < Grid.xSz; i++) {
/*     */                 Grid.sol[i][j] = Grid.copy[i][j];
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             Methods.noReveal(jfSolveTents);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 199 */     this.menuItem = new JMenuItem("Begin again");
/* 200 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 201 */     this.menu.add(this.menuItem);
/* 202 */     this.menuItem
/* 203 */       .addActionListener(ae -> {
/*     */           clearSolution();
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 210 */     this.menu = new JMenu("Help");
/* 211 */     menuBar.add(this.menu);
/* 212 */     this.menuItem = new JMenuItem("Tents Help");
/* 213 */     this.menu.add(this.menuItem);
/* 214 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 215 */     this.menuItem
/* 216 */       .addActionListener(ae -> Methods.cweHelp(jfSolveTents, null, "Solving Tents Puzzles", this.tentsSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     loadTents(Op.te[Op.TE.TePuz.ordinal()]);
/* 223 */     pp = new TentsSolvePP(0, 37, jfSolveTents);
/* 224 */     jfSolveTents.add(pp);
/*     */     
/* 226 */     pp
/* 227 */       .addMouseListener(new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 229 */             TentsSolve.this.updateGrid(e);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 234 */     pp
/* 235 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 237 */             if (Def.isMac) {
/* 238 */               TentsSolve.jfSolveTents.setResizable((TentsSolve.jfSolveTents.getWidth() - e.getX() < 15 && TentsSolve.jfSolveTents
/* 239 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 244 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 248 */     jfSolveTents.setVisible(true);
/* 249 */     Insets insets = jfSolveTents.getInsets();
/* 250 */     panelW = jfSolveTents.getWidth() - insets.left + insets.right;
/* 251 */     panelH = jfSolveTents.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 252 */     pp.setSize(panelW, panelH);
/* 253 */     jfSolveTents.requestFocusInWindow();
/* 254 */     pp.repaint();
/* 255 */     Methods.infoPanel(jl1, jl2, "Solve Tents", "Puzzle : " + Op.te[Op.TE.TePuz.ordinal()], panelW);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 259 */     int i = (int)((width - inset) / (Grid.xSz + 0.5D));
/* 260 */     int j = (int)((height - inset) / (Grid.ySz + 0.5D));
/* 261 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 262 */     Grid.xOrg = x + ((Def.puzzleMode == 8) ? ((width - (int)((Grid.xSz + 0.5D) * Grid.xCell)) / 2) : 10);
/* 263 */     Grid.yOrg = y + ((Def.puzzleMode == 8) ? ((height - (int)((Grid.ySz + 0.5D) * Grid.yCell)) / 2) : 10);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveTents(String tentsName) {
/*     */     try {
/* 269 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream("tents/" + tentsName));
/* 270 */       dataOut.writeInt(Grid.xSz);
/* 271 */       dataOut.writeInt(Grid.ySz);
/* 272 */       dataOut.writeByte(Methods.noReveal);
/* 273 */       dataOut.writeByte(Methods.noErrors);
/* 274 */       for (int i = 0; i < 54; i++)
/* 275 */         dataOut.writeByte(0); 
/* 276 */       for (int j = 0; j <= Grid.ySz; j++) {
/* 277 */         for (int k = 0; k <= Grid.xSz; k++) {
/* 278 */           dataOut.writeInt(Grid.sol[k][j]);
/* 279 */           dataOut.writeInt(Grid.copy[k][j]);
/*     */         } 
/* 281 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 282 */       dataOut.writeUTF(Methods.author);
/* 283 */       dataOut.writeUTF(Methods.copyright);
/* 284 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 285 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 286 */       dataOut.close();
/*     */     }
/* 288 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadTents(String tentsName) {
/*     */     try {
/* 296 */       File fl = new File("tents/" + tentsName);
/* 297 */       if (!fl.exists()) {
/* 298 */         fl = new File("tents/");
/* 299 */         String[] s = fl.list(); int k;
/* 300 */         for (k = 0; k < s.length && (
/* 301 */           s[k].lastIndexOf(".tents") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 303 */         tentsName = s[k];
/* 304 */         Op.te[Op.TE.TePuz.ordinal()] = tentsName;
/*     */       } 
/*     */ 
/*     */       
/* 308 */       DataInputStream dataIn = new DataInputStream(new FileInputStream("tents/" + tentsName));
/* 309 */       Grid.xSz = dataIn.readInt();
/* 310 */       Grid.ySz = dataIn.readInt();
/* 311 */       Methods.noReveal = dataIn.readByte();
/* 312 */       Methods.noErrors = dataIn.readByte(); int i;
/* 313 */       for (i = 0; i < 54; i++)
/* 314 */         dataIn.readByte(); 
/* 315 */       for (int j = 0; j <= Grid.ySz; j++) {
/* 316 */         for (i = 0; i <= Grid.xSz; i++) {
/* 317 */           Grid.sol[i][j] = dataIn.readInt();
/* 318 */           Grid.copy[i][j] = dataIn.readInt();
/*     */         } 
/* 320 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 321 */       Methods.author = dataIn.readUTF();
/* 322 */       Methods.copyright = dataIn.readUTF();
/* 323 */       Methods.puzzleNumber = dataIn.readUTF();
/* 324 */       Methods.puzzleNotes = dataIn.readUTF();
/* 325 */       dataIn.close();
/*     */     }
/* 327 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawOneTent(Graphics2D g2, int x, int y, int xCell, int yCell) {
/* 333 */     int[] xPoints = new int[5], yPoints = new int[5];
/* 334 */     int[] xStart = new int[6], yStart = new int[6];
/* 335 */     int[] xEnd = new int[6], yEnd = new int[6];
/*     */     
/* 337 */     int cntr = xPoints[0] = x + xCell / 2;
/* 338 */     int width = xCell / 4;
/* 339 */     xPoints[2] = cntr - width; xPoints[1] = cntr - width;
/* 340 */     xPoints[4] = cntr + width; xPoints[3] = cntr + width;
/* 341 */     int top = yPoints[0] = y + yCell / 5;
/* 342 */     yPoints[4] = top + width; yPoints[1] = top + width;
/* 343 */     int base = y + 3 * yCell / 4;
/* 344 */     yPoints[3] = base; yPoints[2] = base;
/* 345 */     int flapX = cntr - xCell / 10;
/* 346 */     int flapY = y + 9 * yCell / 20;
/* 347 */     int eaves = xCell / 12;
/* 348 */     xStart[0] = cntr + width; yStart[0] = top + width; xEnd[0] = cntr + width + eaves; yEnd[0] = top + width + eaves;
/* 349 */     xStart[1] = cntr - width; yStart[1] = top + width; xEnd[1] = cntr - width - eaves; yEnd[1] = top + width + eaves;
/* 350 */     xStart[2] = flapX; yStart[2] = flapY; xEnd[2] = flapX; yEnd[2] = base;
/* 351 */     xStart[3] = flapX; yStart[3] = flapY; xEnd[3] = cntr + xCell / 8; yEnd[3] = base;
/* 352 */     xStart[4] = flapX; yStart[4] = flapY; xEnd[4] = cntr + xCell / 8; yEnd[4] = base - yCell / 5;
/* 353 */     xStart[5] = cntr + xCell / 8; yStart[5] = base - yCell / 5; xEnd[5] = cntr + xCell / 8; yEnd[5] = base;
/*     */     
/* 355 */     g2.setStroke(new BasicStroke(xCell / 25.0F, 1, 2));
/*     */     
/* 357 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTent.ordinal(), Op.te)) : Def.COLOR_WHITE);
/* 358 */     g2.fillPolygon(xPoints, yPoints, 5);
/*     */     
/* 360 */     g2.setColor(Def.COLOR_BLACK);
/* 361 */     g2.drawPolygon(xPoints, yPoints, 5);
/*     */     
/* 363 */     for (int i = 0; i < 6; i++)
/* 364 */       g2.drawLine(xStart[i], yStart[i], xEnd[i], yEnd[i]); 
/*     */   }
/*     */   
/*     */   static void drawTree(Graphics2D g2, int x, int y, int xCell, int yCell) {
/* 368 */     int[] xPoints = new int[3], yPoints = new int[3];
/* 369 */     int[] xOffset = { -4, 0, 4, -6, 0, 6, -8, 0, 8 };
/* 370 */     int[] yOffset = { 5, 2, 5, 9, 4, 9, 14, 7, 14 };
/*     */     
/* 372 */     g2.setStroke(new BasicStroke(xCell / 25.0F, 0, 2));
/* 373 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTrunk.ordinal(), Op.te)) : Def.COLOR_BLACK);
/* 374 */     int center = xCell / 2;
/* 375 */     g2.drawLine(x + center, y + 13 * yCell / 20, x + center, y + 18 * yCell / 20);
/*     */     
/* 377 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeTree.ordinal(), Op.te)) : Def.COLOR_BLACK);
/* 378 */     for (int j = 0; j < 3; j++) {
/* 379 */       for (int i = 0; i < 3; i++) {
/* 380 */         xPoints[i] = x + center + xOffset[i + 3 * j] * xCell / 20;
/* 381 */         yPoints[i] = y + yOffset[i + 3 * j] * yCell / 20;
/*     */       } 
/* 383 */       g2.fillPolygon(xPoints, yPoints, 3);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void drawDot(Graphics2D g2, int x, int y, int xCell, int yCell) {
/* 388 */     int[] xPoints = new int[4], yPoints = new int[4];
/* 389 */     int[] xOffset = { 9, 11, 11, 9 };
/* 390 */     int[] yOffset = { 9, 9, 11, 11 };
/*     */     
/* 392 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeLine.ordinal(), Op.te)) : Def.COLOR_BLACK);
/* 393 */     for (int i = 0; i < 4; i++) {
/* 394 */       xPoints[i] = x + xOffset[i] * xCell / 20;
/* 395 */       yPoints[i] = y + yOffset[i] * yCell / 20;
/*     */     } 
/*     */     
/* 398 */     g2.fillPolygon(xPoints, yPoints, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawTents(Graphics2D g2, int[][] puzzleArray) {
/* 405 */     Stroke normalStroke = new BasicStroke(Grid.xCell / 25.0F, 2, 2);
/* 406 */     g2.setStroke(normalStroke);
/*     */     
/* 408 */     RenderingHints rh = g2.getRenderingHints();
/* 409 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 410 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 411 */     g2.setRenderingHints(rh);
/*     */     
/*     */     int j;
/* 414 */     for (j = 0; j < Grid.ySz + 1; j++) {
/* 415 */       for (int i = 0; i < Grid.xSz + 1; i++) {
/* 416 */         if (Def.dispWithColor.booleanValue()) {
/* 417 */           if (Def.dispErrors.booleanValue() && ((Grid.sol[i][j] == TENT && Grid.copy[i][j] != TENT) || (Grid.sol[i][j] == NOTENT && Grid.copy[i][j] == TENT))) {
/* 418 */             g2.setColor(new Color(Op.getColorInt(Op.TE.TeError.ordinal(), Op.te)));
/*     */           } else {
/* 420 */             g2.setColor(new Color(Op.getColorInt(Op.TE.TeCell.ordinal(), Op.te)));
/*     */           } 
/*     */         } else {
/* 423 */           g2.setColor(Def.COLOR_WHITE);
/* 424 */         }  if (i == Grid.xSz || j == Grid.ySz) g2.setColor(Def.COLOR_WHITE); 
/* 425 */         g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, (i == Grid.xSz) ? (Grid.xCell / 2) : Grid.xCell, (j == Grid.ySz) ? (Grid.yCell / 2) : Grid.yCell);
/* 426 */         g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeLine.ordinal(), Op.te)) : Def.COLOR_BLACK);
/*     */       } 
/*     */     } 
/*     */     
/* 430 */     int len = Grid.xSz * Grid.xCell + Grid.xCell / 2;
/* 431 */     for (j = 0; j < Grid.ySz + 1; j++)
/* 432 */       g2.drawLine(Grid.xOrg, Grid.yOrg + j * Grid.yCell, Grid.xOrg + len, Grid.yOrg + j * Grid.yCell); 
/* 433 */     for (j = 0; j < Grid.xSz + 1; j++)
/* 434 */       g2.drawLine(Grid.xOrg + j * Grid.xCell, Grid.yOrg, Grid.xOrg + j * Grid.xCell, Grid.yOrg + len); 
/* 435 */     g2.drawLine(Grid.xOrg, Grid.yOrg + len, Grid.xOrg + len, Grid.yOrg + len);
/* 436 */     g2.drawLine(Grid.xOrg + len, Grid.yOrg, Grid.xOrg + len, Grid.yOrg + len);
/*     */ 
/*     */     
/* 439 */     for (j = 0; j < Grid.ySz; j++) {
/* 440 */       for (int i = 0; i < Grid.xSz; i++) {
/* 441 */         if (Grid.sol[i][j] == TREE)
/* 442 */           drawTree(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/* 443 */         if (Grid.sol[i][j] == NOTENT)
/* 444 */           drawDot(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/* 445 */         if (Grid.sol[i][j] == TENT) {
/* 446 */           drawOneTent(g2, Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */         }
/*     */       } 
/*     */     } 
/* 450 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.TE.TeCount.ordinal(), Op.te)) : Def.COLOR_BLACK);
/* 451 */     g2.setFont(new Font("SansSerif", 0, 4 * Grid.yCell / 10));
/* 452 */     FontMetrics fm = g2.getFontMetrics();
/* 453 */     for (j = 0; j <= Grid.ySz; j++) {
/* 454 */       for (int i = 0; i <= Grid.xSz; i++) {
/* 455 */         if ((i == Grid.xSz && j < Grid.ySz) || (j == Grid.ySz && i < Grid.xSz)) {
/* 456 */           char ch = (char)(48 + Grid.copy[i][j]);
/* 457 */           int w = fm.stringWidth("" + ch);
/* 458 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell / ((i == Grid.xSz) ? 2 : 1) - w) / 2, Grid.yOrg + j * Grid.yCell + ((j == Grid.ySz) ? fm
/* 459 */               .getAscent() : ((Grid.yCell + fm.getAscent()) / 2)));
/*     */         } 
/*     */       } 
/* 462 */     }  g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   
/*     */   static void clearSolution() {
/* 466 */     for (int j = 0; j < Grid.ySz; j++) {
/* 467 */       for (int i = 0; i < Grid.xSz; i++) {
/* 468 */         if (Grid.sol[i][j] != 1)
/* 469 */           Grid.sol[i][j] = 0; 
/*     */       } 
/*     */     } 
/*     */   } void restoreIfDone() {
/* 473 */     for (int j = 0; j < Grid.ySz; j++) {
/* 474 */       for (int i = 0; i < Grid.xSz; i++)
/* 475 */       { if ((Grid.sol[i][j] == 3 || Grid.copy[i][j] == 3) && Grid.sol[i][j] != Grid.copy[i][j])
/*     */           return;  } 
/* 477 */     }  clearSolution();
/*     */   }
/*     */   
/*     */   void checkForCompletion() {
/* 481 */     (new Thread(this.solveThread)).start();
/*     */   }
/*     */   
/*     */   void updateGrid(MouseEvent e) {
/* 485 */     int x = e.getX(), y = e.getY();
/*     */     
/* 487 */     if (x < Grid.xOrg || y < Grid.yOrg)
/* 488 */       return;  x = (x - Grid.xOrg) / Grid.xCell;
/* 489 */     y = (y - Grid.yOrg) / Grid.yCell;
/* 490 */     if (x > Grid.xSz || y > Grid.ySz)
/*     */       return; 
/* 492 */     if (Grid.sol[x][y] != 1) {
/* 493 */       Grid.sol[x][y] = (Grid.sol[x][y] + 1) % 4;
/* 494 */       if (Grid.sol[x][y] == 1)
/* 495 */         Grid.sol[x][y] = 2; 
/*     */     } 
/* 497 */     checkForCompletion();
/* 498 */     restoreFrame();
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\TentsSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */