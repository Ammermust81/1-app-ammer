package crosswordexpress;

class WS {
  int X;
  
  int Y;
  
  int D;
  
  int L;
  
  int sX;
  
  int sY;
  
  int sD;
  
  int wIndex;
  
  int thisTarget;
}


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\WS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */