/*     */ package crosswordexpress;
/*     */ import java.io.DataInputStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class WordTools {
/*  14 */   String matching = "<div>This function will be useful for people wanting to solve those last few elusive words in a crossword puzzle. It is a generalised search tool which enables you to search an entire dictionary for words which match a <b>Word Template (or Filter)</b> which you provide. When you click <b>OK</b> the list of matching words will appear in the list box.</div><p/><span class='m'>Filter Description</span><div>The filter consists of a string of standard characters interleaved with <b>wild card</b> characters in a way which will be quite familiar to users of <b>DOS</b> and <b>UNIX.</b><br/><br/>The components of a filter are:-</div><ul><li/><b>Standard Characters.</b>   The characters in a <b>Word</b> must match exactly any corresponding <b> Standard Characters</b> in the <b>Filter</b>.<p/><li/><b>The ? wild card.</b>   A <b>?</b> character at any position in the <b>Filter</b> will match any character in the corresponding position in the <b>Word</b>.<p/><li/><b>The * wild card.</b>   A <b>*</b> character at any position in the <b>Filter</b> will match any number of characters in the <b>Word</b>, including zero characters.<p/><li/><b>The [ABC...XYZ] wild card.</b> A set of square brackets surrounding a string of standard characters will match the corresponding character in <b>Word</b> if that character is included in the string of standard characters. The string of standard characters can include the - character to denote a run of consecutive characters. eg. A-G is equivalent to ABCDEFG.</ul><div>A few examples may help to clarify these rules:-</div><ul><li/><b>T?E </b>will match the words THE, TOE etc.<p/><li/><b>T*E </b>will match the words THE, TOE, TIME, TROUBLE etc.<p/><li/><b>A[CL]E </b>will match the words ACE and ALE, but not AGE etc.<p/><li/><b>*[A-RT-Z] </b>will match any word not ending with S<p/><li/><b>*ABLE </b>will match any words which end with ABLE.<p/><li/><b>*CEI* </b>will match any word containing the sub-string CEI.<p/><li/><b>*C?E[LNP]? </b>will match the words CREPE, ACCENT, ACCEPT, ANCIENT, NICKELS etc.</ul>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JFrame jfWordTools;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JLabel jlDictionaryName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JComboBox<String> jcbbDictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   String matchHelp = this.matching + "</body>";
/*     */ 
/*     */   
/*  46 */   String anagrams = "<div>An anagram of a word (or group of words) is simply a rearrangement of the letters contained therein to give a different word (or group of words). For example the words <b>BLUE ROT</> can form the anagram <b>TROUBLE</b>.</div><p/><div>Begin by entering the word (or words) into the text box provided. Clicking the <b>OK</b> button will begin the process, and in a short time the anagrams found will appear in the list box.</div><p/><div><b>WARNING:</b> If you enter more than a dozen or so letters, you may get a surprisingly large number of anagrams. For example, the words <b>UNITED STATES</b> will yield 2,227 anagrams using the English dictionary provided with this program.</div><p/><div>If you use the <b>Shortest word to include in list</b> control, you can reduce this to manageable levels. Setting this control to a value of 3 will reduce the number of anagrams to 1,087 and setting it to 5 will reduce it to just 13. Of course, the time taken to generate the list will be correspondingly reduced.</div>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   String anagramHelp = this.anagrams + "</body>";
/*     */ 
/*     */   
/*  59 */   String contained = "<div>For any given word, a <b>Contained Word</b> is any word which can be constructed using the letters of that word, with the proviso that each letter may not be used more than once.</div><p/><div>Begin by entering the word into the text box provided. Clicking the <b>OK</b> button will begin the process, and in a short time the Contained Words that have been found will appear in the list box.</div><p/><div>In some cases you will only be interested in words of a certain length or greater. Using the <b>Shortest word to include in list</b> control will allow you to control this aspect of the process.</div><p/><div>As the name implies, checking the <b>Only list words containing first letter</b> Check Box will limit the list to those words which actually contain the first letter of the given word.</div><p/><div>Checking the <b>Display Sundry letters</b> Check Box will result in those letters not used in the <b>Contained Word</b> being included in the list box.</div>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   String containedHelp = this.contained + "</body>";
/*     */ 
/*     */   
/*  73 */   String container = "<div>For any given word, a <b>Container Word</b> is a word which contains all of the letters of the given word, with the proviso that letters which have multiple appearances in the given word also have multiple appearances in the <b>Container Word</b>.</div><p/><div>Begin by entering the word into the text box provided. Clicking the <b>OK</b> button will begin the process, and in a short time the Container Words that have been found will appear in the list box.</div><p/><div>Checking the <b>Display Sundry letters</b> Check Box will result in the excess letters of the <b>Container Word</b> being included in the list box.</div>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   String containerHelp = this.container + "</body>";
/*     */ 
/*     */   
/*  83 */   String wordToolsHelp = "<div>This menu includes a number of functions which display words extracted from a dictionary according to well defined rules. The functions currently available are:-<p/><ul><li><span class='s'>Find Matching Words</span>" + this.matching + "<p/>" + "<li><span class='s'>Find Anagrams</span>" + this.anagrams + "<p/>" + "<li><span class='s'>Find Contained Words</span>" + this.contained + "<p/>" + "<li><span class='s'>Find Container Words</span>" + this.container + "</ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WordTools(JFrame jfCWE) {
/*  94 */     Def.puzzleMode = 9;
/*  95 */     this.jfWordTools = new JFrame("Word Tools");
/*  96 */     this.jfWordTools.setSize(230, 350);
/*  97 */     int frameX = (jfCWE.getX() + this.jfWordTools.getWidth() > Methods.scrW) ? (Methods.scrW - this.jfWordTools.getWidth() - 10) : jfCWE.getX();
/*  98 */     this.jfWordTools.setLocation(frameX, jfCWE.getY());
/*  99 */     this.jfWordTools.setLayout((LayoutManager)null);
/* 100 */     this.jfWordTools.setDefaultCloseOperation(0);
/* 101 */     this.jfWordTools
/* 102 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 104 */             CrosswordExpress.jfCWE.setVisible(true);
/* 105 */             WordTools.this.jfWordTools.dispose();
/* 106 */             Methods.closeHelp();
/* 107 */             Def.puzzleMode = 1;
/*     */           }
/*     */         });
/*     */     
/* 111 */     Methods.closeHelp();
/*     */     
/* 113 */     JLabel jlSelDic = new JLabel("Select Dictionary");
/* 114 */     jlSelDic.setForeground(Def.COLOR_LABEL);
/* 115 */     jlSelDic.setSize(210, 16);
/* 116 */     jlSelDic.setLocation(15, 10);
/* 117 */     jlSelDic.setHorizontalAlignment(2);
/* 118 */     this.jfWordTools.add(jlSelDic);
/*     */     
/* 120 */     File fl = new File(System.getProperty("user.dir"));
/* 121 */     String[] s = fl.list();
/* 122 */     this.jcbbDictionary = new JComboBox<>();
/* 123 */     this.jcbbDictionary.setSize(205, 26);
/* 124 */     this.jcbbDictionary.setLocation(10, 30);
/* 125 */     for (int i = 0; i < s.length; i++) {
/* 126 */       if (s[i].endsWith(".dic") && !s[i].startsWith(".") && !s[i].startsWith("$")) {
/* 127 */         s[i] = s[i].substring(0, s[i].lastIndexOf('.'));
/* 128 */         this.jcbbDictionary.addItem("   " + s[i]);
/*     */       } 
/* 130 */     }  this.jcbbDictionary.setSelectedItem("   " + Op.msc[Op.MSC.WordToolsDic.ordinal()]);
/* 131 */     this.jfWordTools.add(this.jcbbDictionary);
/* 132 */     this.jcbbDictionary
/* 133 */       .addActionListener(ae -> Op.msc[Op.MSC.WordToolsDic.ordinal()] = this.jcbbDictionary.getSelectedItem().toString().trim());
/*     */ 
/*     */ 
/*     */     
/* 137 */     JButton jbMatchingWords = Methods.cweButton("Find Matching Words", 10, 65, 205, 26, null);
/* 138 */     jbMatchingWords.addActionListener(e -> matchingWords());
/*     */     
/* 140 */     this.jfWordTools.add(jbMatchingWords);
/*     */     
/* 142 */     JButton jbAnagram = Methods.cweButton("Find Anagrams", 10, 100, 205, 26, null);
/* 143 */     jbAnagram.addActionListener(e -> anagrams());
/*     */     
/* 145 */     this.jfWordTools.add(jbAnagram);
/*     */     
/* 147 */     JButton jbContainedWords = Methods.cweButton("Find Contained Words", 10, 135, 205, 26, null);
/* 148 */     jbContainedWords.addActionListener(e -> containedWords());
/*     */     
/* 150 */     this.jfWordTools.add(jbContainedWords);
/*     */     
/* 152 */     JButton jbContainerWords = Methods.cweButton("Find Container Words", 10, 170, 205, 26, null);
/* 153 */     jbContainerWords.addActionListener(e -> containerWords());
/*     */     
/* 155 */     this.jfWordTools.add(jbContainerWords);
/*     */     
/* 157 */     JButton jbQuit = Methods.cweButton("Quit Word Tools", 10, 205, 205, 26, null);
/* 158 */     jbQuit.addActionListener(e -> {
/*     */           CrosswordExpress.jfCWE.setVisible(true);
/*     */           this.jfWordTools.dispose();
/*     */           Def.puzzleMode = 1;
/*     */           Methods.closeHelp();
/*     */         });
/* 164 */     this.jfWordTools.add(jbQuit);
/*     */     
/* 166 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 10, 240, 205, 60, new ImageIcon("graphics/help.png"));
/* 167 */     jbHelp.addActionListener(e -> Methods.cweHelp(this.jfWordTools, null, "Word Tools", this.wordToolsHelp));
/*     */     
/* 169 */     this.jfWordTools.add(jbHelp);
/*     */     
/* 171 */     this.jfWordTools.pack();
/* 172 */     Insets insets = this.jfWordTools.getInsets();
/* 173 */     this.jfWordTools.setSize(225 + insets.left + insets.right, 310 + insets.top + insets.bottom);
/* 174 */     this.jfWordTools.setVisible(true);
/* 175 */     this.jfWordTools.setResizable(false);
/*     */   }
/*     */   
/*     */   static boolean filter(String word, String template) {
/* 179 */     char cht = ' ';
/* 180 */     int lw = word.length(), lt = template.length();
/*     */ 
/*     */     
/* 183 */     if (template.length() == 0) return true;
/*     */     
/* 185 */     int it = 0, iw = it; while (true) {
/* 186 */       char chw; boolean found; if (iw == lw && it == lt) return true; 
/* 187 */       if (iw == lw || it == lt) return false; 
/* 188 */       switch (template.charAt(it)) {
/*     */         case '*':
/* 190 */           if (it + 1 == lt) return true; 
/* 191 */           if (filter(word.substring(iw), template.substring(it + 1))) return true; 
/* 192 */           iw++;
/*     */           continue;
/*     */         case '[':
/* 195 */           chw = word.charAt(iw);
/* 196 */           found = false; it++; while (true) {
/* 197 */             char chx = template.charAt(it);
/* 198 */             if (chx == ']')
/* 199 */               break;  if (chx == '-') {
/* 200 */               char chy = template.charAt(++it); char ch;
/* 201 */               for (ch = cht; ch != chy; ch = (char)(ch + 1)) {
/* 202 */                 if (ch == chw) found = true; 
/* 203 */               }  it++;
/*     */               continue;
/*     */             } 
/* 206 */             cht = chx;
/* 207 */             if (cht == chw) found = true; 
/* 208 */             it++;
/*     */           } 
/*     */           
/* 211 */           if (!found) return false; 
/*     */         case ' ':
/*     */         case '?':
/* 214 */           iw++; it++;
/*     */           continue;
/*     */       } 
/* 217 */       if (word.charAt(iw) != template.charAt(it)) return false; 
/* 218 */       iw++; it++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void findMatchingWords(DefaultListModel<String> lmMatch, String template) {
/* 227 */     lmMatch.removeAllElements();
/*     */     
/*     */     try {
/* 230 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.msc[Op.MSC.WordToolsDic.ordinal()] + ".dic/xword.dic"));
/* 231 */       for (int i = 0; i < 128; i++)
/* 232 */         dataIn.readByte(); 
/* 233 */       while (dataIn.available() > 2) {
/* 234 */         dataIn.readInt();
/* 235 */         String s = dataIn.readUTF();
/* 236 */         if (filter(s.toUpperCase(), template))
/* 237 */           lmMatch.addElement("  " + s); 
/* 238 */         dataIn.readUTF();
/*     */       } 
/* 240 */       dataIn.close();
/*     */     }
/* 242 */     catch (IOException exc) {}
/*     */   }
/*     */   
/*     */   private void matchingWords() {
/* 246 */     JDialog jdlgMatch = new JDialog(this.jfWordTools, "Find Matching Words", true);
/* 247 */     jdlgMatch.setSize(300, 470);
/* 248 */     jdlgMatch.setResizable(false);
/* 249 */     jdlgMatch.setLayout((LayoutManager)null);
/* 250 */     jdlgMatch.setLocation(this.jfWordTools.getX(), this.jfWordTools.getY());
/*     */     
/* 252 */     jdlgMatch
/* 253 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 255 */             Methods.closeHelp();
/*     */           }
/*     */         });
/* 258 */     Methods.closeHelp();
/*     */     
/* 260 */     JLabel jlMatch = new JLabel("Enter the Word Template:");
/* 261 */     jlMatch.setForeground(Def.COLOR_LABEL);
/* 262 */     jlMatch.setSize(275, 20);
/* 263 */     jlMatch.setLocation(10, 5);
/* 264 */     jlMatch.setHorizontalAlignment(2);
/* 265 */     jdlgMatch.add(jlMatch);
/*     */     
/* 267 */     JTextField jtfTemplate = new JTextField("*", 30);
/* 268 */     jtfTemplate.setSize(275, 23);
/* 269 */     jtfTemplate.setLocation(10, 26);
/* 270 */     jtfTemplate.selectAll();
/* 271 */     jtfTemplate.setHorizontalAlignment(2);
/* 272 */     jdlgMatch.add(jtfTemplate);
/*     */     
/* 274 */     jtfTemplate.setFont(new Font("SansSerif", 1, 13));
/*     */     
/* 276 */     JLabel jl1 = new JLabel("The Matching words are:");
/* 277 */     jl1.setForeground(Def.COLOR_LABEL);
/* 278 */     jl1.setSize(275, 20);
/* 279 */     jl1.setLocation(10, 50);
/* 280 */     jl1.setHorizontalAlignment(2);
/* 281 */     jdlgMatch.add(jl1);
/*     */ 
/*     */ 
/*     */     
/* 285 */     DefaultListModel<String> lmMatch = new DefaultListModel<>();
/* 286 */     JList<String> jl = new JList<>(lmMatch);
/* 287 */     JScrollPane jsp = new JScrollPane(jl);
/* 288 */     jsp.setSize(275, 270);
/* 289 */     jsp.setLocation(10, 71);
/* 290 */     jdlgMatch.add(jsp);
/*     */     
/* 292 */     JLabel jlCount = new JLabel("");
/* 293 */     jlCount.setForeground(Def.COLOR_LABEL);
/* 294 */     jlCount.setSize(275, 20);
/* 295 */     jlCount.setLocation(10, 345);
/* 296 */     jlCount.setHorizontalAlignment(2);
/* 297 */     jdlgMatch.add(jlCount);
/*     */     
/* 299 */     JButton jbOK = Methods.cweButton("OK", 10, 370, 100, 26, null);
/* 300 */     jbOK.addActionListener(e -> {
/*     */           findMatchingWords(paramDefaultListModel, paramJTextField.getText().toUpperCase());
/*     */           paramJLabel.setText(paramDefaultListModel.size() + " Item(s) in list.");
/*     */         });
/* 304 */     jdlgMatch.add(jbOK);
/*     */     
/* 306 */     JButton jbCancel = Methods.cweButton("Cancel", 10, 405, 100, 26, null);
/* 307 */     jbCancel.addActionListener(e -> {
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 311 */     jdlgMatch.add(jbCancel);
/*     */     
/* 313 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 125, 370, 160, 61, new ImageIcon("graphics/help.png"));
/* 314 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Find Matching Words", this.matchHelp));
/*     */     
/* 316 */     jdlgMatch.add(jbHelp);
/*     */     
/* 318 */     jdlgMatch.getRootPane().setDefaultButton(jbOK);
/* 319 */     Methods.setDialogSize(jdlgMatch, 295, 441);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void findContainedWords(ArrayList<String> al, String subject, boolean common, boolean showExtra, int minLen) {
/* 327 */     al.clear();
/*     */     
/*     */     try {
/* 330 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.msc[Op.MSC.WordToolsDic.ordinal()] + ".dic/xword.dic")); int i;
/* 331 */       for (i = 0; i < 128; i++)
/* 332 */         dataIn.readByte(); 
/* 333 */       while (dataIn.available() > 2) {
/* 334 */         dataIn.readInt();
/* 335 */         String s = dataIn.readUTF(); int sLen;
/* 336 */         if ((sLen = s.length()) >= minLen && (
/* 337 */           !common || (common && s.indexOf(subject.charAt(0)) != -1))) {
/* 338 */           StringBuffer copy = new StringBuffer(subject); int j;
/* 339 */           for (i = 0; i < sLen && (
/* 340 */             j = copy.indexOf("" + s.charAt(i))) != -1; i++) {
/* 341 */             copy.deleteCharAt(j);
/*     */           }
/* 343 */           if (i == sLen)
/* 344 */             al.add(s + (showExtra ? ("       [" + copy + "]") : "")); 
/*     */         } 
/* 346 */         dataIn.readUTF();
/*     */       } 
/* 348 */       dataIn.close();
/*     */     }
/* 350 */     catch (IOException exc) {}
/*     */   }
/*     */   
/*     */   private void containedWords() {
/* 354 */     ArrayList<String> al = new ArrayList<>();
/*     */ 
/*     */     
/* 357 */     JDialog jdlgContained = new JDialog(this.jfWordTools, "Find Contained Words", false);
/* 358 */     jdlgContained.setSize(300, 546);
/* 359 */     jdlgContained.setResizable(false);
/* 360 */     jdlgContained.setLayout((LayoutManager)null);
/* 361 */     jdlgContained.setLocation(this.jfWordTools.getX(), this.jfWordTools.getY());
/*     */     
/* 363 */     jdlgContained
/* 364 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 366 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/* 370 */     Methods.closeHelp();
/*     */     
/* 372 */     JLabel jlContained = new JLabel("Enter the Subject Word:");
/* 373 */     jlContained.setForeground(Def.COLOR_LABEL);
/* 374 */     jlContained.setSize(275, 20);
/* 375 */     jlContained.setLocation(10, 5);
/* 376 */     jlContained.setHorizontalAlignment(2);
/* 377 */     jdlgContained.add(jlContained);
/*     */     
/* 379 */     JTextField jtfTemplate = new JTextField("*", 30);
/* 380 */     jtfTemplate.setSize(275, 23);
/* 381 */     jtfTemplate.setLocation(10, 26);
/* 382 */     jtfTemplate.selectAll();
/* 383 */     jtfTemplate.setHorizontalAlignment(2);
/* 384 */     jdlgContained.add(jtfTemplate);
/*     */     
/* 386 */     jtfTemplate.setFont(new Font("SansSerif", 1, 13));
/*     */     
/* 388 */     JLabel jlShort = new JLabel("Shortest word to include");
/* 389 */     jlShort.setForeground(Def.COLOR_LABEL);
/* 390 */     jlShort.setSize(275, 20);
/* 391 */     jlShort.setLocation(70, 60);
/* 392 */     jlShort.setHorizontalAlignment(2);
/* 393 */     jdlgContained.add(jlShort);
/*     */     
/* 395 */     JComboBox<Integer> jcbbLen = new JComboBox<>();
/* 396 */     for (int i = 2; i <= 15; i++)
/* 397 */       jcbbLen.addItem(Integer.valueOf(i)); 
/* 398 */     jcbbLen.setSize(50, 20);
/* 399 */     jcbbLen.setLocation(10, 60);
/* 400 */     jdlgContained.add(jcbbLen);
/* 401 */     jcbbLen.setBackground(Def.COLOR_BUTTONBG);
/*     */     
/* 403 */     JCheckBox jcbCommon = new JCheckBox("Only list words using first letter", false);
/* 404 */     jcbCommon.setForeground(Def.COLOR_LABEL);
/* 405 */     jcbCommon.setOpaque(false);
/* 406 */     jcbCommon.setSize(280, 20);
/* 407 */     jcbCommon.setLocation(10, 85);
/* 408 */     jdlgContained.add(jcbCommon);
/*     */     
/* 410 */     JCheckBox jcbShowExtra = new JCheckBox("Display Sundry Letters", false);
/* 411 */     jcbShowExtra.setForeground(Def.COLOR_LABEL);
/* 412 */     jcbShowExtra.setOpaque(false);
/* 413 */     jcbShowExtra.setSize(280, 20);
/* 414 */     jcbShowExtra.setLocation(10, 110);
/* 415 */     jdlgContained.add(jcbShowExtra);
/*     */     
/* 417 */     JLabel jl1 = new JLabel("The Contained words are:");
/* 418 */     jl1.setForeground(Def.COLOR_LABEL);
/* 419 */     jl1.setSize(275, 20);
/* 420 */     jl1.setLocation(10, 135);
/* 421 */     jl1.setHorizontalAlignment(2);
/* 422 */     jdlgContained.add(jl1);
/*     */ 
/*     */ 
/*     */     
/* 426 */     DefaultListModel<String> lmContained = new DefaultListModel<>();
/* 427 */     JList<String> jl = new JList<>(lmContained);
/* 428 */     JScrollPane jsp = new JScrollPane(jl);
/* 429 */     jsp.setSize(275, 260);
/* 430 */     jsp.setLocation(10, 156);
/* 431 */     jdlgContained.add(jsp);
/*     */     
/* 433 */     JLabel jlCount = new JLabel("");
/* 434 */     jlCount.setForeground(Def.COLOR_LABEL);
/* 435 */     jlCount.setSize(275, 20);
/* 436 */     jlCount.setLocation(10, 417);
/* 437 */     jlCount.setHorizontalAlignment(2);
/* 438 */     jdlgContained.add(jlCount);
/*     */     
/* 440 */     JButton jbOK = Methods.cweButton("OK", 10, 442, 100, 26, null);
/* 441 */     jbOK.addActionListener(e -> {
/*     */           findContainedWords(paramArrayList, paramJTextField.getText().toUpperCase(), paramJCheckBox1.isSelected(), paramJCheckBox2.isSelected(), paramJComboBox.getSelectedIndex() + 2);
/*     */           paramDefaultListModel.clear();
/*     */           paramArrayList.stream().forEach(());
/*     */           paramJLabel.setText(paramDefaultListModel.size() + " Item(s) in list.");
/*     */         });
/* 447 */     jdlgContained.add(jbOK);
/*     */ 
/*     */     
/* 450 */     JButton jbCancel = Methods.cweButton("Cancel", 10, 477, 100, 26, null);
/* 451 */     jbCancel.addActionListener(e -> {
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 455 */     jdlgContained.add(jbCancel);
/*     */     
/* 457 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 125, 442, 160, 61, new ImageIcon("graphics/help.png"));
/* 458 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Finding Contained Words", this.containedHelp));
/*     */     
/* 460 */     jdlgContained.add(jbHelp);
/*     */     
/* 462 */     jdlgContained.getRootPane().setDefaultButton(jbOK);
/* 463 */     Methods.setDialogSize(jdlgContained, 295, 513);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void findContainerWords(ArrayList<String> al, String subject, boolean showExtra) {
/* 470 */     int subjectLen = subject.length();
/*     */     
/* 472 */     al.clear();
/*     */     try {
/* 474 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.msc[Op.MSC.WordToolsDic.ordinal()] + ".dic/xword.dic")); int i;
/* 475 */       for (i = 0; i < 128; i++)
/* 476 */         dataIn.readByte(); 
/* 477 */       while (dataIn.available() > 2) {
/* 478 */         dataIn.readInt();
/* 479 */         String s = dataIn.readUTF();
/* 480 */         if (s.length() >= subjectLen) {
/* 481 */           StringBuffer copy = new StringBuffer(s); int j;
/* 482 */           for (i = 0; i < subjectLen && (
/* 483 */             j = copy.indexOf("" + subject.charAt(i))) != -1; i++) {
/* 484 */             copy.deleteCharAt(j);
/*     */           }
/* 486 */           if (i == subjectLen)
/* 487 */             al.add(s + (showExtra ? ("       [" + copy + "]") : "")); 
/*     */         } 
/* 489 */         dataIn.readUTF();
/*     */       } 
/* 491 */       dataIn.close();
/*     */     }
/* 493 */     catch (IOException exc) {}
/*     */   }
/*     */   
/*     */   private void containerWords() {
/* 497 */     ArrayList<String> al = new ArrayList<>();
/*     */     
/* 499 */     JDialog jdlgContainer = new JDialog(this.jfWordTools, "Find Container Words", true);
/* 500 */     jdlgContainer.setSize(300, 545);
/* 501 */     jdlgContainer.setResizable(false);
/* 502 */     jdlgContainer.setLayout((LayoutManager)null);
/* 503 */     jdlgContainer.setLocation(this.jfWordTools.getX(), this.jfWordTools.getY());
/*     */     
/* 505 */     jdlgContainer
/* 506 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 508 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/* 512 */     Methods.closeHelp();
/*     */     
/* 514 */     JLabel jlContainer = new JLabel("Enter the Subject Word:");
/* 515 */     jlContainer.setForeground(Def.COLOR_LABEL);
/* 516 */     jlContainer.setSize(275, 20);
/* 517 */     jlContainer.setLocation(10, 5);
/* 518 */     jlContainer.setHorizontalAlignment(2);
/* 519 */     jdlgContainer.add(jlContainer);
/*     */     
/* 521 */     JTextField jtfTemplate = new JTextField("*", 30);
/* 522 */     jtfTemplate.setSize(275, 23);
/* 523 */     jtfTemplate.setLocation(10, 26);
/* 524 */     jtfTemplate.selectAll();
/* 525 */     jtfTemplate.setHorizontalAlignment(2);
/* 526 */     jdlgContainer.add(jtfTemplate);
/* 527 */     jtfTemplate.setFont(new Font("SansSerif", 1, 13));
/*     */     
/* 529 */     JCheckBox jcbShowExtra = new JCheckBox("Display Sundry Letters", false);
/* 530 */     jcbShowExtra.setForeground(Def.COLOR_LABEL);
/* 531 */     jcbShowExtra.setOpaque(false);
/* 532 */     jcbShowExtra.setSize(275, 20);
/* 533 */     jcbShowExtra.setLocation(10, 51);
/* 534 */     jdlgContainer.add(jcbShowExtra);
/*     */     
/* 536 */     JLabel jl1 = new JLabel("The Container words are:");
/* 537 */     jl1.setForeground(Def.COLOR_LABEL);
/* 538 */     jl1.setSize(275, 20);
/* 539 */     jl1.setLocation(10, 76);
/* 540 */     jl1.setHorizontalAlignment(2);
/* 541 */     jdlgContainer.add(jl1);
/*     */ 
/*     */ 
/*     */     
/* 545 */     DefaultListModel<String> lmContainer = new DefaultListModel<>();
/* 546 */     JList<String> jl = new JList<>(lmContainer);
/* 547 */     JScrollPane jsp = new JScrollPane(jl);
/* 548 */     jsp.setSize(275, 319);
/* 549 */     jsp.setLocation(10, 97);
/* 550 */     jdlgContainer.add(jsp);
/*     */     
/* 552 */     JLabel jlCount = new JLabel("");
/* 553 */     jlCount.setForeground(Def.COLOR_LABEL);
/* 554 */     jlCount.setSize(255, 20);
/* 555 */     jlCount.setLocation(10, 417);
/* 556 */     jlCount.setHorizontalAlignment(2);
/* 557 */     jdlgContainer.add(jlCount);
/*     */     
/* 559 */     JButton jbOK = Methods.cweButton("OK", 10, 442, 100, 26, null);
/* 560 */     jbOK.addActionListener(e -> {
/*     */           findContainerWords(paramArrayList, paramJTextField.getText().toUpperCase(), paramJCheckBox.isSelected());
/*     */           paramDefaultListModel.clear();
/*     */           paramArrayList.stream().forEach(());
/*     */           paramJLabel.setText(paramDefaultListModel.size() + " Item(s) in list.");
/*     */         });
/* 566 */     jdlgContainer.add(jbOK);
/*     */     
/* 568 */     JButton jbCancel = Methods.cweButton("Cancel", 10, 477, 100, 26, null);
/* 569 */     jbCancel.addActionListener(e -> {
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 573 */     jdlgContainer.add(jbCancel);
/*     */     
/* 575 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 125, 442, 160, 61, new ImageIcon("graphics/help.png"));
/* 576 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Finding Container Words", this.containerHelp));
/*     */     
/* 578 */     jdlgContainer.add(jbHelp);
/*     */     
/* 580 */     jdlgContainer.getRootPane().setDefaultButton(jbOK);
/* 581 */     Methods.setDialogSize(jdlgContainer, 295, 513);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void anagramRecursion(ArrayList<String> alSubject, ArrayList<String> alAnagram, StringBuffer sbSubject, StringBuffer sbAnagram, int from, int to) {
/* 588 */     for (int i = from; i < to; i++) {
/* 589 */       StringBuffer sbSubjectThis = new StringBuffer(sbSubject);
/* 590 */       int k = ((String)alSubject.get(i)).length(); int j, m;
/* 591 */       for (j = 0; j < k && (
/* 592 */         m = sbSubjectThis.indexOf("" + ((String)alSubject.get(i)).charAt(j))) != -1; j++) {
/* 593 */         sbSubjectThis.deleteCharAt(m);
/*     */       }
/* 595 */       if (j == k) {
/* 596 */         StringBuffer sbAnagramThis = new StringBuffer(sbAnagram.toString() + " " + (String)alSubject.get(i));
/* 597 */         if (sbSubjectThis.length() == 0) {
/* 598 */           alAnagram.add(sbAnagramThis.toString());
/*     */         } else {
/* 600 */           anagramRecursion(alSubject, alAnagram, sbSubjectThis, sbAnagramThis, i, to);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void anagrams() {
/* 606 */     ArrayList<String> alSubject = new ArrayList<>();
/* 607 */     ArrayList<String> alAnagram = new ArrayList<>();
/*     */     
/* 609 */     JDialog jdlgAnagrams = new JDialog(this.jfWordTools, "Find Anagrams", true);
/* 610 */     jdlgAnagrams.setSize(300, 545);
/* 611 */     jdlgAnagrams.setResizable(false);
/* 612 */     jdlgAnagrams.setLayout((LayoutManager)null);
/* 613 */     jdlgAnagrams.setLocation(this.jfWordTools.getX(), this.jfWordTools.getY());
/*     */     
/* 615 */     jdlgAnagrams
/* 616 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 618 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/* 622 */     Methods.closeHelp();
/*     */     
/* 624 */     JLabel jlAnagrams = new JLabel("Enter the Subject Word(s):");
/* 625 */     jlAnagrams.setForeground(Def.COLOR_LABEL);
/* 626 */     jlAnagrams.setSize(275, 20);
/* 627 */     jlAnagrams.setLocation(10, 5);
/* 628 */     jlAnagrams.setHorizontalAlignment(2);
/* 629 */     jdlgAnagrams.add(jlAnagrams);
/*     */     
/* 631 */     JTextField jtfTemplate = new JTextField("*", 30);
/* 632 */     jtfTemplate.setSize(275, 25);
/* 633 */     jtfTemplate.setLocation(10, 26);
/* 634 */     jtfTemplate.selectAll();
/* 635 */     jtfTemplate.setHorizontalAlignment(2);
/* 636 */     jdlgAnagrams.add(jtfTemplate);
/*     */     
/* 638 */     jtfTemplate.setFont(new Font("SansSerif", 1, 13));
/*     */     
/* 640 */     JLabel jlShort = new JLabel("Shortest word to include");
/* 641 */     jlShort.setForeground(Def.COLOR_LABEL);
/* 642 */     jlShort.setSize(275, 20);
/* 643 */     jlShort.setLocation(70, 56);
/* 644 */     jlShort.setHorizontalAlignment(2);
/* 645 */     jdlgAnagrams.add(jlShort);
/*     */     
/* 647 */     JComboBox<Integer> jcbbLen = new JComboBox<>();
/* 648 */     for (int i = 1; i <= 15; i++)
/* 649 */       jcbbLen.addItem(Integer.valueOf(i)); 
/* 650 */     jcbbLen.setSize(50, 20);
/* 651 */     jcbbLen.setLocation(10, 56);
/* 652 */     jdlgAnagrams.add(jcbbLen);
/* 653 */     jcbbLen.setBackground(Def.COLOR_BUTTONBG);
/*     */     
/* 655 */     JLabel jl1 = new JLabel("The Anagrams are:");
/* 656 */     jl1.setForeground(Def.COLOR_LABEL);
/* 657 */     jl1.setSize(255, 20);
/* 658 */     jl1.setLocation(10, 76);
/* 659 */     jl1.setHorizontalAlignment(2);
/* 660 */     jdlgAnagrams.add(jl1);
/*     */ 
/*     */ 
/*     */     
/* 664 */     DefaultListModel<String> lmAnagram = new DefaultListModel<>();
/* 665 */     JList<String> jl = new JList<>(lmAnagram);
/* 666 */     JScrollPane jsp = new JScrollPane(jl);
/* 667 */     jsp.setSize(275, 319);
/* 668 */     jsp.setLocation(10, 97);
/* 669 */     jdlgAnagrams.add(jsp);
/*     */     
/* 671 */     JLabel jlCount = new JLabel("");
/* 672 */     jlCount.setForeground(Def.COLOR_LABEL);
/* 673 */     jlCount.setSize(275, 20);
/* 674 */     jlCount.setLocation(10, 417);
/* 675 */     jlCount.setHorizontalAlignment(2);
/* 676 */     jdlgAnagrams.add(jlCount);
/*     */     
/* 678 */     JButton jbOK = Methods.cweButton("OK", 10, 442, 100, 26, null);
/* 679 */     jbOK.addActionListener(e -> {
/*     */           StringBuffer sbSubject = new StringBuffer(paramJTextField.getText().toUpperCase()); for (int i = 0; i < sbSubject.length(); i++) {
/*     */             if (sbSubject.charAt(i) == ' ')
/*     */               sbSubject.deleteCharAt(i--); 
/*     */           }  paramArrayList1.clear(); findContainedWords(paramArrayList1, sbSubject.toString(), false, false, paramJComboBox.getSelectedIndex() + 1); if (paramJComboBox.getSelectedIndex() == 0) {
/*     */             if (sbSubject.toString().contains("I"))
/*     */               paramArrayList1.add(0, "I"); 
/*     */             if (sbSubject.toString().contains("A"))
/*     */               paramArrayList1.add(0, "A"); 
/*     */           } 
/*     */           StringBuffer sbAnagram = new StringBuffer();
/*     */           paramArrayList2.clear();
/*     */           anagramRecursion(paramArrayList1, paramArrayList2, sbSubject, sbAnagram, 0, paramArrayList1.size());
/*     */           paramDefaultListModel.clear();
/*     */           paramArrayList2.stream().forEach(());
/*     */           paramJLabel.setText(paramDefaultListModel.size() + " Item(s) in list.");
/*     */         });
/* 696 */     jdlgAnagrams.add(jbOK);
/*     */     
/* 698 */     JButton jbCancel = Methods.cweButton("Cancel", 10, 477, 100, 26, null);
/* 699 */     jbCancel.addActionListener(e -> {
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 703 */     jdlgAnagrams.add(jbCancel);
/*     */     
/* 705 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 125, 442, 160, 61, new ImageIcon("graphics/help.png"));
/* 706 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Finding Anagrams", this.anagramHelp));
/*     */     
/* 708 */     jdlgAnagrams.add(jbHelp);
/*     */     
/* 710 */     jdlgAnagrams.getRootPane().setDefaultButton(jbOK);
/* 711 */     Methods.setDialogSize(jdlgAnagrams, 295, 513);
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\WordTools.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */