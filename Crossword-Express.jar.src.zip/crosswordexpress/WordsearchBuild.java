/*      */ package crosswordexpress;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.geom.GeneralPath;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.KeyStroke;
/*      */ 
/*      */ public final class WordsearchBuild extends JPanel {
/*      */   static JFrame jfWordsearch;
/*      */   static JMenuBar menuBar;
/*      */   JMenu menu;
/*      */   JMenu submenu;
/*      */   JMenuItem menuItem;
/*      */   JMenuItem buildMenuItem;
/*   26 */   int howMany = 1; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Thread thread; int startPuz = Integer.parseInt((new SimpleDateFormat("yyyyMMdd")).format(new Date()));
/*   27 */   static int[] xInc = new int[] { 1, 1, 0, -1, -1, -1, 0, 1 };
/*   28 */   static int[] yInc = new int[] { 0, 1, 1, 1, 0, -1, -1, -1 };
/*      */   static boolean dispLoops = false;
/*   30 */   int[] dirCont = new int[] { 1, 2, 4, 8, 16, 32, 64, 128 }; int shortWord; int longWord;
/*      */   JComboBox<Integer> jcbbShort;
/*      */   JComboBox<Integer> jcbbLong;
/*      */   
/*      */   static void def() {
/*   35 */     Op.updateOption(Op.WS.WsW.ordinal(), "600", Op.ws);
/*   36 */     Op.updateOption(Op.WS.WsH.ordinal(), "664", Op.ws);
/*   37 */     Op.updateOption(Op.WS.WsSolveW.ordinal(), "840", Op.ws);
/*   38 */     Op.updateOption(Op.WS.WsSolveH.ordinal(), "675", Op.ws);
/*   39 */     Op.updateOption(Op.WS.WsAcross.ordinal(), "10", Op.ws);
/*   40 */     Op.updateOption(Op.WS.WsDown.ordinal(), "10", Op.ws);
/*   41 */     Op.updateOption(Op.WS.WsDirMask.ordinal(), "255", Op.ws);
/*   42 */     Op.updateOption(Op.WS.WsBackground.ordinal(), "FFFFFF", Op.ws);
/*   43 */     Op.updateOption(Op.WS.WsBorder.ordinal(), "004444", Op.ws);
/*   44 */     Op.updateOption(Op.WS.WsLoop.ordinal(), "0099CC", Op.ws);
/*   45 */     Op.updateOption(Op.WS.WsLetter.ordinal(), "444444", Op.ws);
/*   46 */     Op.updateOption(Op.WS.WsSlvHilite.ordinal(), "FF0000", Op.ws);
/*   47 */     Op.updateOption(Op.WS.WsClue.ordinal(), "666666", Op.ws);
/*   48 */     Op.updateOption(Op.WS.WsMsgHilite.ordinal(), "FF0000", Op.ws);
/*   49 */     Op.updateOption(Op.WS.WsPuz.ordinal(), "sample.wordsearch", Op.ws);
/*   50 */     Op.updateOption(Op.WS.WsDic.ordinal(), "$physics", Op.ws);
/*   51 */     Op.updateOption(Op.WS.WsTemplate.ordinal(), "", Op.ws);
/*   52 */     Op.updateOption(Op.WS.WsMessage.ordinal(), "", Op.ws);
/*   53 */     Op.updateOption(Op.WS.WsFont.ordinal(), "SansSerif", Op.ws);
/*   54 */     Op.updateOption(Op.WS.WsClueFont.ordinal(), "SansSerif", Op.ws);
/*   55 */     Op.updateOption(Op.WS.WsPuzColor.ordinal(), "false", Op.ws);
/*   56 */     Op.updateOption(Op.WS.WsSolColor.ordinal(), "false", Op.ws);
/*   57 */     Op.updateOption(Op.WS.WsHint.ordinal(), "false", Op.ws);
/*   58 */     Op.updateOption(Op.WS.WsMsgBody.ordinal(), "FFFF00", Op.ws);
/*   59 */     Op.updateOption(Op.WS.WsShort.ordinal(), "5", Op.ws);
/*   60 */     Op.updateOption(Op.WS.WsLong.ordinal(), "10", Op.ws);
/*      */   }
/*      */   
/*   63 */   String wordsearchHelp = "<div>A typical <b>WORD-SEARCH</b> puzzle consists of a matrix of letters in which a number of words are embedded. The words may run up or down, forward or backward, or in any diagonal direction. The Crossword Express version of this puzzle takes its words from a Theme dictionary, and under normal circumstances the program will generate a puzzle in which every letter of the puzzle is linked into at least one of the words of the puzzle. This is sometimes referred to as a <b>Full House</b> puzzle. In addition, it will be normal for each word in the puzzle to intersect with at least one of the other words.<p/>If your dictionary contains insufficient words for these requirements to be met, then the program will revert to a construction mode in which some of the letters will not be part of a word. This construction behaviour may begin immediately if it is clear that insufficient words are available to fill the puzzle completely, or it may commence after an attempt to build a <b>Full House</b> puzzle has proved to be unsuccessful. In any event, this is a decision which is taken care of automatically by the program.<p/>Puzzles can also be constructed so that they contain a <b>Hidden Message</b> which can be read out from those cells which are not occupied by any of the words.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span>Select a Dictionary</span><br/>When loading a new puzzle into the Build screen, you begin by selecting the dictionary which was used to build the WORD-SEARCH puzzle which you want to load.<p/><li/><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of WORD-SEARCH puzzles currently available in the selected dictionary.<p/><li/><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the folder of the dictionary that was used to construct it. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li/><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li/><span class='s'>Build Menu</span><ul><li/><span>Select a Dictionary</span><br/>Use this option to select the dictionary which you want to use to build the new WORD-SEARCH puzzle.<p/><li/><span>Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Edit Offensive Words List</span><br/>As Crossword Express adds words into your Word-search puzzles, it is possible for the letters of those words to combine randomly in such a way as to create extraneous unwanted words, including possibly offensive words. Using this option, you can create a list of all of the words which you consider to be offensive, and Crossword Express will ensure that they do not appear anywhere within you puzzle.<p/><li/><span>Start Building / Stop Building</span><br/>Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Edit clues</span><br/>If you intend to use the option to print clues rather than words for the puzzle, you may wish to edit the clues associated with the words that have been used in the puzzle. If you are using a dictionary without clues, then you will certainly need to use this function to add the clues. When you exit the function, the changes you have made will automatically be saved to the puzzle file.<p/><li/><span>Transfer Puzzle Clues to Dictionary</span><br/>If you have used the <b>Edit Clues</b> function to modify existing clues, or to add clues to clueless words, you may wish to save the alterations to the dictionary. This option will find all such changes, and merge them into the dictionary that was used to construct the puzzle.<p/><li/><span>Print Word-Search Puzzle</span><br/>This will take you to a custom print screen where you can control the details involved with printing your puzzle.<p/><li/><span>Print Word-Weave Puzzle</span><br/>Any Word-Search puzzle can also be printed as a Word-Weave puzzle. In this case, the puzzle grid does not contain any letters, and the words to be placed in the grid are allocated a number. These numbers are placed in the grid in the top left hand corner of the cell which will contain the first letter of the word. Hence you can immediately place a letter into each of the numbered cells. It might appear that this will be an easy puzzle to solve, but remember that the orientation of the words can be in any of a maximum of eight different directions and this can make the solution of some puzzles quite tricky to complete. If you find them too easy for your taste, you can elect to make them quite a bit harder by printing the puzzle with clues rather than words.<p/><li/><span>Solve this Puzzle</span><br/>This will take you to a Solve screen which provides a fully interactive environment for solving the puzzle.<p/><li/><span>Export Puzzle as Text</span><br/>Under normal circumstances, the Print function will provide all of the layout flexibility you will need when printing your puzzles. Inevitably of course special cases will arise where you need to intervene in the printing of either the words or the clues to achieve some special effect. To meet this need, a text export feature offers the following choices:-<ul><li/><b>Export Words.</b> Each line of text has the format <b>Id. WORD</b><li/><b>Export Clues.</b> Each line of text has the format <b>Id. Clue</b><li/><b>Export Words and Clues.</b> Each line of text has the format <b>Id. WORD : Clue</b><li/><b>Export Puzzle Grid.</b> The puzzle grid is exported as a simple square or rectangular array of letters.</ul>In addition, you have the choice of exporting the text to a text file located anywhere on your computer's hard drive, or to the System Clipboard from where you can Paste into any Word Processor or Desk Top Publishing application.<p/><li/><span>Export Wordsearch Web-App</span><br/> This function allows you to export a Web Application Program which you can then upload to your own web site to provide a fully interactive wordsearch puzzle for the entertainment of visitors to your site. For a full description of the facilities provided by this Web-App, please refer to the Help available at <b>Help / Web Application</b> on the menu bar of the <b>Build Wordsearch</b> window of this program.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted WORD-SEARCH puzzles from your file system.</ul><li/><span class='s'>Help Menu</span><ul><li/><span>Word-search Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   String wordsearchOptions = "<div>Before you give the command to build the <b>Word-search</b> puzzle, you can set some options which the program will use during the construction process.</div><br/><ul><li/>To specify the size or shape of the <b>Word-search</b> puzzle you can:-<ul><li/>Enter values for the number of cells Across and Down. This will result in a rectangular puzzle. <b>OR</b><p/><li/><b>Select a Template:</b> You can use the <b>Grid Maintenance</b> function to createTemplates in any shape you desire. Please study the Grid Maintenance Help for instructions on how to do this.</ul><li/>If you want to make a number of puzzles all having the same dimensions, simply type a number into the <b>How many puzzles</b> input field. When you issue the Make command, Crossword Express will make that number of puzzles. The puzzle names will be numbers which represent a date in <b>yyyymmdd</b> format. The default value presented by Crossword Express is always the current date, but you can change this to any date that suits your needs. As the series of puzzles is created, CWE will automatically step on to the next date in the sequence, taking into account such factors as the varying number of days in the months, and of course leap years. Also, CWE will cycle continuously through the theme dictionaries which it finds in your CWE folder, using a different one for each puzzle until the requested number of puzzles has been completed. Virtually any number of puzzles can be made in a single operation using this feature.<p/><li/><b>HOWEVER:</b> If you prefer a simpler numbering scheme for your puzzles, you can enter any number of 7 digits or less to be used for your first puzzle, and Crossword Express will number the remainder of the puzzles sequentially starting with your number.<p/><li/>This dialog also contains a field into which you can enter a <b>Message</b> which is to be used to fill those spaces in the puzzle which are not occupied by any of the words.<p/><li/>These puzzles are very useful for teaching word recognition skills to young students. For very young students, it may be better to limit the direction of hidden words to only Across and Down. This can be done by un-checking the unwanted <b>Direction Control</b> check-boxes. As the word skills of the students increases, the diagonal and reverse directions can of course be included. To build such a puzzle, you will need to create a small theme dictionary which contains precisely the words that you want to appear in the puzzle. Also, you should choose the dimensions of the puzzle so that all of the words in the dictionary will fit comfortably into the finished puzzle. Don't be afraid to create a number of puzzles until one appears which satisfies your aesthetic requirements.<p/><li/>Finally, you can exercise control over the length of the words that will be used during construction by means of <b>Shortest Words to use</b> and <b>Longest Words to use</b> controls.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   static String editOffensive = "<div>As Crossword Express adds words into your Word-search puzzles, it is possible for the letters of those words to combine randomly in such a way as to create extraneous unwanted words. This may cause two undesirable effects to occur:-<br/><br/></div><ul><li/>The unwanted word might duplicate one of the words being inserted into the puzzle. If this were to happen it would create a great deal of confusion for anyone trying to solve the puzzle. Crossword Express scans each puzzle as it is made, and if such a duplication is observed, the puzzle is rejected, and a new one is automatically made.<p/><li/>The unwanted word may be an offensive word which you would naturally prefer not to be present. This function allows you to maintain a text file containing a list of words which are considered offensive in the language being used to construct the puzzle. When a puzzle has been built, Crossword Express will check to see if this file exists, and if it does, it scans the puzzle to ensure that it doesn't contain any of the words. If it does, the puzzle is rejected, and a new one is automatically made.</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  219 */   static String webAppHelp = "<div><span>Step 1: Export</span><br/>To export the Web Application, select the function <b>Export / Export Puzzle as Web App</b> from the menu bar of the <b>Build Wordsearch</b> window of this program. The necessary files will be exported into a folder called <b>Web-App</b> located on your computer's Desktop. Please note that you will need a working Internet connection for this function to operate correctly. The exported files are as follows:-<ul><li><span>wordsearch.js</span> This is the file which contains all of the Java Script which implements the interactive features of the Web App.<li><span>wordsearch.html</span> This file creates the URL address used to access the Web App. Its main purpose is to start the operation of the wordsearch.js Java Script file. If you open wordsearch.html with a simple text editor, you will find two appearances of the following text fragment ... <b>&lt;!-- Your HTML code here. --></b>. If you are an experienced HTML coder and would like to add some content of your own to the Web App window, simply replace these fragments with your own HTML code.<li><span>puzzle.wordsearch</span> This is a standard Crossword Express puzzle file. Depending on how you choose to make use of the Web App, this file may be loaded by the App and presented as an interactive puzzle to be solved by visitors to your site. Its function will be discussed in more detail in the remainder of this Help screen.</ul><span>Step 2: Familiarization</span><br/>Having exported the App, you can give it a first run by starting your web browser, and using it to open the <b>wordsearch.html</b> file mentioned above. Note particularly that you must not use the <b>Chrome </b> browser for this test. The makers of the Chrome browser have included a security feature which prevents a Web App from loading content from the local hard drive. Any other browser will function correctly, and you can rest assured that when you have installed the App on your web server, the Chrome browser will also function correctly.<p/><span>Step 3: Installation</span><br/>Installation is a three step process:-<ul><li>Create a new folder somewhere on your web server.<li>Upload the three files already discussed into this new folder.<li>Create a link from a convenient point within your web site to the wordsearch.html file in your newly created folder.</ul>Now you will be able to start the Web App via the new link. Any modern browser will operate the App, including Chrome.<p/><span>Step 4: Publishing your Puzzle(s)</span><br/><ul><li><span>Single puzzle.</span> If all you need is a single unchanging puzzle, create that puzzle using the <b>Wordsearch</b> function of Crossword Express, and give it the name <b>puzzle.wordsearch</b> Upload the resulting puzzle file to your web server to replace the existing file of the same name which came with the export package.<li><span>Daily puzzle.</span> If you are really serious about publishing wordsearch puzzles for your visitors to solve you will probably want to publish a new puzzle every day, and it would be natural to want this all to happen without the need for daily intervention by yourself. The good news is that Crossword Express takes care of the daily puzzle changeover without any action whatever on your part. The puzzles that you need for this purpose can be made using the <b>Multi-Puzzle control</b> feature when constructing your puzzles. This feature allows you to specify how many puzzles you require the program to make. The names of these puzzles will be eight digit numbers representing a date in the form <b>yyyymmdd</b>. The name of the first puzzle it makes will default to the current date, but you can change this to any date which is appropriate to your needs. Subsequent puzzles will have the date incremented by one until the requested number of puzzles have been completed.<p/><br/>When you have created your puzzle files, they must be uploaded to your web server and into the same folder which contains the wordsearch.js and wordsearch.html files. Then, when the Web App begins operating, the first thing it does is to interrogate the system clock of the computer on which it is running. It uses this information to calculate the current date in yyyymmdd format, and hence create the name of the puzzle file appropriate to the day. It loads this file from the web server, and presents it to your web visitor as an interactive puzzle, ready to be solved. If, for any reason, the puzzle file whose name was calculated is not available, the App simply loads the puzzle.wordsearch file mentioned previously and presents this as the puzzle to be solved. This being the case, you should always be sure that you do have a valid puzzle.wordsearch file present in your Web App folder.</ul><span>Step 5: Warning:</span><br/><ul><li>When you try to operate the Web-App from your web site, it sometimes happens that the required puzzle doesn't appear as expected. This problem happens with some web servers when the Web-App attempts to download the .wordsearch puzzle file that it needs to complete its initialization. Under normal circumstances, there is only a limited number of file types which can be guaranteed to be down-loadable from all web servers, and unfortunately .wordsearch is not one of them. On the other hand some web servers are more forgiving in this regard, and work quite happily. As things stand at the moment, if you are caught by this problem, you will need to contact your server administrator and request that a configuration change be made. The required change will be quite clear to the administrator if you pass on the following quote from a server administrator who was the first to encounter and fix this problem:-<p/><br>&#34;I have gone ahead and added a mimetype for .wordsearch to be an application&#47octet-stream. This simply allows it to download.&#34;</ul></body>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WordsearchBuild(JFrame jf) {
/*  294 */     Def.puzzleMode = 200;
/*  295 */     Def.dispCursor = Boolean.valueOf(false);
/*  296 */     Def.building = 0;
/*  297 */     dispLoops = false;
/*      */     
/*  299 */     makeGrid();
/*  300 */     jfWordsearch = new JFrame("Wordsearch Construction");
/*  301 */     jfWordsearch.setSize(Op.getInt(Op.WS.WsW.ordinal(), Op.ws), Op.getInt(Op.WS.WsH.ordinal(), Op.ws));
/*  302 */     int frameX = (jf.getX() + jfWordsearch.getWidth() > Methods.scrW) ? (Methods.scrW - jfWordsearch.getWidth() - 10) : jf.getX();
/*  303 */     jfWordsearch.setLocation(frameX, jf.getY());
/*  304 */     jfWordsearch.setLayout((LayoutManager)null);
/*  305 */     jfWordsearch.setDefaultCloseOperation(0);
/*  306 */     jfWordsearch
/*  307 */       .addComponentListener(new ComponentAdapter()
/*      */         {
/*      */           public void componentResized(ComponentEvent ce)
/*      */           {
/*  311 */             int w = (WordsearchBuild.jfWordsearch.getWidth() < 600) ? 600 : WordsearchBuild.jfWordsearch.getWidth();
/*  312 */             int h = (WordsearchBuild.jfWordsearch.getHeight() < 664) ? 664 : WordsearchBuild.jfWordsearch.getHeight();
/*  313 */             WordsearchBuild.jfWordsearch.setSize(w, h);
/*  314 */             Op.setInt(Op.WS.WsW.ordinal(), w, Op.ws);
/*  315 */             Op.setInt(Op.WS.WsH.ordinal(), h, Op.ws);
/*  316 */             WordsearchBuild.restoreFrame();
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  321 */     jfWordsearch
/*  322 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  324 */             if (Def.building == 1 || Def.selecting)
/*  325 */               return;  Op.saveOptions("wordsearch.opt", Op.ws);
/*  326 */             CrosswordExpress.transfer(1, WordsearchBuild.jfWordsearch);
/*      */           }
/*      */         });
/*      */     
/*  330 */     Methods.closeHelp();
/*      */ 
/*      */     
/*  333 */     Runnable buildThread = () -> {
/*      */         int res = 1; if (this.howMany == 1) {
/*      */           int i = 0; res = 2;
/*      */           while (res == 2) {
/*      */             res = buildWordsearch(i);
/*      */             i++;
/*      */           } 
/*      */           switch (res) {
/*      */             case 0:
/*      */               makeGrid();
/*      */               restoreFrame();
/*      */               Methods.insufficientWords(jfWordsearch);
/*      */               break;
/*      */             case 1:
/*      */               for (i = 0; i < NodeList.nodeListLength; i++)
/*      */                 (NodeList.nodeList[i]).id = 0; 
/*      */               saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */               Methods.havePuzzle = true;
/*      */               dispLoops = true;
/*      */               restoreFrame();
/*      */               Methods.puzzleSaved(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */               break;
/*      */             case 3:
/*      */               makeGrid();
/*      */               restoreFrame();
/*      */               Methods.interrupted(jfWordsearch);
/*      */               break;
/*      */           } 
/*      */         } else {
/*      */           multiBuild();
/*      */           Op.ws[Op.WS.WsMessage.ordinal()] = "";
/*      */         } 
/*      */         this.buildMenuItem.setText("Start Building");
/*      */         Def.building = 0;
/*      */       };
/*  368 */     jl1 = new JLabel();
/*  369 */     jfWordsearch.add(jl1);
/*  370 */     jl2 = new JLabel();
/*  371 */     jfWordsearch.add(jl2);
/*      */     
/*  373 */     menuBar = new JMenuBar();
/*  374 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/*  375 */     jfWordsearch.setJMenuBar(menuBar);
/*  376 */     this.menu = new JMenu("File");
/*  377 */     menuBar.add(this.menu);
/*  378 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  379 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  380 */     this.menu.add(this.menuItem);
/*  381 */     this.menuItem
/*  382 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.selectDictionary(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()], 3);
/*      */           Op.ws[Op.WS.WsDic.ordinal()] = Methods.dictionaryName;
/*      */           loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  392 */     this.menuItem = new JMenuItem("Load a Puzzle");
/*  393 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  394 */     this.menu.add(this.menuItem);
/*  395 */     this.menuItem
/*  396 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           dispLoops = false;
/*      */           pp.invalidate();
/*      */           pp.repaint();
/*      */           new Select(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", "wordsearch", Op.ws, Op.WS.WsPuz.ordinal(), false);
/*      */         });
/*  406 */     this.menuItem = new JMenuItem("SaveAs");
/*  407 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  408 */     this.menu.add(this.menuItem);
/*  409 */     this.menuItem
/*  410 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.puzzleDescriptionDialog(jfWordsearch, Op.ws[Op.WS.WsPuz.ordinal()].substring(0, Op.ws[Op.WS.WsPuz.ordinal()].indexOf(".wordsearch")), Op.ws[Op.WS.WsDic.ordinal()] + ".dic", ".wordsearch");
/*      */           if (Methods.clickedOK) {
/*      */             saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()] = Methods.theFileName);
/*      */             restoreFrame();
/*      */             Methods.puzzleSaved(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */           } 
/*      */         });
/*  422 */     this.menuItem = new JMenuItem("Quit Construction");
/*  423 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  424 */     this.menu.add(this.menuItem);
/*  425 */     this.menuItem
/*  426 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Op.saveOptions("wordsearch.opt", Op.ws);
/*      */           
/*      */           CrosswordExpress.transfer(1, jfWordsearch);
/*      */         });
/*  435 */     this.menu = new JMenu("Build");
/*  436 */     menuBar.add(this.menu);
/*  437 */     this.menuItem = new JMenuItem("Select a Dictionary");
/*  438 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  439 */     this.menu.add(this.menuItem);
/*  440 */     this.menuItem
/*  441 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.selectDictionary(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()], 3);
/*      */           Op.ws[Op.WS.WsDic.ordinal()] = Methods.dictionaryName;
/*      */           loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */           restoreFrame();
/*      */         });
/*  451 */     this.menuItem = new JMenuItem("Start a new Puzzle");
/*  452 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  453 */     this.menu.add(this.menuItem);
/*  454 */     this.menuItem
/*  455 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Methods.puzzleDescriptionDialog(jfWordsearch, Op.ws[Op.WS.WsPuz.ordinal()].substring(0, Op.ws[Op.WS.WsPuz.ordinal()].indexOf(".wordsearch")), Op.ws[Op.WS.WsDic.ordinal()] + ".dic", ".wordsearch");
/*      */           if (Methods.clickedOK) {
/*      */             Op.ws[Op.WS.WsPuz.ordinal()] = Methods.theFileName;
/*      */             makeGrid();
/*      */           } 
/*      */           dispLoops = false;
/*      */           restoreFrame();
/*      */         });
/*  468 */     this.menuItem = new JMenuItem("Build Options");
/*  469 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  470 */     this.menu.add(this.menuItem);
/*  471 */     this.menuItem
/*  472 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           wordsearchOptions();
/*      */           if (Methods.clickedOK) {
/*      */             makeGrid();
/*      */             Methods.havePuzzle = false;
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  484 */     this.menuItem = new JMenuItem("Edit Offensive Word List");
/*  485 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(69, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  486 */     this.menu.add(this.menuItem);
/*  487 */     this.menuItem
/*  488 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           editOffensiveWords(jfWordsearch);
/*      */         });
/*  495 */     this.buildMenuItem = new JMenuItem("Start Building");
/*  496 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  497 */     this.menu.add(this.buildMenuItem);
/*  498 */     this.buildMenuItem
/*  499 */       .addActionListener(ae -> {
/*      */           if (Op.ws[Op.WS.WsPuz.ordinal()].length() == 0) {
/*      */             Methods.noName(jfWordsearch);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           dispLoops = false;
/*      */           
/*      */           if (Def.building == 0) {
/*      */             this.thread = new Thread(paramRunnable);
/*      */             this.thread.start();
/*      */             Def.building = 1;
/*      */             this.buildMenuItem.setText("Stop Building");
/*      */           } else if (Def.building == 1) {
/*      */             Def.building = 2;
/*      */           } 
/*      */         });
/*  517 */     this.menu = new JMenu("View");
/*  518 */     menuBar.add(this.menu);
/*  519 */     this.menuItem = new JMenuItem("Display Options");
/*  520 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(73, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  521 */     this.menu.add(this.menuItem);
/*  522 */     this.menuItem
/*  523 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           printOptions(jfWordsearch, "Display Options");
/*      */           
/*      */           restoreFrame();
/*      */         });
/*  532 */     this.menu = new JMenu("Tasks");
/*  533 */     menuBar.add(this.menu);
/*  534 */     this.menuItem = new JMenuItem("Edit Clues");
/*  535 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(67, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  536 */     this.menu.add(this.menuItem);
/*  537 */     this.menuItem
/*  538 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           Op.msc[Op.MSC.WordToolsDic.ordinal()] = Op.ob[Op.OB.ObDic.ordinal()];
/*      */           Methods.editClues(jfWordsearch, "Wordsearch");
/*      */           restoreFrame();
/*      */         });
/*  546 */     this.menuItem = new JMenuItem("Transfer Puzzle Clues to Dictionary");
/*  547 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(77, 8));
/*  548 */     this.menu.add(this.menuItem);
/*  549 */     this.menuItem
/*  550 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (!Methods.havePuzzle) {
/*      */             Methods.noPuzzle(jfWordsearch, "Move Clues");
/*      */             
/*      */             return;
/*      */           } 
/*      */           Methods.moveCluesToDic(Op.ws[Op.WS.WsDic.ordinal()]);
/*      */           JOptionPane.showMessageDialog(jfWordsearch, "<html><center>The clues used in this puzzle<br>have been moved to the <font color=880000>" + Op.ws[Op.WS.WsDic.ordinal()] + "</font> dictionary");
/*      */           restoreFrame();
/*      */         });
/*  564 */     this.menuItem = new JMenuItem("Print Word-Search Puzzle");
/*  565 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  566 */     this.menu.add(this.menuItem);
/*  567 */     this.menuItem
/*  568 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Def.puzzleMode = 200;
/*      */           CrosswordExpress.toPrint(jfWordsearch, Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */         });
/*  576 */     this.menuItem = new JMenuItem("Print Word-Weave Puzzle");
/*  577 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(87, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  578 */     this.menu.add(this.menuItem);
/*  579 */     this.menuItem
/*  580 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           Def.puzzleMode = 202;
/*      */           CrosswordExpress.toPrint(jfWordsearch, Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */         });
/*  588 */     this.menuItem = new JMenuItem("Solve this Puzzle");
/*  589 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  590 */     this.menu.add(this.menuItem);
/*  591 */     this.menuItem
/*  592 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           if (Methods.havePuzzle) {
/*      */             CrosswordExpress.transfer(201, jfWordsearch);
/*      */           } else {
/*      */             Methods.noPuzzle(jfWordsearch, "Solve");
/*      */           } 
/*      */         });
/*  602 */     this.menuItem = new JMenuItem("Export as Text");
/*  603 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(84, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  604 */     this.menu.add(this.menuItem);
/*  605 */     this.menuItem
/*  606 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           if (Methods.havePuzzle) {
/*      */             NodeList.exportText(jfWordsearch, false);
/*      */           } else {
/*      */             Methods.noPuzzle(jfWordsearch, "Export");
/*      */           } 
/*      */         });
/*  616 */     this.menuItem = new JMenuItem("Export Wordsearch Web-App");
/*  617 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(87, 1));
/*  618 */     this.menu.add(this.menuItem);
/*  619 */     this.menuItem
/*  620 */       .addActionListener(ae -> Methods.exportWebApp(jfWordsearch, "wordsearch"));
/*      */ 
/*      */     
/*  623 */     this.menuItem = new JMenuItem("Launch a Demo Web App");
/*  624 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, 1));
/*  625 */     this.menu.add(this.menuItem);
/*  626 */     this.menuItem
/*  627 */       .addActionListener(ae -> Methods.launchWebApp(jfWordsearch, "wordsearch"));
/*      */ 
/*      */     
/*  630 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/*  631 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  632 */     this.menu.add(this.menuItem);
/*  633 */     this.menuItem
/*  634 */       .addActionListener(ae -> {
/*      */           if (Def.building == 1) {
/*      */             return;
/*      */           }
/*      */           
/*      */           if (Methods.deleteAPuzzle(jfWordsearch, Op.ws[Op.WS.WsPuz.ordinal()], Op.ws[Op.WS.WsDic.ordinal()] + ".dic", pp)) {
/*      */             loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */             restoreFrame();
/*      */           } 
/*      */         });
/*  644 */     this.menu = new JMenu("Help");
/*  645 */     menuBar.add(this.menu);
/*  646 */     this.menuItem = new JMenuItem("Wordsearch Help");
/*  647 */     this.menu.add(this.menuItem);
/*  648 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/*  649 */     this.menuItem
/*  650 */       .addActionListener(ae -> Methods.cweHelp(jfWordsearch, null, "Building Wordsearch Puzzles", this.wordsearchHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  655 */     this.menuItem = new JMenuItem("Web Application");
/*  656 */     this.menu.add(this.menuItem);
/*  657 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, 1));
/*  658 */     this.menuItem
/*  659 */       .addActionListener(ae -> Methods.cweHelp(jfWordsearch, null, "Web Application", webAppHelp));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  665 */     pp = new WordsearchPP(0, 37);
/*  666 */     jfWordsearch.add(pp);
/*  667 */     makeGrid();
/*      */     
/*  669 */     pp
/*  670 */       .addMouseMotionListener(new MouseAdapter() {
/*      */           public void mouseMoved(MouseEvent e) {
/*  672 */             if (Def.isMac) {
/*  673 */               WordsearchBuild.jfWordsearch.setResizable((WordsearchBuild.jfWordsearch.getWidth() - e.getX() < 15 && WordsearchBuild.jfWordsearch
/*  674 */                   .getHeight() - e.getY() < 95));
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  679 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*  680 */     restoreFrame();
/*      */   }
/*      */   
/*      */   static void restoreFrame() {
/*  684 */     jfWordsearch.setVisible(true);
/*  685 */     Insets insets = jfWordsearch.getInsets();
/*  686 */     panelW = jfWordsearch.getWidth() - insets.left + insets.right;
/*  687 */     panelH = jfWordsearch.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/*  688 */     pp.setSize(panelW, panelH);
/*  689 */     jfWordsearch.requestFocusInWindow();
/*  690 */     pp.repaint();
/*  691 */     Methods.infoPanel(jl1, jl2, "Build Wordsearch", "Dictionary : " + Op.ws[Op.WS.WsDic.ordinal()] + "  -|-  Puzzle : " + Op.ws[Op.WS.WsPuz
/*  692 */           .ordinal()], panelW);
/*      */   }
/*      */ 
/*      */   
/*      */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/*  697 */     int i = (width - inset) / Grid.xSz;
/*  698 */     int j = (height - inset) / Grid.ySz;
/*  699 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/*  700 */     Grid.xOrg = x + (width - Grid.xCell * Grid.xSz) / 2;
/*  701 */     Grid.yOrg = y + (height - Grid.yCell * Grid.ySz) / 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void wordsearchOptions() {
/*  708 */     final JDialog jdlgWordsearch = new JDialog(jfWordsearch, "Wordsearch Options", true);
/*  709 */     jdlgWordsearch.setSize(312, 340);
/*  710 */     jdlgWordsearch.setResizable(false);
/*  711 */     jdlgWordsearch.setLayout((LayoutManager)null);
/*  712 */     jdlgWordsearch.setLocation(jfWordsearch.getX(), jfWordsearch.getY());
/*      */     
/*  714 */     jdlgWordsearch
/*  715 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  717 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  721 */     Methods.closeHelp();
/*      */     
/*  723 */     final String localTemplate = Op.ws[Op.WS.WsTemplate.ordinal()];
/*  724 */     final JCheckBox[] jcbArrow = new JCheckBox[8];
/*      */     
/*  726 */     final HowManyPuzzles hmp = new HowManyPuzzles(jdlgWordsearch, 35, 143, this.howMany, this.startPuz, Op.getBool(Op.SX.VaryDiff.ordinal(), Op.sx).booleanValue());
/*  727 */     hmp.jcbVaryDiff.setEnabled(false);
/*      */     
/*  729 */     Op.ws[Op.WS.WsTemplate.ordinal()] = "";
/*  730 */     JPanel jpWS = new JPanel();
/*  731 */     jpWS.setLayout((LayoutManager)null);
/*  732 */     jpWS.setLocation(30, 10);
/*  733 */     jpWS.setSize(250, 125);
/*  734 */     jpWS.setOpaque(true);
/*  735 */     jpWS.setBorder(BorderFactory.createEtchedBorder());
/*  736 */     jdlgWordsearch.add(jpWS);
/*      */     
/*  738 */     JLabel jl = new JLabel("EITHER:");
/*  739 */     jl.setForeground(Def.COLOR_LABEL);
/*  740 */     jl.setSize(55, 20);
/*  741 */     jl.setLocation(10, 10);
/*  742 */     jl.setHorizontalAlignment(2);
/*  743 */     jpWS.add(jl);
/*      */     
/*  745 */     JLabel jlAcross = new JLabel("Cells Across:");
/*  746 */     jlAcross.setForeground(Def.COLOR_LABEL);
/*  747 */     jlAcross.setSize(100, 20);
/*  748 */     jlAcross.setLocation(70, 10);
/*  749 */     jlAcross.setHorizontalAlignment(4);
/*  750 */     jpWS.add(jlAcross);
/*      */     
/*  752 */     final JTextField jtfAcross = new JTextField("" + Grid.xSz, 15);
/*  753 */     jtfAcross.setSize(60, 20);
/*  754 */     jtfAcross.setLocation(180, 10);
/*  755 */     jtfAcross.selectAll();
/*  756 */     jtfAcross.setHorizontalAlignment(2);
/*  757 */     jpWS.add(jtfAcross);
/*      */     
/*  759 */     JLabel jlDown = new JLabel("Cells Down:");
/*  760 */     jlDown.setForeground(Def.COLOR_LABEL);
/*  761 */     jlDown.setSize(100, 20);
/*  762 */     jlDown.setLocation(70, 40);
/*  763 */     jlDown.setHorizontalAlignment(4);
/*  764 */     jpWS.add(jlDown);
/*      */     
/*  766 */     final JTextField jtfDown = new JTextField("" + Grid.ySz, 15);
/*  767 */     jtfDown.setSize(60, 20);
/*  768 */     jtfDown.setLocation(180, 40);
/*  769 */     jtfDown.selectAll();
/*  770 */     jtfDown.setHorizontalAlignment(2);
/*  771 */     jpWS.add(jtfDown);
/*      */     
/*  773 */     jl = new JLabel("OR:");
/*  774 */     jl.setForeground(Def.COLOR_LABEL);
/*  775 */     jl.setSize(40, 20);
/*  776 */     jl.setLocation(10, 70);
/*  777 */     jl.setHorizontalAlignment(2);
/*  778 */     jpWS.add(jl);
/*      */     
/*  780 */     final JLabel jlTemplate = new JLabel("");
/*  781 */     jlTemplate.setForeground(Def.COLOR_LABEL);
/*  782 */     jlTemplate.setSize(150, 20);
/*  783 */     jlTemplate.setLocation(50, 98);
/*  784 */     jlTemplate.setHorizontalAlignment(0);
/*  785 */     jpWS.add(jlTemplate);
/*      */     
/*  787 */     Action doSelect = new AbstractAction("Select a Template") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  789 */           String oldName = Methods.theFileName;
/*  790 */           WordsearchBuild.makeGrid();
/*  791 */           Def.puzzleMode = 2;
/*  792 */           Def.dispNullCells = Boolean.valueOf(true);
/*  793 */           Methods.theFileName = Op.ws[Op.WS.WsTemplate.ordinal()];
/*      */           
/*  795 */           JFileChooser chooser = new JFileChooser(System.getProperty("user.dir") + "/grids");
/*  796 */           chooser.setFileFilter(new FileNameExtensionFilter("Template", new String[] { "template" }));
/*  797 */           File fl = new File(Methods.theFileName);
/*  798 */           chooser.setSelectedFile(fl);
/*  799 */           chooser.setAccessory(new Preview(chooser));
/*  800 */           if (chooser.showDialog(WordsearchBuild.jfWordsearch, "Select Template") == 0) {
/*  801 */             String theName = chooser.getSelectedFile().getName();
/*  802 */             fl = new File("grids/" + theName);
/*  803 */             if (fl.exists()) {
/*  804 */               Methods.theFileName = theName;
/*      */             } else {
/*  806 */               JOptionPane.showMessageDialog(WordsearchBuild.jfWordsearch, "There is no file by that name!");
/*  807 */               Methods.theFileName = oldName;
/*      */             } 
/*      */           } 
/*      */           
/*  811 */           Def.puzzleMode = 200;
/*  812 */           Def.dispNullCells = Boolean.valueOf(false);
/*  813 */           if (Methods.theFileName.length() > 0) {
/*  814 */             Grid.loadGrid(Op.ws[Op.WS.WsTemplate.ordinal()] = Methods.theFileName);
/*  815 */             jlTemplate.setText(Op.ws[Op.WS.WsTemplate.ordinal()]);
/*      */           } else {
/*      */             
/*  818 */             Grid.clearGrid();
/*  819 */           }  WordsearchBuild.makeGrid();
/*  820 */           WordsearchBuild.restoreFrame();
/*      */         }
/*      */       };
/*  823 */     JButton jbSelectTemplate = Methods.newButton("doSelect", doSelect, 83, 50, 68, 190, 26);
/*  824 */     jpWS.add(jbSelectTemplate);
/*      */     
/*  826 */     JLabel jlMessage = new JLabel("Message:");
/*  827 */     jlMessage.setForeground(Def.COLOR_LABEL);
/*  828 */     jlMessage.setSize(80, 20);
/*  829 */     jlMessage.setLocation(10, 254);
/*  830 */     jlMessage.setHorizontalAlignment(4);
/*  831 */     jdlgWordsearch.add(jlMessage);
/*      */     
/*  833 */     final JTextField jtfMessage = new JTextField(Op.ws[Op.WS.WsMessage.ordinal()], 10);
/*  834 */     jtfMessage.setSize(180, 23);
/*  835 */     jtfMessage.setLocation(100, 254);
/*  836 */     jtfMessage.selectAll();
/*  837 */     jtfMessage.setHorizontalAlignment(2);
/*  838 */     jdlgWordsearch.add(jtfMessage);
/*  839 */     jtfMessage.setFont(new Font("SansSerif", 1, 13));
/*      */     
/*  841 */     JPanel jpDir = new JPanel();
/*  842 */     jpDir.setLayout((LayoutManager)null);
/*  843 */     jpDir.setLocation(10, 284);
/*  844 */     jpDir.setSize(290, 90);
/*  845 */     jpDir.setOpaque(true);
/*  846 */     jpDir.setBorder(BorderFactory.createEtchedBorder());
/*  847 */     jdlgWordsearch.add(jpDir);
/*      */     
/*  849 */     jl = new JLabel("Direction Control");
/*  850 */     jl.setForeground(Def.COLOR_LABEL);
/*  851 */     jl.setSize(270, 20);
/*  852 */     jl.setLocation(10, 2);
/*  853 */     jl.setHorizontalAlignment(0);
/*  854 */     jpDir.add(jl);
/*      */     int mask;
/*  856 */     for (int i = 0; i < 8; i++, mask *= 2) {
/*  857 */       ImageIcon theIcon = new ImageIcon("graphics/arrow" + i + ".png");
/*  858 */       JLabel jl1 = new JLabel(theIcon);
/*  859 */       jl1.setSize(21, 21);
/*  860 */       jl1.setLocation(40 + 70 * i % 4, 25 + 30 * i / 4);
/*  861 */       jpDir.add(jl1);
/*  862 */       jcbArrow[i] = new JCheckBox("" + i, ((Op.getInt(Op.WS.WsDirMask.ordinal(), Op.ws) & mask) > 0));
/*  863 */       jcbArrow[i].setOpaque(false);
/*  864 */       jcbArrow[i].setSize(40, 20);
/*  865 */       jcbArrow[i].setLocation(5 + 70 * i % 4, 25 + 30 * i / 4);
/*  866 */       jpDir.add(jcbArrow[i]);
/*      */     } 
/*  868 */     jcbArrow[0].setVisible(false);
/*  869 */     jcbArrow[2].setVisible(false);
/*      */     
/*  871 */     JLabel jlShort = new JLabel("Shortest Word to use:");
/*  872 */     jlShort.setForeground(Def.COLOR_LABEL);
/*  873 */     jlShort.setSize(140, 20);
/*  874 */     jlShort.setLocation(35, 385);
/*  875 */     jlShort.setHorizontalAlignment(4);
/*  876 */     jdlgWordsearch.add(jlShort);
/*      */     
/*  878 */     this.jcbbShort = new JComboBox<>(); int j;
/*  879 */     for (j = 3; j <= 15; j++)
/*  880 */       this.jcbbShort.addItem(Integer.valueOf(j)); 
/*  881 */     this.jcbbShort.setSize(60, 20);
/*  882 */     this.jcbbShort.setLocation(190, 385);
/*  883 */     jdlgWordsearch.add(this.jcbbShort);
/*  884 */     this.jcbbShort.setBackground(Def.COLOR_BUTTONBG);
/*  885 */     this.jcbbShort.setSelectedIndex(Op.getInt(Op.WS.WsShort.ordinal(), Op.ws) - 3);
/*      */     
/*  887 */     JLabel jlLong = new JLabel("Longest Word to use:");
/*  888 */     jlLong.setForeground(Def.COLOR_LABEL);
/*  889 */     jlLong.setSize(140, 20);
/*  890 */     jlLong.setLocation(35, 415);
/*  891 */     jlLong.setHorizontalAlignment(4);
/*  892 */     jdlgWordsearch.add(jlLong);
/*      */     
/*  894 */     this.jcbbLong = new JComboBox<>();
/*  895 */     for (j = 3; j <= 15; j++)
/*  896 */       this.jcbbLong.addItem(Integer.valueOf(j)); 
/*  897 */     this.jcbbLong.setSize(60, 20);
/*  898 */     this.jcbbLong.setLocation(190, 415);
/*  899 */     jdlgWordsearch.add(this.jcbbLong);
/*  900 */     this.jcbbLong.setBackground(Def.COLOR_BUTTONBG);
/*  901 */     this.jcbbLong.setSelectedIndex(Op.getInt(Op.WS.WsLong.ordinal(), Op.ws) - 3);
/*      */     
/*  903 */     Action doOK = new AbstractAction("OK")
/*      */       {
/*      */         public void actionPerformed(ActionEvent e)
/*      */         {
/*  907 */           Op.setInt(Op.WS.WsAcross.ordinal(), Integer.parseInt(jtfAcross.getText()), Op.ws);
/*  908 */           if (Op.getInt(Op.WS.WsAcross.ordinal(), Op.ws) < 5) Op.setInt(Op.WS.WsAcross.ordinal(), 5, Op.ws); 
/*  909 */           if (Op.getInt(Op.WS.WsAcross.ordinal(), Op.ws) > 50) Op.setInt(Op.WS.WsAcross.ordinal(), 50, Op.ws); 
/*  910 */           Op.setInt(Op.WS.WsDown.ordinal(), Integer.parseInt(jtfDown.getText()), Op.ws);
/*  911 */           if (Op.getInt(Op.WS.WsDown.ordinal(), Op.ws) < 5) Op.setInt(Op.WS.WsDown.ordinal(), 5, Op.ws); 
/*  912 */           if (Op.getInt(Op.WS.WsDown.ordinal(), Op.ws) > 50) Op.setInt(Op.WS.WsDown.ordinal(), 50, Op.ws); 
/*  913 */           Op.ws[Op.WS.WsMessage.ordinal()] = jtfMessage.getText();
/*  914 */           Op.setInt(Op.WS.WsDirMask.ordinal(), 0, Op.ws); for (int i1 = 0, mask1 = 1; i1 < 8; i1++, mask1 *= 2) {
/*  915 */             if (jcbArrow[i1].isSelected()) {
/*  916 */               int v = Op.getInt(Op.WS.WsDirMask.ordinal(), Op.ws);
/*  917 */               Op.setInt(Op.WS.WsDirMask.ordinal(), v |= mask1, Op.ws);
/*      */             } 
/*      */           } 
/*  920 */           WordsearchBuild.this.howMany = Integer.parseInt(hmp.jtfHowMany.getText());
/*  921 */           WordsearchBuild.this.startPuz = Integer.parseInt(hmp.jtfStartPuz.getText());
/*      */           
/*  923 */           Op.setInt(Op.WS.WsLong.ordinal(), WordsearchBuild.this.jcbbLong.getSelectedIndex() + 3, Op.ws);
/*  924 */           Op.setInt(Op.WS.WsShort.ordinal(), WordsearchBuild.this.jcbbShort.getSelectedIndex() + 3, Op.ws);
/*      */           
/*  926 */           Methods.clickedOK = true;
/*  927 */           WordsearchBuild.makeGrid();
/*  928 */           jdlgWordsearch.dispose();
/*  929 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  932 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 454, 120, 26);
/*  933 */     jdlgWordsearch.add(jbOK);
/*      */     
/*  935 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/*  937 */           Op.ws[Op.WS.WsTemplate.ordinal()] = localTemplate;
/*  938 */           Methods.clickedOK = false;
/*  939 */           jdlgWordsearch.dispose();
/*  940 */           Methods.closeHelp();
/*      */         }
/*      */       };
/*  943 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 489, 120, 26);
/*  944 */     jdlgWordsearch.add(jbCancel);
/*      */     
/*  946 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/*  948 */           Methods.cweHelp(null, jdlgWordsearch, "Wordsearch Options", WordsearchBuild.this.wordsearchOptions);
/*      */         }
/*      */       };
/*  951 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 140, 454, 160, 61);
/*  952 */     jdlgWordsearch.add(jbHelp);
/*      */     
/*  954 */     dispLoops = false;
/*  955 */     Methods.setDialogSize(jdlgWordsearch, 310, 529);
/*      */   }
/*      */ 
/*      */   
/*      */   static void editOffensiveWords(JFrame jf) {
/*  960 */     String target = "";
/*      */ 
/*      */     
/*  963 */     final JDialog jdlgOffensiveWords = new JDialog(jf, "Edit Offensive Words List", true);
/*  964 */     jdlgOffensiveWords.setSize(312, 340);
/*  965 */     jdlgOffensiveWords.setResizable(false);
/*  966 */     jdlgOffensiveWords.setLayout((LayoutManager)null);
/*  967 */     jdlgOffensiveWords.setLocation(jf.getX(), jf.getY());
/*      */     
/*  969 */     jdlgOffensiveWords
/*  970 */       .addWindowListener(new WindowAdapter() {
/*      */           public void windowClosing(WindowEvent we) {
/*  972 */             Methods.closeHelp();
/*      */           }
/*      */         });
/*      */     
/*  976 */     Methods.closeHelp();
/*      */     
/*  978 */     JLabel jlMessage = new JLabel("<html><font size=4>Offensive Words : Type a single Offensive Word into each line of text.");
/*  979 */     jlMessage.setForeground(Def.COLOR_LABEL);
/*  980 */     jlMessage.setSize(250, 50);
/*  981 */     jlMessage.setLocation(10, 2);
/*  982 */     jlMessage.setHorizontalAlignment(2);
/*  983 */     jdlgOffensiveWords.add(jlMessage);
/*      */     
/*  985 */     final JTextArea jtaOffensiveWords = new JTextArea("");
/*  986 */     jtaOffensiveWords.setLineWrap(true);
/*  987 */     jtaOffensiveWords.setWrapStyleWord(true);
/*  988 */     JScrollPane jsp = new JScrollPane(jtaOffensiveWords);
/*  989 */     jsp.setSize(250, 300);
/*  990 */     jsp.setLocation(10, 70);
/*  991 */     jtaOffensiveWords.selectAll();
/*  992 */     jdlgOffensiveWords.add(jsp);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  997 */       BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("badwords.txt"), "UTF-8")); int i;
/*  998 */       while ((i = br.read()) != -1)
/*  999 */         target = target + (char)i; 
/* 1000 */       br.close();
/*      */     }
/* 1002 */     catch (IOException exc) {}
/* 1003 */     jtaOffensiveWords.setText(target);
/* 1004 */     jtaOffensiveWords.setFont(new Font("SansSerif", 1, 15));
/*      */     
/* 1006 */     Action doOK = new AbstractAction("OK") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1008 */           Methods.clickedOK = true;
/*      */           
/*      */           try {
/* 1011 */             OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("badwords.txt"), "UTF-8");
/* 1012 */             String str = jtaOffensiveWords.getText();
/* 1013 */             String str2 = "";
/* 1014 */             for (int j = 0; j < str.length(); j++) {
/* 1015 */               if (str.charAt(j) != ' ')
/* 1016 */                 str2 = str2 + str.charAt(j); 
/* 1017 */             }  out.write(str2);
/* 1018 */             out.close();
/*      */           }
/* 1020 */           catch (IOException exc) {}
/* 1021 */           jdlgOffensiveWords.dispose();
/* 1022 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1025 */     JButton jbOK = Methods.newButton("doOK", doOK, 79, 10, 384, 100, 26);
/* 1026 */     jdlgOffensiveWords.add(jbOK);
/*      */     
/* 1028 */     Action doCancel = new AbstractAction("Cancel") {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1030 */           Methods.clickedOK = false;
/* 1031 */           jdlgOffensiveWords.dispose();
/* 1032 */           Methods.closeHelp();
/*      */         }
/*      */       };
/* 1035 */     JButton jbCancel = Methods.newButton("doCancel", doCancel, 67, 10, 419, 100, 26);
/* 1036 */     jdlgOffensiveWords.add(jbCancel);
/*      */     
/* 1038 */     Action doHelp = new AbstractAction("<html><font size=6 color=BB0000 face=Serif>Help ", new ImageIcon("graphics/help.png")) {
/*      */         public void actionPerformed(ActionEvent e) {
/* 1040 */           Methods.cweHelp(null, jdlgOffensiveWords, "Edit Offensive Word List", WordsearchBuild.editOffensive);
/*      */         }
/*      */       };
/* 1043 */     JButton jbHelp = Methods.newButton("doHelp", doHelp, 72, 120, 384, 140, 61);
/* 1044 */     jdlgOffensiveWords.add(jbHelp);
/*      */     
/* 1046 */     Methods.setDialogSize(jdlgOffensiveWords, 270, 454);
/*      */   }
/*      */   
/*      */   static void printOptions(JFrame jf, String type) {
/* 1050 */     String[] colorLabel = { "Background Color", "Border Color", "Loop Color", "Letter Color", "Solve Hilite Color", "Clue Color", "Msg Hilite", "Msg Background" };
/*      */ 
/*      */     
/* 1053 */     int[] colorInt = { Op.WS.WsBackground.ordinal(), Op.WS.WsBorder.ordinal(), Op.WS.WsLoop.ordinal(), Op.WS.WsLetter.ordinal(), Op.WS.WsSlvHilite.ordinal(), Op.WS.WsClue.ordinal(), Op.WS.WsMsgHilite.ordinal(), Op.WS.WsMsgBody.ordinal() };
/* 1054 */     String[] fontLabel = { "Puzzle Font", "Clue Font" };
/* 1055 */     int[] fontInt = { Op.WS.WsFont.ordinal(), Op.WS.WsClueFont.ordinal() };
/* 1056 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color.", "RPrint Clues, not Words." };
/* 1057 */     int[] checkInt = { Op.WS.WsPuzColor.ordinal(), Op.WS.WsSolColor.ordinal(), Op.WS.WsHint.ordinal() };
/* 1058 */     Methods.stdPrintOptions(jf, "Wordsearch " + type, Op.ws, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveWordsearch(String wordsearchName) {
/*      */     try {
/* 1069 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName));
/* 1070 */       dataOut.writeInt(Grid.xSz);
/* 1071 */       dataOut.writeInt(Grid.ySz);
/* 1072 */       dataOut.writeByte(Methods.noReveal);
/* 1073 */       dataOut.writeByte(Methods.noErrors); int i;
/* 1074 */       for (i = 0; i < 54; i++) {
/* 1075 */         dataOut.writeByte(0);
/*      */       }
/* 1077 */       for (int j = 0; j < Grid.ySz; j++) {
/* 1078 */         for (i = 0; i < Grid.xSz; i++)
/* 1079 */           dataOut.writeChar(Grid.letter[i][j]); 
/*      */       } 
/* 1081 */       dataOut.writeUTF(Methods.puzzleTitle);
/* 1082 */       dataOut.writeUTF(Methods.author);
/* 1083 */       dataOut.writeUTF(Methods.copyright);
/* 1084 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 1085 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 1086 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 1087 */         dataOut.writeInt((NodeList.nodeList[i]).x);
/* 1088 */         dataOut.writeInt((NodeList.nodeList[i]).y);
/* 1089 */         dataOut.writeInt((NodeList.nodeList[i]).direction);
/* 1090 */         dataOut.writeInt((NodeList.nodeList[i]).id);
/* 1091 */         dataOut.writeInt((NodeList.nodeList[i]).length);
/* 1092 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/* 1093 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/* 1094 */         dataOut.writeBoolean((NodeList.nodeList[i]).solved);
/*      */       } 
/* 1096 */       dataOut.close();
/*      */     }
/* 1098 */     catch (IOException exc) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void loadWordsearch(String wordsearchName) {
/* 1107 */     Op.ws[Op.WS.WsDic.ordinal()] = Methods.confirmDictionary(Op.ws[Op.WS.WsDic.ordinal()] + ".dic", true);
/*      */     
/*      */     try {
/* 1110 */       File fl = new File(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName);
/* 1111 */       if (!fl.exists()) {
/* 1112 */         fl = new File(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/");
/* 1113 */         String[] s = fl.list(); int k;
/* 1114 */         for (k = 0; k < s.length && (
/* 1115 */           s[k].lastIndexOf(".wordsearch") == -1 || s[k].charAt(0) == '.'); k++);
/*      */         
/* 1117 */         if (k == s.length) {
/* 1118 */           makeGrid();
/*      */           return;
/*      */         } 
/* 1121 */         wordsearchName = s[k];
/* 1122 */         Op.ws[Op.WS.WsPuz.ordinal()] = wordsearchName;
/*      */       } 
/*      */       
/* 1125 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName));
/* 1126 */       Grid.xSz = dataIn.readInt();
/* 1127 */       Grid.ySz = dataIn.readInt();
/* 1128 */       Methods.noReveal = dataIn.readByte();
/* 1129 */       Methods.noErrors = dataIn.readByte(); int i;
/* 1130 */       for (i = 0; i < 54; i++)
/* 1131 */         dataIn.readByte(); 
/* 1132 */       for (int j = 0; j < Grid.ySz; j++) {
/* 1133 */         for (i = 0; i < Grid.xSz; i++)
/* 1134 */           Grid.letter[i][j] = dataIn.readChar(); 
/* 1135 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 1136 */       Methods.author = dataIn.readUTF();
/* 1137 */       Methods.copyright = dataIn.readUTF();
/* 1138 */       Methods.puzzleNumber = dataIn.readUTF();
/* 1139 */       Methods.puzzleNotes = dataIn.readUTF();
/* 1140 */       NodeList.nodeListLength = 0;
/* 1141 */       while (dataIn.available() > 4) {
/* 1142 */         NodeList.nodeList[NodeList.nodeListLength] = new Node();
/* 1143 */         (NodeList.nodeList[NodeList.nodeListLength]).x = dataIn.readInt();
/* 1144 */         (NodeList.nodeList[NodeList.nodeListLength]).y = dataIn.readInt();
/* 1145 */         (NodeList.nodeList[NodeList.nodeListLength]).direction = dataIn.readInt();
/* 1146 */         (NodeList.nodeList[NodeList.nodeListLength]).id = dataIn.readInt();
/* 1147 */         (NodeList.nodeList[NodeList.nodeListLength]).length = dataIn.readInt();
/* 1148 */         (NodeList.nodeList[NodeList.nodeListLength]).word = dataIn.readUTF();
/* 1149 */         (NodeList.nodeList[NodeList.nodeListLength]).clue = dataIn.readUTF();
/* 1150 */         (NodeList.nodeList[NodeList.nodeListLength]).solved = dataIn.readBoolean();
/* 1151 */         NodeList.nodeListLength++;
/*      */       } 
/* 1153 */       dataIn.close();
/*      */     }
/* 1155 */     catch (IOException exc) {
/*      */       return;
/* 1157 */     }  if (Def.puzzleMode == 202) {
/*      */       int i;
/* 1159 */       for (i = 0; i < NodeList.nodeListLength - 1; i++) {
/* 1160 */         for (int j = i + 1; j < NodeList.nodeListLength; j++) {
/* 1161 */           if ((NodeList.nodeList[i]).y > (NodeList.nodeList[j]).y || ((NodeList.nodeList[i]).y == (NodeList.nodeList[j]).y && (NodeList.nodeList[i]).x > (NodeList.nodeList[j]).x)) {
/*      */ 
/*      */             
/* 1164 */             Node memNode = NodeList.nodeList[i];
/* 1165 */             NodeList.nodeList[i] = NodeList.nodeList[j];
/* 1166 */             NodeList.nodeList[j] = memNode;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1170 */       (NodeList.nodeList[0]).id = 1;
/* 1171 */       for (int thisID = 1; i < NodeList.nodeListLength; i++) {
/* 1172 */         if ((NodeList.nodeList[i]).x != (NodeList.nodeList[i - 1]).x || (NodeList.nodeList[i]).y != (NodeList.nodeList[i - 1]).y)
/* 1173 */           thisID++; 
/* 1174 */         (NodeList.nodeList[i]).id = thisID;
/*      */       } 
/*      */     } 
/*      */     
/* 1178 */     Methods.havePuzzle = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawWordsearch(Graphics2D g2) {
/* 1185 */     int lwidth = (Grid.xCell < 30) ? 1 : (Grid.xCell / 15);
/*      */     
/* 1187 */     Stroke normalStroke = new BasicStroke(lwidth, 2, 0);
/* 1188 */     RenderingHints rh = g2.getRenderingHints();
/* 1189 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1190 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1191 */     rh.put(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_DEFAULT);
/* 1192 */     g2.setRenderingHints(rh);
/* 1193 */     g2.setStroke(normalStroke);
/*      */     
/* 1195 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsBackground.ordinal(), Op.ws)) : Def.COLOR_WHITE); int j;
/* 1196 */     for (j = 0; j < Grid.ySz; j++) {
/* 1197 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1198 */         if (Grid.letter[i][j] != 2)
/* 1199 */           g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */       } 
/* 1201 */     }  g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsBorder.ordinal(), Op.ws)) : Def.COLOR_BLACK);
/* 1202 */     for (j = 0; j < Grid.ySz; j++) {
/* 1203 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1204 */         if (Grid.letter[i][j] != 2) {
/* 1205 */           int x = Grid.xOrg + i * Grid.xCell;
/* 1206 */           int y = Grid.yOrg + j * Grid.yCell;
/* 1207 */           if (j == 0 || Grid.letter[i][j - 1] == 2) g2.drawLine(x, y, x + Grid.xCell, y); 
/* 1208 */           if (i == Grid.xSz - 1 || Grid.letter[i + 1][j] == 2) g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); 
/* 1209 */           if (j == Grid.ySz - 1 || Grid.letter[i][j + 1] == 2) g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); 
/* 1210 */           if (i == 0 || Grid.letter[i - 1][j] == 2) g2.drawLine(x, y + Grid.yCell, x, y);
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1216 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsLoop.ordinal(), Op.ws)) : Def.COLOR_BLACK);
/* 1217 */     double qx = 10.0D * Grid.xCell / 34.0D;
/* 1218 */     double vx = qx * 0.707D;
/* 1219 */     double qy = 10.0D * Grid.yCell / 34.0D;
/* 1220 */     double vy = qy * 0.707D;
/* 1221 */     if (dispLoops) {
/* 1222 */       for (int i = 0; i < NodeList.nodeListLength; i++) {
/* 1223 */         double xs = (Grid.xOrg + (NodeList.nodeList[i]).x * Grid.xCell) + Grid.xCell / 2.0D;
/* 1224 */         double ys = (Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell) + Grid.yCell / 2.0D;
/* 1225 */         j = (NodeList.nodeList[i]).direction;
/* 1226 */         int len = (NodeList.nodeList[i]).length - 1;
/* 1227 */         double xe = xs + (xInc[j] * Grid.xCell * len);
/* 1228 */         double ye = ys + (yInc[j] * Grid.yCell * len);
/* 1229 */         GeneralPath loop = new GeneralPath(1);
/* 1230 */         double diagGap = 2.0D * Math.sqrt(vx * vx + vy * vy) * 0.66D * 0.707D;
/* 1231 */         double orthogGap = 2.0D * qy * 0.66D;
/* 1232 */         switch (j) {
/*      */           case 0:
/* 1234 */             loop.moveTo(xe, ye + qy);
/* 1235 */             loop.curveTo(xe + orthogGap, ye + qy, xe + orthogGap, ye - qy, xe, ye - qy);
/* 1236 */             loop.lineTo(xs, ys - qy);
/* 1237 */             loop.curveTo(xs - orthogGap, ys - qy, xs - orthogGap, ys + qy, xs, ys + qy);
/*      */             break;
/*      */           case 4:
/* 1240 */             loop.moveTo(xe, ye + qy);
/* 1241 */             loop.curveTo(xe - orthogGap, ye + qy, xe - orthogGap, ye - qy, xe, ye - qy);
/* 1242 */             loop.lineTo(xs, ys - qy);
/* 1243 */             loop.curveTo(xs + orthogGap, ys - qy, xs + orthogGap, ys + qy, xs, ys + qy);
/*      */             break;
/*      */           case 2:
/* 1246 */             loop.moveTo(xe + qx, ye);
/* 1247 */             loop.curveTo(xe + qx, ye + orthogGap, xe - qx, ye + orthogGap, xe - qx, ye);
/* 1248 */             loop.lineTo(xs - qx, ys);
/* 1249 */             loop.curveTo(xs - qx, ys - orthogGap, xs + qx, ys - orthogGap, xs + qx, ys);
/*      */             break;
/*      */           case 6:
/* 1252 */             loop.moveTo(xe + qx, ye);
/* 1253 */             loop.curveTo(xe + qx, ye - orthogGap, xe - qx, ye - orthogGap, xe - qx, ye);
/* 1254 */             loop.lineTo(xs - qx, ys);
/* 1255 */             loop.curveTo(xs - qx, ys + orthogGap, xs + qx, ys + orthogGap, xs + qx, ys);
/*      */             break;
/*      */           case 1:
/* 1258 */             loop.moveTo(xe + vx, ye - vy);
/* 1259 */             loop.curveTo(xe + vx + diagGap, ye - vy + diagGap, xe - vx + diagGap, ye + vy + diagGap, xe - vx, ye + vy);
/* 1260 */             loop.lineTo(xs - vx, ys + vy);
/* 1261 */             loop.curveTo(xs - vx - diagGap, ys + vy - diagGap, xs + vx - diagGap, ys - vy - diagGap, xs + vx, ys - vy);
/*      */             break;
/*      */           case 5:
/* 1264 */             loop.moveTo(xe + vx, ye - vy);
/* 1265 */             loop.curveTo(xe + vx - diagGap, ye - vy - diagGap, xe - vx - diagGap, ye + vy - diagGap, xe - vx, ye + vy);
/* 1266 */             loop.lineTo(xs - vx, ys + vy);
/* 1267 */             loop.curveTo(xs - vx + diagGap, ys + vy + diagGap, xs + vx + diagGap, ys - vy + diagGap, xs + vx, ys - vy);
/*      */             break;
/*      */           case 3:
/* 1270 */             loop.moveTo(xe + vx, ye + vy);
/* 1271 */             loop.curveTo(xe + vx - diagGap, ye + vy + diagGap, xe - vx - diagGap, ye - vy + diagGap, xe - vx, ye - vy);
/* 1272 */             loop.lineTo(xs - vx, ys - vy);
/* 1273 */             loop.curveTo(xs - vx + diagGap, ys - vy - diagGap, xs + vx + diagGap, ys + vy - diagGap, xs + vx, ys + vy);
/*      */             break;
/*      */           case 7:
/* 1276 */             loop.moveTo(xe + vx, ye + vy);
/* 1277 */             loop.curveTo(xe + vx + diagGap, ye + vy - diagGap, xe - vx + diagGap, ye - vy - diagGap, xe - vx, ye - vy);
/* 1278 */             loop.lineTo(xs - vx, ys - vy);
/* 1279 */             loop.curveTo(xs - vx - diagGap, ys - vy + diagGap, xs + vx - diagGap, ys + vy + diagGap, xs + vx, ys + vy);
/*      */             break;
/*      */         } 
/* 1282 */         loop.closePath();
/* 1283 */         g2.draw(loop);
/*      */       } 
/*      */     }
/*      */     
/* 1287 */     if (dispLoops) {
/* 1288 */       Methods.clearGrid(Grid.sig);
/* 1289 */       for (int i = 0; i < NodeList.nodeListLength; i++) {
/* 1290 */         int x = (NodeList.nodeList[i]).x;
/* 1291 */         int k = (NodeList.nodeList[i]).y;
/* 1292 */         int d = (NodeList.nodeList[i]).direction;
/* 1293 */         for (j = 0; j < (NodeList.nodeList[i]).length; j++) {
/* 1294 */           Grid.sig[x][k] = 1;
/* 1295 */           x += xInc[d];
/* 1296 */           k += yInc[d];
/*      */         } 
/*      */       } 
/*      */       
/* 1300 */       for (int y = 0; y < Grid.ySz; y++) {
/* 1301 */         for (int x = 0; x < Grid.xSz; x++) {
/* 1302 */           if (Grid.sig[x][y] == 0 && (char)Grid.letter[x][y] > '/' && Methods.havePuzzle == true) {
/* 1303 */             g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsMsgBody.ordinal(), Op.ws)) : Def.COLOR_WHITE);
/* 1304 */             g2.fillOval(Grid.xOrg + x * Grid.xCell + Grid.xCell / 6, Grid.yOrg + y * Grid.yCell + Grid.yCell / 6, Grid.xCell - Grid.xCell / 3, Grid.yCell - Grid.xCell / 3);
/* 1305 */             g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsMsgHilite.ordinal(), Op.ws)) : Def.COLOR_BLACK);
/* 1306 */             g2.drawOval(Grid.xOrg + x * Grid.xCell + Grid.xCell / 6, Grid.yOrg + y * Grid.yCell + Grid.yCell / 6, Grid.xCell - Grid.xCell / 3, Grid.yCell - Grid.xCell / 3);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1310 */     }  g2.setFont(new Font(Op.ws[Op.WS.WsFont.ordinal()], 0, 4 * Grid.yCell / 10));
/* 1311 */     FontMetrics fm = g2.getFontMetrics();
/* 1312 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsLetter.ordinal(), Op.ws)) : Def.COLOR_BLACK);
/* 1313 */     for (j = 0; j < Grid.ySz; j++) {
/* 1314 */       for (int i = 0; i < Grid.xSz; i++) {
/* 1315 */         char ch = (char)Grid.letter[i][j];
/* 1316 */         if (ch > ' ') {
/* 1317 */           int w = fm.stringWidth("" + ch);
/* 1318 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1323 */     g2.setStroke(new BasicStroke(1.0F));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawWordWeave(Graphics2D g2) {
/* 1330 */     int lwidth = (Grid.xCell < 30) ? 1 : (Grid.xCell / 15);
/* 1331 */     Stroke normalStroke = new BasicStroke(lwidth, 2, 0);
/* 1332 */     RenderingHints rh = g2.getRenderingHints();
/* 1333 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 1334 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 1335 */     rh.put(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_DEFAULT);
/* 1336 */     g2.setRenderingHints(rh);
/* 1337 */     g2.setStroke(normalStroke);
/*      */ 
/*      */     
/* 1340 */     g2.setColor(new Color(Op.getColorInt(Op.WS.WsBackground.ordinal(), Op.ws))); int j;
/* 1341 */     for (j = 0; j < Grid.ySz; j++) {
/* 1342 */       for (int k = 0; k < Grid.xSz; k++) {
/* 1343 */         if (Grid.letter[k][j] != 2)
/* 1344 */           g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*      */       } 
/*      */     } 
/* 1347 */     g2.setColor(Def.COLOR_LIGHTGRAY); int i;
/* 1348 */     for (i = 1; i < Grid.ySz; i++)
/* 1349 */       g2.drawLine(Grid.xOrg, Grid.yOrg + i * Grid.yCell, Grid.xOrg + Grid.xSz * Grid.xCell, Grid.yOrg + i * Grid.yCell); 
/* 1350 */     for (i = 1; i < Grid.xSz; i++) {
/* 1351 */       g2.drawLine(Grid.xOrg + i * Grid.xCell, Grid.yOrg, Grid.xOrg + i * Grid.xCell, Grid.yOrg + Grid.ySz * Grid.yCell);
/*      */     }
/*      */     
/* 1354 */     g2.setColor(Def.COLOR_BLACK);
/* 1355 */     for (j = 0; j < Grid.ySz; j++) {
/* 1356 */       for (i = 0; i < Grid.xSz; i++) {
/* 1357 */         if (Grid.letter[i][j] != 2) {
/* 1358 */           int x = Grid.xOrg + i * Grid.xCell;
/* 1359 */           int y = Grid.yOrg + j * Grid.yCell;
/* 1360 */           if (j == 0 || Grid.letter[i][j - 1] == 2) g2.drawLine(x, y, x + Grid.xCell, y); 
/* 1361 */           if (i == Grid.xSz - 1 || Grid.letter[i + 1][j] == 2) g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); 
/* 1362 */           if (j == Grid.ySz - 1 || Grid.letter[i][j + 1] == 2) g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); 
/* 1363 */           if (i == 0 || Grid.letter[i - 1][j] == 2) g2.drawLine(x, y + Grid.yCell, x, y);
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1369 */     g2.setFont(new Font(Op.cw[Op.CW.CwIDFont.ordinal()], 0, Grid.yCell / 3));
/* 1370 */     FontMetrics fm = g2.getFontMetrics();
/* 1371 */     for (i = 0; i < NodeList.nodeListLength; i++)
/* 1372 */       g2.drawString("" + (NodeList.nodeList[i]).id, Grid.xOrg + (NodeList.nodeList[i]).x * Grid.xCell + ((Grid.xCell / 20 > 1) ? (Grid.xCell / 20) : 1), Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell + fm
/* 1373 */           .getAscent()); 
/*      */   }
/*      */   
/*      */   static void printWordSearchPuz(Graphics2D g2, int left, int top, int width, int height) {
/* 1377 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/* 1378 */     setSizesAndOffsets(left, top, width, height, 0);
/* 1379 */     dispLoops = false;
/* 1380 */     Def.dispWithColor = Op.getBool(Op.WS.WsPuzColor.ordinal(), Op.ws);
/* 1381 */     drawWordsearch(g2);
/* 1382 */     Def.dispWithColor = Boolean.valueOf(true);
/* 1383 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printWordWeavePuz(Graphics2D g2, int left, int top, int width, int height) {
/* 1387 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/* 1388 */     setSizesAndOffsets(left, top, width, height, 0);
/* 1389 */     Def.dispWithColor = Op.getBool(Op.WS.WsSolColor.ordinal(), Op.ws);
/* 1390 */     drawWordWeave(g2);
/* 1391 */     Def.dispWithColor = Boolean.valueOf(true);
/* 1392 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 1396 */     loadWordsearch(solutionPuzzle);
/* 1397 */     setSizesAndOffsets(left, top, width, height, 0);
/* 1398 */     dispLoops = true;
/* 1399 */     Def.dispWithColor = Op.getBool(Op.WS.WsSolColor.ordinal(), Op.ws);
/* 1400 */     drawWordsearch(g2);
/* 1401 */     Def.dispWithColor = Boolean.valueOf(true);
/* 1402 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */   }
/*      */   
/*      */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 1406 */     loadWordsearch(solutionPuzzle);
/* 1407 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/* 1408 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean CheckFit(String theWord, WS ws, int forward, boolean mustLink) {
/*      */     int dStart, iStart;
/* 1417 */     Random r = new Random();
/*      */     
/* 1419 */     int lenW = theWord.length();
/* 1420 */     if (ws.D == -1) {
/* 1421 */       iStart = lenW / 2;
/* 1422 */       ws.sD = dStart = r.nextInt(8);
/*      */     } else {
/*      */       
/* 1425 */       if ((iStart = Math.abs(ws.X - ws.sX)) == 0)
/* 1426 */         iStart = Math.abs(ws.Y - ws.sY); 
/* 1427 */       if ((dStart = ws.D) == ws.sD) {
/* 1428 */         iStart = (iStart + lenW + forward) % lenW;
/* 1429 */         if (iStart == lenW / 2)
/* 1430 */           return false; 
/*      */       } 
/*      */     } 
/* 1433 */     int i = iStart; do {
/* 1434 */       int d; for (d = (dStart + 1) % 8;; d = (d + 1) % 8) {
/* 1435 */         if ((Op.getInt(Op.WS.WsDirMask.ordinal(), Op.ws) & this.dirCont[d]) != 0) {
/* 1436 */           int xs = ws.sX - i * xInc[d];
/* 1437 */           int ys = ws.sY - i * yInc[d]; int j;
/*      */           boolean linked;
/* 1439 */           for (linked = false, j = 0; j < lenW && 
/* 1440 */             xs >= 0 && xs < Grid.xSz && ys >= 0 && ys < Grid.ySz; j++) {
/*      */             
/* 1442 */             if (Grid.letter[xs][ys] == theWord.charAt(j)) {
/* 1443 */               linked = true;
/* 1444 */             } else if (Grid.letter[xs][ys] != 0) {
/*      */               break;
/* 1446 */             }  xs += xInc[d];
/* 1447 */             ys += yInc[d];
/*      */           } 
/* 1449 */           if (j == lenW && (linked || !mustLink)) {
/* 1450 */             ws.D = d;
/* 1451 */             ws.L = lenW;
/* 1452 */             return true;
/*      */           } 
/*      */         } 
/* 1455 */         if (d == ws.sD)
/*      */           break; 
/*      */       } 
/* 1458 */       i = (i + lenW + forward) % lenW;
/* 1459 */     } while (i != lenW / 2);
/*      */ 
/*      */     
/* 1462 */     return false;
/*      */   }
/*      */   
/*      */   static void makeGrid() {
/* 1466 */     Grid.clearGrid();
/* 1467 */     Grid.xSz = Op.getInt(Op.WS.WsAcross.ordinal(), Op.ws);
/* 1468 */     Grid.ySz = Op.getInt(Op.WS.WsDown.ordinal(), Op.ws);
/* 1469 */     if (Op.ws[Op.WS.WsTemplate.ordinal()].length() > 0)
/* 1470 */       Grid.loadGrid(Op.ws[Op.WS.WsTemplate.ordinal()]); 
/* 1471 */     NodeList.nodeListLength = 0;
/* 1472 */     for (int y = 0; y < Grid.ySz; y++) {
/* 1473 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1474 */         if (Grid.mode[x][y] == 0)
/* 1475 */           Grid.letter[x][y] = 42; 
/*      */       } 
/*      */     }  } int buildWordsearch(int start) {
/*      */     boolean fullHouse;
/* 1479 */     int wCount = 0;
/*      */     
/* 1481 */     int wj = 0;
/* 1482 */     WS ws[] = new WS[400], val = new WS();
/* 1483 */     String[] word = new String[400], clue = new String[400];
/*      */     
/* 1485 */     int[] wordIndex = new int[400];
/* 1486 */     int charsLoaded = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     Random r = new Random();
/*      */ 
/*      */     
/* 1497 */     int lenL = Op.getInt(Op.WS.WsLong.ordinal(), Op.ws);
/* 1498 */     int lenS = Op.getInt(Op.WS.WsShort.ordinal(), Op.ws);
/*      */ 
/*      */     
/*      */     try {
/* 1502 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/xword.dic"));
/* 1503 */       for (int k = 0; k < 128; k++)
/* 1504 */         dataIn.readByte(); 
/* 1505 */       for (wCount = 0; dataIn.available() > 2; ) {
/* 1506 */         dataIn.readInt();
/* 1507 */         String stW = dataIn.readUTF();
/* 1508 */         if (stW.length() <= lenL && stW.length() >= lenS)
/* 1509 */           wCount++; 
/* 1510 */         dataIn.readUTF();
/*      */       } 
/* 1512 */       dataIn.close();
/*      */     }
/* 1514 */     catch (IOException exc) {}
/* 1515 */     if (wCount == 0) return 0; 
/*      */     int i;
/* 1517 */     for (i = 0; i < 400; wordIndex[i++] = -1);
/* 1518 */     if (wCount <= 400)
/* 1519 */     { for (i = 0; i < wCount; ) { wordIndex[i] = i; i++; }
/*      */        }
/* 1521 */     else { for (i = 0; i < 400; ) {
/* 1522 */         int k = r.nextInt(wCount);
/* 1523 */         for (int n = 0; n < 400 && 
/* 1524 */           wordIndex[n] != k; n++) {
/*      */           
/* 1526 */           if (k < wordIndex[n] || wordIndex[n] == -1) {
/* 1527 */             for (int i1 = 198; i1 >= n; i1--)
/* 1528 */               wordIndex[i1 + 1] = wordIndex[i1]; 
/* 1529 */             wordIndex[n] = k;
/* 1530 */             i++;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }  }
/*      */ 
/*      */     
/*      */     try {
/* 1539 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/xword.dic"));
/* 1540 */       for (i = 0; i < 128; i++)
/* 1541 */         dataIn.readByte(); 
/* 1542 */       for (int n = 0; wCount < 400 && dataIn.available() > 2; ) {
/* 1543 */         dataIn.readInt();
/* 1544 */         String stW = dataIn.readUTF(), stC = dataIn.readUTF();
/* 1545 */         if (stW.length() <= lenL && stW.length() >= lenS && 
/* 1546 */           n++ == wordIndex[wCount]) {
/* 1547 */           charsLoaded += stW.length();
/* 1548 */           word[wCount] = stW;
/* 1549 */           clue[wCount++] = stC;
/*      */         } 
/*      */       } 
/* 1552 */       dataIn.close();
/*      */     }
/* 1554 */     catch (IOException exc) {}
/*      */     
/* 1556 */     for (i = 0; i < wCount; i++) {
/* 1557 */       int k = r.nextInt(wCount);
/* 1558 */       String stC = clue[k]; clue[k] = clue[i]; clue[i] = stC;
/* 1559 */       String stW = word[k]; word[k] = word[i]; word[i] = stW;
/*      */     } 
/*      */ 
/*      */     
/* 1563 */     makeGrid(); int y;
/* 1564 */     for (y = 0; y < Grid.ySz; y++) {
/* 1565 */       for (int x = 0; x < Grid.xSz; x++)
/* 1566 */         Grid.letter[x][y] = Grid.mode[x][y]; 
/* 1567 */     }  for (i = 0; i < 400; i++) {
/* 1568 */       ws[i] = new WS();
/* 1569 */       wordIndex[i] = (ws[i]).wIndex = -1;
/* 1570 */       (ws[i]).thisTarget = 0;
/*      */     } 
/*      */     int j, gapsLeft;
/* 1573 */     for (gapsLeft = j = 0; j < Grid.ySz; j++) {
/* 1574 */       for (i = 0; i < Grid.xSz; i++) {
/* 1575 */         if (Grid.letter[i][j] == 0 && Grid.mode[i][j] != 2)
/* 1576 */           gapsLeft++; 
/*      */       } 
/* 1578 */     }  int gapTarget; for (i = gapTarget = 0; i < Op.ws[Op.WS.WsMessage.ordinal()].length(); i++) {
/* 1579 */       if (Op.ws[Op.WS.WsMessage.ordinal()].charAt(i) != ' ')
/* 1580 */         gapTarget++; 
/*      */     } 
/* 1582 */     if ((charsLoaded + gapTarget) * 7 / 10 < gapsLeft) {
/* 1583 */       if (Op.ws[Op.WS.WsMessage.ordinal()].length() > 0) {
/* 1584 */         return 0;
/*      */       }
/* 1586 */       fullHouse = false;
/*      */     } else {
/*      */       
/* 1589 */       fullHouse = true;
/*      */     } 
/* 1591 */     if (start > 100 && fullHouse && Op.ws[Op.WS.WsMessage.ordinal()].length() == 0)
/* 1592 */       fullHouse = false; 
/* 1593 */     float nextGap = gapsLeft / gapTarget - 1.0F, gapSpace = nextGap; int refresh, wsi, fillMode;
/*      */     boolean sameWord;
/* 1595 */     for (fillMode = r.nextInt(2), refresh = 1, wsi = 0, sameWord = false; wsi >= 0; wsi++) {
/* 1596 */       if (++refresh % 500 == 0) {
/* 1597 */         dispLoops = false;
/* 1598 */         restoreFrame();
/* 1599 */         if (Def.building == 2)
/* 1600 */           return 3; 
/* 1601 */         if (refresh >= 5000)
/* 1602 */           return 2; 
/*      */       } 
/* 1604 */       if (fullHouse)
/* 1605 */       { int v; if (fillMode == 0) {
/* 1606 */           for (v = 0, (ws[wsi]).sX = 0, (ws[wsi]).sY = 0; v < Grid.xSz * Grid.ySz && 
/* 1607 */             Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] != 0; v++) {
/*      */             
/* 1609 */             (ws[wsi]).sX++; (ws[wsi]).sY--;
/* 1610 */             if ((ws[wsi]).sX == Grid.xSz || (ws[wsi]).sY == -1) {
/* 1611 */               (ws[wsi]).sY += (ws[wsi]).sX + 1;
/* 1612 */               (ws[wsi]).sX = 0;
/* 1613 */               int correction = (ws[wsi]).sY - Grid.ySz + 1;
/* 1614 */               if (correction > 0) {
/* 1615 */                 (ws[wsi]).sX += correction;
/* 1616 */                 (ws[wsi]).sY -= correction;
/*      */               } 
/*      */             } 
/*      */           } 
/* 1620 */           if (v == Grid.xSz * Grid.ySz) {
/*      */             break;
/*      */           }
/*      */         } else {
/* 1624 */           for ((ws[wsi]).sY = 0; (ws[wsi]).sY < Grid.ySz; (ws[wsi]).sY++) {
/* 1625 */             for ((ws[wsi]).sX = 0; (ws[wsi]).sX < Grid.xSz && 
/* 1626 */               Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] != 0; (ws[wsi]).sX++);
/*      */             
/* 1628 */             if ((ws[wsi]).sX < Grid.xSz)
/*      */               break; 
/*      */           } 
/* 1631 */           if ((ws[wsi]).sY == Grid.ySz)
/*      */             break; 
/* 1633 */           v = (ws[wsi]).sY * Grid.xSz + (ws[wsi]).sX;
/*      */         } 
/*      */         
/* 1636 */         if (gapTarget > 0 && 
/* 1637 */           v > nextGap && (
/* 1638 */           (ws[wsi]).sX == 0 || Grid.letter[(ws[wsi]).sX - 1][(ws[wsi]).sY] != 3) && (
/* 1639 */           (ws[wsi]).sY == 0 || Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY - 1] != 3))
/* 1640 */         { nextGap += gapSpace;
/* 1641 */           Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] = 3;
/* 1642 */           (ws[wsi]).wIndex = 0;
/* 1643 */           (ws[wsi]).L = 0;
/* 1644 */           gapsLeft--;
/* 1645 */           gapTarget--;
/*      */            }
/*      */         
/*      */         else
/*      */         
/*      */         { 
/* 1651 */           (ws[wsi]).D = -1;
/*      */           
/* 1653 */           v = 0;
/*      */           
/* 1655 */           if ((ws[wsi]).sX > 0) {
/* 1656 */             v = Grid.letter[(ws[wsi]).sX - 1][(ws[wsi]).sY] | Grid.letter[(ws[wsi]).sX - 1][(ws[wsi]).sY + 1];
/* 1657 */             if ((ws[wsi]).sY > 0)
/* 1658 */               v |= Grid.letter[(ws[wsi]).sX - 1][(ws[wsi]).sY - 1]; 
/*      */           } 
/* 1660 */           if ((ws[wsi]).sY > 0)
/* 1661 */             v |= Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY - 1] | Grid.letter[(ws[wsi]).sX + 1][(ws[wsi]).sY - 1]; 
/* 1662 */           boolean mustLink = ((v & 0xF0) > 0);
/*      */           
/* 1664 */           int wi = 0; while (true) {
/* 1665 */             if (sameWord) {
/* 1666 */               sameWord = false;
/*      */             } else {
/*      */               
/* 1669 */               for (; wi < wCount && 
/* 1670 */                 wordIndex[wi] != -1; wi++);
/*      */               
/* 1672 */               if (wi == wCount) {
/* 1673 */                 if (--wsi < 0) {
/*      */                   break;
/*      */                 }
/* 1676 */                 while (Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] == 3) {
/* 1677 */                   Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] = 0;
/* 1678 */                   nextGap -= gapSpace;
/* 1679 */                   gapsLeft++;
/* 1680 */                   gapTarget++;
/* 1681 */                   wsi--;
/*      */                 } 
/*      */                 
/* 1684 */                 int k = (ws[wsi]).X; y = (ws[wsi]).Y;
/* 1685 */                 wi = (ws[wsi]).wIndex;
/* 1686 */                 wordIndex[wi] = (ws[wsi]).wIndex = -1;
/* 1687 */                 for (i = 0; i < word[wi].length(); i++) {
/* 1688 */                   Grid.mode[k][y] = Grid.mode[k][y] - 1; if (Grid.mode[k][y] - 1 == 0) {
/* 1689 */                     Grid.letter[k][y] = 0;
/* 1690 */                     gapsLeft++;
/*      */                   } 
/* 1692 */                   k += xInc[(ws[wsi]).D]; y += yInc[(ws[wsi]).D];
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/* 1697 */             if (!CheckFit(word[wi], ws[wsi], 2 * wsi % 2 - 1, mustLink)) {
/* 1698 */               wi++;
/*      */               
/*      */               continue;
/*      */             } 
/* 1702 */             int x = (ws[wsi]).X; y = (ws[wsi]).Y;
/* 1703 */             wordIndex[wi] = wsi;
/* 1704 */             (ws[wsi]).wIndex = wi;
/* 1705 */             (ws[wsi]).L = word[wi].length();
/* 1706 */             for (i = 0; i < word[wi].length(); i++) {
/* 1707 */               Grid.letter[x][y] = word[wi].charAt(i);
/* 1708 */               Grid.mode[x][y] = Grid.mode[x][y] + 1; if (Grid.mode[x][y] == 0)
/* 1709 */                 gapsLeft--; 
/* 1710 */               x += xInc[(ws[wsi]).D]; y += yInc[(ws[wsi]).D];
/*      */             } 
/* 1712 */             (ws[wsi]).thisTarget = gapTarget;
/* 1713 */             if (gapsLeft == gapTarget)
/*      */               break; 
/* 1715 */             if (gapsLeft > gapTarget) {
/* 1716 */               for (i = 0; i < Grid.xSz * Grid.ySz; i++) {
/* 1717 */                 val.sY = i / Grid.xSz;
/* 1718 */                 val.sX = i % Grid.xSz;
/* 1719 */                 if (Grid.letter[val.sX][val.sY] == 0) {
/* 1720 */                   for (wj = 0; wj < wCount; wj++) {
/* 1721 */                     if (wordIndex[wj] == -1) {
/* 1722 */                       val.D = -1;
/* 1723 */                       if (CheckFit(word[wj], val, 1, false))
/*      */                         break; 
/*      */                     } 
/*      */                   } 
/* 1727 */                   if (wj == wCount)
/*      */                     break; 
/*      */                 } 
/*      */               } 
/* 1731 */               if (wj < wCount) {
/*      */                 break;
/*      */               }
/*      */             } 
/* 1735 */             x = (ws[wsi]).X; y = (ws[wsi]).Y;
/* 1736 */             wi = (ws[wsi]).wIndex;
/* 1737 */             wordIndex[wi] = (ws[wsi]).wIndex = -1;
/* 1738 */             for (i = 0; i < word[wi].length(); i++) {
/* 1739 */               Grid.mode[x][y] = Grid.mode[x][y] - 1; if (Grid.mode[x][y] - 1 == 0) {
/* 1740 */                 Grid.letter[x][y] = 0;
/* 1741 */                 gapsLeft++;
/*      */               } 
/* 1743 */               x += xInc[(ws[wsi]).D]; y += yInc[(ws[wsi]).D];
/*      */             } 
/* 1745 */             sameWord = true;
/*      */           } 
/* 1747 */           if (gapsLeft == 0) {
/*      */             break;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1784 */           if (!fullHouse) break;  }  } else { dispLoops = false; int wi; for (wsi = 0, wi = 0; wi < wCount; ) { (ws[wsi]).sY = r.nextInt(Grid.ySz); (ws[wsi]).sX = r.nextInt(Grid.xSz); for (i = 0; i < Grid.xSz * Grid.ySz; i++) { do { (ws[wsi]).sX = 0; if ((ws[wsi]).sX++ != Grid.xSz || (ws[wsi]).sY++ != Grid.ySz) continue;  (ws[wsi]).sY = 0; } while (Grid.letter[(ws[wsi]).sX][(ws[wsi]).sY] != 0); if (CheckFit(word[wi], ws[wsi], 2 * wsi % 2 - 1, false)) { int x = (ws[wsi]).X; y = (ws[wsi]).Y; (ws[wsi]).wIndex = wi; (ws[wsi]).L = word[wi].length(); for (i = 0; i < word[wi].length(); i++) { Grid.letter[x][y] = word[wi].charAt(i); Grid.mode[x][y] = Grid.mode[x][y] + 1; if (Grid.mode[x][y] == 0) gapsLeft--;  x += xInc[(ws[wsi]).D]; y += yInc[(ws[wsi]).D]; }  wsi++; break; }  }  wi++; }  if (!fullHouse)
/*      */           break;  }
/*      */     
/* 1787 */     }  for (int m = 0; m < Grid.ySz; m++) {
/* 1788 */       for (int n = 0; n < Grid.xSz; n++) {
/* 1789 */         if (Grid.letter[n][m] == 0 || Grid.letter[n][m] == 3) {
/* 1790 */           if (Op.ws[Op.WS.WsMessage.ordinal()].length() > 0) {
/* 1791 */             while (Op.ws[Op.WS.WsMessage.ordinal()].charAt(i) == ' ')
/* 1792 */               i++; 
/* 1793 */             Grid.letter[n][m] = Op.ws[Op.WS.WsMessage.ordinal()].charAt(i++);
/*      */           } else {
/*      */             int letter;
/*      */             do {
/* 1797 */               letter = Grid.letter[r.nextInt(Grid.xSz)][r.nextInt(Grid.ySz)];
/* 1798 */             } while (letter >= 0 && letter <= 3);
/* 1799 */             Grid.letter[n][m] = letter;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1805 */     NodeList.nodeListLength = 0;
/* 1806 */     for (i = 0; i < wCount; i++) {
/* 1807 */       if ((ws[i]).L != 0) {
/*      */         
/* 1809 */         if ((ws[i]).wIndex < 0)
/* 1810 */           return 2; 
/* 1811 */         NodeList.nodeList[NodeList.nodeListLength] = new Node();
/* 1812 */         (NodeList.nodeList[NodeList.nodeListLength]).x = (ws[i]).X;
/* 1813 */         (NodeList.nodeList[NodeList.nodeListLength]).y = (ws[i]).Y;
/* 1814 */         (NodeList.nodeList[NodeList.nodeListLength]).direction = (ws[i]).D;
/* 1815 */         (NodeList.nodeList[NodeList.nodeListLength]).id = (NodeList.nodeList[NodeList.nodeListLength]).length = (ws[i]).L;
/* 1816 */         (NodeList.nodeList[NodeList.nodeListLength]).word = word[(ws[i]).wIndex];
/* 1817 */         (NodeList.nodeList[NodeList.nodeListLength]).clue = clue[(ws[i]).wIndex];
/* 1818 */         (NodeList.nodeList[NodeList.nodeListLength]).solved = false;
/* 1819 */         NodeList.nodeListLength++;
/*      */       } 
/* 1821 */     }  NodeList.sortNodeList(0);
/*      */     int ortho, diag;
/* 1823 */     for (ortho = diag = i = 0; i < NodeList.nodeListLength; i++) {
/* 1824 */       if ((NodeList.nodeList[i]).direction % 2 == 0) {
/* 1825 */         ortho++;
/*      */       } else {
/* 1827 */         diag++;
/*      */       } 
/*      */     } 
/* 1830 */     if (fullHouse && 
/* 1831 */       fullHouse && (ortho == 0 || diag == 0 || ortho / diag > 3 || diag / ortho > 3)) {
/* 1832 */       return 2;
/*      */     }
/* 1834 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/* 1835 */       String thisWord = (NodeList.nodeList[i]).word; int count;
/* 1836 */       for (count = j = 0; j < NodeList.nodeListLength; j++) {
/* 1837 */         if ((NodeList.nodeList[j]).word.contains((NodeList.nodeList[i]).word)) {
/* 1838 */           count++;
/*      */         }
/*      */       } 
/* 1841 */       int len = thisWord.length(); int k;
/* 1842 */       for (k = 0; k < len && 
/* 1843 */         thisWord.charAt(k) == thisWord.charAt(len - 1 - k); k++);
/*      */       
/* 1845 */       if (k == len) count *= 2;
/*      */       
/* 1847 */       j = unwantedWord(thisWord);
/* 1848 */       if (j > count) {
/* 1849 */         return 2;
/*      */       }
/*      */     } 
/*      */     
/*      */     try {
/* 1854 */       BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("badwords.txt"), "UTF-8")); String badword;
/* 1855 */       while ((badword = br.readLine()) != null) {
/* 1856 */         if (badword.length() > 0 && 
/* 1857 */           unwantedWord(badword) > 0) {
/* 1858 */           br.close();
/* 1859 */           return 2;
/*      */         } 
/*      */       } 
/* 1862 */       br.close();
/*      */     }
/* 1864 */     catch (IOException exc) {}
/* 1865 */     dispLoops = true;
/* 1866 */     return 1;
/*      */   }
/*      */   
/*      */   int unwantedWord(String word) {
/* 1870 */     int count = 0, l = word.length();
/*      */     
/* 1872 */     for (int y = 0; y < Grid.ySz; y++) {
/* 1873 */       for (int x = 0; x < Grid.xSz; x++) {
/* 1874 */         if (Grid.letter[x][y] == word.charAt(0))
/* 1875 */         { if (x + l <= Grid.xSz) { int i; for (i = 0; i < l && Grid.letter[x + i][y] == word.charAt(i); i++); if (i == l) count++;  }
/* 1876 */            if (x + l <= Grid.xSz && y + l <= Grid.ySz) { int i; for (i = 0; i < l && Grid.letter[x + i][y + i] == word.charAt(i); i++); if (i == l) count++;  }
/* 1877 */            if (y + l <= Grid.ySz) { int i; for (i = 0; i < l && Grid.letter[x][y + i] == word.charAt(i); i++); if (i == l) count++;  }
/* 1878 */            if (x - l >= -1 && y + l <= Grid.ySz) { int i; for (i = 0; i < l && Grid.letter[x - i][y + i] == word.charAt(i); i++); if (i == l) count++;  }
/* 1879 */            if (x - l >= -1) { int i; for (i = 0; i < l && Grid.letter[x - i][y] == word.charAt(i); i++); if (i == l) count++;  }
/* 1880 */            if (x - l >= -1 && y - l >= -1) { int i; for (i = 0; i < l && Grid.letter[x - i][y - i] == word.charAt(i); i++); if (i == l) count++;  }
/* 1881 */            if (y - l >= -1) { int i; for (i = 0; i < l && Grid.letter[x][y - i] == word.charAt(i); i++); if (i == l) count++;  }
/* 1882 */            if (x + l <= Grid.xSz && y - l >= -1) { int i; for (i = 0; i < l && Grid.letter[x + i][y - i] == word.charAt(i); i++); if (i == l) count++;  }  } 
/*      */       } 
/* 1884 */     }  return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void multiBuild() {
/* 1893 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/* 1894 */     Calendar c = Calendar.getInstance();
/*      */     
/* 1896 */     File fl = new File("$wordsearch.dic");
/* 1897 */     if (!fl.exists())
/* 1898 */       fl.mkdir(); 
/* 1899 */     fl = new File(System.getProperty("user.dir"));
/* 1900 */     String[] s = fl.list();
/* 1901 */     for (int scan = -1, count = 0; count < this.howMany; ) {
/*      */       do {
/* 1903 */         if (++scan != s.length)
/* 1904 */           continue;  scan = 0;
/* 1905 */       } while (!s[scan].endsWith(".dic") || 
/* 1906 */         !s[scan].startsWith("$") || s[scan]
/* 1907 */         .equalsIgnoreCase("$wordsearch.dic"));
/*      */ 
/*      */       
/* 1910 */       String str = s[scan].substring(0, s[scan].lastIndexOf(".dic"));
/* 1911 */       Op.ws[Op.WS.WsDic.ordinal()] = str;
/* 1912 */       Op.ws[Op.WS.WsMessage.ordinal()] = str.substring(1).toUpperCase();
/*      */       
/* 1914 */       if (this.startPuz > 9999999) { try {
/* 1915 */           c.setTime(sdf.parse("" + this.startPuz));
/* 1916 */         } catch (ParseException ex) {}
/* 1917 */         this.startPuz = Integer.parseInt(sdf.format(c.getTime())); }
/*      */ 
/*      */       
/* 1920 */       String puzName = "" + this.startPuz + ".wordsearch";
/*      */       
/* 1922 */       Op.ws[Op.WS.WsPuz.ordinal()] = puzName;
/* 1923 */       for (int retry = 0; retry < 10; retry++) {
/* 1924 */         int result = buildWordsearch(-1);
/* 1925 */         switch (result) {
/*      */           case 1:
/* 1927 */             Methods.puzzleTitle = "WORDSEARCH : " + this.startPuz;
/*      */             
/* 1929 */             Op.ws[Op.WS.WsDic.ordinal()] = "$wordsearch";
/* 1930 */             restoreFrame();
/* 1931 */             saveWordsearch(puzName);
/* 1932 */             count++;
/* 1933 */             this.startPuz++;
/*      */             break;
/*      */           case 3:
/* 1936 */             makeGrid();
/* 1937 */             restoreFrame();
/* 1938 */             Methods.interrupted(jfWordsearch);
/* 1939 */             this.howMany = 1;
/*      */             return;
/*      */         } 
/* 1942 */         if (result == 1)
/*      */           break; 
/*      */       } 
/*      */     } 
/* 1946 */     Methods.havePuzzle = true;
/* 1947 */     restoreFrame();
/* 1948 */     Methods.puzzleSaved(jfWordsearch, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", Op.ws[Op.WS.WsPuz.ordinal()]);
/*      */   }
/*      */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\WordsearchBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */