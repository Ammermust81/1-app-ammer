/*     */ package crosswordexpress;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public class WordsearchSolve extends JPanel {
/*     */   static JFrame jfSolveWordsearch;
/*     */   static JMenuBar menuBar;
/*     */   JMenu menu;
/*     */   JMenu submenu;
/*     */   JMenuItem menuItem;
/*     */   static JPanel pp;
/*     */   static int panelW;
/*  29 */   int xSz = 10; static int panelH; static JLabel jl1; static JLabel jl2; Timer myTimer; static Runnable solveThread; static DefaultListModel<String> lmWords; static JList<String> jlstWords; static JScrollPane jspWords; int ySz = 10; int xOrg = 10; int yOrg = 10; int xCell = 10; int yCell; static int startX; static int startY; static int endX; static int endY;
/*     */   static int solveDir;
/*     */   int memMode;
/*     */   static boolean dispLoops = false;
/*  33 */   static int[] xInc = new int[] { 1, 1, 0, -1, -1, -1, 0, 1 };
/*  34 */   static int[] yInc = new int[] { 0, 1, 1, 1, 0, -1, -1, -1 };
/*     */   
/*  36 */   String wordsearchSolve = "<div>A typical <b>WORD-SEARCH</b> puzzle consists of a matrix of letters in which a number of words are embedded. The words may run up or down, forward or backward, or in any diagonal direction. The Crossword Express version of this puzzle will normally have every letter of the puzzle linked into at least one of the words of the puzzle. This is sometimes referred to as a <b>Full House</b> puzzle. In addition, it will be normal for each word in the puzzle to intersect with at least one of the other words.<p/>All of the words in the scrollable list to the left of the screen are hidden in the matrix of letters to right of the screen.<p/>Your task is to identify each word by holding down the mouse on the first letter of a word, and dragging to the last letter. When you release the mouse button, the word will be struck-out in the letter matrix, and will also be removed from the list.<p/>You can also do this by pointing to the last letter and dragging toward the first letter.<br/><br/></div><span class='m'>Menu Functions</span><ul><li/><span class='s'>File Menu</span><ul><li/><span class='menusub'>Select a Dictionary</span><br/>When loading a new puzzle, you begin by selecting the dictionary which was used to build the WORD-SEARCH puzzle which you want to solve.<p/><li/><span class='menusub'>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of WORD-SEARCH puzzles currently available in the selected dictionary.<p/><li/><span class='menusub'>Quit Solving</span><br/>Returns you to the WORD-SEARCH Construction screen.</ul><li/><span class='s'>View Menu</span><ul><li/><span class='menusub'>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span class='menusub'>Reveal One Word</span><br/>If you need a little help to get started, this option will reveal the location of the word currently selected in the list of words not yet found.<p/><li/><span class='menusub'>Reveal Solution</span><br/>The entire solution can be seen by selecting this option.<p/><li/><span class='menusub'>Begin Again</span><br/>You can restart the entire solution process at any time by selecting this option.</ul><li/><span class='s'>Help Menu</span><ul><li/><span class='menusub'>Word-search Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WordsearchSolve(JFrame jf) {
/*  80 */     this.memMode = Def.puzzleMode;
/*  81 */     Def.puzzleMode = 201;
/*  82 */     Def.dispSolArray = Boolean.valueOf(true); Def.dispCursor = Boolean.valueOf(true); Def.dispGuideDigits = Boolean.valueOf(true);
/*     */     
/*  84 */     jfSolveWordsearch = new JFrame("Solve a Wordsearch Puzzle");
/*  85 */     jfSolveWordsearch.setSize(Op.getInt(Op.WS.WsSolveW.ordinal(), Op.ws), Op.getInt(Op.WS.WsSolveH.ordinal(), Op.ws));
/*  86 */     int frameX = (jf.getX() + jfSolveWordsearch.getWidth() > Methods.scrW) ? (Methods.scrW - jfSolveWordsearch.getWidth() - 10) : jf.getX();
/*  87 */     jfSolveWordsearch.setLocation(frameX, jf.getY());
/*  88 */     jfSolveWordsearch.setLayout((LayoutManager)null);
/*  89 */     jfSolveWordsearch.getContentPane().setBackground(Def.COLOR_FRAMEBG);
/*  90 */     jfSolveWordsearch.setDefaultCloseOperation(0);
/*  91 */     jfSolveWordsearch
/*  92 */       .addComponentListener(new ComponentAdapter()
/*     */         {
/*     */           public void componentResized(ComponentEvent ce) {
/*  95 */             int w = (WordsearchSolve.jfSolveWordsearch.getWidth() < 840) ? 840 : WordsearchSolve.jfSolveWordsearch.getWidth();
/*  96 */             int h = (WordsearchSolve.jfSolveWordsearch.getHeight() < 674) ? 674 : WordsearchSolve.jfSolveWordsearch.getHeight();
/*  97 */             WordsearchSolve.jfSolveWordsearch.setSize(w, h);
/*  98 */             Op.setInt(Op.WS.WsW.ordinal(), w, Op.ws);
/*  99 */             Op.setInt(Op.WS.WsH.ordinal(), h, Op.ws);
/* 100 */             WordsearchSolve.restoreFrame();
/*     */           }
/*     */         });
/*     */     
/* 104 */     jfSolveWordsearch
/* 105 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 107 */             if (Def.selecting)
/* 108 */               return;  WordsearchSolve.restoreIfDone();
/* 109 */             WordsearchSolve.saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/* 110 */             CrosswordExpress.transfer(200, WordsearchSolve.jfSolveWordsearch);
/*     */           }
/*     */         });
/*     */     
/* 114 */     Methods.closeHelp();
/*     */     
/* 116 */     jl1 = new JLabel(); jfSolveWordsearch.add(jl1);
/* 117 */     jl2 = new JLabel(); jfSolveWordsearch.add(jl2);
/*     */ 
/*     */     
/* 120 */     menuBar = new JMenuBar();
/* 121 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 122 */     jfSolveWordsearch.setJMenuBar(menuBar);
/* 123 */     this.menu = new JMenu("File");
/* 124 */     menuBar.add(this.menu);
/* 125 */     this.menuItem = new JMenuItem("Select a Dictionary");
/* 126 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 127 */     this.menu.add(this.menuItem);
/* 128 */     this.menuItem
/* 129 */       .addActionListener(ae -> {
/*     */           Methods.selectDictionary(jfSolveWordsearch, Op.ws[Op.WS.WsDic.ordinal()], 2);
/*     */           
/*     */           if (!Methods.fileAvailable(Methods.dictionaryName + ".dic", "wordsearch")) {
/*     */             JOptionPane.showMessageDialog(jfSolveWordsearch, "<html>No Wordsearch puzzles are available in this dictionary.<br>Use the <font color=880000>Build</font> option to create one.");
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           restoreIfDone();
/*     */           saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*     */           Op.ws[Op.WS.WsDic.ordinal()] = Methods.dictionaryName;
/*     */           loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*     */           restoreFrame();
/*     */         });
/* 144 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 145 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 146 */     this.menu.add(this.menuItem);
/* 147 */     this.menuItem
/* 148 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           restoreIfDone();
/*     */           saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*     */           new Select(jfSolveWordsearch, Op.ws[Op.WS.WsDic.ordinal()] + ".dic", "wordsearch", Op.ws, Op.WS.WsPuz.ordinal(), false);
/*     */         });
/* 156 */     this.menuItem = new JMenuItem("Quit Solving");
/* 157 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 158 */     this.menu.add(this.menuItem);
/* 159 */     this.menuItem
/* 160 */       .addActionListener(ae -> {
/*     */           restoreIfDone();
/*     */           
/*     */           saveWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/*     */           
/*     */           CrosswordExpress.transfer(200, jfSolveWordsearch);
/*     */         });
/*     */     
/* 168 */     this.menu = new JMenu("View");
/* 169 */     menuBar.add(this.menu);
/* 170 */     this.menuItem = new JMenuItem("Display Options");
/* 171 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(73, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 172 */     this.menu.add(this.menuItem);
/* 173 */     this.menuItem
/* 174 */       .addActionListener(ae -> {
/*     */           WordsearchBuild.printOptions(jfSolveWordsearch, "Display Options");
/*     */ 
/*     */           
/*     */           restoreFrame();
/*     */         });
/*     */     
/* 181 */     this.menu = new JMenu("Task");
/* 182 */     menuBar.add(this.menu);
/*     */     
/* 184 */     ActionListener errorTimer = ae -> {
/*     */         Def.dispErrors = Boolean.valueOf(false);
/*     */         pp.repaint();
/*     */         this.myTimer.stop();
/*     */       };
/* 189 */     this.myTimer = new Timer(1500, errorTimer);
/*     */     
/* 191 */     this.menuItem = new JMenuItem("Reveal One Word");
/* 192 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 193 */     this.menu.add(this.menuItem);
/* 194 */     this.menuItem
/* 195 */       .addActionListener(ae -> {
/*     */           Object ob = jlstWords.getSelectedValue();
/*     */           if (ob != null) {
/*     */             String st = ((String)ob).trim();
/*     */             lmWords.removeElement(" " + st);
/*     */             for (int i = 0; i < NodeList.nodeListLength; i++) {
/*     */               if ((NodeList.nodeList[i]).word.equals(st)) {
/*     */                 (NodeList.nodeList[i]).id = 1;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 208 */     this.menuItem = new JMenuItem("Reveal Solution");
/* 209 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 210 */     this.menu.add(this.menuItem);
/* 211 */     this.menuItem
/* 212 */       .addActionListener(ae -> {
/*     */           if (Methods.noReveal == 0) {
/*     */             lmWords.clear();
/*     */             
/*     */             for (int i = 0; i < NodeList.nodeListLength; i++) {
/*     */               (NodeList.nodeList[i]).id = 1;
/*     */             }
/*     */             dispLoops = true;
/*     */           } else {
/*     */             Methods.noReveal(jfSolveWordsearch);
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 225 */     this.menuItem = new JMenuItem("Begin Again");
/* 226 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 227 */     this.menu.add(this.menuItem);
/* 228 */     this.menuItem
/* 229 */       .addActionListener(ae -> {
/*     */           lmWords.clear();
/*     */           
/*     */           for (int i = 0; i < NodeList.nodeListLength; i++) {
/*     */             (NodeList.nodeList[i]).id = 0;
/*     */             
/*     */             lmWords.addElement(" " + (NodeList.nodeList[i]).word);
/*     */           } 
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 240 */     this.menu = new JMenu("Help");
/* 241 */     menuBar.add(this.menu);
/* 242 */     this.menuItem = new JMenuItem("Wordsearch Help");
/* 243 */     this.menu.add(this.menuItem);
/* 244 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 245 */     this.menuItem
/* 246 */       .addActionListener(ae -> Methods.cweHelp(jfSolveWordsearch, null, "Solving Wordsearch Puzzles", this.wordsearchSolve));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     JLabel jl = new JLabel("<html><font color=006644 size=3><font size=4>Words");
/* 253 */     jl.setSize(180, 16);
/* 254 */     jl.setLocation(10, 45);
/* 255 */     jl.setHorizontalAlignment(2);
/* 256 */     jfSolveWordsearch.add(jl);
/*     */     
/* 258 */     lmWords = new DefaultListModel<>();
/* 259 */     jlstWords = new JList<>(lmWords);
/* 260 */     jlstWords.setFont(new Font("SansSerif", 1, 12));
/* 261 */     jspWords = new JScrollPane(jlstWords);
/* 262 */     jspWords.setLocation(10, 65);
/* 263 */     jspWords.setSize(180, 240);
/* 264 */     jspWords.setHorizontalScrollBarPolicy(31);
/* 265 */     jfSolveWordsearch.add(jspWords);
/*     */     
/* 267 */     solveThread = (() -> {
/*     */         for (int i = 0; i < NodeList.nodeListLength; i++) {
/*     */           if ((NodeList.nodeList[i]).id == 0)
/*     */             return; 
/*     */         } 
/*     */         dispLoops = true;
/*     */         Methods.congratulations(jfSolveWordsearch);
/*     */       });
/* 275 */     loadWordsearch(Op.ws[Op.WS.WsPuz.ordinal()]);
/* 276 */     pp = new WordsearchSolvePP(190, 37);
/* 277 */     jfSolveWordsearch.add(pp);
/*     */     
/* 279 */     pp
/* 280 */       .addMouseMotionListener(new MouseAdapter() {
/*     */           public void mouseMoved(MouseEvent e) {
/* 282 */             if (Def.isMac) {
/* 283 */               WordsearchSolve.jfSolveWordsearch.setResizable((WordsearchSolve.jfSolveWordsearch.getWidth() - e.getX() < 200 && WordsearchSolve.jfSolveWordsearch
/* 284 */                   .getHeight() - e.getY() < 95));
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 289 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 293 */     jfSolveWordsearch.setVisible(true);
/* 294 */     Insets insets = jfSolveWordsearch.getInsets();
/* 295 */     panelW = jfSolveWordsearch.getWidth() - insets.left + insets.right + 190;
/* 296 */     panelH = jfSolveWordsearch.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 297 */     pp.setSize(panelW, panelH);
/* 298 */     setSizesAndOffsets(0, 0, panelW, panelH, 20);
/* 299 */     jspWords.setSize(180, Grid.ySz * Grid.yCell - 25 - Grid.yOrg);
/* 300 */     jfSolveWordsearch.requestFocusInWindow();
/* 301 */     pp.repaint();
/* 302 */     Methods.infoPanel(jl1, jl2, "Solve Wordsearch", "Dictionary : " + Op.ws[Op.WS.WsDic.ordinal()] + "  -|-  Puzzle : " + Op.ws[Op.WS.WsPuz
/* 303 */           .ordinal()], panelW + 190);
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset) {
/* 307 */     int i = (width - inset) / Grid.xSz;
/* 308 */     int j = (height - inset) / Grid.ySz;
/* 309 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 310 */     Grid.xOrg = x + 10;
/* 311 */     Grid.yOrg = y + 10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveWordsearch(String wordsearchName) {
/*     */     try {
/* 319 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName));
/* 320 */       dataOut.writeInt(Grid.xSz);
/* 321 */       dataOut.writeInt(Grid.ySz);
/* 322 */       dataOut.writeByte(Methods.noReveal);
/* 323 */       dataOut.writeByte(Methods.noErrors); int i;
/* 324 */       for (i = 0; i < 54; i++)
/* 325 */         dataOut.writeByte(0); 
/* 326 */       for (int j = 0; j < Grid.ySz; j++) {
/* 327 */         for (i = 0; i < Grid.xSz; i++)
/* 328 */           dataOut.writeChar(Grid.letter[i][j]); 
/* 329 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 330 */       dataOut.writeUTF(Methods.author);
/* 331 */       dataOut.writeUTF(Methods.copyright);
/* 332 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 333 */       dataOut.writeUTF(Methods.puzzleNotes);
/*     */       
/* 335 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 336 */         dataOut.writeInt((NodeList.nodeList[i]).x);
/* 337 */         dataOut.writeInt((NodeList.nodeList[i]).y);
/* 338 */         dataOut.writeInt((NodeList.nodeList[i]).direction);
/* 339 */         dataOut.writeInt((NodeList.nodeList[i]).id);
/* 340 */         dataOut.writeInt((NodeList.nodeList[i]).length);
/* 341 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/* 342 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/* 343 */         dataOut.writeBoolean((NodeList.nodeList[i]).solved);
/*     */       } 
/* 345 */       dataOut.close();
/*     */     }
/* 347 */     catch (IOException exc) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadWordsearch(String wordsearchName) {
/*     */     
/* 356 */     try { File fl = new File(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName);
/* 357 */       if (!fl.exists()) {
/*     */         
/* 359 */         fl = new File(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/");
/* 360 */         String[] s = fl.list(); int k;
/* 361 */         for (k = 0; k < s.length && (
/* 362 */           s[k].lastIndexOf(".wordsearch") == -1 || s[k].charAt(0) == '.'); k++);
/*     */         
/* 364 */         wordsearchName = s[k];
/* 365 */         Op.ws[Op.WS.WsPuz.ordinal()] = wordsearchName;
/*     */       } 
/*     */ 
/*     */       
/* 369 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.ws[Op.WS.WsDic.ordinal()] + ".dic/" + wordsearchName));
/* 370 */       Grid.xSz = dataIn.readInt();
/* 371 */       Grid.ySz = dataIn.readInt();
/* 372 */       Methods.noReveal = dataIn.readByte();
/* 373 */       Methods.noErrors = dataIn.readByte(); int i;
/* 374 */       for (i = 0; i < 54; i++)
/* 375 */         dataIn.readByte();  int j;
/* 376 */       for (j = 0; j < Grid.ySz; j++) {
/* 377 */         for (i = 0; i < Grid.xSz; i++)
/* 378 */           Grid.letter[i][j] = dataIn.readChar(); 
/* 379 */       }  Methods.puzzleTitle = dataIn.readUTF();
/* 380 */       Methods.author = dataIn.readUTF();
/* 381 */       Methods.copyright = dataIn.readUTF();
/* 382 */       Methods.puzzleNumber = dataIn.readUTF();
/* 383 */       Methods.puzzleNotes = dataIn.readUTF();
/*     */       
/* 385 */       NodeList.nodeListLength = 0;
/* 386 */       while (dataIn.available() > 4) {
/* 387 */         NodeList.nodeList[NodeList.nodeListLength] = new Node();
/* 388 */         (NodeList.nodeList[NodeList.nodeListLength]).x = dataIn.readInt();
/* 389 */         (NodeList.nodeList[NodeList.nodeListLength]).y = dataIn.readInt();
/* 390 */         (NodeList.nodeList[NodeList.nodeListLength]).direction = dataIn.readInt();
/* 391 */         (NodeList.nodeList[NodeList.nodeListLength]).id = dataIn.readInt();
/* 392 */         (NodeList.nodeList[NodeList.nodeListLength]).length = dataIn.readInt();
/* 393 */         (NodeList.nodeList[NodeList.nodeListLength]).word = dataIn.readUTF();
/* 394 */         (NodeList.nodeList[NodeList.nodeListLength]).clue = dataIn.readUTF();
/* 395 */         (NodeList.nodeList[NodeList.nodeListLength]).solved = dataIn.readBoolean();
/* 396 */         NodeList.nodeListLength++;
/*     */       } 
/* 398 */       dataIn.close();
/* 399 */       for (j = 0; j < Grid.ySz; j++) {
/* 400 */         for (i = 0; i < Grid.xSz; i++)
/* 401 */           Grid.color[i][j] = 16777215; 
/*     */       } 
/* 403 */       lmWords.clear();
/* 404 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 405 */         if ((NodeList.nodeList[i]).id == 0)
/* 406 */           lmWords.addElement(" " + (NodeList.nodeList[i]).word); 
/*     */       }  }
/* 408 */     catch (IOException exc) { return; }
/* 409 */      Methods.havePuzzle = true;
/* 410 */     restoreIfDone();
/*     */   }
/*     */ 
/*     */   
/*     */   static void drawOneLoop(Graphics2D g2, double xs, double ys, int j, int len) {
/* 415 */     double xe = xs + (xInc[j] * Grid.xCell * len);
/* 416 */     double ye = ys + (yInc[j] * Grid.yCell * len);
/* 417 */     double qx = 10.0D * Grid.xCell / 34.0D, vx = qx * 0.707D;
/* 418 */     double qy = 10.0D * Grid.yCell / 34.0D, vy = qy * 0.707D;
/*     */     
/* 420 */     GeneralPath loop = new GeneralPath(1);
/* 421 */     double diagGap = 2.0D * Math.sqrt(vx * vx + vy * vy) * 0.66D * 0.707D;
/* 422 */     double orthogGap = 2.0D * qy * 0.66D;
/* 423 */     switch (j) {
/*     */       case 0:
/* 425 */         loop.moveTo(xe, ye + qy);
/* 426 */         loop.curveTo(xe + orthogGap, ye + qy, xe + orthogGap, ye - qy, xe, ye - qy);
/* 427 */         loop.lineTo(xs, ys - qy);
/* 428 */         loop.curveTo(xs - orthogGap, ys - qy, xs - orthogGap, ys + qy, xs, ys + qy);
/*     */         break;
/*     */       case 4:
/* 431 */         loop.moveTo(xe, ye + qy);
/* 432 */         loop.curveTo(xe - orthogGap, ye + qy, xe - orthogGap, ye - qy, xe, ye - qy);
/* 433 */         loop.lineTo(xs, ys - qy);
/* 434 */         loop.curveTo(xs + orthogGap, ys - qy, xs + orthogGap, ys + qy, xs, ys + qy);
/*     */         break;
/*     */       case 2:
/* 437 */         loop.moveTo(xe + qx, ye);
/* 438 */         loop.curveTo(xe + qx, ye + orthogGap, xe - qx, ye + orthogGap, xe - qx, ye);
/* 439 */         loop.lineTo(xs - qx, ys);
/* 440 */         loop.curveTo(xs - qx, ys - orthogGap, xs + qx, ys - orthogGap, xs + qx, ys);
/*     */         break;
/*     */       case 6:
/* 443 */         loop.moveTo(xe + qx, ye);
/* 444 */         loop.curveTo(xe + qx, ye - orthogGap, xe - qx, ye - orthogGap, xe - qx, ye);
/* 445 */         loop.lineTo(xs - qx, ys);
/* 446 */         loop.curveTo(xs - qx, ys + orthogGap, xs + qx, ys + orthogGap, xs + qx, ys);
/*     */         break;
/*     */       case 1:
/* 449 */         loop.moveTo(xe + vx, ye - vy);
/* 450 */         loop.curveTo(xe + vx + diagGap, ye - vy + diagGap, xe - vx + diagGap, ye + vy + diagGap, xe - vx, ye + vy);
/* 451 */         loop.lineTo(xs - vx, ys + vy);
/* 452 */         loop.curveTo(xs - vx - diagGap, ys + vy - diagGap, xs + vx - diagGap, ys - vy - diagGap, xs + vx, ys - vy);
/*     */         break;
/*     */       case 5:
/* 455 */         loop.moveTo(xe + vx, ye - vy);
/* 456 */         loop.curveTo(xe + vx - diagGap, ye - vy - diagGap, xe - vx - diagGap, ye + vy - diagGap, xe - vx, ye + vy);
/* 457 */         loop.lineTo(xs - vx, ys + vy);
/* 458 */         loop.curveTo(xs - vx + diagGap, ys + vy + diagGap, xs + vx + diagGap, ys - vy + diagGap, xs + vx, ys - vy);
/*     */         break;
/*     */       case 3:
/* 461 */         loop.moveTo(xe + vx, ye + vy);
/* 462 */         loop.curveTo(xe + vx - diagGap, ye + vy + diagGap, xe - vx - diagGap, ye - vy + diagGap, xe - vx, ye - vy);
/* 463 */         loop.lineTo(xs - vx, ys - vy);
/* 464 */         loop.curveTo(xs - vx + diagGap, ys - vy - diagGap, xs + vx + diagGap, ys + vy - diagGap, xs + vx, ys + vy);
/*     */         break;
/*     */       case 7:
/* 467 */         loop.moveTo(xe + vx, ye + vy);
/* 468 */         loop.curveTo(xe + vx + diagGap, ye + vy - diagGap, xe - vx + diagGap, ye - vy - diagGap, xe - vx, ye - vy);
/* 469 */         loop.lineTo(xs - vx, ys - vy);
/* 470 */         loop.curveTo(xs - vx - diagGap, ys - vy + diagGap, xs + vx - diagGap, ys + vy + diagGap, xs + vx, ys + vy);
/*     */         break;
/*     */     } 
/* 473 */     loop.closePath();
/* 474 */     g2.draw(loop);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawWordsearch(Graphics2D g2) {
/* 480 */     int dir = -1;
/*     */     
/* 482 */     int lwidth = (Grid.xCell < 30) ? 1 : (Grid.xCell / 15);
/* 483 */     if (lwidth % 2 == 0) lwidth++; 
/* 484 */     Stroke normalStroke = new BasicStroke(lwidth, 2, 0);
/* 485 */     RenderingHints rh = g2.getRenderingHints();
/* 486 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 487 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 488 */     rh.put(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_DEFAULT);
/* 489 */     g2.setRenderingHints(rh);
/* 490 */     g2.setStroke(normalStroke);
/*     */     int j;
/* 492 */     for (j = 0; j < Grid.ySz; j++) {
/* 493 */       for (int k = 0; k < Grid.xSz; k++) {
/* 494 */         if (Grid.letter[k][j] != 2) {
/* 495 */           g2.setColor(new Color(Op.getColorInt(Op.WS.WsBackground.ordinal(), Op.ws)));
/* 496 */           g2.fillRect(Grid.xOrg + k * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */         } 
/*     */       } 
/*     */     } 
/* 500 */     g2.setColor(new Color(Op.getColorInt(Op.WS.WsBorder.ordinal(), Op.ws)));
/* 501 */     for (j = 0; j < Grid.ySz; j++) {
/* 502 */       for (int k = 0; k < Grid.xSz; k++) {
/* 503 */         if (Grid.letter[k][j] != 2) {
/* 504 */           int x = Grid.xOrg + k * Grid.xCell;
/* 505 */           int y = Grid.yOrg + j * Grid.yCell;
/* 506 */           if (j == 0 || Grid.letter[k][j - 1] == 2)
/* 507 */             g2.drawLine(x, y, x + Grid.xCell, y); 
/* 508 */           if (k == Grid.xSz - 1 || Grid.letter[k + 1][j] == 2)
/* 509 */             g2.drawLine(x + Grid.xCell, y, x + Grid.xCell, y + Grid.yCell); 
/* 510 */           if (j == Grid.ySz - 1 || Grid.letter[k][j + 1] == 2)
/* 511 */             g2.drawLine(x, y + Grid.yCell, x + Grid.xCell, y + Grid.yCell); 
/* 512 */           if (k == 0 || Grid.letter[k - 1][j] == 2)
/* 513 */             g2.drawLine(x, y + Grid.yCell, x, y); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 517 */     g2.setColor(new Color(Op.getColorInt(Op.WS.WsLoop.ordinal(), Op.ws))); int i;
/* 518 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/* 519 */       if ((NodeList.nodeList[i]).id != 0) {
/* 520 */         double xs = (Grid.xOrg + (NodeList.nodeList[i]).x * Grid.xCell) + Grid.xCell / 2.0D;
/* 521 */         double ys = (Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell) + Grid.yCell / 2.0D;
/* 522 */         j = (NodeList.nodeList[i]).direction;
/* 523 */         int k = (NodeList.nodeList[i]).length - 1;
/* 524 */         drawOneLoop(g2, xs, ys, j, k);
/*     */       } 
/*     */     } 
/* 527 */     g2.setColor(new Color(Op.getColorInt(Op.WS.WsSlvHilite.ordinal(), Op.ws)));
/* 528 */     int len = Math.abs((startX == endX) ? (endY - startY) : (endX - startX));
/* 529 */     if (startX == endX) { dir = (startY < endY) ? 2 : 6; }
/* 530 */     else if (startY == endY) { dir = (startX < endX) ? 0 : 4; }
/* 531 */     else if (startX < endX) { dir = (startY < endY) ? 1 : 7; }
/* 532 */     else if (startX > endX) { dir = (startY < endY) ? 3 : 5; }
/* 533 */      if (dir != -1 && len != 0) {
/* 534 */       drawOneLoop(g2, (Grid.xOrg + startX * Grid.xCell) + Grid.xCell / 2.0D, (Grid.yOrg + startY * Grid.yCell) + Grid.yCell / 2.0D, dir, len);
/*     */     }
/*     */     
/* 537 */     for (i = 0; i < NodeList.nodeListLength && 
/* 538 */       (NodeList.nodeList[i]).id != 0; i++);
/*     */     
/* 540 */     if (i == NodeList.nodeListLength && 
/* 541 */       dispLoops) {
/* 542 */       Methods.clearGrid(Grid.sig);
/* 543 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 544 */         int x = (NodeList.nodeList[i]).x;
/* 545 */         int k = (NodeList.nodeList[i]).y;
/* 546 */         int d = (NodeList.nodeList[i]).direction;
/* 547 */         for (j = 0; j < (NodeList.nodeList[i]).length; j++) {
/* 548 */           Grid.sig[x][k] = 1;
/* 549 */           x += xInc[d];
/* 550 */           k += yInc[d];
/*     */         } 
/*     */       } 
/*     */       
/* 554 */       g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.WS.WsMsgHilite.ordinal(), Op.ws)) : Def.COLOR_BLACK);
/*     */       
/* 556 */       for (int y = 0; y < Grid.ySz; y++) {
/* 557 */         for (int x = 0; x < Grid.xSz; x++) {
/* 558 */           if (Grid.sig[x][y] == 0 && (char)Grid.letter[x][y] > ' ') {
/* 559 */             g2.setColor(new Color(Op.getColorInt(Op.WS.WsMsgBody.ordinal(), Op.ws)));
/* 560 */             g2.fillOval(Grid.xOrg + x * Grid.xCell + Grid.xCell / 6, Grid.yOrg + y * Grid.yCell + Grid.yCell / 6, Grid.xCell - Grid.xCell / 3, Grid.yCell - Grid.xCell / 3);
/* 561 */             g2.setColor(new Color(Op.getColorInt(Op.WS.WsMsgHilite.ordinal(), Op.ws)));
/* 562 */             g2.drawOval(Grid.xOrg + x * Grid.xCell + Grid.xCell / 6, Grid.yOrg + y * Grid.yCell + Grid.yCell / 6, Grid.xCell - Grid.xCell / 3, Grid.yCell - Grid.xCell / 3);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 567 */     g2.setFont(new Font(Op.ws[Op.WS.WsFont.ordinal()], 0, 4 * Grid.yCell / 10));
/* 568 */     FontMetrics fm = g2.getFontMetrics();
/* 569 */     g2.setColor(new Color(Op.getColorInt(Op.WS.WsLetter.ordinal(), Op.ws)));
/* 570 */     for (j = 0; j < Grid.ySz; j++) {
/* 571 */       for (i = 0; i < Grid.xSz; i++) {
/* 572 */         char ch = (char)Grid.letter[i][j];
/* 573 */         if (Character.isLetter(ch)) {
/* 574 */           int w = fm.stringWidth("" + ch);
/* 575 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + (Grid.yCell + fm.getAscent() - fm.getDescent()) / 2);
/*     */         } 
/*     */       } 
/*     */     } 
/* 579 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   static void restoreIfDone() {
/*     */     int i;
/* 583 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/* 584 */       if ((NodeList.nodeList[i]).id == 0) {
/*     */         return;
/*     */       }
/*     */     } 
/* 588 */     for (i = 0; i < NodeList.nodeListLength; i++) {
/* 589 */       (NodeList.nodeList[i]).id = 0;
/* 590 */       lmWords.addElement(" " + (NodeList.nodeList[i]).word);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void clearColor() {
/* 596 */     for (int j = 0; j < Grid.ySz; j++) {
/* 597 */       for (int i = 0; i < Grid.xSz; i++)
/* 598 */         Grid.color[i][j] = 16777215; 
/*     */     } 
/*     */   }
/*     */   static void processMouse(MouseEvent e, int mode) {
/* 602 */     int type, x = e.getX(), y = e.getY();
/* 603 */     boolean repaintNeeded = false;
/*     */     
/* 605 */     if (x < Grid.xOrg || y < Grid.yOrg)
/* 606 */       return;  int i = (x - Grid.xOrg) / Grid.xCell;
/* 607 */     int j = (y - Grid.yOrg) / Grid.yCell;
/* 608 */     if (i >= Grid.xSz || j >= Grid.ySz)
/* 609 */       return;  switch (mode) {
/*     */       case 0:
/* 611 */         startX = i; startY = j;
/* 612 */         Grid.color[startX][startY] = 43690;
/*     */         break;
/*     */       case 1:
/* 615 */         clearColor();
/* 616 */         endX = i; endY = j;
/* 617 */         type = 0;
/* 618 */         if (startX == endX) { type = 1; }
/* 619 */         else if (startY == endY) { type = 2; }
/* 620 */         else if (startX - endX == startY - endY) { type = 3; }
/* 621 */         else if (startX - endX == endY - startY) { type = 4; }
/* 622 */          for (j = 0; j < Grid.ySz; j++) {
/* 623 */           for (i = 0; i < Grid.xSz; i++) {
/* 624 */             if ((i >= startX || i >= endX) && (i <= startX || i <= endX) && (
/* 625 */               j >= startY || j >= endY) && (j <= startY || j <= endY) && (
/* 626 */               type == 1 || type == 2 || (type == 3 && startX - i == startY - j) || (type == 4 && startX - i == j - startY))) {
/* 627 */               Grid.color[i][j] = 43690;
/* 628 */               repaintNeeded = true;
/*     */             } 
/*     */           } 
/*     */         }  break;
/*     */       case 2:
/* 633 */         for (i = 0; i < NodeList.nodeListLength; i++) {
/* 634 */           int dir = (NodeList.nodeList[i]).direction;
/* 635 */           int len = (NodeList.nodeList[i]).length - 1;
/* 636 */           int lastX = (NodeList.nodeList[i]).x + xInc[dir] * len;
/* 637 */           int lastY = (NodeList.nodeList[i]).y + yInc[dir] * len;
/* 638 */           if (((NodeList.nodeList[i]).x == startX && (NodeList.nodeList[i]).y == startY && lastX == endX && lastY == endY) || ((NodeList.nodeList[i]).x == endX && (NodeList.nodeList[i]).y == endY && lastX == startX && lastY == startY)) {
/*     */             
/* 640 */             (NodeList.nodeList[i]).id = 1;
/* 641 */             lmWords.removeElement(" " + (NodeList.nodeList[i]).word);
/*     */             break;
/*     */           } 
/*     */         } 
/* 645 */         startX = startY = endX = endY = 0;
/* 646 */         clearColor();
/* 647 */         repaintNeeded = true;
/* 648 */         (new Thread(solveThread)).start();
/*     */         break;
/*     */     } 
/* 651 */     if (repaintNeeded)
/* 652 */       restoreFrame(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\WordsearchSolve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */