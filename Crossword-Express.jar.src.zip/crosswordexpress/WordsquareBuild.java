/*     */ package crosswordexpress;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public final class WordsquareBuild {
/*     */   static JFrame jfWordsquare;
/*     */   static JMenuBar menuBar;
/*     */   JMenu menu;
/*     */   JMenu submenu;
/*     */   JMenuItem menuItem;
/*     */   JMenuItem buildMenuItem;
/*  21 */   static int[][] wordCount = new int[5][50]; static JPanel pp; static int panelW; static int panelH; static JLabel jl1; static JLabel jl2; Thread thread;
/*  22 */   static char[][][][][] chWord = new char[2][5][50][][];
/*  23 */   static boolean[][][] busy = new boolean[5][50][];
/*     */   
/*  25 */   String wordsquareOptionsHelp = "<div>The single option available in this dialog allows you to set the size of the WORDSQUARE puzzle you will construct. You can select a size in the range 4x4 to 10x10.</div>";
/*     */ 
/*     */ 
/*     */   
/*  29 */   String wordsquareHelp = "<div>A WORDSQUARE puzzle is a Crossword puzzle having a couple of unique features. It is built on a square grid which can range in size from 4x4 up to 10x10. It has none of the familiar pattern squares of a traditional crossword. Consequently its contents is a list of words equal in number and equal in length to the size of the grid. Also, the list of ACROSS words is exactly the same as the list of DOWN words. As you might imagine, it is not possible to build a large number of these puzzle in the larger sizes. Using the English dictionary supplied with the program, you should have no problem building 7x7 puzzles, but if you want an 8x8 puzzle (or larger) you will need a much larger dictionary.<p/></div><span class='m'>Menu Functions</span><ul><li><span class='s'>File Menu</span><ul><li><span>Select a Dictionary</span><br/>When loading a new puzzle into the Build screen, you begin by selecting the dictionary which was used to build the WORDSQUARE puzzle which you want to load.<p/><li><span>Load a Puzzle</span><br/>Then you choose your puzzle from the pool of WORDSQUARE puzzles currently available in the selected dictionary.<p/><li><span>SaveAs</span><br/>This option allows you to make an exact copy of the current puzzle using a different file name. The copy will be saved in the folder of the dictionary that was used to construct it. Alternatively, if you don't enter a new name for the puzzle, you can change the Puzzle Description, or any of the other descriptive items without changing the puzzle name.<p/><li><span>Quit Construction</span><br/>Returns you to the Crossword Express opening screen.</ul><li><span class='s'>Build Menu</span><ul><li/><span >Start a New Puzzle</span><br/>This option presents you with a dialog into which you can enter a file name for your new puzzle. You can also enter several other pieces of optional information such as a <b>Puzzle Title, Author</b> and <b>Copyright</b> information.<p/><li/><span>Select a Dictionary</span><br/>Use this option to select the dictionary which you want to use to build the new WORDSQUARE puzzle.<p/><li/><span>Build Options</span><br/>Use this option to access a Build Options dialog where you can set some rules to be followed by the puzzle building function as it builds your puzzle.<p/><li/><span>Start Building / Stop Building</span><br/> Construction of the puzzle will commence when you select the <b>Start Building</b> option. If puzzle building is successful you will receive a message containing the name of the puzzle file, and the location where it was saved. If it becomes necessary, you can interrupt the building process by selecting this option a second time. Note that during the construction phase, the text of this option is changed to <b>Stop Building</b></ul><li/><span class='s'>View Menu</span><ul><li/><span>Display Options</span><br/>This leads you to a dialog box in which you can change the colors of various elements within the puzzle, and control the fonts which will be used for the puzzle's text components. You can also decide if printing of the puzzle will be done in black and white or in color.</ul><li/><span class='s'>Tasks Menu</span><ul><li/><span>Print Wordsquare puzzle</span><br/>The current puzzle can be printed as if it were a standard CROSSWORD puzzle.<p/><li/><span>Solve Wordsquare puzzle</span><br/>The current puzzle can be solved as if it were a standard CROSSWORD puzzle.<p/><li/><span>Delete this Puzzle</span><br/>Use this option to eliminate unwanted WORDSQUARE puzzles from your file system.<p/></ul><li/><span class='s'>Help Menu</span><ul><li/><span>Wordsquare Help</span><br/>Displays the Help screen which you are now reading.</ul></ul></body>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void def() {
/*  91 */     Op.updateOption(Op.SW.SwPuz.ordinal(), "sample.wordsquare", Op.sw);
/*  92 */     Op.updateOption(Op.SW.SwDic.ordinal(), "english", Op.sw);
/*  93 */     Op.updateOption(Op.SW.SwW.ordinal(), "500", Op.sw);
/*  94 */     Op.updateOption(Op.SW.SwH.ordinal(), "580", Op.sw);
/*  95 */     Op.updateOption(Op.SW.SwPuzC.ordinal(), "false", Op.sw);
/*  96 */     Op.updateOption(Op.SW.SwSolC.ordinal(), "false", Op.sw);
/*  97 */     Op.updateOption(Op.SW.SwSize.ordinal(), "5", Op.sw);
/*  98 */     Op.updateOption(Op.SW.SwCellC.ordinal(), "FFFFFF", Op.sw);
/*  99 */     Op.updateOption(Op.SW.SwGridC.ordinal(), "000000", Op.sw);
/* 100 */     Op.updateOption(Op.SW.SwLettersC.ordinal(), "000000", Op.sw);
/* 101 */     Op.updateOption(Op.SW.SwIDC.ordinal(), "000000", Op.sw);
/* 102 */     Op.updateOption(Op.SW.SwFont.ordinal(), "Serif", Op.sw);
/* 103 */     Op.updateOption(Op.SW.SwIDFont.ordinal(), "SansSerif", Op.sw);
/* 104 */     Op.updateOption(Op.SW.SwClueFont.ordinal(), "SansSerif", Op.sw);
/* 105 */     Op.updateOption(Op.SW.SwClueC.ordinal(), "000000", Op.sw);
/*     */   }
/*     */   
/*     */   WordsquareBuild(JFrame jfCWE) {
/* 109 */     Def.puzzleMode = 210;
/* 110 */     Def.dispGuideDigits = Boolean.valueOf(true);
/* 111 */     Def.building = 0;
/* 112 */     Def.dispWithColor = Boolean.valueOf(true);
/* 113 */     makeGrid();
/*     */     
/* 115 */     jfWordsquare = new JFrame("Wordsquare Construction");
/* 116 */     if (Op.getInt(Op.SW.SwH.ordinal(), Op.sw) > Methods.scrH - 200) {
/* 117 */       int diff = Op.getInt(Op.SW.SwH.ordinal(), Op.sw) - Op.getInt(Op.SW.SwW.ordinal(), Op.sw);
/* 118 */       Op.setInt(Op.SW.SwH.ordinal(), Methods.scrH - 200, Op.sw);
/* 119 */       Op.setInt(Op.SW.SwW.ordinal(), Methods.scrH - 200 + diff, Op.sw);
/*     */     } 
/* 121 */     jfWordsquare.setSize(Op.getInt(Op.SW.SwW.ordinal(), Op.sw), Op.getInt(Op.SW.SwH.ordinal(), Op.sw));
/* 122 */     int frameX = (jfCWE.getX() + jfWordsquare.getWidth() > Methods.scrW) ? (Methods.scrW - jfWordsquare.getWidth() - 10) : jfCWE.getX();
/* 123 */     jfWordsquare.setLocation(frameX, jfCWE.getY());
/* 124 */     jfWordsquare.setLayout((LayoutManager)null);
/* 125 */     jfWordsquare.getContentPane().setBackground(Def.COLOR_FRAMEBG);
/* 126 */     jfWordsquare.setDefaultCloseOperation(0);
/* 127 */     jfWordsquare
/* 128 */       .addComponentListener(new ComponentAdapter() {
/*     */           public void componentResized(ComponentEvent ce) {
/* 130 */             int oldw = Op.getInt(Op.SW.SwW.ordinal(), Op.sw);
/* 131 */             int oldh = Op.getInt(Op.SW.SwH.ordinal(), Op.sw);
/* 132 */             Methods.frameResize(WordsquareBuild.jfWordsquare, oldw, oldh, 500, 580);
/* 133 */             Op.setInt(Op.SW.SwW.ordinal(), WordsquareBuild.jfWordsquare.getWidth(), Op.sw);
/* 134 */             Op.setInt(Op.SW.SwH.ordinal(), WordsquareBuild.jfWordsquare.getHeight(), Op.sw);
/* 135 */             WordsquareBuild.restoreFrame();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 140 */     jfWordsquare
/* 141 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 143 */             if (Def.building == 1 || Def.selecting)
/*     */               return; 
/* 145 */             Op.saveOptions("wordsquare.opt", Op.sw);
/* 146 */             CrosswordExpress.transfer(1, WordsquareBuild.jfWordsquare);
/*     */           }
/*     */         });
/*     */     
/* 150 */     Methods.closeHelp();
/*     */ 
/*     */     
/* 153 */     Runnable buildThread = () -> {
/*     */         Methods.havePuzzle = false;
/*     */         
/*     */         if (buildWordsquare()) {
/*     */           Methods.havePuzzle = true;
/*     */           
/*     */           saveWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */         } 
/*     */         
/*     */         this.buildMenuItem.setText("Start Building");
/*     */         
/*     */         if (Def.building == 2) {
/*     */           Def.building = 0;
/*     */           Methods.interrupted(jfWordsquare);
/*     */           makeGrid();
/*     */           restoreFrame();
/*     */           return;
/*     */         } 
/*     */         Def.building = 0;
/*     */         if (Methods.havePuzzle) {
/*     */           saveWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */           Methods.puzzleSaved(jfWordsquare, Op.sw[Op.SW.SwDic.ordinal()] + ".dic", Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */         } else {
/*     */           makeGrid();
/*     */           Methods.cantBuild(jfWordsquare);
/*     */         } 
/*     */       };
/* 180 */     jl1 = new JLabel();
/* 181 */     jfWordsquare.add(jl1);
/* 182 */     jl2 = new JLabel();
/* 183 */     jfWordsquare.add(jl2);
/*     */     
/* 185 */     menuBar = new JMenuBar();
/* 186 */     menuBar.setBackground(Def.COLOR_MENUBAR);
/* 187 */     jfWordsquare.setJMenuBar(menuBar);
/* 188 */     this.menu = new JMenu("File");
/*     */     
/* 190 */     menuBar.add(this.menu);
/* 191 */     this.menuItem = new JMenuItem("Select a Dictionary");
/* 192 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 193 */     this.menu.add(this.menuItem);
/* 194 */     this.menuItem
/* 195 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           Methods.selectDictionary(jfWordsquare, Op.sw[Op.SW.SwDic.ordinal()], 1);
/*     */           Op.sw[Op.SW.SwDic.ordinal()] = Methods.dictionaryName;
/*     */           Grid.clearGrid();
/*     */           loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */           restoreFrame();
/*     */         });
/* 206 */     this.menuItem = new JMenuItem("Load a Puzzle");
/* 207 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(76, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 208 */     this.menu.add(this.menuItem);
/* 209 */     this.menuItem
/* 210 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           pp.invalidate();
/*     */           restoreFrame();
/*     */           new Select(jfWordsquare, Op.sw[Op.SW.SwDic.ordinal()] + ".dic", "wordsquare", Op.sw, Op.SW.SwPuz.ordinal(), false);
/*     */         });
/* 219 */     this.menuItem = new JMenuItem("SaveAs");
/* 220 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 221 */     this.menu.add(this.menuItem);
/* 222 */     this.menuItem
/* 223 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           Methods.puzzleDescriptionDialog(jfWordsquare, Op.sw[Op.SW.SwPuz.ordinal()].substring(0, Op.sw[Op.SW.SwPuz.ordinal()].indexOf(".wordsquare")), Op.sw[Op.SW.SwDic.ordinal()] + ".dic", ".wordsquare");
/*     */           if (Methods.clickedOK) {
/*     */             saveWordsquare(Op.sw[Op.SW.SwPuz.ordinal()] = Methods.theFileName);
/*     */             restoreFrame();
/*     */             Methods.puzzleSaved(jfWordsquare, Op.sw[Op.SW.SwDic.ordinal()] + ".dic", Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */           } 
/*     */         });
/* 235 */     this.menuItem = new JMenuItem("Quit Construction");
/* 236 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(81, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 237 */     this.menu.add(this.menuItem);
/* 238 */     this.menuItem
/* 239 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           Op.saveOptions("wordsquare.opt", Op.sw);
/*     */           
/*     */           CrosswordExpress.transfer(1, jfWordsquare);
/*     */         });
/* 248 */     this.menu = new JMenu("Build");
/* 249 */     menuBar.add(this.menu);
/* 250 */     this.menuItem = new JMenuItem("Start a New Puzzle");
/* 251 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 252 */     this.menu.add(this.menuItem);
/* 253 */     this.menuItem
/* 254 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           Methods.puzzleDescriptionDialog(jfWordsquare, Op.sw[Op.SW.SwPuz.ordinal()].substring(0, Op.sw[Op.SW.SwPuz.ordinal()].indexOf(".wordsquare")), Op.sw[Op.SW.SwDic.ordinal()] + ".dic", ".wordsquare");
/*     */           if (Methods.clickedOK) {
/*     */             Op.sw[Op.SW.SwPuz.ordinal()] = Methods.theFileName;
/*     */             makeGrid();
/*     */           } 
/*     */           restoreFrame();
/*     */         });
/* 266 */     this.menuItem = new JMenuItem("Select a Dictionary");
/* 267 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(68, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 268 */     this.menu.add(this.menuItem);
/* 269 */     this.menuItem
/* 270 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           Methods.selectDictionary(jfWordsquare, Op.sw[Op.SW.SwDic.ordinal()], 1);
/*     */           Op.sw[Op.SW.SwDic.ordinal()] = Methods.dictionaryName;
/*     */           restoreFrame();
/*     */         });
/* 279 */     this.menuItem = new JMenuItem("Build Options");
/* 280 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 281 */     this.menu.add(this.menuItem);
/* 282 */     this.menuItem
/* 283 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           wordsquareOptions();
/*     */           makeGrid();
/*     */           NodeList.buildNodeList();
/*     */           restoreFrame();
/*     */         });
/* 293 */     this.buildMenuItem = new JMenuItem("Start Building");
/* 294 */     this.buildMenuItem.setAccelerator(KeyStroke.getKeyStroke(66, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 295 */     this.menu.add(this.buildMenuItem);
/* 296 */     this.buildMenuItem
/* 297 */       .addActionListener(ae -> {
/*     */           if (Op.sw[Op.SW.SwPuz.ordinal()].length() == 0) {
/*     */             Methods.noName(jfWordsquare);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           if (Def.building == 0) {
/*     */             this.thread = new Thread(paramRunnable);
/*     */             
/*     */             this.thread.start();
/*     */             Def.building = 1;
/*     */             this.buildMenuItem.setText("Stop Building");
/*     */           } else {
/*     */             Def.building = 2;
/*     */           } 
/*     */         });
/* 314 */     this.menu = new JMenu("View");
/* 315 */     menuBar.add(this.menu);
/* 316 */     this.menuItem = new JMenuItem("Display Options");
/* 317 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(89, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 318 */     this.menu.add(this.menuItem);
/* 319 */     this.menuItem
/* 320 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           printOptions(jfWordsquare, "Display Options");
/*     */           
/*     */           restoreFrame();
/*     */         });
/* 329 */     this.menu = new JMenu("Tasks");
/* 330 */     menuBar.add(this.menu);
/* 331 */     this.menuItem = new JMenuItem("Print Wordsquare");
/* 332 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(80, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 333 */     this.menu.add(this.menuItem);
/* 334 */     this.menuItem
/* 335 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           Def.puzzleMode = 210;
/*     */           CrosswordExpress.toPrint(jfWordsquare, Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */         });
/* 342 */     this.menuItem = new JMenuItem("Solve Wordsquare puzzle");
/* 343 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 344 */     this.menu.add(this.menuItem);
/* 345 */     this.menuItem
/* 346 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           if (Methods.havePuzzle) {
/*     */             CrosswordExpress.transfer(5, jfWordsquare);
/*     */           } else {
/*     */             Methods.noPuzzle(jfWordsquare, "Solve");
/*     */           } 
/*     */         });
/* 356 */     this.menuItem = new JMenuItem("Delete this Puzzle");
/* 357 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 358 */     this.menu.add(this.menuItem);
/* 359 */     this.menuItem
/* 360 */       .addActionListener(ae -> {
/*     */           if (Def.building == 1) {
/*     */             return;
/*     */           }
/*     */           
/*     */           if (Methods.deleteAPuzzle(jfWordsquare, Op.sw[Op.SW.SwPuz.ordinal()], Op.sw[Op.SW.SwDic.ordinal()] + ".dic", pp)) {
/*     */             loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */             
/*     */             restoreFrame();
/*     */           } 
/*     */         });
/* 371 */     this.menu = new JMenu("Help");
/* 372 */     menuBar.add(this.menu);
/* 373 */     this.menuItem = new JMenuItem("Wordsquare Help");
/* 374 */     this.menu.add(this.menuItem);
/* 375 */     this.menuItem.setAccelerator(KeyStroke.getKeyStroke(72, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
/* 376 */     this.menuItem
/* 377 */       .addActionListener(ae -> Methods.cweHelp(jfWordsquare, null, "Building Wordsquare Puzzles", this.wordsquareHelp));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 383 */     loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/* 384 */     pp = new WordsquarePP(0, 37);
/* 385 */     jfWordsquare.add(pp);
/*     */     
/* 387 */     if (Def.isMac) {
/* 388 */       pp
/* 389 */         .addMouseMotionListener(new MouseAdapter() {
/*     */             public void mouseMoved(MouseEvent e) {
/* 391 */               if (Def.isMac) {
/* 392 */                 WordsquareBuild.jfWordsquare.setResizable((WordsquareBuild.jfWordsquare.getWidth() - e.getX() < 345 && WordsquareBuild.jfWordsquare
/* 393 */                     .getHeight() - e.getY() < 95));
/*     */               }
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 401 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.SW.SwDic.ordinal() + ".dic/xword.dic"));
/* 402 */       dataIn.read(DictionaryMtce.dicHeader, 0, 128);
/* 403 */       dataIn.close();
/* 404 */     } catch (IOException exc) {}
/*     */     
/* 406 */     restoreFrame();
/*     */   }
/*     */   
/*     */   static void restoreFrame() {
/* 410 */     jfWordsquare.setVisible(true);
/* 411 */     Insets insets = jfWordsquare.getInsets();
/* 412 */     panelW = jfWordsquare.getWidth() - insets.left + insets.right;
/* 413 */     panelH = jfWordsquare.getHeight() - insets.top + insets.bottom + 37 + menuBar.getHeight();
/* 414 */     pp.setSize(panelW, panelH);
/* 415 */     jfWordsquare.requestFocusInWindow();
/* 416 */     pp.repaint();
/* 417 */     Methods.infoPanel(jl1, jl2, "Build Wordsquare", "Dictionary : " + Op.sw[Op.SW.SwDic.ordinal()] + "  -|-  Puzzle : " + Op.sw[Op.SW.SwPuz
/* 418 */           .ordinal()], jfWordsquare.getWidth());
/*     */   }
/*     */   
/*     */   static void setSizesAndOffsets(int x, int y, int width, int height, int inset, boolean print) {
/* 422 */     int i = (width - inset) / Grid.xSz;
/* 423 */     int j = (height - inset) / Grid.ySz;
/* 424 */     Grid.xCell = Grid.yCell = (i < j) ? i : j;
/* 425 */     Grid.xOrg = x + (print ? ((width - Grid.xSz * Grid.xCell) / 2) : 10);
/* 426 */     Grid.yOrg = y + (print ? ((height - Grid.ySz * Grid.yCell) / 2) : 10);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void wordsquareOptions() {
/* 432 */     JDialog jdlgWordsquare = new JDialog(jfWordsquare, "Build Options", true);
/* 433 */     jdlgWordsquare.setSize(270, 485);
/* 434 */     jdlgWordsquare.setResizable(false);
/* 435 */     jdlgWordsquare.setLayout((LayoutManager)null);
/* 436 */     jdlgWordsquare.setLocation(jfWordsquare.getX(), jfWordsquare.getY());
/*     */     
/* 438 */     jdlgWordsquare
/* 439 */       .addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent we) {
/* 441 */             Methods.closeHelp();
/*     */           }
/*     */         });
/*     */     
/* 445 */     Methods.closeHelp();
/*     */     
/* 447 */     JLabel jlSize = new JLabel("Wordsquare Size:");
/* 448 */     jlSize.setForeground(Def.COLOR_LABEL);
/* 449 */     jlSize.setSize(120, 20);
/* 450 */     jlSize.setLocation(10, 8);
/* 451 */     jlSize.setHorizontalAlignment(4);
/* 452 */     jdlgWordsquare.add(jlSize);
/*     */     
/* 454 */     JComboBox<Integer> jcbbSize = new JComboBox<>();
/* 455 */     for (int i = 4; i <= 10; i++)
/* 456 */       jcbbSize.addItem(Integer.valueOf(i)); 
/* 457 */     jcbbSize.setSize(80, 23);
/* 458 */     jcbbSize.setLocation(150, 8);
/* 459 */     jdlgWordsquare.add(jcbbSize);
/* 460 */     jcbbSize.setBackground(Def.COLOR_BUTTONBG);
/* 461 */     jcbbSize.setSelectedIndex(Op.getInt(Op.SW.SwSize.ordinal(), Op.sw) - 4);
/*     */     
/* 463 */     JButton jbOK = Methods.cweButton("OK", 10, 40, 80, 26, null);
/* 464 */     jbOK.addActionListener(e -> {
/*     */           Op.setInt(Op.SW.SwSize.ordinal(), paramJComboBox.getSelectedIndex() + 4, Op.sw);
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 469 */     jdlgWordsquare.add(jbOK);
/*     */     
/* 471 */     JButton jbCancel = Methods.cweButton("Cancel", 10, 75, 80, 26, null);
/* 472 */     jbCancel.addActionListener(e -> {
/*     */           paramJDialog.dispose();
/*     */           Methods.closeHelp();
/*     */         });
/* 476 */     jdlgWordsquare.add(jbCancel);
/*     */     
/* 478 */     JButton jbHelp = Methods.cweButton("<html><font size=6 color=BB0000 face=Serif>Help ", 100, 40, 150, 61, new ImageIcon("graphics/help.png"));
/* 479 */     jbHelp.addActionListener(e -> Methods.cweHelp(null, paramJDialog, "Wordsquare Options", this.wordsquareOptionsHelp));
/*     */     
/* 481 */     jdlgWordsquare.add(jbHelp);
/*     */     
/* 483 */     jdlgWordsquare.getRootPane().setDefaultButton(jbOK);
/* 484 */     Methods.setDialogSize(jdlgWordsquare, 260, 111);
/*     */   }
/*     */   
/*     */   static void printOptions(JFrame jf, String type) {
/* 488 */     String[] colorLabel = { "Cell Color", "Grid Line Color", "Letter Color", "ID Number Color", "Clue Color" };
/* 489 */     int[] colorInt = { Op.SW.SwCellC.ordinal(), Op.SW.SwGridC.ordinal(), Op.SW.SwLettersC.ordinal(), Op.SW.SwIDC.ordinal(), Op.SW.SwClueC.ordinal() };
/* 490 */     String[] fontLabel = { "Select Puzzle Font", "Select ID Font", "Select Clue Font" };
/* 491 */     int[] fontInt = { Op.SW.SwFont.ordinal(), Op.SW.SwIDFont.ordinal(), Op.SW.SwClueFont.ordinal() };
/* 492 */     String[] checkLabel = { "PPrint Puzzle with color.", "SPrint Solution with color." };
/* 493 */     int[] checkInt = { Op.SW.SwPuzC.ordinal(), Op.SW.SwSolC.ordinal() };
/* 494 */     Methods.stdPrintOptions(jf, "Wordsquare " + type, Op.sw, colorLabel, colorInt, fontLabel, fontInt, checkLabel, checkInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveWordsquare(String wordsquareName) {
/*     */     try {
/* 505 */       DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/" + wordsquareName));
/* 506 */       dataOut.writeInt(Grid.xSz);
/* 507 */       dataOut.writeInt(Grid.ySz);
/* 508 */       dataOut.writeByte(Methods.noReveal);
/* 509 */       dataOut.writeByte(Methods.noErrors); int i;
/* 510 */       for (i = 0; i < 54; i++)
/* 511 */         dataOut.writeByte(0); 
/* 512 */       for (int j = 0; j < Grid.ySz; j++) {
/* 513 */         for (i = 0; i < Grid.xSz; i++) {
/* 514 */           dataOut.writeInt(Grid.mode[i][j]);
/* 515 */           dataOut.writeInt(Grid.letter[i][j]);
/* 516 */           dataOut.writeInt(Grid.sol[i][j]);
/* 517 */           dataOut.writeInt(Grid.color[i][j]);
/*     */         } 
/* 519 */       }  dataOut.writeUTF(Methods.puzzleTitle);
/* 520 */       dataOut.writeUTF(Methods.author);
/* 521 */       dataOut.writeUTF(Methods.copyright);
/* 522 */       dataOut.writeUTF(Methods.puzzleNumber);
/* 523 */       dataOut.writeUTF(Methods.puzzleNotes);
/* 524 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 525 */         dataOut.writeUTF((NodeList.nodeList[i]).word);
/* 526 */         dataOut.writeUTF((NodeList.nodeList[i]).clue);
/*     */       } 
/* 528 */       dataOut.close();
/*     */     }
/* 530 */     catch (IOException exc) {}
/* 531 */     Methods.havePuzzle = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadWordsquare(String wordsquareName) {
/* 538 */     Op.sw[Op.SW.SwDic.ordinal()] = Methods.confirmDictionary(Op.sw[Op.SW.SwDic.ordinal()] + ".dic", false);
/*     */     
/* 540 */     File fl = new File(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/" + wordsquareName);
/* 541 */     if (!fl.exists()) {
/* 542 */       fl = new File(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/");
/* 543 */       String[] s = fl.list(); int i;
/* 544 */       for (i = 0; i < s.length && (
/* 545 */         s[i].lastIndexOf(".wordsquare") == -1 || s[i].charAt(0) == '.'); i++);
/*     */ 
/*     */       
/* 548 */       if (i == s.length) {
/* 549 */         makeGrid();
/*     */         return;
/*     */       } 
/* 552 */       wordsquareName = s[i];
/* 553 */       Op.sw[Op.SW.SwPuz.ordinal()] = wordsquareName;
/*     */     } 
/*     */     try {
/* 556 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/" + wordsquareName));
/* 557 */       Grid.xSz = dataIn.readInt();
/* 558 */       Grid.ySz = dataIn.readInt();
/* 559 */       Methods.noReveal = dataIn.readByte();
/* 560 */       Methods.noErrors = dataIn.readByte(); int i;
/* 561 */       for (i = 0; i < 54; i++)
/* 562 */         dataIn.readByte(); 
/* 563 */       for (int j = 0; j < Grid.ySz; j++) {
/* 564 */         for (i = 0; i < Grid.xSz; i++) {
/* 565 */           Grid.mode[i][j] = dataIn.readInt();
/* 566 */           Grid.letter[i][j] = dataIn.readInt();
/* 567 */           Grid.sol[i][j] = dataIn.readInt();
/* 568 */           Grid.color[i][j] = dataIn.readInt();
/*     */         } 
/*     */       } 
/* 571 */       Methods.puzzleTitle = dataIn.readUTF();
/* 572 */       Methods.author = dataIn.readUTF();
/* 573 */       Methods.copyright = dataIn.readUTF();
/* 574 */       Methods.puzzleNumber = dataIn.readUTF();
/* 575 */       Methods.puzzleNotes = dataIn.readUTF();
/* 576 */       NodeList.buildNodeList();
/* 577 */       for (i = 0; i < NodeList.nodeListLength; i++) {
/* 578 */         (NodeList.nodeList[i]).word = dataIn.readUTF();
/* 579 */         (NodeList.nodeList[i]).clue = dataIn.readUTF();
/* 580 */         if ((NodeList.nodeList[i]).clue.length() < 2)
/* 581 */           (NodeList.nodeList[i]).clue = "No clue"; 
/*     */       } 
/* 583 */       dataIn.close();
/*     */     }
/* 585 */     catch (IOException exc) {}
/*     */     
/* 587 */     Methods.havePuzzle = true;
/* 588 */     Grid.xCur = (NodeList.nodeList[0]).x;
/* 589 */     Grid.yCur = (NodeList.nodeList[0]).y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawWordsquare(Graphics2D g2, String pars) {
/* 597 */     int nL = (int)Math.ceil((Grid.xCell / 60.0F)), wL = (int)Math.ceil((Grid.xCell / 10.0F));
/* 598 */     Stroke normalStroke = new BasicStroke(nL, 2, 0);
/* 599 */     Stroke wideStroke = new BasicStroke(wL, 0, 0);
/* 600 */     g2.setStroke(normalStroke);
/* 601 */     RenderingHints rh = g2.getRenderingHints();
/* 602 */     rh.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 603 */     rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 604 */     g2.setRenderingHints(rh);
/*     */     
/*     */     int j;
/* 607 */     for (j = 0; j < Grid.ySz; j++) {
/* 608 */       for (int i = 0; i < Grid.xSz; i++) {
/* 609 */         if (Grid.mode[i][j] != 2) {
/* 610 */           int k; if (Def.dispWithColor.booleanValue()) {
/* 611 */             if (Grid.curColor[i][j] != 16777215) {
/* 612 */               k = Grid.curColor[i][j];
/* 613 */             } else if (Grid.color[i][j] != 16777215) {
/* 614 */               k = Grid.color[i][j];
/*     */             } else {
/* 616 */               k = Op.getColorInt(Op.SW.SwCellC.ordinal(), Op.sw);
/*     */             } 
/*     */           } else {
/* 619 */             k = 16777215;
/* 620 */           }  if (Grid.mode[i][j] == 2)
/* 621 */             k = 16777215; 
/* 622 */           g2.setColor(new Color(k));
/* 623 */           g2.fillRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 629 */     g2.setStroke(normalStroke);
/* 630 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SW.SwGridC.ordinal(), Op.sw)) : Def.COLOR_BLACK);
/* 631 */     for (j = 0; j < Grid.ySz; j++) {
/* 632 */       for (int i = 0; i < Grid.xSz; i++) {
/* 633 */         if (Grid.mode[i][j] != 2)
/* 634 */           g2.drawRect(Grid.xOrg + i * Grid.xCell, Grid.yOrg + j * Grid.yCell, Grid.xCell, Grid.yCell); 
/*     */       } 
/* 636 */     }  g2.setFont(new Font(Op.sw[Op.SW.SwFont.ordinal()], 0, 8 * Grid.yCell / 10));
/* 637 */     g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SW.SwLettersC.ordinal(), Op.sw)) : Def.COLOR_BLACK);
/* 638 */     FontMetrics fm = g2.getFontMetrics();
/* 639 */     for (j = 0; j < Grid.ySz; j++) {
/* 640 */       for (int i = 0; i < Grid.xSz; i++) {
/* 641 */         char ch = (char)Grid.letter[i][j];
/* 642 */         if (ch != '\000') {
/* 643 */           int w = fm.stringWidth("" + ch);
/* 644 */           g2.drawString("" + ch, Grid.xOrg + i * Grid.xCell + (Grid.xCell - w) / 2, Grid.yOrg + j * Grid.yCell + 9 * Grid.yCell / 10);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 649 */     g2.setStroke(wideStroke);
/* 650 */     Grid.drawOutline(g2, true);
/*     */ 
/*     */     
/* 653 */     if (Def.dispGuideDigits.booleanValue()) {
/* 654 */       g2.setFont(new Font(Op.sw[Op.SW.SwIDFont.ordinal()], 0, Grid.yCell / 3));
/* 655 */       g2.setColor(Def.dispWithColor.booleanValue() ? new Color(Op.getColorInt(Op.SW.SwIDC.ordinal(), Op.sw)) : Def.COLOR_BLACK);
/* 656 */       fm = g2.getFontMetrics();
/* 657 */       for (int i = 0; NodeList.nodeList[i] != null; i++) {
/* 658 */         int drawI = (NodeList.nodeList[i]).x;
/* 659 */         int xCoord = Grid.xOrg + drawI * Grid.xCell + ((Grid.xCell / 20 > 1) ? (Grid.xCell / 20) : 1);
/* 660 */         g2.drawString("" + (NodeList.nodeList[i]).id, xCoord, Grid.yOrg + (NodeList.nodeList[i]).y * Grid.yCell + fm.getAscent());
/*     */       } 
/*     */     } 
/* 663 */     g2.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */   
/*     */   static void printPuz(Graphics2D g2, int left, int top, int width, int height) {
/* 667 */     loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/* 668 */     setSizesAndOffsets(left, top, width, height, 0, true);
/* 669 */     Methods.clearGrid(Grid.sol);
/* 670 */     Def.dispGuideDigits = Boolean.valueOf(true);
/* 671 */     Def.dispWithColor = Op.getBool(Op.SW.SwPuzC.ordinal(), Op.sw);
/* 672 */     drawWordsquare(g2, "");
/* 673 */     Def.dispWithColor = Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   static void printSol(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 677 */     loadWordsquare(solutionPuzzle);
/* 678 */     setSizesAndOffsets(left, top, width, height, 0, true);
/* 679 */     Def.dispGuideDigits = Boolean.valueOf(false);
/* 680 */     Def.dispWithColor = Op.getBool(Op.SW.SwSolC.ordinal(), Op.sw);
/* 681 */     drawWordsquare(g2, "");
/* 682 */     Def.dispWithColor = Boolean.valueOf(true);
/* 683 */     Def.dispGuideDigits = Boolean.valueOf(true);
/* 684 */     loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */   }
/*     */   
/*     */   static void printSolTitle(Graphics2D g2, int left, int top, int width, int height, String solutionPuzzle) {
/* 688 */     loadWordsquare(solutionPuzzle);
/* 689 */     Print.outputTextItem(g2, left, top, width, height, "SansSerif", 0, Methods.puzzleTitle);
/* 690 */     loadWordsquare(Op.sw[Op.SW.SwPuz.ordinal()]);
/*     */   }
/*     */   
/*     */   static void makeGrid() {
/* 694 */     Methods.havePuzzle = false;
/* 695 */     Grid.clearGrid();
/* 696 */     Grid.xSz = Grid.ySz = Op.getInt(Op.SW.SwSize.ordinal(), Op.sw);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void orderNodeList() {
/*     */     int i;
/* 703 */     for (i = 0; i < NodeList.nodeListLength - 1; i++) {
/* 704 */       for (int j = i + 1; j < NodeList.nodeListLength; j++) {
/* 705 */         if ((NodeList.nodeList[i]).direction > (NodeList.nodeList[j]).direction || ((NodeList.nodeList[i]).direction == (NodeList.nodeList[j]).direction && (NodeList.nodeList[i]).x > (NodeList.nodeList[j]).x))
/*     */         
/* 707 */         { Node swapNode = NodeList.nodeList[i];
/* 708 */           NodeList.nodeList[i] = NodeList.nodeList[j];
/* 709 */           NodeList.nodeList[j] = swapNode; } 
/*     */       } 
/* 711 */     }  for (i = 0; i < NodeList.nodeListLength; i++)
/* 712 */       (NodeList.nodeList[i]).wordIndex = -1; 
/*     */   }
/*     */   
/*     */   static void loadDictionary() {
/* 716 */     int[] puzWords = new int[50];
/*     */     
/*     */     int i;
/*     */     
/* 720 */     for (i = 0; i < 50; wordCount[0][i++] = 0);
/*     */     
/*     */     try {
/* 723 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/xword.dic"));
/* 724 */       dataIn.read(DictionaryMtce.dicHeader, 0, 128);
/* 725 */       while (dataIn.available() > 2) {
/* 726 */         dataIn.readInt();
/* 727 */         String word = dataIn.readUTF();
/* 728 */         if (word.length() > 1)
/* 729 */           wordCount[0][word.length()] = wordCount[0][word.length()] + 1; 
/* 730 */         dataIn.readUTF();
/*     */       } 
/* 732 */       dataIn.close();
/* 733 */     } catch (IOException exc) {}
/*     */     
/*     */     int len;
/* 736 */     for (len = 2; len < 50; len++) {
/* 737 */       if (wordCount[0][len] > 0) {
/* 738 */         chWord[0][0][len] = new char[wordCount[0][len]][len];
/* 739 */         chWord[1][0][len] = new char[wordCount[0][len]][len];
/* 740 */         busy[0][len] = new boolean[wordCount[0][len]];
/*     */       } 
/*     */     } 
/*     */     
/* 744 */     for (i = 0; i < 50; wordCount[0][i++] = 0);
/*     */     try {
/* 746 */       DataInputStream dataIn = new DataInputStream(new FileInputStream(Op.sw[Op.SW.SwDic.ordinal()] + ".dic/xword.dic"));
/* 747 */       for (i = 0; i < 128; i++)
/* 748 */         dataIn.readByte(); 
/* 749 */       while (dataIn.available() > 2) {
/* 750 */         dataIn.readInt();
/* 751 */         String word = dataIn.readUTF();
/* 752 */         len = word.length();
/* 753 */         if (len > 1) {
/* 754 */           wordCount[0][len] = wordCount[0][len] + 1; chWord[0][0][len][wordCount[0][len]] = word.toCharArray();
/* 755 */         }  dataIn.readUTF();
/*     */       } 
/* 757 */       dataIn.close();
/* 758 */     } catch (IOException exc) {}
/*     */   }
/*     */   
/*     */   int firstBinarySearch(char[] template, int wlen, int tlen, int m) {
/* 762 */     int first = 0, last = wordCount[0][wlen] - 1;
/*     */     
/*     */     while (true) {
/* 765 */       int current = (first + last) / 2; int i;
/* 766 */       for (i = 0; i < tlen; i++) {
/* 767 */         if (template[i] > chWord[m][0][wlen][current][i]) {
/* 768 */           first = current;
/*     */           break;
/*     */         } 
/* 771 */         if (template[i] < chWord[m][0][wlen][current][i]) {
/* 772 */           last = current;
/*     */           break;
/*     */         } 
/*     */       } 
/* 776 */       if (i == tlen)
/* 777 */         last = current; 
/* 778 */       if (last - first <= 1)
/* 779 */         return first; 
/*     */     } 
/*     */   }
/*     */   
/*     */   int lastBinarySearch(char[] template, int wlen, int tlen, int m) {
/* 784 */     int first = 0, last = wordCount[0][wlen] - 1;
/*     */     while (true) {
/* 786 */       int current = (first + last) / 2; int i;
/* 787 */       for (i = 0; i < tlen; i++) {
/* 788 */         if (template[i] < chWord[m][0][wlen][current][i]) {
/* 789 */           last = current;
/*     */           break;
/*     */         } 
/* 792 */         if (template[i] > chWord[m][0][wlen][current][i]) {
/* 793 */           first = current;
/*     */           break;
/*     */         } 
/*     */       } 
/* 797 */       if (i == tlen)
/* 798 */         first = current; 
/* 799 */       if (last - first <= 1)
/* 800 */         return last; 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean findMatchingWord(int nodeIndex) {
/* 805 */     Random r = new Random();
/*     */     
/* 807 */     int j = 0;
/* 808 */     Node thisNode = NodeList.nodeList[nodeIndex];
/* 809 */     int mode = thisNode.mode;
/* 810 */     int length = thisNode.length;
/* 811 */     if (wordCount[0][length] == 0) {
/* 812 */       return false;
/*     */     }
/* 814 */     char[] temp = thisNode.template.toCharArray();
/* 815 */     if (thisNode.wordIndex != -1) {
/*     */       do {
/* 817 */         if (++thisNode.wordIndex > thisNode.last)
/* 818 */           thisNode.wordIndex = thisNode.first; 
/* 819 */         if (thisNode.wordIndex == thisNode.start) {
/* 820 */           thisNode.wordIndex = -1;
/* 821 */           return false;
/*     */         } 
/* 823 */       } while (busy[0][length][thisNode.wordIndex]);
/*     */     } else {
/* 825 */       if (temp[0] == ' ') {
/* 826 */         thisNode.first = 0;
/* 827 */         thisNode.last = wordCount[0][length] - 1;
/*     */       } else {
/*     */         int tlen;
/* 830 */         for (tlen = 0; tlen < length && 
/* 831 */           temp[tlen] != ' '; tlen++);
/*     */         
/* 833 */         thisNode.first = firstBinarySearch(temp, length, tlen, mode);
/* 834 */         thisNode.last = lastBinarySearch(temp, length, tlen, mode);
/* 835 */         if (thisNode.last - thisNode.first < 0)
/* 836 */           return false; 
/*     */       } 
/* 838 */       thisNode.wordIndex = thisNode.start = thisNode.first + r.nextInt(thisNode.last - thisNode.first + 1);
/*     */     } 
/*     */     
/*     */     label50: while (true) {
/* 842 */       if (!busy[0][length][thisNode.wordIndex]) {
/* 843 */         for (j = 0; j < length && (
/* 844 */           temp[j] == ' ' || temp[j] == chWord[mode][0][length][thisNode.wordIndex][j]); j++);
/*     */       }
/*     */       
/* 847 */       if (j == length) {
/* 848 */         if (mode == 0)
/* 849 */           thisNode.word = new String(chWord[0][0][length][thisNode.wordIndex], 0, length); 
/* 850 */         return true;
/*     */       } 
/*     */       while (true) {
/* 853 */         if (++thisNode.wordIndex > thisNode.last)
/* 854 */           thisNode.wordIndex = thisNode.first; 
/* 855 */         if (thisNode.wordIndex == thisNode.start) {
/* 856 */           thisNode.wordIndex = -1;
/* 857 */           return false;
/*     */         } 
/* 859 */         if (!busy[0][length][thisNode.wordIndex])
/*     */           continue label50; 
/*     */       } 
/*     */       break;
/*     */     }  } boolean wordOK(int index) {
/* 864 */     for (int i = index + 1; i < (NodeList.nodeList[index]).length; i++) {
/* 865 */       int scanIndex = index + 1;
/* 866 */       NodeList.buildTemplate(scanIndex);
/* 867 */       (NodeList.nodeList[scanIndex]).wordIndex = -1;
/* 868 */       if (!findMatchingWord(scanIndex))
/* 869 */         return false; 
/*     */     } 
/* 871 */     return true;
/*     */   }
/*     */   
/*     */   void insertWord(int index) {
/* 875 */     Node thisNode = NodeList.nodeList[index];
/* 876 */     for (int i = index; i < thisNode.length; i++) {
/* 877 */       Grid.letter[i][index] = thisNode.word.charAt(i); Grid.letter[index][i] = thisNode.word.charAt(i);
/* 878 */     }  busy[0][thisNode.length][thisNode.wordIndex] = true;
/*     */   }
/*     */   
/*     */   void extractWord(int index) {
/* 882 */     Node thisNode = NodeList.nodeList[index];
/* 883 */     for (int i = index; i < thisNode.length; i++) {
/* 884 */       Grid.letter[i][index] = 0; Grid.letter[index][i] = 0;
/* 885 */     }  busy[0][thisNode.length][thisNode.wordIndex] = false;
/*     */   }
/*     */ 
/*     */   
/*     */   int fillWordsquare() {
/*     */     int nodeIndex;
/* 891 */     NodeList.buildTemplate(nodeIndex = 0);
/* 892 */     int j = 0; while (true)
/* 893 */     { while (findMatchingWord(nodeIndex))
/* 894 */       { insertWord(nodeIndex);
/* 895 */         if (wordOK(nodeIndex)) {
/* 896 */           nodeIndex++;
/* 897 */           if (++j % 50000 == 0) {
/* 898 */             restoreFrame();
/* 899 */             if (Def.building == 2) return 0; 
/*     */           } 
/* 901 */           if (nodeIndex < NodeList.nodeListLength / 2) {
/* 902 */             (NodeList.nodeList[nodeIndex]).wordIndex = -1;
/* 903 */             NodeList.buildTemplate(nodeIndex);
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } else {
/* 908 */           extractWord(nodeIndex);
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 916 */         return 1; }  if (nodeIndex == 0) return 0;  nodeIndex = (NodeList.nodeList[nodeIndex]).revert; extractWord(nodeIndex); }  return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean buildWordsquare() {
/* 923 */     makeGrid();
/* 924 */     NodeList.buildNodeList();
/* 925 */     orderNodeList();
/* 926 */     loadDictionary(); int index;
/* 927 */     for (index = 1; index < NodeList.nodeListLength; index++)
/* 928 */       (NodeList.nodeList[index]).revert = index - 1; 
/* 929 */     boolean ret = (fillWordsquare() == 1);
/* 930 */     if (ret) {
/* 931 */       NodeList.attachClues(Op.sw[Op.SW.SwDic.ordinal()], Boolean.valueOf(false));
/* 932 */       for (index = 0; index < NodeList.nodeListLength / 2; index++)
/* 933 */         (NodeList.nodeList[index + NodeList.nodeListLength / 2]).clue = (NodeList.nodeList[index]).clue; 
/* 934 */       NodeList.sortNodeList(2);
/*     */     } 
/* 936 */     restoreFrame();
/* 937 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\WordsquareBuild.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */