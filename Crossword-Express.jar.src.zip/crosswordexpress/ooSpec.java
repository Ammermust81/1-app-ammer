package crosswordexpress;

class ooSpec {
  int x;
  
  int y;
  
  int w;
}


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\ooSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */