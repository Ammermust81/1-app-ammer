package crosswordexpress;

class wingDat {
  int row;
  
  int col;
  
  int box;
  
  int dat;
}


/* Location:              C:\Users\mustapha\Desktop\Crossword-Express.jar!\crosswordexpress\wingDat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */